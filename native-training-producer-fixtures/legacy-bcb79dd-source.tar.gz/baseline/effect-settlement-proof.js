const fs = require("fs");
const path = require("path");
const { manifestDigest } = require("./repository-artifact-store");
const { loadCampaignHistory, deriveOrder } = require("./campaign-supervisor");
const { evaluateAttestationQuorum } = require("./verification-attestation");
const { verifyVerifierExecutionEvidence } = require("./verifier-execution-evidence");

function hash(value) { return require("./dispatch-runtime-controller").inputDigest(value); }
function sameRef(a, b) { return require("./tool-effect-review").sameEffectRef(a, b); }
function requireTrue(value, code) { if (!value) throw new Error(code); }
function ref(entry) { return { artifact_id: entry.artifact_id, relative_path: entry.relative_path, sha256: entry.sha256 }; }
function context(store, repositoryState) {
  return { repository: store.verification.repository, artifactRoot: store.artifactRoot, manifest: store.manifest, repositoryState };
}
function load(store, reference, kind, type, scope) {
  const value = require("./tool-effect-review").loadEffectArtifact(context(store), reference, kind, type, scope);
  return value.payload;
}

function retainedEffectSettlements(store) {
  return store.manifest.artifacts.filter(item =>
    ["tool-effect-settlements", "gateway-effect-settlements"].includes(item.kind)).map(entry => {
    const type = entry.kind === "tool-effect-settlements" ? "tool-effect-settlement" : "gateway-effect-settlement";
    const previous = load(store, ref(entry), entry.kind, type);
    requireTrue(previous.request.mission_id === entry.mission_id && previous.request.wave_id === entry.wave_id,
      "EFFECT_SETTLEMENT_NAMESPACE_MISMATCH");
    return previous;
  });
}
function assertEffectSettlementInputsAvailable(store, request) {
  for (const previous of retainedEffectSettlements(store)) {
    requireTrue(!sameRef(previous.request.decision_ref, request.decision_ref) &&
      !sameRef(previous.request.cycle_order_ref, request.cycle_order_ref), "EFFECT_SETTLEMENT_INPUT_ALREADY_CONSUMED");
  }
}
function assertEffectSettlementConsumptionUnique(store) {
  const consumed = new Set();
  for (const previous of retainedEffectSettlements(store)) {
    for (const reference of [previous.request.decision_ref, previous.request.cycle_order_ref]) {
      requireTrue(!consumed.has(hash(reference)), "EFFECT_SETTLEMENT_INPUT_CONFLICT");
      consumed.add(hash(reference));
    }
  }
}

// Ownership, review replay and one-use consumption remain the caller's separate gates.
// This appraiser never publishes a settlement or grants execution authority.
function appraiseEffectSettlementProof({ store, request, at, scope, review, scopeSha256, expectedDecisionOption,
  additionalDecisionReferences = [] }) {
  const receipt = load(store, review.verification_receipt_ref, "verification-receipts", "verification-receipt", request);
  const campaign = load(store, request.campaign_ref, "self-improvement-campaigns", "self-improvement-campaign");
  requireTrue(["0.3", "0.4"].includes(campaign.schema_version) && campaign.id === receipt.campaign_id &&
    campaign.mission_id === request.mission_id, "TOOL_EFFECT_VERIFICATION_CAMPAIGN_MISMATCH");
  const history = loadCampaignHistory(store, campaign.id);
  requireTrue(sameRef(ref(history.campaignEntry), request.campaign_ref) && history.trustPolicy &&
    ["0.4", "0.5", "0.6", "0.7"].includes(history.trustPolicy.schema_version), "TOOL_EFFECT_EXECUTION_ASSURANCE_REQUIRED");
  const order = load(store, request.cycle_order_ref, "self-improvement-cycle-orders", "self-improvement-cycle-order");
  const dispatchStore = historicalStore(store, order.observed_manifest.revision, order.observed_manifest.sha256);
  const dispatched = deriveOrder(dispatchStore, loadCampaignHistory(dispatchStore, campaign.id), order.generated_at);
  requireTrue(hash(dispatched) === hash(order), "TOOL_EFFECT_DISPATCH_PROOF_MISMATCH");
  const current = deriveOrder(store, history, at);
  requireTrue(current.status === "ready" && current.trust_policy_admission.required && current.trust_policy_admission.satisfied,
    `TOOL_EFFECT_VERIFIER_READINESS_BLOCKED:${current.blocking_codes.join(",")}`);
  requireTrue(order.status === "ready" && sameRef(order.campaign_ref, request.campaign_ref) &&
    order.campaign_id === receipt.campaign_id && order.mission_id === request.mission_id &&
    order.cycle_number === receipt.cycle_number && current.cycle_number === order.cycle_number &&
    current.attempt_number === order.attempt_number && current.transition === order.transition &&
    hash(current.task_order) === hash(order.task_order) && hash(current.proof_requirements) === hash(order.proof_requirements) &&
    sameRef(current.source_checkpoint_ref, order.source_checkpoint_ref) && sameRef(current.source_decision_ref, order.source_decision_ref) &&
    Date.parse(order.generated_at) <= Date.parse(receipt.started_at), "TOOL_EFFECT_CYCLE_ORDER_MISMATCH");
  const admission = current.trust_policy_admission;
  requireTrue(admission.identity_assurance.required && admission.identity_assurance.satisfied, "TOOL_EFFECT_WORKLOAD_IDENTITY_REQUIRED");
  const executionEvidence = new Map();
  const nativeProviderEvidence = new Map();
  const nativeTrustBundles = new Map();
  const attestations = [];
  const deadlines = [scope.expires_at, admission.valid_until,
    new Date(Date.parse(campaign.created_at) + campaign.budgets.max_elapsed_minutes * 60000).toISOString()];
  for (const reference of request.attestation_refs) {
    const attestation = load(store, reference, "verification-attestations", "verification-attestation");
    requireTrue(attestation.receipt_id === receipt.id && admission.receipt_quorum.verifier_ids.includes(attestation.verifier_id),
      "TOOL_EFFECT_ATTESTER_NOT_ADMITTED");
    const execution = load(store, attestation.execution_evidence_ref, "verifier-execution-evidence", "verifier-execution-evidence");
    const identity = admission.identity_assurance.evidence.find(item => item.verifier_id === attestation.verifier_id);
    requireTrue(identity && sameRef(execution.workload_identity_evidence_ref, identity.evidence_ref), "TOOL_EFFECT_WORKLOAD_EVIDENCE_MISMATCH");
    let native = null;
    let nativeTrust = null;
    if (execution.native_provider_evidence_ref) {
      const prefix = { github_actions: "github-actions-oidc", gitlab_ci: "gitlab-ci-oidc" }[execution.provider];
      requireTrue(prefix, "TOOL_EFFECT_NATIVE_PROVIDER_UNSUPPORTED");
      native = load(store, execution.native_provider_evidence_ref, `${prefix}-evidence`, `${prefix}-evidence`);
      nativeTrust = load(store, native.trust_bundle_ref, `${prefix}-trust-bundles`, `${prefix}-trust-bundle`);
      nativeProviderEvidence.set(native.id, native);
      nativeTrustBundles.set(nativeTrust.id, nativeTrust);
    }
    const executionResult = verifyVerifierExecutionEvidence({ evidence: execution, trustPolicy: history.trustPolicy,
      runtimePolicy: history.runtimePolicy, runtimePolicyReference: history.trustPolicy.execution_assurance.runtime_policy_ref,
      nativeProviderEvidence: native, nativeTrustBundle: nativeTrust, nativeTrustBundleReference: native && native.trust_bundle_ref,
      evaluatedAt: at, expectations: { purpose: "verification_receipt", verifierId: attestation.verifier_id,
        subjectReference: review.verification_receipt_ref, workloadIdentityEvidenceReference: identity.evidence_ref,
        repositoryKey: scope.repository_binding.repository_key, repositoryFingerprint: scope.repository_binding.identity_fingerprint,
        repositoryState: receipt.repository_state_before, verificationTarget: { name: scope.id, digest: { sha256: scopeSha256 } } } });
    requireTrue(executionResult.valid, `TOOL_EFFECT_EXECUTION_EVIDENCE_INVALID:${executionResult.codes.join(",")}`);
    requireTrue(Date.parse(execution.invocation.started_at) <= Date.parse(receipt.started_at) &&
      Date.parse(execution.invocation.finished_at) >= Date.parse(receipt.finished_at) &&
      Date.parse(execution.issued_at) <= Date.parse(attestation.issued_at), "TOOL_EFFECT_EXECUTION_WINDOW_MISMATCH");
    executionEvidence.set(execution.id, execution);
    attestations.push(attestation);
    deadlines.push(attestation.expires_at, executionResult.valid_until);
    deadlines.push(new Date(Date.parse(attestation.issued_at) + Math.min(
      campaign.attestation_policy.max_attestation_age_seconds,
      history.trustPolicy.quorum.max_attestation_age_seconds) * 1000).toISOString());
  }
  const quorum = evaluateAttestationQuorum(attestations, history.trustPolicy, {
    receiptReferences: { [receipt.id]: { relative_path: review.verification_receipt_ref.relative_path,
      sha256: review.verification_receipt_ref.sha256, receipt_sha256: receipt.receipt_sha256,
      repository_state: receipt.repository_state_before, verification_target: { name: scope.id, digest: { sha256: scopeSha256 } } } },
    campaignId: receipt.campaign_id, missionId: receipt.mission_id, cycleNumber: receipt.cycle_number,
    candidateId: scope.id, candidateRevision: scopeSha256, repositoryKey: scope.repository_binding.repository_key,
    maxAttestationAgeSeconds: campaign.attestation_policy.max_attestation_age_seconds,
    runtimePolicy: history.runtimePolicy, runtimePolicyReference: history.trustPolicy.execution_assurance.runtime_policy_ref,
    executionEvidence, nativeProviderEvidence, nativeTrustBundles
  }, campaign.attestation_policy, at);
  requireTrue(quorum.valid, `TOOL_EFFECT_ATTESTATION_INVALID:${quorum.codes.join(",")}`);
  const decision = load(store, request.decision_ref, "decision-logs", "decision-log", request);
  const expectedPaths = [request.review_ref, request.campaign_ref, request.cycle_order_ref, review.scope_ref,
    review.verification_plan_ref, review.verification_receipt_ref, ...request.attestation_refs,
    ...additionalDecisionReferences].map(item => item.relative_path).sort();
  requireTrue(decision.decision_maker === "USER" && decision.decision_type === "scope" && decision.status === "complete" &&
    decision.mission_id === scope.mission_id && decision.authority_basis.basis_type === "retained_authority" &&
    decision.authority_basis.reference === scope.id && decision.chosen_option === expectedDecisionOption &&
    decision.options_considered.includes(decision.chosen_option) && hash([...decision.affected_artifacts].sort()) === hash(expectedPaths),
  "TOOL_EFFECT_USER_DECISION_MISMATCH");
  const decisionTime = Date.parse(decision.decided_at);
  requireTrue(decisionTime >= Date.parse(review.reviewed_at) && attestations.every(item => decisionTime >= Date.parse(item.issued_at)) &&
    decisionTime <= Date.parse(at) && Date.parse(at) - decisionTime < 3600000, "TOOL_EFFECT_USER_DECISION_STALE");
  for (const entry of store.manifest.artifacts.filter(item => item.kind === "decision-logs" &&
      item.mission_id === request.mission_id && item.wave_id === request.wave_id && !sameRef(item, request.decision_ref))) {
    const other = load(store, ref(entry), entry.kind, "decision-log", request);
    requireTrue(!(other.decision_maker === "USER" && other.decision_type === "scope" && other.status === "complete" &&
      other.authority_basis.reference === scope.id && Date.parse(other.decided_at) >= decisionTime),
    "TOOL_EFFECT_USER_DECISION_CONFLICT");
  }
  deadlines.push(new Date(decisionTime + 3600000).toISOString());
  return { scope, review, admissionValidUntil: new Date(Math.min(...deadlines.map(Date.parse))).toISOString(),
    proof: { trust_policy_ref: campaign.attestation_policy.trust_policy_ref, assurance_scope: admission.assurance_scope,
      verifier_ids: quorum.verifier_ids, key_ids: quorum.key_ids, independence_groups: quorum.independence_groups } };
}

function historicalStore(store, revision, sha256) {
  requireTrue(Number.isSafeInteger(revision) && revision >= store.manifest.integrity.history_start_revision &&
    revision < store.manifest.manifest_revision && store.manifestHistory.get(revision) === sha256,
  "TOOL_EFFECT_SETTLEMENT_HISTORY_MISMATCH");
  const historyPath = path.join(store.artifactRoot, "repositories", store.verification.repository.key,
    ".manifest-history", `manifest-r${String(revision).padStart(8, "0")}.json`);
  const manifest = JSON.parse(fs.readFileSync(historyPath, "utf8"));
  requireTrue(manifestDigest(manifest) === sha256, "TOOL_EFFECT_SETTLEMENT_HISTORY_MISMATCH");
  return { ...store, manifest, verification: { ...store.verification, manifest_revision: revision, manifest_sha256: sha256 } };
}

const historicalRuntimeViews = new WeakMap();
function historicalRuntimeView(store) {
  const view = { ...store, repository: store.verification.repository,
    verification: { ...store.verification, artifact_count: store.manifest.artifacts.length } };
  historicalRuntimeViews.set(view, manifestDigest(store.manifest));
  return view;
}

function verifiedRuntimeSnapshot(view) {
  const store = require("./campaign-supervisor").loadVerifiedStore(view.repository.root, view.artifactRoot);
  requireTrue(store.verification.repository.key === view.repository.key &&
    store.verification.repository.identity_fingerprint === view.repository.identity_fingerprint,
  "EFFECT_SETTLEMENT_REPOSITORY_MISMATCH");
  const sha256 = manifestDigest(view.manifest);
  if (sha256 === store.verification.manifest_sha256) return store;
  requireTrue(historicalRuntimeViews.get(view) === sha256, "EFFECT_SETTLEMENT_STORE_CHANGED");
  // Only an exact prefix of the currently verified chain may be replayed.
  return historicalStore(store, view.manifest.manifest_revision, sha256);
}

module.exports = {
  historicalRuntimeView,
  verifiedRuntimeSnapshot,
  assertEffectSettlementInputsAvailable,
  assertEffectSettlementConsumptionUnique,
  appraiseEffectSettlementProof,
  historicalSettlementStore: historicalStore,
  loadSettlementArtifact: load,
  settlementContext: context
};
