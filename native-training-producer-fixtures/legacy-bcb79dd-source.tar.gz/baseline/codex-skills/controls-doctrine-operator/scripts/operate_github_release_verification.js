#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

function findRuntimeRoot() {
  const candidates = [];
  if (process.env.CANNAE_OS_HOME) {
    candidates.push(process.env.CANNAE_OS_HOME);
  }
  const skillRoot = path.resolve(__dirname, "..");
  const marker = path.join(skillRoot, ".cannae-os-root");
  if (fs.existsSync(marker)) {
    candidates.push(fs.readFileSync(marker, "utf8").trim());
  }
  for (const start of [fs.realpathSync(__dirname), process.cwd()]) {
    let current = path.resolve(start);
    while (true) {
      candidates.push(current);
      const parent = path.dirname(current);
      if (parent === current) break;
      current = parent;
    }
  }
  for (const candidate of candidates.filter(Boolean)) {
    const root = path.resolve(candidate);
    if (fs.existsSync(path.join(root, "github-release-trusted-root.js")) &&
        fs.existsSync(path.join(root, "github-release-bundle-verifier.js")) &&
        fs.existsSync(path.join(root, "docs", "source-map.md"))) {
      return root;
    }
  }
  throw new Error(
    "Cannae OS independent release verifier not found. " +
    "Reinstall the skill or set CANNAE_OS_HOME."
  );
}

function main() {
  try {
    const [surface, ...args] = process.argv.slice(2);
    const target = {
      "trusted-root": "github-release-trusted-root.js",
      bundle: "github-release-bundle-verifier.js"
    }[surface];
    if (!target) {
      throw new Error(
        "Usage: operate_github_release_verification.js " +
        "trusted-root <refresh|verify> ... | bundle verify ..."
      );
    }
    const root = findRuntimeRoot();
    const result = spawnSync(
      process.execPath,
      [path.join(root, target), ...args],
      { cwd: process.cwd(), stdio: "inherit" }
    );
    if (result.error) throw result.error;
    process.exitCode = result.status === null ? 2 : result.status;
  } catch (error) {
    console.error(error.message);
    process.exitCode = 2;
  }
}

if (require.main === module) main();

module.exports = { findRuntimeRoot };
