# Document Routing

## Force Registry Enrollment

Read `docs/force-registry-enrollment.md` for stable organization, capability and
performer definitions. Use `scripts/operate_controls_force_registry.js propose`
for an exact non-authorizing request, then leave its distinct definition-only
review and password reauthentication to the real owner in the console. A chat
approval, Commander string, earlier order consent or proposed profile is not
enrollment authority. Never read/export the owner's private signing state.
Inspect a lost response and retain partial publication holds; no replay,
automatic repair, signature replacement or retired-ID resurrection is supported.
Public-key pins come from the trusted operator, never from the acting agent.
Require the browser's digest of the complete displayed review; a nonce alone
cannot approve a modified or truncated subject. Keep supporting text in its
original artifact and private owner review, not copied into signed enrollment
history. A changed manifest or target needs a new preview, never replayed consent.
Enrolled is still unassessed: do not dispatch, promote, train unrestrictedly or
activate a standing unit from this registry. Qualification, mandatory actual
grant consumers, full organization lifecycle and controlled rollout remain open.

## Actual Workload Controls

Route `workload-control`, `subject-bound` and report/evidence scan issues to
`docs/subject-bound-workload-controls.md`. Run the workload and control-enforcement
fixtures for code changes, but do not cite those fixture results as a mission's
policy assessment. Use the actual lifecycle `report` operation: it reads exact
same-mission/wave work bytes, runs the bounded worker and retains a separate
digest-only receipt. Keep rejected attempts; replace/redact only through reviewed
work, assign a fresh report ID, then rerun admission. No caller flag skips this
gate. Legacy admitted reports remain readable, not newly publishable authority.

## Readiness Restrictions

Read `docs/readiness-drop-reconciliation.md` after a readiness drop. A rating or
schema-valid event is not a grant. Inspect actual affected leases with
`scripts/reconcile_controls_readiness.js inspect`, collect already admitted
results and use `reconcile` to narrow them. Blocked is not terminal revocation;
preserve tool-effect/gateway obligations and reconcile again after settlement.
Never replay a tool, delete an event, use a later promotion to revive old scope
or infer full qualification from the absence of a drop. Match the actual receiver
role/task and inspect retained introduction history, not path-sorted manifests.
Literal task matching is not a stable cross-mission capability/performer registry.

## Native Producer History

For native consumer upgrades, route to `docs/native-training-producer-history.md`
and use `scripts/inspect_controls_training_producer.js inspect <method-sha256>`.
Run both producer fixture runners before accepting a new consumer. Preserve the
real old producer, exact source/ignored directory shape and original records;
inspection never signs, executes, settles, qualifies or clears a native hold.

## Manual Receipt Procedure

Use only for diagnosis/lower-level integration, not default dispatch. Give the
wave and every receiver the same mission objective as `--capability-query`; the
final query describes that receipt's narrower task. These commands grant nothing:

```bash
node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --receipt --scope=wave --mission=MIS-... --wave=W2 --agent=chief-of-staff --actor=ai --role=COS --department=coordination --authority=tasking --capability-query="<mission objective>" "<wave task>" .
node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --receipt --scope=agent --mission=MIS-... --wave=W2 --agent=plans-agent --actor=ai --role=S3 --department=operations --authority=scoped-execution --capability-query="<mission objective>" "<agent task>" .
node agent-routing-preflight-runner.js <agent-routing-preflight-bundle.json>
```

## Requirement Review

For model-proposed analysis from a retained request, read
`docs/native-order-analysis.md`. Use `scripts/prepare_controls_analysis.js`
only to prepare; real transfer uses the owner's exact request-analysis purpose,
not omission/order consent or a CLI run flag. Inspect Model Actions after a lost
response; never rerun to hide failure or use the omission acknowledgment to clear
an analysis hold. Generate the exact bounded plan, then obtain fresh coverage and
USER adoption before dispatch. Proposed roles and quoted bytes do not
prove semantic completeness or expand authority.
On `ORDER_INTAKE_DRAFT_TOO_LARGE`, stop publication and preserve the original
analysis/transfer history. Small responses can amplify through inherited task
text; do not raise the 8 MiB reader limit, drop constraints/tasks or retry a
model automatically. Ask for a separately reviewed bounded decomposition and
fresh review/consent where required. Test the actual compiler and reader, not
only response schema/input bytes. Old oversized artifacts are not repaired by
truncation or re-signing.
An overall-size regression must first pass structural validation; a per-field
`MAX_LENGTH` denial does not prove the complete-output budget ran.
After uncertain draft publication, inspect Evidence and Model Actions separately;
preserve a draft already written without clearing the held transfer or rerunning it.
For a verifiable failed analysis, use the separate procedure in
`docs/order-analysis-reconciliation.md`. Review both original process/journal
proof and the exact observed draft publication, then let the real owner consume
the analysis-specific two-acknowledgment ceremony. Never use omission endpoints,
recompile to discover effects, adopt/delete a draft as cleanup or treat verified
manifest absence as proof of no effects. Inspect a lost commit; obtain fresh
consent after a failed reservation. Unknown/integrity holds remain unsupported.
For signed model history, require the full invocation and nested preview to rehash
to their original signed commitments before trusting displayed scope. A valid
signature over a digest field alone is insufficient. Keep changed records held;
never recalculate their hashes or re-sign altered bodies as a history repair.

Inventory coverage and request routing are separate gates. After adding a
contract alias, run `node run-document-routing-fixtures.js` as well as `--coverage`
for both providers; a fully indexed corpus can still misroute a real query.
If a known `semantic-review-assignment` request returns `gap_detected`, retain
that failed result and inspect the query rule before proposing a new department.
Do not suppress real capability gaps or infer authority from a corrected route.

For automatic structural plan construction, read `docs/bounded-plan-synthesis.md`
and use `scripts/plan_controls_mission.js` against the explicit target repository.
Supply bounded roster/policy/control inputs, not a fabricated complete plan.
Inspect `blocked` and search-limit results; never drop tasks, raise a budget or
retry a larger search automatically to obtain readiness. Use only the returned
plan with `planning_ref`. For a successor, run `prepare-revision` before preparing
fresh coverage, then use its finalized plan. An old review is invalid after that
binding changes. Preserve parent intent/caps and actual supersession/settlement;
generation grants neither model transfer nor adoption, dispatch or release.
The structural generator uses zero model calls and does not replace calibrated
semantic analysis or an independently reviewed strategic planner.
Reuse agent identity across a successor only with wave-distinct backbrief,
rehearsal and decision IDs; a prior wave's evidence is not fresh acknowledgment.
Keep `BoundedPlanningOperation` outputs out of task evidence, including legacy
untyped bundles and nested/array-wrapped planning or semantic packets. Publish
independent work facts and cite exact control references instead; wrapping a
proposal or removing its outer tag never proves a task was performed.

For requirement inventory and semantic coverage admission, read
`docs/requirement-inventory-admission.md` and run
`scripts/review_controls_requirements.js` with the exact target repository.
Its template performs no extraction or transmission. Review every source
fragment, retain coverage of every actual receiver and bind new adoption v0.2.
Whole-plan edits invalidate that review. Legacy history is readable, not a way
to regain active captured-request execution. Model results remain advisory;
human inventory review is an explicit separate class, not calibrated automation.
For linked revision, finalize its returned successor plan before preparing
coverage: its new revision reference and shortened validity change the plan hash.
Do not backdate coverage before the plan's creation or reuse the prior review.
For browser adoption, compare the Source classifications (including context),
global restrictions and each actual receiver in the Coverage view; inspect the
complete Plan and Exact Approval Subject for budgets and fields not quoted in
the matrix. Receiver/status filters and pagination narrow only the display, not
the signed decision subject. They never renew consent. A readable matrix does
not establish semantic equivalence or prove the human reviewed it. Close stale
previews and obtain fresh review after plan changes; never approve from a
partial or malformed matrix. Run `run-operator-coverage-ui-fixtures.js` and the
real `operator-consent-fixtures/browser-check.js` after changing this presentation.

For semantic omission evaluation, read `docs/semantic-omission-evaluation.md`
and `docs/model-transfer-consent.md`. Run the collector, operator-semantic and
control-evidence fixture suites plus the real browser check. `prepare` transmits nothing.
Use bundled `scripts/evaluate_controls_request.js prepare --repository <repo>
--draft-id <id>` outside the checkout; it exposes no model-execution command.
Inspect actual compiled order/receiver projections, not unused analysis quotes.
Existing CLI login and order consent never approve model transfer. Do not mint
operational consent with fixture keys or expose private previews in agent chat.
Use the console's exact-packet owner preview, password and one-use session-bound
nonce after the trusted host explicitly configures its CLI/model pair. Never
automate the real owner's account or approval. After logout/stop/shutdown require
actual child close and group absence; inspect Model Actions after a lost
response. For a verifiable failed transfer, read `docs/model-transfer-reconciliation.md`
and use Review Model Hold. Require a fresh password/session-bound acknowledgment,
exact original history and independently observed PID/group absence. Require the
original v0.2 signed journal binding: never trust an unsigned journal PID or
retroactively sign a v0.1 result's current files. Legacy unbound results remain
readable but held; a later receipt cannot manufacture their missing provenance.
Preserve the original failure; a saved signed receipt acknowledges only this local model hold
and never starts a new call. After an interrupted acknowledgment, inspect history
and obtain new consent; never finish the old reservation or replay its nonce.
Missing signatures/journals or unconfirmed termination stay held. Never delete
rows/journals or use another nonce/session to bypass a hold. Do not cite
previews, transfer consents or evaluation results as task outputs, even in text
or binary form. Native process exit does not prove upstream billing cancellation.
Reject any response changed between collection and signing; do not bless the new
bytes with a fresh signature or rerun the model to hide the original mismatch.
Treat null/non-object JSONL and invalid UTF-8 as failed collection, not a reason
to restart the HTTP service or replay consent. Confirm its actual child exit.
An authentic signed transport-failure record is not signature corruption. Keep
known digit-bearing codes such as `SEMANTIC_EVENT_UTF8_INVALID` intact; never
replace that distinction with a broad diagnostic exception or a success label.
At shutdown fence the worker queue and model collector together, then await both
actual exits before releasing ownership. Never wait on one while the other admits work.
After a timeout or lost result, keep the consumed reservation and inspect it;
never retry the model automatically. Treat `complete` as advisory until held-out
calibration and mandatory consumers exist; fake-process passes are not calibration.
Unexpected startup diagnostics stay private and failed. Inspect their quarantined
file; never broaden the diagnostic allowlist just to make the run pass.
After a signal failure, preserve that failure and require actual child close
plus group absence; a termination request or clean working tree proves neither.

For an operational situation read, use `docs/operational-cop.md` and the
authenticated Operations view; run `node run-operational-cop-fixtures.js` when
maintaining it. Read attention across the entire permitted scope even when
mission/staff filters return no rows. Refresh expired snapshots and reselect
evidence after manifest drift. A recorded active lease, zero alerts or a fresh
snapshot never proves worker liveness, task completion or tool eligibility.
Never clear a hold by editing the view or recovering issuance during a read;
follow its owning controller. COP JSON is control metadata, not work evidence.

At lease issuance, inspect repository-wide gateway and unknown-effect holds,
including other waves. A new session/wave cannot clear them. Publication must
retain the specific hold before a generic manifest conflict. Use the exact
gateway regression filter for diagnosis only; unknown filters must fail and a
filtered pass never replaces the full consuming suites.

For a real local evidence workspace, route to `docs/local-operator-console.md`
and `scripts/serve_controls_operator.js`; validate with
`node run-operator-console-fixtures.js`. The human creates the owner account.
Do not read private setup links into chat, seed fake operational records, or
interpret login, viewer invitations or proposal inspection as scope approval.
Grant explicit restricted mission access only after owner reauthentication.
After a stale manifest/cursor error, refresh the list and reselect the evidence.
After logout, account replacement or a changed filter/selection, discard earlier
responses and obtain a fresh principal-bound read; hidden old tables and dialogs
must remain cleared. Run `operator-console-fixtures/session-browser-check.js`
with the existing browser/API suites. A discarded approval response is not a
cancelled decision: inspect its exact retained outcome, never replay its write.
Keep authentication throttles active and obey an observed retry interval.

For actual owner plan decisions, read `docs/operator-consent-and-adoption.md`
and run `node run-operator-consent-fixtures.js` with the adoption/console suites.
Keep full-plan preview, selected rehearsal/backbriefs and password
reauthentication together. Never script an actual owner's approval, copy a
nonce to an artifact or retry a write because the response was lost. Inspect
the stored action outcome and preserve any reconciliation-required hold.
An adopted plan still needs ordinary lifecycle/lease/gateway checks; signed
consent cannot replace work evidence or authorize tool execution or release.

For a timed-out or interrupted local owner decision, run
`node run-operator-console-worker-fixtures.js` when maintaining the runtime.
Do not clear the SQLite hold, replace the service ownership or launch another
writer while worker exit is unconfirmed. An observed exit only stops that
worker; inspect the actual action and retained manifest to determine effects.
Preserve reconciliation-required state even after shutdown. A lost response
is never permission to replay the nonce or create a second approval. The exact
local order terminal ceremony below is separate from worker termination.

Use Decisions > Inspect Outcome to compare that exact action with the pinned-key
signed consent, expected decision payload and historical adoption replay.
An `applied` inspection does not clear a private hold or restore expired/current
authority. `unconsumed_decision` needs a later explicit cancellation fence, not
a database edit. Keep `conflicting`/`unverifiable` visible; do not regenerate
missing records. Run `node run-operator-consent-outcome-fixtures.js` and the
browser checks when changing this read path; it never performs terminal discharge.

For one exact interrupted local owner order, read
`docs/operator-terminal-reconciliation.md` and use the authenticated console's
Review Terminal Outcome after inspection. Require the human's fresh password
and one-use terminal nonce; do not script a real owner's consent. Confirm the
retained cancellation or original controller result, signed receipt and archived
failure before accepting a cleared local hold. After another interruption,
keep conflicting or unverifiable projections held even if their private state
claims completion. Do not repair that disagreement by editing the database;
inspect again and obtain fresh terminal consent; reuse only the service-verified
old cancellation reference, never its nonce or original adoption mutation.
Run `node run-operator-reconciliation-fixtures.js` plus the terminal browser
flows and existing consent/adoption suites. The offline signature CLI explicitly
does not verify artifact history or clear state. These contracts cannot settle
campaign/gateway obligations, replace work evidence or grant new tools/release.
Do not trust an evidence file's MIME or extension to distinguish work from
control records: whole JSON audit metadata stays forbidden after plain-text or
binary relabeling. This is not a semantic guarantee for arbitrary prose.

For exact successor activation, read `docs/campaign-successor-admission.md`,
its four request/proposal/admission schemas, `campaign-successor-controller.js`
and `run-campaign-successor-fixtures.js`. Use
`scripts/activate_controls_successor.js` for propose/decision-option/activate/status.
A held candidate is not an admission, and admission is not ordinary dispatch.
Use its non-authorizing `repository-state` command before freezing the proposal.

For campaign terminal reconciliation or successor-activation prerequisites,
read `docs/campaign-terminal-reconciliation.md`, its request/record schemas,
`campaign-terminal-controller.js` and `run-campaign-terminal-fixtures.js`.
Use `scripts/reconcile_controls_campaign.js`; also run hook/gateway settlement
fixtures after historical replay changes. Terminal status never clears a stop.

For campaign stop, cancellation intake, or a denied restart, route to
`docs/bounded-self-improvement-operations.md#210-explicit-user-stop-intake`,
`campaign-stop-controller.js`, its request/record schemas and
`run-campaign-supervisor-fixtures.js`. Use `scripts/stop_controls_campaign.js`
for decision preparation, exact USER-bound stop and status. It does not resume
work, settle effects or create successor authority.

Use this map after running `scripts/route_controls_docs.js`, or when a task is obvious enough to route manually.

## Inventory Coverage

For unknown tool outcomes, route `docs/tool-effect-review.md` and
`docs/tool-effect-settlement.md`. Evidence preparation does not clear holds;
settlement needs historical/current verifier admission and an exact USER
decision. Both fixture suites are required when changing this boundary.
For a reconciled failure or legacy resumed/terminal lease, inspect the separate
failed-agent marker and require explicit post-settlement revocation. Do not
translate zero unresolved effects into successful completion or renewed tools.

For implementation-candidate audits and existing-program completion, route to
`docs/implementation-candidate-registry.md` and `docs/completion-backlog.md`.
Run `node implementation-candidate-registry.js audit`; use its source-bound
entries rather than regex filename counts or a changelog's closure wording.
Execute selected mapped checks with `verify` before declaring implementation.

The router scans tracked and unignored candidate corpus artifacts, including Markdown/HTML docs, JSON schemas, sample payloads, runtime payloads, fixtures, runner scripts, prototype scripts, dashboard state, and skill metadata. Git-ignored local state such as `.cxt` and `.cannae`, plus `.git` and `node_modules`, is not doctrine inventory. A non-Git fallback retains the explicit directory exclusions. Every routable corpus artifact must have at least one route category.

Run coverage after adding, renaming, deleting, or moving any corpus artifact:

```bash
node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --coverage .
```

The report must return `valid: true` and `unrouted_artifact_count: 0`. If it does not, update `ROUTE_HINTS`, `RULES`, or the artifact naming so the item has a clear route.

Inventory coverage does not prove that a specific task received its documents.
The recommendation bundle preserves orientation, role/authority, capability-gap,
and all documents from the top four selected task routes, without a 16-document
cutoff. `--limit` and `--all` affect only supporting artifacts. Check the exact
task paths in `recommended_documents` and the resulting context pack; a matched
route or validation command alone is not enough. Do not manually truncate a
receipt or context pack. Narrow an overly broad request before creating a fresh
wave, preserve existing evidence, and retain the document-access manifest's
delivery restrictions: a routing recommendation never grants raw-data access.
Run `node run-agent-routing-preflight-fixtures.js` for task-level routing
regressions in both provider skill trees, in addition to inventory coverage.

## Operator Mode

| Mode | Trigger | Routing Rule | Escalation |
| --- | --- | --- | --- |
| Human final decision authority | The chat user asks directly, researches, decides, or asks "how should we use this?" | Route for efficiency and evidence, not to restrict the user's visibility. Read the minimum useful docs, then brief options and tradeoffs. | Warn before high-risk, release, or irreversible actions, but the user decides. |
| Delegated AI operator | The user asks an AI agent, role, department, staff function, or TF to perform work | Route by role, department, authority, task, release target, risk, and need-to-know. Start with role/access/approval policy before task docs. | Escalate to the human user for anything outside delegated authority, cross-boundary release, or high-risk tool use. |

For delegated AI routing, declare as much context as available:

```bash
node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --actor=ai --role=S3 --department=operations --authority=scoped-execution "<mission request>" .
```

## Capability Gap Routing

The router assesses doctrine capability from the request text only; role,
department, and authority options affect access and control documents but do
not prove that the corpus owns the requested domain. For manual wave/agent
receipts, pass the same mission objective through `--capability-query` on every
call and use the positional query for the narrower task.

When `capability_routing.status` is `gap_detected`:

1. Do not return "outside the corpus" and continue as general, unowned work.
2. Task-organize the returned mission-scoped capability cell for analysis and reversible drafting under existing authority.
3. Preserve its deterministic `CELL-*` ID and the paired `DEPT-*` standing-department candidate across CoS, agent receipts, and context packs.
4. Run `run-force-structure-change-fixtures.js` as a mandatory control and assess DOTMLPF-P alternatives.
5. Keep authority expansion and standing activation false. Only the USER can decide whether a validated `ForceStructureChangeOrder` should activate the candidate.
6. Disband the provisional cell at mission handoff unless the standing change is approved.

For delegated execution, routing must create a receipt and pass preflight before any agent starts work:

```bash
node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --receipt --scope=wave --mission=MIS-... --wave=W2 --agent=chief-of-staff --actor=ai --role=COS --department=coordination --authority=tasking "<wave mission>" .
node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --receipt --scope=agent --mission=MIS-... --wave=W2 --agent=plans-agent --actor=ai --role=S3 --department=operations --authority=scoped-execution "<agent task>" .
node agent-routing-preflight-runner.js <agent-routing-preflight-bundle.json>
```

Preflight requires one CoS wave receipt and one S3 operations receipt for each expected agent. A missing, stale, manually claimed, or wrong-role receipt blocks the wave.

Routing preflight proves that the agent received the correct doctrine context.
It does not authorize tool execution. Before opening a dispatch-controlled wave,
put each exact policy-draft digest and agent/provider/policy tuple in the
USER-authorized mission plan. After `open`, compile that draft and issue the
single repository-, mission-, wave-, agent-, and session-bound lease lineage;
place the provider hook adapter on the execution path. A resumed or forked
session requires explicit lineage continuation after checkpoint review;
restored conversational context never restores authority.

## Core Navigation

| Task | Read First | Then Read |
| --- | --- | --- |
| Understand the whole framework | `README.md`, `docs/military-llm-framework-v0.1.md` | `docs/military-operating-system.md`, `docs/glossary.md` |
| Contribute or review project governance | `CONTRIBUTING.md`, `GOVERNANCE.md` | `CODE_OF_CONDUCT.md`, `SECURITY.md`, `SUPPORT.md` |
| Find source backing | `docs/source-map.md` | `docs/research-compendium.md`, `docs/source-reliability-rubric.md` |
| Choose docs for a request | `README.md`, router output | `docs/military-operating-deep-research-queue.md` |
| Add external military sources | `docs/source-map.md` | `docs/research-compendium.md`, `source-map-linter.js` |

## Mission, Orders, Reporting

| Task | Primary Docs | Executable Surface |
| --- | --- | --- |
| General request intake and draft compilation | `docs/request-order-intake.md`, `docs/orders-production-pipeline.md` | `scripts/compile_controls_order.js`, `request-order-compiler.js`, `order-intake-contract.js`, three intake schemas and `run-request-order-compiler-fixtures.js` |
| Exact USER order adoption and plan-bound agent tasking | `docs/order-adoption-and-plan-binding.md`, `docs/skill-operational-mission-lifecycle.md` | `scripts/adopt_controls_order.js`, `order-adoption-controller.js`, six adoption contracts, plan v0.2/context v0.3 and `run-order-adoption-fixtures.js`; changed plans need new review and legacy downgrade cannot discharge intake |
| Opened-plan revision and predecessor handoff | `docs/order-revision-and-supersession.md`, `docs/order-adoption-and-plan-binding.md` | `scripts/revise_controls_order.js`, revision contracts/controller and `run-order-revision-fixtures.js`; prepare the successor, settle old results, supersede exact scope, then request normal tool admission |
| OPORD/WARNO/FRAGO/SITREP/AAR prompting | `docs/prompt-templates.md`, `docs/orders-production-pipeline.md` | `schema-files/opord.schema.json`, `schema-files/warno.schema.json`, `schema-files/frago.schema.json`, `schema-files/sitrep.schema.json`, `schema-files/aar.schema.json` |
| Commander's intent and disciplined initiative | `docs/mission-command-runtime-policy.md`, `docs/disciplined-initiative-rules.md`, `docs/intent-continuity-runtime.md`, `docs/method-deviation-runtime.md`, `docs/commander-handbook.md` | `intent-continuity-runner.js`, `method-deviation-runner.js`, `run-intent-continuity-fixtures.js`, `run-method-deviation-contract-fixtures.js`, `run-disciplined-initiative-fixtures.js`, `scripts/check_controls_intent.js`, `scripts/operate_controls_methods.js`, bound schemas and samples |
| Source-plan annex | `docs/opord-annex-model.md` | `schema-files/source-plan.schema.json`, `schema-files/verification-plan.schema.json` |
| Annex vs FRAGO change | `docs/opord-annex-model.md` | `schema-files/annex.schema.json`, `schema-files/frago-scope-change.schema.json`, `run-rehearsal-to-ccir-fixtures.js` |
| Backbrief/rehearsal | `docs/backbrief-and-rehearsal-sop.md`, `docs/dry-run-approval-ui.md` | `schema-files/backbrief.schema.json`, `schema-files/rehearsal.schema.json`, `orders-dissemination-runner.js`, `event-fixtures/rehearsal-event-fixtures.json`, `run-rehearsal-event-fixtures.js` |
| CCIR reporting thresholds and COP | `docs/reporting-threshold-policy.md`, `docs/common-operational-picture-state.md`, `docs/ccir-alerting-model.md` | `ccir-linter.js`, `run-ccir-linter-fixtures.js`, `alert-router-prototype/` |
| Information to operations | `docs/information-to-operations-cycle.md` | `information-to-operations-router.js`, `run-information-to-operations-fixtures.js` |

For an enrolled method baseline, deliver only the receiver's `method_assignment`
with its exact task/plan binding and usable instructions. Keep the routed query
unchanged; adding this control cannot cover an unrelated capability gap. Send
structured requests to the trusted CoS/operator host running the method wrapper
outside the agent's scoped session. Do not grant shell or metadata-write access
to a Read-only agent just to submit its reports. The v0.1 CLI does not implement
automatic provider-message transport. For a newly reviewed v0.2 channel, read
`docs/method-control-channel.md` and use `scripts/operate_controls_channel.js`:
prepare before startup, observe the exact native session, issue its lease, then
enroll. Configure the exact returned server descriptor,
not a prefix-wide MCP allowlist. Keep private state outside the target and model
context. A lost response holds work; only actual retained metadata may be
reconciled. Never renew authority or rerun a task to repair delivery. SDK and
synthetic-hook tests do not attest actual native client startup.
Keep raw private-file/parser diagnostics on the trusted operator side; agents
receive fixed non-secret error codes, never private contents or paths. Same-wave
continuation needs a newly reviewed channel policy v0.2. Settle callbacks,
actual after-reports and metadata delivery, then interrupt and inspect its exact
checkpoint. Use `prepare-continuation` for a fresh private file; configure it,
observe the exact native start, explicitly `resume`, then `enroll` that lease.
Never reuse the old file or reset root deadlines, request IDs, metadata/task
budgets or rule counters. Initial-only v0.1 needs a newly reviewed wave instead.
For interrupted core issuance, read `docs/dispatch-issuance-recovery.md` and
inspect `status` before retrying. Use only the retained issuance ID with
`recover-issuance`; bindings, nonce and expiry are frozen. An unused request may
be explicitly cancelled, never converted into a completed task. Missing legacy
requests cannot be reconstructed. If verification reports `PENDING_TRANSACTION`,
pause dispatch and inspect/recover the actual store journal before issuance
status; require a valid store, then recover only the retained issuance ID.
Store recovery is not issuance approval or task replay. An ordinary first wave
can initialize a genuinely missing namespace; never seed invented evidence or
treat an existing corrupt store as empty. Preserve admitted results; do not hot-swap
runtime code, reuse the old private file or replay a task to repair issuance.
Keep issuance/recovery/cancellation commands on the trusted operator side;
listing their shell digest as an ordinary task does not delegate control-plane
authority. A valid lease JSON and a historical commit result are not current
tool permission. Inspect unresolved issuance before reporting settled work.
Store recovery may finish the final commit record. Still require the live
source-binding and ordinary tool gates; committed history or
`runtime_source_current` alone grants nothing. On source drift, preserve
already-admitted results and explicitly revoke unused authority; never renew
bindings or replay work to hide the denial.
Diagnose dispatch denials by their exact reason code; changed prose is not a
different authority state or permission to retry with new bindings.
For legacy result-only leases, inspect reconciled failure and revocation markers
separately. Preserve their specific hold; a generic migration denial is not
clearance or permission to skip post-settlement revocation of a failed agent.
Require full supervisor, gateway, intent, channel and lifecycle regressions
after changing issuance. Preserve specific stop/failure reasons and legacy
result settlement separately from new authority. When a stricter guard rejects
earlier, prove its exact denial and absence of publications; do not weaken the
guard or broaden an expected-error regex to simulate the old unsafe sequence.
When a retained stop wins over generic CAS, require its exact blocked code and
stop reason plus an actually denied successor admission. Align the assertion
with that stricter boundary; do not restore a generic error or suppress the case.

Propose the exact reviewed alternative before calling its tool. Obtain an exact
USER acknowledgment when required, then report
the actual admission/result through the method wrapper before another call or
completion. A generic SITREP, schema pass, tool output in chat or later report
cannot repair a missed boundary or restore a stopped mission. Inspect the real
revocation checkpoint; blocked revocation preserves containment/effect holds.
Use verified manifest introduction history for causality, never array order or
lexicographic timestamps. Keep caches inside one verified snapshot and reappraise
at publication. The routed pure checks do not substitute for full integration
tests, and legacy workflows do not gain the new guarantee retroactively.
Use the reviewed baseline's shorter validity, never the schema-wide ceiling,
as the operational deadline; after expiry only actual-result reporting remains.

Keep actual task outputs separate from derived SITREPs and other control records.
Whole-record JSON copies remain metadata even without a type tag or after MIME,
whitespace or key-order changes. The report publisher reappraises current retained
control content after its required controls run. A denied publication needs a
fresh report ID and freshly executed controls, not recycled receipts. Run
`node run-skill-control-evidence-fixtures.js` after changing this boundary; it
exercises actual report admission, ordinary JSON work and publication races in
legacy data-only waves, not method dispatch or semantic truth of arbitrary prose.

## Authority, Release, Risk

| Task | Primary Docs | Executable Surface |
| --- | --- | --- |
| Role authority | `docs/agent-roles-and-authority.md` | `schema-files/authority-matrix.schema.json`, `readiness-gate-prototype/` |
| Tool use policy | `docs/tool-use-roe.md`, `docs/policy-engine-rules.md` | `policy-engine-prototype/`, `policy-engine-authority-integration.js` |
| Enforced tool dispatch and explicit resume | `docs/enforced-dispatch-and-resume.md`, `docs/tool-use-roe.md` | `dispatch-runtime-controller.js`, `dispatch-hook-adapter.js`, `install-dispatch-hooks.js`, dispatch policy/lease/admission/checkpoint schemas |
| Protected tool transaction, gateway ownership/obligations, late gateway callback, idempotency, and recovery | `docs/protected-tool-gateway-contract.md`, `docs/enforced-dispatch-and-resume.md` | `protected-tool-gateway.js`, `dispatch-runtime-controller.js`, gateway request/decision/receipt/event schemas, `run-protected-tool-gateway-fixtures.js`; inspect gateway obligations separately from hook settlement |
| Gateway effect review, gateway settlement intake, or orphan admission | `docs/gateway-effect-review.md`, `docs/completion-backlog.md` | `gateway-effect-review.js`, gateway-effect schemas, `scripts/review_gateway_effects.js`, `run-gateway-effect-review-fixtures.js`; classify first and preserve all holds after review |
| Authenticated gateway principal, mTLS, SPIFFE, TLS exporter, challenge, or replay | `docs/gateway-identity-admission.md`, `docs/protected-tool-gateway-contract.md` | `gateway-identity-adapter.js`, `gateway-identity-evidence.js`, identity policy/challenge/evidence schemas, `run-gateway-identity-adapter-fixtures.js` |
| Protected native process, exact executable/argv, envelope, observation, timeout, shebang rejection, or no-rerun recovery | `docs/protected-process-execution.md`, `docs/protected-tool-gateway-contract.md` | `protected-process-executor.js`, `protected-execution-evidence.js`, protected-execution schemas, `scripts/operate_protected_executor.js`, `run-protected-process-executor-fixtures.js` |
| OCI Linux sandbox, immutable image, seccomp, no-new-privileges, capabilities, namespaces, read-only mounts, cgroup, network none, kernel probe, container cleanup, daemon unavailable, or container absence | `docs/oci-linux-sandbox-provider.md`, `docs/protected-tool-gateway-contract.md`, `docs/protected-process-execution.md` | `oci-linux-sandbox-provider.js`, `oci-linux-sandbox-evidence.js`, `oci-linux-sandbox-probe.go`, OCI sandbox schemas/samples, `runtime-profiles/`, `scripts/operate_oci_sandbox.js`, `run-oci-linux-sandbox-provider-fixtures.js` |
| Production sandbox, RATS/EAT appraisal, OCI/SLSA provenance, managed exclusivity, independent deployment quorum, external coordinator, or storage fencing | `docs/production-sandbox-admission.md`, `docs/protected-tool-gateway-contract.md`, `docs/gateway-identity-admission.md`, `docs/oci-linux-sandbox-provider.md` | `production-sandbox-admission.js`, `production-sandbox-admission-adapter.js`, production schemas/samples, `scripts/operate_production_sandbox.js`, `run-production-sandbox-admission-fixtures.js`, `run-production-sandbox-gateway-fixtures.js` |
| Approval lifecycle | `docs/approval-scope-policy.md` | `approval-consumption-runner.js`, `approval-renewal-runner.js`, `approval-revocation-runner.js`, `approval-delegation-runner.js` |
| Risk acceptance | `docs/risk-acceptance-authority.md` | `schema-files/risk-acceptance.schema.json`, `run-authority-integration-fixtures.js` |
| Readiness to authority | `docs/readiness-to-authority-policy.md`, `docs/training-progression-model.md`, `docs/agent-metl.md` | `schema-files/agent-metl.schema.json`, `schema-files/readiness-event.schema.json`, `readiness-gate-prototype/` |
| Release review | `docs/context-releasability-policy.md`, `docs/opsec-classification-model.md`, `docs/sensitive-output-filter.md` | `release-review-runner.js`, `policy-engine-release-integration.js`, `release-gate-decision-runner.js`, `opsec-linter.js`, `evidence-redactor.js`, `eefi-detector.js`, `schema-files/classification-label.schema.json`, `schema-files/releasability-review.schema.json`, `schema-files/eefi-alert.schema.json`, `schema-files/context-release.schema.json` |
| GitHub repository release-immutability policy activation | `docs/github-release-immutability.md`, `docs/github-release-authorization.md` | `github-release-immutability.js`, policy authorization/receipt schemas and samples, `scripts/operate_github_release_immutability.js`, `run-github-release-immutability-fixtures.js` |
| GitHub immutable-policy drift, release-attestation monitoring, trust-checkpoint continuity, or initial bootstrap recovery | `docs/github-release-integrity-monitoring.md`, `docs/github-release-independent-verification.md`, `docs/github-release-trust-checkpoint-continuity.md`, `docs/github-release-immutability.md`, `docs/github-release-authorization.md` | `.github/release-integrity-policy.json`, `github-release-integrity-monitor.js`, `github-release-trusted-root.js`, `github-release-trust-checkpoint.js`, `github-release-checkpoint-store.js`, `github-release-bootstrap-recovery.js`, `github-release-bootstrap-recovery-operator.js`, `github-release-bundle-verifier.js`, integrity/trust/recovery schemas and fixtures, `scripts/operate_github_release_integrity.js`, `scripts/operate_github_release_verification.js`, `.github/workflows/release-integrity.yml` |
| Exact GitHub tag/release authorization and publication | `docs/github-release-authorization.md`, `docs/github-release-independent-verification.md`, `docs/github-release-trust-checkpoint-continuity.md`, exact tracked release notes | `github-release-publisher.js`, trusted-root, trust-checkpoint, and independent-verification runtimes, authorization/receipt/trust schemas, `scripts/operate_github_release.js`, `scripts/operate_github_release_verification.js`, publisher, checkpoint, and independent-verification fixtures |

For verifier dependency migration, lockfile updates or `ip-address` maintenance,
read `docs/github-release-independent-verification.md#producer-compatibility`
and the dependency procedure in `references/self-improvement-loop.md`.
Run `run-github-release-independent-verification-fixtures.js` before the monitor,
checkpoint, publisher and full aggregate gates. Preserve the prior-producer
sample bytes; regenerate only the separately named current sample.

## Multi-Agent Organization

| Task | Primary Docs | Executable Surface |
| --- | --- | --- |
| Org chart / roles | `docs/llm-agent-org-chart.md`, `docs/agent-roles-and-authority.md` | `schema-files/agent.schema.json` |
| Department collaboration | `docs/interdepartment-collaboration-policy.md`, `docs/b2c2wg-operating-model.md` | `schema-files/department-collaboration-charter.schema.json`, `department-collaboration-runner.js` |
| Chief of staff and battle rhythm | `docs/chief-of-staff-agent.md`, `docs/b2c2wg-operating-model.md`, `docs/agent-battle-rhythm.md` | `schema-files/board-decision.schema.json`, `schema-files/battle-rhythm-event.schema.json`, `schema-files/battle-rhythm-scheduler.schema.json`, `battle-rhythm-scheduler.js`, `run-battle-rhythm-scheduler-fixtures.js` |
| Liaison and partner interop | `docs/liaison-agent-model.md`, `docs/interop-release-packet.md`, `docs/partner-command-relationship.md` | `schema-files/context-release.schema.json`, `release-review-runner.js`, `release-gate-decision-runner.js` |
| Agent routing preflight | `docs/role-document-access-policy.md`, `docs/agent-roles-and-authority.md`, this routing reference | `schema-files/routing-receipt.schema.json`, `agent-routing-preflight-runner.js`, `run-agent-routing-preflight-fixtures.js` |
| Operational mission lifecycle, expiry, abort, and supersession | `docs/skill-operational-mission-lifecycle.md`, `docs/agent-battle-rhythm.md`, `docs/knowledge-management-sop.md` | `skill-mission-controller.js`, mission-wave/context/report/closeout/termination schemas, `scripts/operate_controls_mission.js`, `run-skill-mission-controller-fixtures.js` |
| One lease lineage per delegated mission agent | `docs/enforced-dispatch-and-resume.md`, `docs/repository-artifact-isolation-policy.md` | `dispatch-runtime-controller.js`, `scripts/operate_dispatch_runtime.js`, `scripts/enforce_controls_dispatch.js`, `scripts/install_dispatch_hooks.js`, `run-dispatch-runtime-fixtures.js` |
| SOF / high-risk TF | `docs/ai-special-operations-tf.md` | `schema-files/sof-tf-charter.schema.json`, `sof-tf-activation-runner.js` |
| Force structure changes | `docs/force-structure-change-policy.md` | `schema-files/force-structure-change-order.schema.json`, `force-structure-change-runner.js` |
| Unmatched mission capability | `docs/force-structure-change-policy.md`, `docs/interdepartment-collaboration-policy.md`, `docs/b2c2wg-operating-model.md` | routing receipt/context-pack v0.2 `capability_routing`, `run-force-structure-change-fixtures.js`, `skill-mission-controller.js` |
| Mission-based model allocation and dispatch | `docs/model-force-assignment-policy.md`, `docs/model-force-v0.2-operations.md`, `docs/agent-metl.md`, `docs/agent-readiness-ledger.md` | `schema-files/model-registry.schema.json`, `schema-files/model-assignment-request.schema.json`, `model-assignment-compiler.js`, `integrated-mission-preflight-runner.js`, `run-model-force-v0.2-fixtures.js` |
| Continuity and handoff | `docs/personnel-continuity-model.md`, `docs/knowledge-management-sop.md`, `docs/handoff-packet-template.md` | `schema-files/continuity-plan.schema.json`, `handoff-generator.js`, `continuity-drill-runner.js` |

## Source, Culture, Multinational Use

| Task | Primary Docs | Executable Surface |
| --- | --- | --- |
| Korean adaptation | `docs/korean-military-sources.md`, `docs/korean-org-culture.md` | source-map coverage and local policy notes |
| Multinational consistency | `docs/multinational-doctrine-consistency-review.md` | `schema-files/doctrine-consistency-review.schema.json`, `doctrine-consistency-runner.js` |
| Source reliability | `docs/source-reliability-rubric.md` | source-map linter and evidence samples |
| Research backlog | `docs/military-operating-deep-research-queue.md` | new docs/schemas/runners as justified |

## Runtime, UI, Persistence

| Task | Primary Docs | Executable Surface |
| --- | --- | --- |
| Reference architecture | `docs/reference-architecture.md`, `docs/implementation-guide.md` | runner suite and prototype directories |
| Event sourcing | `docs/event-sourcing-model.md` | `event-replay-prototype/`, `event-fixtures/` |
| Dashboard | `docs/command-post-dashboard.md`, `docs/dashboard-wireframes.md` | dashboard runners and `dashboard-ui-prototype/*.json` |
| Data model | `docs/data-model.sql.md`, `docs/sample-runtime-state.md` | JSON samples and SQL notes |
| Maintenance/readiness | `docs/maintenance-readiness-model.md`, `docs/agent-readiness-ledger.md`, `docs/sustainment-agent-sop.md`, `docs/resource-priority-policy.md` | `maintenance-readiness-runner.js`, `maintenance-dashboard-runner.js`, `schema-files/resource-status.schema.json`, `resource-budget-checker.js`, `tool-fallback-planner.js` |
| Knowledge management review | `docs/knowledge-management-sop.md`, `docs/handoff-packet-template.md` | `schema-files/decision-log.schema.json`, `schema-files/source-record.schema.json`, `km-review-runner.js`, `run-km-review-fixtures.js` |
| Repository-isolated artifacts | `docs/repository-artifact-isolation-policy.md`, `docs/knowledge-management-sop.md` | `repository-artifact-store.js`, `repository-lease.js`, `repository-artifact-verify.js`, `schema-files/repository-artifact-manifest.schema.json`, isolation/concurrency/recovery fixtures |
| Enforced dispatch, interruption, and resume | `docs/enforced-dispatch-and-resume.md`, `docs/skill-operational-mission-lifecycle.md` | `dispatch-runtime-controller.js`, `dispatch-hook-adapter.js`, `install-dispatch-hooks.js`, `run-dispatch-runtime-fixtures.js` |
| Protected gateway transaction, authenticated identity, bounded process/OCI sandbox execution, production admission, and recovery | `docs/protected-tool-gateway-contract.md`, `docs/gateway-identity-admission.md`, `docs/protected-process-execution.md`, `docs/oci-linux-sandbox-provider.md`, `docs/production-sandbox-admission.md`, `docs/repository-artifact-isolation-policy.md` | `protected-tool-gateway.js`, `gateway-identity-adapter.js`, `protected-process-executor.js`, `oci-linux-sandbox-provider.js`, `production-sandbox-admission-adapter.js`, protected operation wrappers, gateway/executor/sandbox/production fixture runners |
| Bounded self-improvement and active work evolution | `docs/bounded-self-improvement-operations.md`, `docs/sigstore-verifier-workload-admission.md`, `docs/verifier-execution-integrity.md`, `docs/github-actions-native-verifier-adapter.md`, `docs/gitlab-ci-native-verifier-adapter.md`, `docs/verifier-pre-dispatch-challenge.md`, `docs/verifier-independence-assurance.md`, `docs/transparency-operations.md`, `docs/evaluation-metrics.md`, `docs/runtime-automation-roadmap.md`, `docs/knowledge-management-sop.md` | `self-improvement-campaign-init.js`, `campaign-supervisor.js`, `verifier-trust-readiness.js`, `verifier-identity-evidence.js`, `sigstore-trusted-root.js`, `sigstore-verifier-identity-evidence.js`, `verifier-execution-evidence.js`, `verifier-execution-runner.js`, `github-actions-oidc.js`, `github-actions-oidc-runner.js`, `gitlab-ci-oidc.js`, `gitlab-ci-oidc-runner.js`, `verifier-challenge-set.js`, `verifier-independence.js`, `transparency-operations.js`, `transparency-operations-runner.js`, `verification-runner.js`, `verification-attestation-runner.js`, `comparative-evaluation-runner.js`, `comparative-evaluation-attestation-runner.js`, `autonomous-improvement-controller.js`, campaign/cycle-order/proof/trust/root/identity/runtime/execution/challenge/independence/transparency/admission/comparison schemas and fixtures |

## Validation Sets

| Change Type | Minimum Commands |
| --- | --- |
| Schema or sample | `node validator-cli-prototype/run-fixtures.js`, targeted `node validator-cli-prototype/validate.js ...` |
| Any runner | targeted `node run-...-fixtures.js`, then all `run-*.js` if shared logic changed |
| English-only corpus | `node .github/scripts/check-english-only.js` |
| Source-map or official URL | `node source-map-linter.js --write-report` |
| Release/authority/risk | `node run-authority-integration-fixtures.js`, `node run-release-integration-fixtures.js`, relevant lifecycle runner |
| GitHub release-immutability policy authorization or receipt | `node run-github-release-immutability-fixtures.js`, targeted policy authorization/receipt validation, publisher regression fixtures, direct CLI module-entry validation, Codex and Claude wrapper resolution, routing coverage |
| GitHub release-integrity policy, observation, attestation, trusted root, trust checkpoint, initial recovery, bundle, workflow, or monitor credential | `node run-github-release-independent-verification-fixtures.js`, `node run-github-release-trust-checkpoint-fixtures.js`, `node run-github-release-integrity-fixtures.js`, `node run-github-release-publisher-fixtures.js`, targeted policy/root/checkpoint/recovery/observation validation with explicit clocks, fresh first-attempt full provider run after credential changes, API-digest and exact-triplet replay, Codex and Claude wrapper resolution, routing coverage |
| Exact GitHub release authorization or receipt | `node run-github-release-independent-verification-fixtures.js`, `node run-github-release-trust-checkpoint-fixtures.js`, `node run-github-release-publisher-fixtures.js`, targeted authorization/receipt/root/checkpoint validation, direct CLI module-entry validation, Codex and Claude wrapper resolution, routing coverage |
| Orders/backbrief/rehearsal | `node runtime-demo-runner.js`, `node orders-dissemination-runner.js ...`, relevant routing fixture |
| Skill update | `node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --coverage .`, `python3 "${CODEX_HOME:-$HOME/.codex}/skills/.system/skill-creator/scripts/quick_validate.py" codex-skills/controls-doctrine-operator`, `python3 "${CODEX_HOME:-$HOME/.codex}/skills/.system/skill-creator/scripts/quick_validate.py" .claude/skills/controls-doctrine-operator`, review both diffs for equivalent operational semantics |
| Delegated agent routing | `node validator-cli-prototype/validate.js sample-payloads/valid-routing-receipt-agent-s3.json routing-receipt`, `node run-agent-routing-preflight-fixtures.js` |
| Operational skill lifecycle | `node run-skill-mission-controller-fixtures.js`, `node validator-cli-prototype/run-fixtures.js`, Codex and Claude route coverage |
| Dispatch policy, lease, hooks, or resume | `node run-dispatch-runtime-fixtures.js`, targeted validation of dispatch policy/lease/checkpoint samples, Codex and Claude route coverage |
| Protected gateway contract or controller | `node run-protected-tool-gateway-fixtures.js`, `node run-dispatch-runtime-fixtures.js`, `node validator-cli-prototype/run-fixtures.js`, Codex and Claude route coverage |
| Protected process policy, executor, or evidence | `node run-protected-process-executor-fixtures.js`, `node run-protected-tool-gateway-fixtures.js`, `node validator-cli-prototype/run-fixtures.js`, Codex and Claude route coverage |
| OCI Linux sandbox policy, provider, probe, or evidence | `CANNAE_REQUIRE_LIVE_OCI=1 node run-oci-linux-sandbox-provider-fixtures.js` for release/CI validation, `node run-protected-tool-gateway-fixtures.js`, `node validator-cli-prototype/run-fixtures.js`, Codex and Claude route coverage |
| Production sandbox policy, appraiser evidence, admission, managed gateway, or coordinator binding | `node run-production-sandbox-admission-fixtures.js`, `node run-production-sandbox-gateway-fixtures.js`, `node run-protected-tool-gateway-fixtures.js`, `node run-gateway-identity-adapter-fixtures.js`, `node validator-cli-prototype/run-fixtures.js`, Codex and Claude route coverage |
| Model allocation or routing | `node validator-cli-prototype/validate.js sample-payloads/valid-model-registry.json model-registry`, `node run-model-force-assignment-fixtures.js`, `node run-model-force-v0.2-fixtures.js` |
| Multi-repository artifacts | `node run-repository-artifact-isolation-fixtures.js`, `node run-repository-artifact-concurrency-fixtures.js`, `node run-repository-artifact-recovery-fixtures.js`, `node validator-cli-prototype/validate.js sample-payloads/valid-repository-artifact-manifest.json repository-artifact-manifest` |
| Bounded self-improvement | `node run-self-improvement-fixtures.js`, `node run-signed-self-improvement-fixtures.js`, `node run-campaign-supervisor-fixtures.js`, `node run-verifier-trust-readiness-fixtures.js`, `node run-verifier-identity-evidence-fixtures.js`, `node run-sigstore-verifier-identity-fixtures.js`, `node run-verifier-execution-evidence-fixtures.js`, `node run-github-actions-oidc-fixtures.js`, `node run-gitlab-ci-oidc-fixtures.js`, `node run-verifier-challenge-fixtures.js`, `node run-verifier-independence-fixtures.js`, `node run-transparency-operations-fixtures.js`, `node run-transparency-supervisor-fixtures.js`, `node run-workload-identity-admission-fixtures.js`, `node run-cycle-order-admission-fixtures.js`, `node run-verification-runner-fixtures.js`, `node run-verification-attestation-fixtures.js`, `node run-comparative-evaluation-fixtures.js`, `node run-comparative-evaluation-attestation-fixtures.js`, `node validator-cli-prototype/validate.js sample-payloads/valid-verifier-runtime-policy-v0.3.json verifier-runtime-policy`, `node validator-cli-prototype/validate.js sample-payloads/valid-github-actions-oidc-evidence.json github-actions-oidc-evidence`, `node validator-cli-prototype/validate.js sample-payloads/valid-gitlab-ci-oidc-evidence.json gitlab-ci-oidc-evidence`, `node validator-cli-prototype/validate.js sample-payloads/valid-verifier-challenge-set.json verifier-challenge-set`, `node validator-cli-prototype/validate.js sample-payloads/valid-transparency-state.json transparency-state` |
| GitHub/community infrastructure | `node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --coverage .`, `node .github/scripts/check-json.js`, `node .github/scripts/check-english-only.js`, `node .github/scripts/check-markdown-links.js`, `git diff --check` |
