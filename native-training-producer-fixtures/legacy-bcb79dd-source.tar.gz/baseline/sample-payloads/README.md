# Sample Payloads

The `order-analysis-response` and `operator-order-analysis` pairs are synthetic
proposed/held contract examples, not real model runs, owner decisions or independent
labels. Regenerate only these with
`node order-analysis-fixtures/write-schemas-and-samples.js`. Retained private
collector history must never be rewritten to acquire a different purpose.

The `bounded-planning-request` and `bounded-planning-proposal` pairs are synthetic
non-authorizing structural construction examples, not model strategy, real
readiness or USER consent. Regenerate these four only with
`node bounded-planning-fixtures/write-samples.js`; never rewrite retained producer
history to match a newer runtime.

The `requirement-inventory`, `semantic-coverage-proposal` and
`semantic-review-assignment` pairs are authored synthetic structural examples,
not real owner decisions, model assessments or independent calibration labels.
Regenerate only these six samples with
`node requirement-inventory-fixtures/write-samples.js`. Retained operational
history must not be rewritten to acquire a new review or provenance field.

The `operational-cop` pair is a synthetic empty read-product contract example,
not a live status report. The invalid record attempts release authority.
Actual Operations data comes only from authenticated verified-history replay.

The `dispatch-lease-issuance-request`, `dispatch-lease-issuance-resolution` and
`agent-dispatch-lease-issuance` pairs are synthetic structural examples for the
frozen transaction and lease v0.2. Their references do not identify a real
retained graph, native agent or USER approval. Regenerate only these samples
with `node dispatch-issuance-fixtures/write-samples.js`; never rewrite retained
operational evidence or treat a valid lease JSON as execution permission.

The eight `method-control-channel-policy`, `method-control-launch-slot`,
`method-control-session-observation`, `method-control-enrollment`,
`method-control-request`, `method-control-receipt`, `method-control-delivery`
and `method-control-response` pairs are synthetic structural examples, not
actual native-provider execution, USER consent or work outputs. Regenerate
them explicitly with `node method-control-fixtures/write-samples.js` after
reviewing runtime/lock changes; never rewrite retained operational evidence.
The additional three `*-continuation.json` pairs demonstrate policy v0.2,
versioned continuation slots and observed resume sources. Their synthetic
references are structural examples, not actual task or resume authorization.

`valid-github-release-independent-verification-pre-mcp-v0.2.json` preserves the
exact accepted `18b6e21` producer before the MCP dependency migration. Its bytes
and historical tuple remain unchanged; only the separately current sample is
regenerated through the pinned verification engine.

The method-control-baseline, method-deviation-event, initiative-deviation-report,
degeneration-incident-event, mission-wave-plan-methods and agent-context-pack-methods pairs are synthetic
non-authorizing examples. They bind exact task/method metadata and before/after
phases; only the separate live controller replays actual admissions, results,
SITREPs and revocation. Do not treat a valid sample as a USER decision or work
evidence. Regeneration is explicit through `disciplined-initiative-fixtures/`.

The valid/invalid `operator-reconciliation-authorization` and
`operator-reconciliation-record` pairs are synthetic non-authorizing terminal
audit metadata. `operator-reconciliation-fixtures/` holds their public key and
exact cancellation payload, never a private key. They illustrate cleanup after
old consent expiry without renewing it. They are not an admitted artifact
history, actual USER consent, tool permission or a hold-discharge command.

The valid/invalid `operator-consent-record` samples cover local authenticated
order-decision audit metadata, not real USER consent. The public fixture key and
matching decision payload are in `operator-consent-fixtures/`; no private signing
key is committed. Verify cryptography separately from schema validity.

The byte-identical `valid-github-release-independent-verification-pre-console-v0.2.json`
preserves producer `ad14016` before the local-console lockfile migration. Do not
rewrite it to match current hashes. The separately regenerated current sample
must match a fresh pinned-engine replay; the historical sample must replay
unchanged through that engine.

This directory contains valid and invalid runtime payload fixtures.

The commander-intent, intent-delegation-event, intent-continuity-projection,
mission-wave-plan-intent and agent-context-pack-intent pairs demonstrate mandatory
task commitments and narrowing-only hierarchy. They are synthetic wire examples,
not retained USER consent or tool authority. See the
[intent continuity procedure](../docs/intent-continuity-runtime.md).

`valid-mission-wave-termination-request.json` and
`valid-mission-wave-termination.json` show evidence-preserving expiry, not
successful execution. The unapproved-request and premature-termination invalid
samples enforce the decision and time boundaries. Replace sample references
with exact manifest entries before operation; the sample request and record
are independent structural examples, not an admitted history. Lifecycle
fixtures also exercise USER-bound abort/supersession, settled dispatch,
terminal retries, legacy evidence preservation, and denied reopening.

Use these examples to test:

- JSON Schema validation
- semantic validator rules
- tool-use ROE policy checks
- authority matrix validation
- decision packet validation
- working group charter validation
- AI special operations TF charter validation
- department collaboration charter validation
- force structure change order validation
- WARNO, battle-rhythm, METL, readiness-event, source-plan, context-release, resource-status, decision-log, source-record, and OPSEC label/review/alert validation
- model force assignment validation
- model registry and assignment request validation
- integrated mission preflight validation
- model usage event validation
- repository artifact manifest validation
- bounded self-improvement campaign, checkpoint, decision, and cycle-order validation
- verification plan and runtime-issued receipt validation
- verifier trust policy, SPIFFE/Sigstore workload identity, trusted-root, verifier runtime policy, execution evidence, signed verification attestation, and signed comparative report validation
- sealed comparative evaluation set, paired execution plan, and promotion report validation
- CCIR alert validation
- handoff packet validation
- continuity plan validation
- context item validation
- document access manifest validation
- doctrine consistency review validation
- release review validation
- release gate decision validation
- exact GitHub release authorization and terminal receipt validation
- GitHub release-immutability policy authorization and receipt validation
- GitHub release-integrity policy and continuous observation validation
- GitHub release initial-bootstrap recovery validation
- maintenance readiness validation
- backbrief validation
- rehearsal validation
- annex validation
- FRAGO scope-change validation
- information report validation
- intelligence assessment validation
- approval scope validation
- approval consumption event validation
- approval revocation event validation
- approval renewal event validation
- approval delegation event validation
- approval delegation revocation event validation
- risk acceptance validation
- AAR readiness update validation
- routing receipt validation
- capability-gap routing, provisional mission-cell, and force-structure control validation
- operational mission wave, context pack, mandatory control execution receipt, report, and closeout validation
- dispatch tool policy, agent lease, tool admission, and execution checkpoint validation
- gateway identity policy, one-use challenge, TLS principal evidence, and immutable identity-reference validation
- production sandbox policy, signed appraiser evidence, failure-domain quorum, managed admission, and release-boundary validation
- approval UI rendering
- AAR/readiness update logic
- agent routing preflight logic
- model force compilation and dispatch preflight logic
- repository-scoped JSON and file artifact isolation logic
- bounded self-improvement decision and persistence logic
- deterministic campaign reconstruction, finite retry/advance orders, terminal holds, and idempotent order persistence
- proof receipt integrity, shell prohibition, parent lineage, and approval-consumption logic
- Ed25519 key identity, DSSE statement binding, signature quorum, replay expiry, and receipt-content binding
- baseline-versus-candidate non-regression, harness identity, contamination control, and no-release comparison logic
- report-artifact digest, plan/set/lineage/evaluator binding, purpose-authorized keys, and independent comparative signature quorum
- native Sigstore bundle/root normalization, exact Fulcio identity/issuer, static-key dual binding, freshness, and nonzero transparency thresholds
- exact verifier code, OCI image, lockfile, harness, invocation, tool, network, sandbox, repository-state, target-digest, builder-signature, and verifier-signature validation
- manifest-pinned GitHub Actions and GitLab CI OIDC/JWKS identity, stable claim, protected workflow/config, token-time, clean-commit, and conservative failure-domain validation
- exact pre-dispatch challenge task/lineage binding, unique nonce issuance, dual-signed response freshness, deadline, ambiguity, and replay rejection
- provider/operator/control-plane/account/project/runner/infrastructure/region/zone correlation, transitive failure domains, and execution-bound quorum diversity
- signed checkpoint consistency, witness/monitor operator quorum, TUF root rotation, immutable transparency incident history, and continuous v0.7 admission

Fixture convention:

- `valid-*.json`: should pass JSON Schema validation.
- `invalid-*.json`: should fail JSON Schema or semantic validation.

The invalid examples are intentionally small so the expected failure is obvious.

`valid-verifier-execution-evidence.json` is a schema and semantic-validation example with structurally valid placeholder signature bytes. Use `run-verifier-execution-evidence-fixtures.js`, which generates real ephemeral Ed25519 keys and signatures, for cryptographic verification behavior.

`valid-verifier-trust-policy-v0.5.json`, `valid-verifier-challenge-set.json`, and `valid-self-improvement-cycle-order-v0.5.json` are independent schema examples of the Phase 12B policy, issued challenge, and satisfied admission contracts; they are not one mutually linked artifact-store history. `invalid-verifier-challenge-set-authority.json` proves that a challenge cannot grant release authority. Use `run-verifier-challenge-fixtures.js` for a coherent manifest-backed policy, issuer-signed challenge, real dual-signed nonce responses, and supervisor round-trip behavior.

The `*-v0.6.json` trust-policy/cycle-order samples and `*-v0.2.json` runtime/execution samples show Phase 12C contracts. The missing-domain and domain-substitution samples fail closed. Use `run-verifier-independence-fixtures.js` for real ephemeral keys, dual-signed execution evidence, transitive correlation, and post-execution quorum behavior.

The `*-v0.7.json` trust-policy and cycle-order samples show Phase 13 continuous transparency admission. The transparency policy, observation, root rotation, incident, and state samples are one coherent generated evidence family. Use `run-transparency-operations-fixtures.js` for real ephemeral log/witness/monitor/TUF signatures and `run-transparency-supervisor-fixtures.js` for repository-manifest rejection behavior.

The GitHub and GitLab native OIDC samples show Phase 14 trust-bundle, projected-evidence, and runtime-policy contracts. Use `run-github-actions-oidc-fixtures.js` and `run-gitlab-ci-oidc-fixtures.js` for real ephemeral RSA signatures, provider-specific adversarial claims, common execution-evidence admission, and missing-manifest-evidence rejection.

The mission lifecycle samples show the plan an operator supplies and the context, controller-issued control receipt, report, and closeout contracts used by `skill-mission-controller.js`. Routing receipt and context-pack v0.2 preserve a separate mission capability query; an unmatched query creates a bounded provisional cell and a standing-department candidate while keeping activation and authority expansion false. `invalid-routing-receipt-capability-gap-bypass.json` proves that acknowledging the gap without routing force-structure doctrine and its fixture gate fails closed. The other invalid examples prove that an AI cannot become final decision authority, forge a passing control receipt, request release in a wave report, or turn a closeout into release approval. Use `run-skill-control-enforcement-fixtures.js` for allowlist, shell, failure, timeout, and state-binding behavior, and `run-skill-mission-controller-fixtures.js` for real temporary Git repositories, generated routing receipts, controller-executed controls, manifest-backed evidence, model-preflight binding, AAR follow-on work, and repository isolation.

The enforced-dispatch samples form a reference controller-authorized policy, lease, baseline checkpoint, and admitted tool event. Their unsafe counterparts cover a self-declared issuer, traversal or mixed matcher fields, lease budget and clean-start drift, malformed none sentinels, allow-without-rule, deny-without-reason, invalid checkpoint chains, active terminal state, unresolved effects, and authority expansion. Use `run-dispatch-runtime-fixtures.js` for mission-plan draft authorization, concurrent one-agent issuance, ordered cross-agent repository handoff, exact post-tool binding, replay denial, repository-state drift, unresolved-effect reconciliation, revocation, interruption, and explicit lineage-continuation behavior.

The protected-gateway samples define the Phase 17A request, decision, receipt, and append-only transaction-event contracts. Receipt v0.4 cites exact bounded-process or OCI policy/envelope/observation references while other modes retain exact none sentinels; v0.5 additionally binds managed production admission and deployment verification. The Phase 17B1 identity samples add the gateway identity policy, signed challenge, and signed TLS principal-evidence contracts. Phase 17B2A adds the protected executor policy, minimal native-executable policy/rule tool input, signed pre-execution envelope, and signed post-execution observation. Phase 17B2B adds OCI policy, tool input, envelope, direct probe, and terminal observation. Phase 17B2C1 adds production policy, signed appraiser evidence, and quorum admission. Invalid examples cover managed-assurance mismatch, mixed identity or executor references, audience and validity drift, raw-input retention, policy/authority overclaim, stale challenge, unbound certificate projection, incomplete commit, unbound execution evidence, inconsistent output/process state, broken transition, correlated or inconsistent deployment evidence, admission expiry, and authority expansion. These static samples are structural examples rather than one mutually linked manifest history.

The GitHub release samples define the terminal Phase 18 exception to the
otherwise false release boundary. The valid authorization carries true only
for one USER-granted repository/tag/commit/main-CI/notes tuple; the invalid
authorization proves that AI approval cannot enter the boundary. The valid
receipt binds the resolved tag commit and consumed authorization, while the
invalid receipt proves that a repaired digest cannot hide tag drift. Use
`run-github-release-publisher-fixtures.js` for state reappraisal, expiry,
tamper, publication, and idempotency behavior without network access. The
small static files remain historical v0.1 compatibility examples; the runner
generates and schema-validates the active v0.5 checkpoint/root-bound
authorization and receipt.

The GitHub release-immutability samples define the Phase 19A repository-policy
boundary. The valid authorization binds one disabled-to-enabled ADMIN action
to the exact repository, clean main commit, successful CI, endpoint, latest
release, USER grant, and expiry while release stays false. The invalid
authorization proves that a repaired digest cannot legitimize AI approval.
The valid receipt records an actual HTTP 204 and verified enabled state while
preserving the historical release's non-immutable status; the invalid receipt
proves that policy execution cannot claim release authority. Use
`run-github-release-immutability-fixtures.js` for activation, retry, drift, and
post-action verification behavior without network access.

The GitHub release-integrity samples define the historical Phase 19B read-only
monitoring boundary. The active fixture runner generates policy/observation
v0.3 with Phase 19C independent verification and Phase 19D predecessor
checkpoint continuity. The static valid observation records an enabled live
policy and unchanged baseline while keeping policy mutation and release false.
The invalid samples show that neither contract can be repaired into mutation
or release authority.
Use `run-github-release-integrity-fixtures.js` for policy drift, credential
uncertainty, mutable future releases, GitHub attestation commit substitution,
missing or changed baseline releases, uncommitted-policy substitution, stale
default-branch state, parent-symlink output escape, bounded retry, and exact
release-event scope.

The Phase 19E bootstrap-recovery samples define the only partial initial
checkpoint exception. The valid contract binds one exact USER grant, policy
introduction, sequence-zero checkpoint/root, failed run, retained artifact,
and blocked observation while reset and release remain false. The invalid
sample proves that AI authority cannot enter this path. Use
`run-github-release-trust-checkpoint-fixtures.js` for exact run-set,
current-run, expiry, missing-authorization, and normal-lineage behavior.

Use `run-protected-tool-gateway-fixtures.js` for coherent contract-reference authorization, idempotency, exact begin/commit correlation, pre-execution cancellation, and unknown-outcome recovery. Use `run-gateway-identity-adapter-fixtures.js` for a real TLS 1.3 mTLS handshake, SPIFFE X.509 chain, equal endpoint exporter proof, Ed25519 challenge/evidence signatures, manifest-backed gateway commit, and adversarial expiry, replay, revocation, tamper, challenge-reuse, and certificate-substitution rejection. Use `run-protected-process-executor-fixtures.js` for real exact process execution, signed before/after evidence, caller-result rejection, executable drift, timeout, no-rerun recovery, and forbidden repository-effect rejection. Use `run-oci-linux-sandbox-provider-fixtures.js` for measured container execution and no-rerun recovery. Use `run-production-sandbox-admission-fixtures.js` for cryptographic quorum/admission behavior and `run-production-sandbox-gateway-fixtures.js` for actual mTLS identity, exact production scope, external coordinator enforcement, and v0.5 terminal projection.
