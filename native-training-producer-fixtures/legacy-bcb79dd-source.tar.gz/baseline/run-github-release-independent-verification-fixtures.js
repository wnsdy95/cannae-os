#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");
const {
  CURRENT_EVIDENCE_VERSION,
  CURRENT_SIGSTORE_VERIFY_VERSION,
  HISTORICAL_VERIFIER_PROFILES,
  independentVerificationDigest,
  validateIndependentVerificationEvidence,
  verifyGitHubReleaseBundle
} = require("./github-release-bundle-verifier");
const {
  sha256,
  trustedRootArtifactDigest,
  validateGitHubReleaseTrustedRoot
} = require("./github-release-trusted-root");
const {
  validatePayload
} = require("./validator-cli-prototype/validate");
const {
  findRuntimeRoot: findCodexRuntimeRoot
} = require(
  "./codex-skills/controls-doctrine-operator/scripts/operate_github_release_verification"
);
const {
  findRuntimeRoot: findClaudeRuntimeRoot
} = require(
  "./.claude/skills/controls-doctrine-operator/scripts/operate_github_release_verification"
);

const FIXTURE_DIRECTORY = path.join(
  __dirname,
  "github-release-independent-verification-fixtures"
);
const RAW_VERIFICATION_PATH = path.join(
  FIXTURE_DIRECTORY,
  "cli-v2.93.0-release-verification.json"
);
const TRUSTED_ROOT_PATH = path.join(
  FIXTURE_DIRECTORY,
  "github-trusted-root.json"
);
const VERIFIED_AT = "2026-07-27T00:05:00.000Z";
const EXPECTED = Object.freeze({
  repository: "cli/cli",
  tagName: "v2.93.0",
  commitSha: "f96972ce1c11fdb8eaa556257fde962a363dffde"
});
const RAW_FIXTURE_SHA256 =
  "1f8402869f4361c61dd25f17c6f6585394548afe70306ddc98175e3b6faa9d1c";
const ROOT_FIXTURE_SHA256 =
  "7594e70efc1cd9e94ca96d608b5b1ac22428b28bf5df0e60756747745201e131";

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function expectError(name, expectedCode, callback) {
  try {
    callback();
    return {
      name,
      ok: false,
      detail: `expected ${expectedCode}, operation succeeded`
    };
  } catch (error) {
    return {
      name,
      ok: error.code === expectedCode,
      detail: `${error.code || error.name}: ${error.message}`
    };
  }
}

function mutateEncodedJson(encoded, callback) {
  const document = JSON.parse(
    Buffer.from(encoded, "base64").toString("utf8")
  );
  callback(document);
  return Buffer.from(JSON.stringify(document), "utf8").toString("base64");
}

function braceDependencyRegressions() {
  // Keep hostile parser inputs outside the fixture runner's own event loop.
  const cases = [
    ["deep comma groups do not exhaust the parser stack", `
      const input = "{" + "{a},".repeat(10000) + "b}";
      const result = expand(input);
      assert.equal(result.length, 10001);
      assert.equal(result[0], "{a}");
      assert.equal(result.at(-1), "b");
      expand(input, { max: 1, maxLength: 1 });
    `],
    ["large comma arrays do not overflow argument spreading", `
      const result = expand("{{x}," + "a,".repeat(200000) + "b}");
      assert.equal(result.length, 100000);
      assert.equal(result[0], "{x}");
      assert.equal(result.at(-1), "a");
    `],
    ["both nested-set paths stop before stack exhaustion", `
      for (const input of [
        "{a,".repeat(10000) + "z" + "}".repeat(10000),
        "{".repeat(10000) + "a,b" + "}".repeat(10000)
      ]) assert.ok(expand(input).length > 0);
      assert.deepEqual(expand("{a,{b,c}}", { maxDepth: 0 }), ["a", "{b,c}"]);
      assert.deepEqual(expand("x{{a,b}}y", { maxDepth: 0 }), ["x{{a,b}}y"]);
    `],
    ["rewrite budget prevents the quadratic rescan payload", `
      assert.deepEqual(expand("{a},b}", { maxRewrites: 0 }), ["{a},b}"]);
      const result = expand("{a}" + "}".repeat(128000) + ",z}");
      assert.equal(result.length, 1);
      assert.ok(result[0].startsWith("{a}"));
      expand("{a}" + "}".repeat(128000) + ",z}", { max: 1, maxLength: 1 });
    `],
    ["ordinary glob and expansion semantics remain unchanged", `
      assert.deepEqual(expand("src/{a,{b,c}}.{js,ts}"), [
        "src/a.js", "src/a.ts", "src/b.js", "src/b.ts", "src/c.js", "src/c.ts"
      ]);
      assert.deepEqual(expand("{a},b}"), ["a}", "b"]);
      const { minimatch } = require("minimatch");
      assert.equal(minimatch("src/b.ts", "src/{a,{b,c}}.{js,ts}"), true);
      assert.equal(minimatch("src/d.ts", "src/{a,{b,c}}.{js,ts}"), false);
    `]
  ];
  return cases.map(([name, program]) => {
    const child = spawnSync(process.execPath, ["-e", `
      const assert = require("node:assert/strict");
      const { expand } = require("brace-expansion");
      ${program}
    `], { cwd: __dirname, encoding: "utf8", timeout: 15000, maxBuffer: 65536 });
    return { name: `patched brace dependency: ${name}`, ok: child.status === 0 && !child.error,
      detail: child.error ? child.error.code : child.stderr.trim() };
  });
}

function ipZoneDependencyRegressions() {
  const cases = [
    ["the installed parser and lock both pin the reviewed patch", `
      assert.equal(require("ip-address/package.json").version, "10.7.4");
      assert.equal(require("./package-lock.json").packages["node_modules/ip-address"].version, "10.7.4");
    `],
    ["isValid rejects large zones with each line terminator within the child deadline", `
      for (const end of ["\\n", "\\r", "\\u2028", "\\u2029", "\\ntrailer"]) {
        assert.equal(Address6.isValid("%".repeat(160000) + end), false);
      }
    `],
    ["constructor retains typed rejection for large invalid zones", `
      for (const end of ["\\n", "\\r", "\\u2028", "\\u2029", "\\rtrailer"]) {
        assert.throws(() => new Address6("%".repeat(160000) + end), error => error.name === "AddressError");
      }
    `],
    ["ordinary zones and CIDR keep exact parsing semantics", `
      for (const zone of ["%eth0", "%en0%extra", "%zone-with-space "]) {
        const address = new Address6("fe80::1" + zone + "/64");
        assert.equal(address.zone, zone); assert.equal(address.correctForm(), "fe80::1"); assert.equal(address.subnetMask, 64);
      }
      assert.equal(new Address6("2001:db8::1/128").zone, "");
    `],
    ["long valid zones are not truncated or rejected by a blanket input cap", `
      const zone = "%" + "x".repeat(160000), address = new Address6("fe80::1" + zone);
      assert.equal(address.zone, zone); assert.equal(address.correctForm(), "fe80::1");
    `],
    ["equal-size non-zone and unterminated controls still reject", `
      assert.equal(Address6.isValid("!".repeat(160000) + "\\n"), false);
      assert.equal(Address6.isValid("%".repeat(160000)), false);
    `],
    ["library parsing no longer calls the retained deprecated zone regex", `
      const { RE_ZONE_STRING } = require("ip-address/dist/v6/constants"); let invoked = false;
      RE_ZONE_STRING.exec = () => { invoked = true; throw new Error("DEPRECATED_ZONE_REGEX_CALLED"); };
      assert.equal(new Address6("fe80::1%eth0").zone, "%eth0");
      assert.equal(Address6.isValid("%".repeat(160000) + "\\n"), false); assert.equal(invoked, false);
    `]
  ];
  return cases.map(([name, program]) => {
    const child = spawnSync(process.execPath, ["--max-old-space-size=128", "-e", `
      const assert = require("node:assert/strict"), { Address6 } = require("ip-address");
      ${program}
    `], { cwd: __dirname, env: { PATH: process.env.PATH, LANG: "C.UTF-8" }, encoding: "utf8", timeout: 2500, maxBuffer: 65536 });
    return { name: `patched IP-zone dependency: ${name}`, ok: child.status === 0 && !child.error,
      detail: child.error ? child.error.code : child.stderr.trim() };
  });
}

function runFixtures() {
  const results = [...braceDependencyRegressions(), ...ipZoneDependencyRegressions()];
  const { Address6 } = require("ip-address");
  for (const address of ["64:ff9b:1::", "64:ff9b:1:7f00:0:100::", "64:ff9b:1::7f00:1", "64:ff9b:1:ffff:ffff:ffff:ffff:ffff"]) {
    const parsed = new Address6(address);
    results.push({ name: `patched dependency classifies NAT64 local-use ${address} as private`,
      ok: parsed.isPrivate() === true && parsed.isGlobal() === false });
  }
  results.push({ name: "NAT64 regression does not misclassify an ordinary public IPv6 address",
    ok: new Address6("2001:4860:4860::8888").isPrivate() === false &&
      new Address6("2001:4860:4860::8888").isGlobal() === true });
  const rawBytes = fs.readFileSync(RAW_VERIFICATION_PATH);
  const rootBytes = fs.readFileSync(TRUSTED_ROOT_PATH);
  const rawVerification = JSON.parse(rawBytes.toString("utf8"));
  const trustedRoot = JSON.parse(rootBytes.toString("utf8"));

  results.push({
    name: "public release and retained TUF fixtures keep exact file digests",
    ok: sha256(rawBytes) === RAW_FIXTURE_SHA256 &&
      sha256(rootBytes) === ROOT_FIXTURE_SHA256
  });

  results.push({
    name: "retained GitHub TUF chain replays offline and remains schema valid",
    ok: validateGitHubReleaseTrustedRoot(trustedRoot, {
      evaluatedAt: VERIFIED_AT
    }).length === 0 &&
      validatePayload(
        trustedRoot,
        "github-release-trusted-root",
        { evaluatedAt: VERIFIED_AT }
      ).valid === true
  });

  {
    const withoutClock = validatePayload(
      trustedRoot,
      "github-release-trusted-root"
    );
    results.push({
      name: "trusted-root validation requires an explicit evaluation clock",
      ok: withoutClock.valid === false &&
        withoutClock.issues.some(item =>
          item.code ===
            "GITHUB_RELEASE_TRUST_EVALUATION_TIME_REQUIRED")
    });
  }

  {
    const withoutClock = spawnSync(process.execPath, [
      path.join(__dirname, "github-release-trusted-root.js"),
      "verify",
      "--input",
      TRUSTED_ROOT_PATH
    ], { encoding: "utf8" });
    const withClock = spawnSync(process.execPath, [
      path.join(__dirname, "github-release-trusted-root.js"),
      "verify",
      "--input",
      TRUSTED_ROOT_PATH,
      "--evaluated-at",
      VERIFIED_AT
    ], { encoding: "utf8" });
    results.push({
      name: "trusted-root CLI requires and consumes an explicit clock",
      ok: withoutClock.status === 1 &&
        withoutClock.stderr.includes(
          "GITHUB_RELEASE_TRUST_EVALUATION_TIME_REQUIRED"
        ) &&
        withClock.status === 0 &&
        JSON.parse(withClock.stdout).valid === true
    });
  }

  {
    const withoutClock = spawnSync(process.execPath, [
      path.join(__dirname, "validator-cli-prototype", "validate.js"),
      TRUSTED_ROOT_PATH,
      "github-release-trusted-root"
    ], { encoding: "utf8" });
    const withClock = spawnSync(process.execPath, [
      path.join(__dirname, "validator-cli-prototype", "validate.js"),
      TRUSTED_ROOT_PATH,
      "github-release-trusted-root",
      "--evaluated-at",
      VERIFIED_AT
    ], { encoding: "utf8" });
    const output = JSON.parse(withoutClock.stdout);
    const validOutput = JSON.parse(withClock.stdout);
    results.push({
      name: "generic validator requires and consumes an explicit root clock",
      ok: withoutClock.status === 1 && output.valid === false &&
        output.issues.some(item =>
          item.code ===
            "GITHUB_RELEASE_TRUST_EVALUATION_TIME_REQUIRED") &&
        withClock.status === 0 && validOutput.valid === true
    });
  }

  {
    const issues = validateGitHubReleaseTrustedRoot(trustedRoot, {
      evaluatedAt: VERIFIED_AT,
      requiredValidUntil: "2026-08-03T02:00:00.000Z"
    });
    results.push({
      name: "trusted root must remain valid through a preflighted operation window",
      ok: issues.some(item =>
        item.code === "GITHUB_RELEASE_TUF_METADATA_VALIDITY_TOO_SHORT") &&
        issues.some(item =>
          item.code === "GITHUB_RELEASE_TRUST_VALIDITY_TOO_SHORT")
    });
  }

  {
    const attacked = clone(trustedRoot);
    attacked.source.fetched_at = "2026-08-03T01:30:00.000Z";
    attacked.artifact_sha256 = trustedRootArtifactDigest(attacked);
    const evaluatedAt = "2026-08-03T02:30:00.000Z";
    const issues = validateGitHubReleaseTrustedRoot(attacked, {
      evaluatedAt
    });
    const bundleResult = expectError(
      "expired signed TUF metadata cannot remain usable within wrapper age",
      "GITHUB_RELEASE_TUF_METADATA_EXPIRED",
      () => verifyGitHubReleaseBundle({
        rawVerification,
        trustedRoot: attacked,
        expected: EXPECTED,
        verifiedAt: evaluatedAt
      })
    );
    results.push({
      ...bundleResult,
      ok: bundleResult.ok && issues.some(item =>
        item.code === "GITHUB_RELEASE_TUF_METADATA_EXPIRED")
    });
  }

  const evidence = verifyGitHubReleaseBundle({
    rawVerification,
    trustedRoot,
    expected: EXPECTED,
    verifiedAt: VERIFIED_AT
  });
  results.push({
    name: "independent verifier validates the real GitHub release bundle",
    ok: evidence.cryptographic_verification_succeeded === true &&
      evidence.schema_version === CURRENT_EVIDENCE_VERSION &&
      evidence.verifier.version === CURRENT_SIGSTORE_VERIFY_VERSION &&
      evidence.statement.repository === EXPECTED.repository &&
      evidence.statement.tag_name === EXPECTED.tagName &&
      evidence.statement.commit_sha1 === EXPECTED.commitSha &&
      evidence.bundle.tlog_entry_count === 0 &&
      evidence.bundle.rfc3161_timestamp_count === 1 &&
      evidence.cli_cross_check.statement_equal === true &&
      evidence.authority.human_final_decision_authority === "USER" &&
      evidence.release_authorized === false &&
      evidence.verification_sha256 ===
        independentVerificationDigest(evidence) &&
      validatePayload(
        evidence,
        "github-release-independent-verification"
      ).valid === true
  });

  results.push({
    name: "retained evidence exactly equals an independent cryptographic replay",
    ok: validateIndependentVerificationEvidence(
      evidence,
      rawVerification,
      trustedRoot,
      EXPECTED
    ).length === 0
  });
  results.push({ name: "the current v0.2 sample matches the installed producer and complete fresh replay",
    ok: JSON.stringify(JSON.parse(fs.readFileSync(path.join(__dirname,
      "sample-payloads/valid-github-release-independent-verification-v0.2.json"), "utf8"))) === JSON.stringify(evidence) });

  function historicalEvidence(profile = HISTORICAL_VERIFIER_PROFILES[0]) {
    const historical = clone(evidence);
    historical.schema_version = profile.schema_version;
    historical.verifier.version = profile.version;
    historical.verifier.module_sha256 = profile.module_sha256;
    historical.verifier.dependency_lock_sha256 = profile.dependency_lock_sha256;
    historical.verification_sha256 = independentVerificationDigest(historical);
    return historical;
  }

  for (const profile of HISTORICAL_VERIFIER_PROFILES) {
    const historical = historicalEvidence(profile);
    const retainedBytes = JSON.stringify(historical);
    results.push({
      name: `current engine replays exact historical source profile ${profile.commit.slice(0, 7)} without rewriting it`,
      ok: validatePayload(historical, "github-release-independent-verification").valid &&
        validatePayload(historical, "github-release-independent-verification").can_execute === false &&
        validateIndependentVerificationEvidence(historical, rawVerification, trustedRoot, EXPECTED).length === 0 &&
        JSON.stringify(historical) === retainedBytes
    });
  }

  const preConsolePath = path.join(__dirname, "sample-payloads/valid-github-release-independent-verification-pre-console-v0.2.json");
  const preConsoleBytes = fs.readFileSync(preConsolePath);
  results.push({ name: "byte-identical pre-console producer sample replays after the HTTP dependency migration",
    ok: sha256(preConsoleBytes) === "0b3689ca33ac2741aa75fc136739ab1d5a919ee1a0bb645ee012d622340637f8" &&
      validateIndependentVerificationEvidence(JSON.parse(preConsoleBytes), rawVerification, trustedRoot, EXPECTED).length === 0 &&
      fs.readFileSync(preConsolePath).equals(preConsoleBytes) });

  const preBracePath = path.join(__dirname,
    "sample-payloads/valid-github-release-independent-verification-pre-brace-v0.2.json");
  const preBraceBytes = fs.readFileSync(preBracePath);
  const preBrace = JSON.parse(preBraceBytes);
  results.push({ name: "byte-identical accepted pre-brace producer replays without rewriting historical evidence",
    ok: sha256(preBraceBytes) === "860ab0f98826f58d8ea44d42d4fd3fab03d87cc689f32190ef4c8fa70e20939a" &&
      preBrace.verifier.module_sha256 === "485cdefe3640bde3365c30bc7c4d3fe35ccd29020429cae3a4078bf909ef3055" &&
      preBrace.verifier.dependency_lock_sha256 === "024545143f72f7007f2ce54ae5b19f8fa5748bf6df07016224e94ab92ebf30dd" &&
      validatePayload(preBrace, "github-release-independent-verification").valid === true &&
      validateIndependentVerificationEvidence(preBrace, rawVerification, trustedRoot, EXPECTED).length === 0 &&
      fs.readFileSync(preBracePath).equals(preBraceBytes) });

  const preMcpPath = path.join(__dirname, "sample-payloads/valid-github-release-independent-verification-pre-mcp-v0.2.json");
  const preMcpBytes = fs.readFileSync(preMcpPath);
  results.push({ name: "byte-identical accepted pre-MCP producer replays after the transport dependency migration",
    ok: sha256(preMcpBytes) === "e2c7bd72279cd6af7d3423cb1595402c655049a61624ab74b847cf178720cf0e" &&
      validateIndependentVerificationEvidence(JSON.parse(preMcpBytes), rawVerification, trustedRoot, EXPECTED).length === 0 &&
      fs.readFileSync(preMcpPath).equals(preMcpBytes) });

  const preZonePath = path.join(__dirname, "sample-payloads/valid-github-release-independent-verification-pre-zone-v0.2.json");
  const preZoneBytes = fs.readFileSync(preZonePath), preZone = JSON.parse(preZoneBytes);
  results.push({ name: "byte-identical accepted pre-zone producer replays under the patched parser without mutation",
    ok: sha256(preZoneBytes) === "874ab43758c1a312e9cb45a2dbe675bb3738d9a09ac48b562b494b154ebdc484" &&
      preZone.verifier.module_sha256 === "012795a0c4cb6d63e0b4ad18edc9495db4732a54994cea534f38a279184a69c3" &&
      preZone.verifier.dependency_lock_sha256 === "ef9fcf979ddc996bf9b2808d7f565264bedd8d45319bc6baae2f19510a9589f3" &&
      validatePayload(preZone, "github-release-independent-verification").valid === true &&
      validateIndependentVerificationEvidence(preZone, rawVerification, trustedRoot, EXPECTED).length === 0 &&
      fs.readFileSync(preZonePath).equals(preZoneBytes) });

  const priorBytes = fs.readFileSync(path.join(__dirname,
    "sample-payloads/valid-github-release-independent-verification-prior-v0.2.json"));
  const prior = JSON.parse(priorBytes);
  results.push({ name: "unchanged retained v0.2 sample survives the dependency and verifier-module migration",
    ok: sha256(priorBytes) === "0ff6f52dc6667d7db3ad2ecfbbb7f8fa2d6aa9cafe200bed47ca5c6448a4ad68" &&
      prior.schema_version === "0.2" && prior.verifier.module_sha256 !== evidence.verifier.module_sha256 &&
      prior.verifier.dependency_lock_sha256 !== evidence.verifier.dependency_lock_sha256 &&
      validateIndependentVerificationEvidence(prior, rawVerification, trustedRoot, EXPECTED).length === 0 &&
      fs.readFileSync(path.join(__dirname, "sample-payloads/valid-github-release-independent-verification-prior-v0.2.json")).equals(priorBytes) });

  for (const profile of HISTORICAL_VERIFIER_PROFILES) {
    for (const [field, value] of [
      ["module_sha256", "0".repeat(64)], ["dependency_lock_sha256", "0".repeat(64)],
      ["version", "4.1.1"], ["minimum_version", "4.0.0"],
      ["node_minimum_version", "18.0.0"], ["package", "unrecognized-verifier"], ["override", true]
    ]) {
      const attacked = historicalEvidence(profile);
      attacked.verifier[field] = value;
      attacked.verification_sha256 = independentVerificationDigest(attacked);
      results.push({
        name: `historical ${profile.commit.slice(0, 7)} producer substitution in ${field} is denied even with a valid bundle`,
        ok: validateIndependentVerificationEvidence(attacked, rawVerification, trustedRoot, EXPECTED)
          .some(item => item.code === "GITHUB_RELEASE_INDEPENDENT_PRODUCER_UNRECOGNIZED")
      });
    }
    const hybrid = historicalEvidence(profile);
    hybrid.verifier.dependency_lock_sha256 = evidence.verifier.dependency_lock_sha256;
    hybrid.verification_sha256 = independentVerificationDigest(hybrid);
    results.push({ name: `historical ${profile.commit.slice(0, 7)} module cannot adopt the current lockfile identity`,
      ok: validateIndependentVerificationEvidence(hybrid, rawVerification, trustedRoot, EXPECTED)
        .some(item => item.code === "GITHUB_RELEASE_INDEPENDENT_PRODUCER_UNRECOGNIZED") });
  }

  for (const profile of HISTORICAL_VERIFIER_PROFILES) {
    const attacked = historicalEvidence(profile);
    attacked.statement.commit_sha1 = "0".repeat(40);
    attacked.verification_sha256 = independentVerificationDigest(attacked);
    results.push({
      name: `recognized historical ${profile.commit.slice(0, 7)} metadata does not bless changed signed claims`,
      ok: validateIndependentVerificationEvidence(attacked, rawVerification, trustedRoot, EXPECTED)
        .some(item => item.code === "GITHUB_RELEASE_INDEPENDENT_EVIDENCE_REPLAY_MISMATCH")
    });
  }

  for (const profile of HISTORICAL_VERIFIER_PROFILES) {
    const attacked = clone(rawVerification);
    attacked.attestation.bundle.dsseEnvelope.payload = mutateEncodedJson(
      attacked.attestation.bundle.dsseEnvelope.payload,
      statement => { statement.predicate.repository = "attacker/repository"; }
    );
    results.push({
      name: `historical ${profile.commit.slice(0, 7)} replay must pass the current cryptographic engine`,
      ok: validateIndependentVerificationEvidence(historicalEvidence(profile), attacked, trustedRoot, EXPECTED)
        .some(item => item.code === "GITHUB_RELEASE_INDEPENDENT_CRYPTOGRAPHIC_VERIFICATION_FAILED")
    });
  }

  for (const profile of HISTORICAL_VERIFIER_PROFILES) {
    const attacked = historicalEvidence(profile);
    attacked.schema_version = profile.schema_version === "0.1" ? "0.2" : "0.1";
    attacked.verification_sha256 = independentVerificationDigest(attacked);
    results.push({ name: `historical ${profile.commit.slice(0, 7)} identity cannot change its evidence schema`,
      ok: validateIndependentVerificationEvidence(attacked, rawVerification, trustedRoot, EXPECTED)
        .some(item => item.code === "GITHUB_RELEASE_INDEPENDENT_PRODUCER_UNRECOGNIZED") });
  }
  {
    const attacked = clone(prior);
    attacked.verifier.dependency_lock_sha256 = evidence.verifier.dependency_lock_sha256;
    attacked.verification_sha256 = independentVerificationDigest(attacked);
    results.push({ name: "a former module and current lockfile are not an approved hybrid producer",
      ok: validateIndependentVerificationEvidence(attacked, rawVerification, trustedRoot, EXPECTED)
        .some(item => item.code === "GITHUB_RELEASE_INDEPENDENT_PRODUCER_UNRECOGNIZED") });
  }

  for (const [version, producer] of [["0.1", "4.1.2"], ["0.2", "4.1.0"]]) {
    const attacked = clone(evidence);
    attacked.schema_version = version;
    attacked.verifier.version = producer;
    attacked.verification_sha256 = independentVerificationDigest(attacked);
    results.push({
      name: `schema ${version} cannot claim producer ${producer}`,
      ok: validatePayload(attacked, "github-release-independent-verification").issues
        .some(item => item.code === "CONST_MISMATCH") &&
        validateIndependentVerificationEvidence(attacked, rawVerification, trustedRoot, EXPECTED).length > 0
    });
  }

  {
    const packagePath = path.resolve(path.dirname(require.resolve("@sigstore/verify")), "..", "package.json");
    const readFileSync = fs.readFileSync;
    const prototype = require("@sigstore/verify").Verifier.prototype;
    const verify = prototype.verify;
    let engineInvoked = false;
    try {
      prototype.verify = function() {
        engineInvoked = true;
        throw new Error("The version gate must run before cryptographic input processing.");
      };
      fs.readFileSync = function(file, ...args) {
        const content = readFileSync.call(this, file, ...args);
        if (typeof file === "string" && path.resolve(file) === packagePath) {
          const manifest = JSON.parse(content);
          manifest.version = "4.1.0";
          return JSON.stringify(manifest);
        }
        return content;
      };
      const result = expectError(
        "historical evidence support cannot make the old runtime eligible for fresh verification",
        "GITHUB_RELEASE_INDEPENDENT_VERIFIER_VERSION_UNSUPPORTED",
        () => verifyGitHubReleaseBundle({ rawVerification, trustedRoot, expected: EXPECTED, verifiedAt: VERIFIED_AT })
      );
      results.push({ ...result, ok: result.ok && !engineInvoked });
    } finally {
      fs.readFileSync = readFileSync;
      prototype.verify = verify;
    }
  }

  {
    const attacked = clone(trustedRoot);
    attacked.source.tuf_evidence.root_chain_base64.pop();
    attacked.artifact_sha256 = trustedRootArtifactDigest(attacked);
    results.push({
      name: "missing root rotation version is rejected",
      ok: validateGitHubReleaseTrustedRoot(attacked, {
        evaluatedAt: VERIFIED_AT
      }).some(item =>
        item.code === "GITHUB_RELEASE_TUF_ROOT_CHAIN_INVALID")
    });
  }

  {
    const attacked = clone(trustedRoot);
    const finalIndex =
      attacked.source.tuf_evidence.root_chain_base64.length - 1;
    attacked.source.tuf_evidence.root_chain_base64[finalIndex] =
      mutateEncodedJson(
        attacked.source.tuf_evidence.root_chain_base64[finalIndex],
        root => {
          root.signed.phase19c_tampered = true;
        }
      );
    const finalBytes = Buffer.from(
      attacked.source.tuf_evidence.root_chain_base64[finalIndex],
      "base64"
    );
    attacked.source.metadata.root.sha256 = sha256(finalBytes);
    attacked.artifact_sha256 = trustedRootArtifactDigest(attacked);
    results.push({
      name: "recomputed wrapper digest cannot hide a forged TUF root body",
      ok: validateGitHubReleaseTrustedRoot(attacked, {
        evaluatedAt: VERIFIED_AT
      }).some(item =>
        item.code === "GITHUB_RELEASE_TUF_ROOT_SIGNATURE_INVALID")
    });
  }

  {
    const attacked = clone(trustedRoot);
    attacked.source.tuf_evidence.targets_base64 = mutateEncodedJson(
      attacked.source.tuf_evidence.targets_base64,
      targets => {
        targets.signed.targets["trusted_root.json"].length += 1;
      }
    );
    attacked.source.metadata.targets.sha256 = sha256(Buffer.from(
      attacked.source.tuf_evidence.targets_base64,
      "base64"
    ));
    attacked.artifact_sha256 = trustedRootArtifactDigest(attacked);
    results.push({
      name: "recomputed wrapper digest cannot hide forged targets metadata",
      ok: validateGitHubReleaseTrustedRoot(attacked, {
        evaluatedAt: VERIFIED_AT
      }).some(item =>
        item.code ===
          "GITHUB_RELEASE_TUF_METADATA_SIGNATURE_INVALID")
    });
  }

  {
    const attacked = clone(rawVerification);
    attacked.verificationResult.statement.predicate.repository =
      "attacker/repository";
    results.push(expectError(
      "CLI result substitution cannot replace the signed DSSE statement",
      "GITHUB_RELEASE_INDEPENDENT_CLI_CROSS_CHECK_FAILED",
      () => verifyGitHubReleaseBundle({
        rawVerification: attacked,
        trustedRoot,
        expected: EXPECTED,
        verifiedAt: VERIFIED_AT
      })
    ));
  }

  {
    const attacked = clone(rawVerification);
    attacked.attestation.bundle.dsseEnvelope.payload =
      mutateEncodedJson(
        attacked.attestation.bundle.dsseEnvelope.payload,
        statement => {
          statement.predicate.repository = "attacker/repository";
        }
      );
    attacked.verificationResult.statement.predicate.repository =
      "attacker/repository";
    results.push(expectError(
      "modified DSSE payload fails independent cryptographic verification",
      "GITHUB_RELEASE_INDEPENDENT_CRYPTOGRAPHIC_VERIFICATION_FAILED",
      () => verifyGitHubReleaseBundle({
        rawVerification: attacked,
        trustedRoot,
        expected: EXPECTED,
        verifiedAt: VERIFIED_AT
      })
    ));
  }

  results.push(expectError(
    "valid signature cannot authorize a substituted commit",
    "GITHUB_RELEASE_INDEPENDENT_SCOPE_MISMATCH",
    () => verifyGitHubReleaseBundle({
      rawVerification,
      trustedRoot,
      expected: {
        ...EXPECTED,
        commitSha: "0000000000000000000000000000000000000000"
      },
      verifiedAt: VERIFIED_AT
    })
  ));

  {
    const attacked = clone(evidence);
    attacked.authority.release_authorized = true;
    attacked.release_authorized = true;
    attacked.verification_sha256 =
      independentVerificationDigest(attacked);
    const issues = validateIndependentVerificationEvidence(
      attacked,
      rawVerification,
      trustedRoot,
      EXPECTED
    );
    results.push({
      name: "independent evidence cannot be repaired into release authority",
      ok: issues.some(item =>
        item.code ===
          "GITHUB_RELEASE_INDEPENDENT_EVIDENCE_AUTHORITY_DRIFT") &&
        issues.some(item =>
          item.code ===
            "GITHUB_RELEASE_INDEPENDENT_EVIDENCE_REPLAY_MISMATCH")
    });
  }

  results.push({
    name: "Codex and Claude wrappers resolve the same independent verifier",
    ok: fs.realpathSync(findCodexRuntimeRoot()) ===
      fs.realpathSync(__dirname) &&
      fs.realpathSync(findClaudeRuntimeRoot()) ===
        fs.realpathSync(__dirname)
  });

  return results;
}

const results = runFixtures();
for (const result of results) {
  console.log(`${result.ok ? "PASS" : "FAIL"} ${result.name}`);
  if (!result.ok && result.detail) {
    console.log(`  ${result.detail}`);
  }
}
const failed = results.filter(result => !result.ok);
console.log(JSON.stringify({
  total: results.length,
  passed: results.length - failed.length,
  failed: failed.length
}, null, 2));
process.exit(failed.length === 0 ? 0 : 1);
