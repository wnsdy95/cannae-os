#!/usr/bin/env node

const fs = require("fs");
const crypto = require("crypto");
const path = require("path");
const { DRAFT_TYPES, intakeIssues } = require("../order-intake-contract");
const { ADOPTION_TYPES, adoptionIssues } = require("../order-adoption-contract");
const { REVISION_TYPES, revisionIssues } = require("../order-revision-contract");
const { TYPES: INTENT_TYPES, intentIssues } = require("../intent-continuity-contract");
const { TYPES: METHOD_TYPES, methodIssues } = require("../method-deviation-contract");
const { TYPES: METHOD_CONTROL_TYPES, issues: methodControlIssues } = require("../method-control-contract");
const { TYPES: ISSUANCE_TYPES, issues: issuanceIssues } = require("../dispatch-issuance-contract");
const { TYPES: COP_TYPES, issues: copIssues } = require("../operational-cop-contract");
const { consentIssues } = require("../operator-consent-contract");
const { reconciliationIssues, TYPES: RECONCILIATION_TYPES } = require("../operator-reconciliation-contract");
const { contractIssues: modelReconciliationIssues, TYPES: MODEL_RECONCILIATION_TYPES } = require("../operator-model-reconciliation-contract");
const { contractIssues: analysisReconciliationIssues, TYPES: ANALYSIS_RECONCILIATION_TYPES } = require("../operator-analysis-reconciliation-contract");
const { evaluationIssues, TYPES: MODEL_EVALUATION_TYPES } = require("../operator-semantic-evaluation-contract");
const { evaluationIssues: analysisEvaluationIssues, TYPES: ANALYSIS_EVALUATION_TYPES } = require("../operator-order-analysis-contract");
const { selectionIssues } = require("../codex-model-selection-contract");
const { issues: requirementInventoryIssues, TYPES: REQUIREMENT_INVENTORY_TYPES } = require("../requirement-inventory-contract");
const { issues: planningIssues, TYPES: PLANNING_TYPES } = require("../bounded-planning-contract");
const { attestationDigest, publicKeyId, strictBase64 } = require("../verification-attestation");
const {
  COMPARATIVE_PREDICATE_TYPE,
  comparativeAttestationDigest
} = require("../comparative-evaluation-attestation");
const {
  canonicalJsonBytes,
  certificateSha256,
  identityEvidenceDigest,
  merkleLeafHash,
  parseSpiffeId,
  transparencyEntry
} = require("../verifier-identity-evidence");
const { verifySigstoreTrustedRoot } = require("../sigstore-trusted-root");
const {
  expectedStatement: expectedSigstoreIdentityStatement,
  normalizeBundle,
  sigstoreEvidenceDigest
} = require("../sigstore-verifier-identity-evidence");
const {
  EXECUTION_PREDICATE_TYPE,
  EXECUTION_PREDICATE_TYPE_V2,
  EXECUTION_PREDICATE_TYPE_V3,
  evidenceDigest: verifierExecutionEvidenceDigest,
  providerRequiredClaims
} = require("../verifier-execution-evidence");
const {
  deriveGitHubActionsIndependence,
  nativeEvidenceDigest,
  parseCompactJwt,
  trustBundleDigest,
  verifyGitHubActionsOIDCTrustBundle
} = require("../github-actions-oidc");
const {
  deriveGitLabCIIndependence,
  nativeEvidenceDigest: gitlabNativeEvidenceDigest,
  parseCompactJwt: parseGitLabCompactJwt,
  projectedClaims: projectedGitLabClaims,
  trustBundleDigest: gitlabTrustBundleDigest,
  verifyGitLabCIOIDCTrustBundle
} = require("../gitlab-ci-oidc");
const {
  computeVerifierIndependence,
  exactDimensions,
  profileClaimsMatchProvider,
  validClaims
} = require("../verifier-independence");
const {
  incidentDigest,
  observationDigest,
  rotationDigest,
  stateDigest
} = require("../transparency-operations");
const {
  gatewayChallengeDigest,
  gatewayEvidenceDigest
} = require("../gateway-identity-evidence");
const {
  objectDigest: productionObjectDigest,
  productionSandboxAdmissionDigest,
  productionSandboxEvidenceDigest,
  validateProductionSandboxPolicy
} = require("../production-sandbox-admission");
const {
  validateAuthorizationSemantics: validateGitHubReleaseAuthorization,
  validateReceiptSemantics: validateGitHubReleaseReceipt
} = require("../github-release-publisher");
const {
  validateAuthorizationSemantics: validateGitHubReleaseImmutabilityAuthorization,
  validateReceiptSemantics: validateGitHubReleaseImmutabilityReceipt
} = require("../github-release-immutability");
const {
  validateIntegrityObservationSemantics: validateGitHubReleaseIntegrityObservation,
  validateIntegrityPolicySemantics: validateGitHubReleaseIntegrityPolicy
} = require("../github-release-integrity-monitor");
const {
  validateGitHubReleaseTrustedRoot
} = require("../github-release-trusted-root");
const {
  validateGitHubReleaseTrustCheckpoint
} = require("../github-release-trust-checkpoint");
const {
  validateGitHubReleaseBootstrapRecovery
} = require("../github-release-bootstrap-recovery");
const {
  independentVerificationDigest
} = require("../github-release-bundle-verifier");

const ROOT = path.resolve(__dirname, "..");
const SCHEMA_DIR = path.join(ROOT, "schema-files");

function controlExecutionReceiptId({ reportId, reportInputSha256, commandSha256 }) {
  const reportPart = String(reportId || "unknown").replace(/[^A-Za-z0-9_-]+/g, "_") || "unknown";
  return `CER-${reportPart}-${String(reportInputSha256 || "").slice(0, 12)}-${String(commandSha256 || "").slice(0, 16)}`;
}

function controlExecutionDescriptor(command) {
  if (typeof command !== "string" || command.trim() !== command || command.length === 0) {
    throw new Error("Validation command must be one exact non-empty string without surrounding whitespace.");
  }
  if (/[;&|`<>\n\r]/.test(command)) {
    throw new Error(`Validation command contains a forbidden shell operator: ${command}`);
  }
  if (/["'$\\]/.test(command)) {
    throw new Error(`Node validation command contains unsupported quoting or expansion: ${command}`);
  }
  const tokens = command.split(/\s+/);
  if (tokens[0] !== "node" || tokens.length < 2) {
    throw new Error(`Validation command runner is not allowlisted: ${command}`);
  }
  const scriptPath = tokens[1];
  if (!/^[A-Za-z0-9._/-]+\.js$/.test(scriptPath) || path.isAbsolute(scriptPath) || scriptPath.split("/").includes("..")) {
    throw new Error(`Validation command script path is unsafe: ${scriptPath}`);
  }
  const commandSha256 = crypto.createHash("sha256").update(command).digest("hex");
  return {
    control_id: `CTRL-${commandSha256.slice(0, 16)}`,
    command,
    command_sha256: commandSha256,
    runner: "node",
    script_path: scriptPath,
    argv: tokens.slice(2),
    working_directory: "doctrine_root",
    shell: false
  };
}

const TYPE_TO_SCHEMA = {
  "codex-model-selection": "codex-model-selection.schema.json",
  "operational-cop": "operational-cop.schema.json",
  "operator-consent-record": "operator-consent-record.schema.json",
  "operator-reconciliation-authorization": "operator-reconciliation-authorization.schema.json",
  "operator-reconciliation-record": "operator-reconciliation-record.schema.json",
  "operator-model-reconciliation-authorization": "operator-model-reconciliation-authorization.schema.json",
  "operator-model-reconciliation-record": "operator-model-reconciliation-record.schema.json",
  "operator-analysis-reconciliation-authorization": "operator-analysis-reconciliation-authorization.schema.json",
  "operator-analysis-reconciliation-record": "operator-analysis-reconciliation-record.schema.json",
  "operator-semantic-evaluation": "operator-semantic-evaluation.schema.json",
  "operator-order-analysis": "operator-order-analysis.schema.json",
  "order-analysis-response": "order-analysis-response.schema.json",
  "requirement-inventory": "requirement-inventory.schema.json",
  "bounded-planning-request": "bounded-planning-request.schema.json",
  "bounded-planning-proposal": "bounded-planning-proposal.schema.json",
  "semantic-coverage-proposal": "semantic-coverage-proposal.schema.json",
  "semantic-review-assignment": "semantic-review-assignment.schema.json",
  ...Object.fromEntries([...INTENT_TYPES].map(type => [type, `${type}.schema.json`])),
  ...Object.fromEntries([...METHOD_TYPES].map(type => [type, `${type}.schema.json`])),
  ...Object.fromEntries([...METHOD_CONTROL_TYPES].map(type => [type, `${type}.schema.json`])),
  ...Object.fromEntries([...ISSUANCE_TYPES].map(type => [type, `${type}.schema.json`])),
  ...Object.fromEntries([...REVISION_TYPES].map(type => [type, `${type}.schema.json`])),
  ...Object.fromEntries([...ADOPTION_TYPES].map(type => [type, `${type}.schema.json`])),
  "mission-request": "mission-request.schema.json",
  "mission-order-analysis": "mission-order-analysis.schema.json",
  "order-draft": "order-draft.schema.json",
  "implementation-candidate-registry": "implementation-candidate-registry.schema.json",
  mission: "mission.schema.json",
  agent: "agent.schema.json",
  warno: "warno.schema.json",
  "board-decision": "board-decision.schema.json",
  "battle-rhythm-event": "battle-rhythm-event.schema.json",
  "battle-rhythm-scheduler": "battle-rhythm-scheduler.schema.json",
  "agent-metl": "agent-metl.schema.json",
  "readiness-event": "readiness-event.schema.json",
  "readiness-drop-reconciliation": "readiness-drop-reconciliation.schema.json",
  "source-plan": "source-plan.schema.json",
  "context-release": "context-release.schema.json",
  "resource-status": "resource-status.schema.json",
  "decision-log": "decision-log.schema.json",
  "source-record": "source-record.schema.json",
  "classification-label": "classification-label.schema.json",
  "releasability-review": "releasability-review.schema.json",
  "eefi-alert": "eefi-alert.schema.json",
  opord: "opord.schema.json",
  "task-order": "task-order.schema.json",
  "tool-request": "tool-request.schema.json",
  "dispatch-tool-policy": "dispatch-tool-policy.schema.json",
  "agent-dispatch-lease": "agent-dispatch-lease.schema.json",
  "tool-admission-event": "tool-admission-event.schema.json",
  "agent-execution-checkpoint": "agent-execution-checkpoint.schema.json",
  "tool-effect-scope": "tool-effect-scope.schema.json",
  "gateway-effect-subject": "gateway-effect-subject.schema.json",
  "gateway-effect-scope": "gateway-effect-scope.schema.json",
  "gateway-effect-review": "gateway-effect-review.schema.json",
  "gateway-effect-settlement-request": "gateway-effect-settlement-request.schema.json",
  "gateway-effect-settlement": "gateway-effect-settlement.schema.json",
  "tool-effect-review": "tool-effect-review.schema.json",
  "tool-effect-settlement-request": "tool-effect-settlement-request.schema.json",
  "tool-effect-settlement": "tool-effect-settlement.schema.json",
  "tool-gateway-request": "tool-gateway-request.schema.json",
  "tool-gateway-decision": "tool-gateway-decision.schema.json",
  "tool-execution-receipt": "tool-execution-receipt.schema.json",
  "tool-gateway-transaction-event": "tool-gateway-transaction-event.schema.json",
  "protected-executor-policy": "protected-executor-policy.schema.json",
  "protected-process-tool-input": "protected-process-tool-input.schema.json",
  "protected-execution-envelope": "protected-execution-envelope.schema.json",
  "protected-execution-observation": "protected-execution-observation.schema.json",
  "oci-linux-sandbox-policy": "oci-linux-sandbox-policy.schema.json",
  "oci-sandbox-tool-input": "oci-sandbox-tool-input.schema.json",
  "oci-sandbox-execution-envelope": "oci-sandbox-execution-envelope.schema.json",
  "oci-sandbox-probe-observation": "oci-sandbox-probe-observation.schema.json",
  "oci-sandbox-execution-observation": "oci-sandbox-execution-observation.schema.json",
  "oci-sandbox-containment-observation": "oci-sandbox-containment-observation.schema.json",
  "gateway-identity-policy": "gateway-identity-policy.schema.json",
  "gateway-identity-challenge": "gateway-identity-challenge.schema.json",
  "gateway-principal-evidence": "gateway-principal-evidence.schema.json",
  "production-sandbox-policy": "production-sandbox-policy.schema.json",
  "production-sandbox-evidence": "production-sandbox-evidence.schema.json",
  "production-sandbox-admission": "production-sandbox-admission.schema.json",
  "approval-request": "approval-request.schema.json",
  sitrep: "sitrep.schema.json",
  frago: "frago.schema.json",
  "frago-scope-change": "frago-scope-change.schema.json",
  annex: "annex.schema.json",
  "information-report": "information-report.schema.json",
  "intelligence-assessment": "intelligence-assessment.schema.json",
  evidence: "evidence.schema.json",
  aar: "aar.schema.json",
  "aar-readiness-update": "aar-readiness-update.schema.json",
  "readiness-ledger": "readiness-ledger.schema.json",
  "authority-matrix": "authority-matrix.schema.json",
  "decision-packet": "decision-packet.schema.json",
  "working-group": "working-group.schema.json",
  "sof-tf-charter": "sof-tf-charter.schema.json",
  "department-collaboration-charter": "department-collaboration-charter.schema.json",
  "force-structure-change-order": "force-structure-change-order.schema.json",
  "document-access-manifest": "document-access-manifest.schema.json",
  "doctrine-consistency-review": "doctrine-consistency-review.schema.json",
  "ccir-alert": "ccir-alert.schema.json",
  "handoff-packet": "handoff-packet.schema.json",
  "continuity-plan": "continuity-plan.schema.json",
  "context-item": "context-item.schema.json",
  "release-review": "release-review.schema.json",
  "maintenance-readiness": "maintenance-readiness.schema.json",
  backbrief: "backbrief.schema.json",
  rehearsal: "rehearsal.schema.json",
  "approval-scope": "approval-scope.schema.json",
  "risk-acceptance": "risk-acceptance.schema.json",
  "approval-consumption-event": "approval-consumption-event.schema.json",
  "approval-revocation-event": "approval-revocation-event.schema.json",
  "approval-renewal-event": "approval-renewal-event.schema.json",
  "approval-delegation-event": "approval-delegation-event.schema.json",
  "approval-delegation-revocation-event": "approval-delegation-revocation-event.schema.json",
  "release-gate-decision-event": "release-gate-decision-event.schema.json",
  "github-release-authorization": "github-release-authorization.schema.json",
  "github-release-receipt": "github-release-receipt.schema.json",
  "github-release-immutability-authorization": "github-release-immutability-authorization.schema.json",
  "github-release-immutability-receipt": "github-release-immutability-receipt.schema.json",
  "github-release-integrity-policy": "github-release-integrity-policy.schema.json",
  "github-release-integrity-observation": "github-release-integrity-observation.schema.json",
  "github-release-trusted-root": "github-release-trusted-root.schema.json",
  "github-release-trust-checkpoint": "github-release-trust-checkpoint.schema.json",
  "github-release-bootstrap-recovery": "github-release-bootstrap-recovery.schema.json",
  "github-release-independent-verification": "github-release-independent-verification.schema.json",
  "routing-receipt": "routing-receipt.schema.json",
  "mission-wave-plan": "mission-wave-plan.schema.json",
  "agent-context-pack": "agent-context-pack.schema.json",
  "control-execution-receipt": "control-execution-receipt.schema.json",
  "workload-control-input": "workload-control-input.schema.json",
  "workload-policy-assessment": "workload-policy-assessment.schema.json",
  "workload-control-receipt": "workload-control-receipt.schema.json",
  "force-registry-entity": "force-registry-entity.schema.json",
  "force-registry-request": "force-registry-request.schema.json",
  "force-registry-proposal": "force-registry-proposal.schema.json",
  "force-registry-authorization": "force-registry-authorization.schema.json",
  "force-registry-event": "force-registry-event.schema.json",
  "task-training-standard": "task-training-standard.schema.json",
  "task-training-trial-request": "task-training-trial-request.schema.json",
  "task-training-session-binding": "task-training-session-binding.schema.json",
  "task-training-completion-input": "task-training-completion-input.schema.json",
  "task-training-trial-appraisal": "task-training-trial-appraisal.schema.json",
  "training-session-proposal": "training-session-proposal.schema.json",
  "training-session-authorization": "training-session-authorization.schema.json",
  "native-training-product-request": "native-training-product-request.schema.json",
  "native-training-product-response": "native-training-product-response.schema.json",
  "native-training-product-appraisal": "native-training-product-appraisal.schema.json",
  "native-training-transfer-review-request": "native-training-transfer-review-request.schema.json",
  "native-training-transfer-authorization": "native-training-transfer-authorization.schema.json",
  "operator-native-training-product": "operator-native-training-product.schema.json",
  "native-training-producer-inspection": "native-training-producer-inspection.schema.json",
  "mission-wave-report": "mission-wave-report.schema.json",
  "mission-wave-closeout": "mission-wave-closeout.schema.json",
  "mission-wave-termination-request": "mission-wave-termination-request.schema.json",
  "mission-wave-termination": "mission-wave-termination.schema.json",
  "campaign-stop-request": "campaign-stop-request.schema.json",
  "campaign-stop-record": "campaign-stop-record.schema.json",
  "campaign-terminal-request": "campaign-terminal-request.schema.json",
  "campaign-terminal-record": "campaign-terminal-record.schema.json",
  "campaign-successor-proposal-request": "campaign-successor-proposal-request.schema.json",
  "campaign-successor-proposal": "campaign-successor-proposal.schema.json",
  "campaign-successor-activation-request": "campaign-successor-activation-request.schema.json",
  "campaign-successor-admission": "campaign-successor-admission.schema.json",
  "model-force-assignment-plan": "model-force-assignment-plan.schema.json",
  "model-registry": "model-registry.schema.json",
  "model-assignment-request": "model-assignment-request.schema.json",
  "integrated-mission-preflight": "integrated-mission-preflight.schema.json",
  "model-usage-event": "model-usage-event.schema.json",
  "repository-artifact-manifest": "repository-artifact-manifest.schema.json",
  "self-improvement-campaign": "self-improvement-campaign.schema.json",
  "self-improvement-checkpoint": "self-improvement-checkpoint.schema.json",
  "self-improvement-decision": "self-improvement-decision.schema.json",
  "self-improvement-cycle-order": "self-improvement-cycle-order.schema.json",
  "comparative-evaluation-set": "comparative-evaluation-set.schema.json",
  "comparative-evaluation-plan": "comparative-evaluation-plan.schema.json",
  "comparative-evaluation-report": "comparative-evaluation-report.schema.json",
  "verification-plan": "verification-plan.schema.json",
  "verification-receipt": "verification-receipt.schema.json",
  "verifier-trust-policy": "verifier-trust-policy.schema.json",
  "verifier-identity-evidence": "verifier-identity-evidence.schema.json",
  "sigstore-trusted-root": "sigstore-trusted-root.schema.json",
  "sigstore-verifier-identity-evidence": "sigstore-verifier-identity-evidence.schema.json",
  "verifier-runtime-policy": "verifier-runtime-policy.schema.json",
  "verifier-execution-evidence": "verifier-execution-evidence.schema.json",
  "github-actions-oidc-trust-bundle": "github-actions-oidc-trust-bundle.schema.json",
  "github-actions-oidc-evidence": "github-actions-oidc-evidence.schema.json",
  "gitlab-ci-oidc-trust-bundle": "gitlab-ci-oidc-trust-bundle.schema.json",
  "gitlab-ci-oidc-evidence": "gitlab-ci-oidc-evidence.schema.json",
  "verifier-challenge-set": "verifier-challenge-set.schema.json",
  "transparency-policy": "transparency-policy.schema.json",
  "transparency-observation": "transparency-observation.schema.json",
  "trust-root-rotation": "trust-root-rotation.schema.json",
  "transparency-incident": "transparency-incident.schema.json",
  "transparency-state": "transparency-state.schema.json",
  "verification-attestation": "verification-attestation.schema.json",
  "comparative-evaluation-attestation": "comparative-evaluation-attestation.schema.json"
};

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, "utf8"));
}

function issue(severity, code, pointer, message, fix) {
  return { severity, code, path: pointer || "$", message, ...(fix ? { fix } : {}) };
}

function renderedCommandArgument(value) {
  const arg = String(value);
  if (/^[A-Za-z0-9_./:=@-]+$/.test(arg)) return arg;
  return `"${arg.replace(/(["\\$`])/g, "\\$1")}"`;
}

function validateCapabilityRouting(payload, options = {}) {
  const issues = [];
  const capability = payload.capability_routing || {};
  const provisional = capability.provisional_organization || {};
  const forceStructure = capability.force_structure_review || {};
  const pathPrefix = options.pathPrefix || "$.capability_routing";
  const routeIds = new Set(options.routeIds || []);
  const documentPaths = new Set(options.documentPaths || []);
  const commands = new Set(options.commands || []);

  if (provisional.authority_expansion_authorized !== false ||
      provisional.standing_department_activation_authorized !== false) {
    issues.push(issue("critical", "CAPABILITY_ROUTING_AUTHORITY_EXPANSION", `${pathPrefix}.provisional_organization`, "A provisional capability cell cannot expand authority or activate a standing department."));
  }
  if (forceStructure.final_decision_authority !== "USER" ||
      forceStructure.formal_approving_role !== "COMMANDER") {
    issues.push(issue("critical", "CAPABILITY_ROUTING_FINAL_AUTHORITY_DRIFT", `${pathPrefix}.force_structure_review`, "The USER remains final decision authority and COMMANDER remains the formal force-structure approving role."));
  }
  if (options.capabilityQuery !== undefined &&
      capability.capability_scope !== options.capabilityQuery) {
    issues.push(issue("critical", "CAPABILITY_ROUTING_SCOPE_MISMATCH", `${pathPrefix}.capability_scope`, "Capability routing must bind the exact mission capability query."));
  }

  if (capability.status === "gap_detected") {
    const expectedSuffix = crypto.createHash("sha256")
      .update(String(options.missionId || ""))
      .digest("hex")
      .slice(0, 12)
      .toUpperCase();
    if (capability.reason_code !== "NO_CAPABILITY_ROUTE" ||
        (capability.matched_capability_routes || []).length !== 0 ||
        provisional.required !== true ||
        provisional.organization_type !== "mission_scoped_capability_cell" ||
        provisional.task_organization_status !== "task_organized" ||
        forceStructure.required !== true ||
        forceStructure.change_type !== "create" ||
        forceStructure.target_kind !== "department" ||
        forceStructure.status !== "analysis_required" ||
        !/^DEPT-[A-F0-9]{12}$/.test(forceStructure.candidate_department_id || "") ||
        String(forceStructure.candidate_department_id).slice(5) !== String(provisional.organization_id || "").slice(5)) {
      issues.push(issue("critical", "CAPABILITY_GAP_WITHOUT_PROVISIONAL_ORGANIZATION", pathPrefix, "An unmatched capability must create a bounded mission cell and initiate department force-structure analysis."));
    }
    if (provisional.organization_id !== `CELL-${expectedSuffix}` ||
        forceStructure.candidate_department_id !== `DEPT-${expectedSuffix}`) {
      issues.push(issue("critical", "CAPABILITY_ROUTING_ORGANIZATION_ID_MISMATCH", `${pathPrefix}.provisional_organization.organization_id`, "Provisional cell and department-candidate ids must derive from the exact mission id."));
    }
    if ((options.requireRouteEvidence !== false && !routeIds.has("force-structure")) ||
        !documentPaths.has("docs/force-structure-change-policy.md") ||
        !commands.has("node run-force-structure-change-fixtures.js")) {
      issues.push(issue("critical", "CAPABILITY_GAP_WITHOUT_FORCE_STRUCTURE_CONTROL", pathPrefix, "A capability gap must route force-structure doctrine and its executable fixture gate."));
    }
  }

  const declaredCapabilityRoutes = capability.matched_capability_routes || [];
  if (capability.status === "covered" &&
      (declaredCapabilityRoutes.length === 0 ||
       provisional.required !== false ||
       provisional.organization_type !== "existing_doctrine_route" ||
       provisional.task_organization_status !== "not_required" ||
       forceStructure.required !== false ||
       forceStructure.status !== "not_required" ||
       forceStructure.candidate_department_id !== "none" ||
       forceStructure.candidate_department_name !== "none")) {
    issues.push(issue("critical", "COVERED_CAPABILITY_WITH_ORGANIZATION_DRIFT", pathPrefix, "A covered capability must use an existing route without inventing or activating an organization."));
  }
  if (capability.status === "covered" && options.requireRouteEvidence !== false &&
      declaredCapabilityRoutes.some(routeId => !routeIds.has(routeId))) {
    issues.push(issue("critical", "COVERED_CAPABILITY_ROUTE_MISMATCH", `${pathPrefix}.matched_capability_routes`, "Every declared capability route must exist in the router's matched route evidence."));
  }
  return issues;
}

function loadSchemas() {
  const schemas = {};
  for (const file of fs.readdirSync(SCHEMA_DIR)) {
    if (file.endsWith(".json")) {
      schemas[file] = readJson(path.join(SCHEMA_DIR, file));
    }
  }
  return schemas;
}

function resolveRef(ref, schemas, rootSchema) {
  const [file, fragment] = ref.split("#");
  const schema = file ? schemas[file] : rootSchema;
  if (!schema) return null;
  if (!fragment) return schema;
  const parts = fragment.replace(/^\//, "").split("/").filter(Boolean);
  let current = schema;
  for (const part of parts) {
    current = current && current[part];
  }
  return current || null;
}

function typeMatches(value, expected) {
  if (Array.isArray(expected)) return expected.some(type => typeMatches(value, type));
  if (expected === "null") return value === null;
  if (expected === "array") return Array.isArray(value);
  if (expected === "object") return value !== null && typeof value === "object" && !Array.isArray(value);
  if (expected === "string") return typeof value === "string";
  if (expected === "boolean") return typeof value === "boolean";
  if (expected === "number") return typeof value === "number";
  if (expected === "integer") return Number.isInteger(value);
  return false;
}

function hasSchemaErrors(issues) {
  return issues.some(item =>
    item.severity === "error" || item.severity === "critical");
}

function validateSchema(value, schema, schemas, pointer = "$", seen = new Set(), rootSchema = schema) {
  const issues = [];
  if (!schema || typeof schema !== "object") return issues;

  if (schema.$ref) {
    const key = `${rootSchema.$id || ""}:${schema.$ref}@${pointer}`;
    if (seen.has(key)) return issues;
    seen.add(key);
    const resolved = resolveRef(schema.$ref, schemas, rootSchema);
    if (!resolved) {
      issues.push(issue("error", "UNRESOLVED_REF", pointer, `Cannot resolve schema ref ${schema.$ref}.`));
      return issues;
    }
    // A referenced fragment still resolves its local refs from the owning document.
    const referencedRoot = schema.$ref.startsWith("#") ? rootSchema : schemas[schema.$ref.split("#")[0]];
    return validateSchema(value, resolved, schemas, pointer, seen, referencedRoot);
  }

  if (Array.isArray(schema.allOf)) {
    for (const branch of schema.allOf) {
      issues.push(...validateSchema(
        value,
        branch,
        schemas,
        pointer,
        new Set(seen),
        rootSchema
      ));
    }
  }

  if (Array.isArray(schema.anyOf)) {
    const matchingBranches = schema.anyOf.filter(branch =>
      !hasSchemaErrors(validateSchema(
        value,
        branch,
        schemas,
        pointer,
        new Set(seen),
        rootSchema
      )));
    if (matchingBranches.length === 0) {
      issues.push(issue(
        "error",
        "ANY_OF_MISMATCH",
        pointer,
        "Value must satisfy at least one allowed schema branch."
      ));
    }
  }

  if (Array.isArray(schema.oneOf)) {
    const matchingBranches = schema.oneOf.filter(branch =>
      !hasSchemaErrors(validateSchema(
        value,
        branch,
        schemas,
        pointer,
        new Set(seen),
        rootSchema
      )));
    if (matchingBranches.length !== 1) {
      issues.push(issue(
        "error",
        "ONE_OF_MISMATCH",
        pointer,
        "Value must satisfy exactly one allowed schema branch."
      ));
    }
  }

  if (schema.not && typeof schema.not === "object") {
    const excludedIssues = validateSchema(
      value,
      schema.not,
      schemas,
      pointer,
      new Set(seen),
      rootSchema
    );
    if (!hasSchemaErrors(excludedIssues)) {
      issues.push(issue(
        "error",
        "NOT_SCHEMA_MATCH",
        pointer,
        "Value matches a prohibited schema."
      ));
    }
  }

  if (schema.if && typeof schema.if === "object") {
    const conditionIssues = validateSchema(
      value,
      schema.if,
      schemas,
      pointer,
      new Set(seen),
      rootSchema
    );
    const selected = !hasSchemaErrors(conditionIssues)
      ? schema.then
      : schema.else;
    if (selected && typeof selected === "object") {
      issues.push(...validateSchema(
        value,
        selected,
        schemas,
        pointer,
        new Set(seen),
        rootSchema
      ));
    }
  }

  if (schema.type && !typeMatches(value, schema.type)) {
    issues.push(issue("error", "TYPE_MISMATCH", pointer, `Expected ${Array.isArray(schema.type) ? schema.type.join(" or ") : schema.type}.`));
    return issues;
  }

  if (schema.const !== undefined && value !== schema.const) {
    issues.push(issue("error", "CONST_MISMATCH", pointer, `Expected constant ${JSON.stringify(schema.const)}.`));
  }

  if (schema.enum && !schema.enum.includes(value)) {
    issues.push(issue("error", "ENUM_MISMATCH", pointer, `Expected one of ${schema.enum.join(", ")}.`));
  }

  if (schema.type === "string" && typeof value === "string") {
    if (schema.minLength !== undefined && value.length < schema.minLength) {
      issues.push(issue("error", "MIN_LENGTH", pointer, `String must have length >= ${schema.minLength}.`));
    }
    if (schema.maxLength !== undefined && value.length > schema.maxLength) {
      issues.push(issue("error", "MAX_LENGTH", pointer, `String must have length <= ${schema.maxLength}.`));
    }
    if (schema.pattern && !(new RegExp(schema.pattern).test(value))) {
      issues.push(issue("error", "PATTERN_MISMATCH", pointer, `String does not match ${schema.pattern}.`));
    }
    if (schema.format === "uri" && !/^https?:\/\//.test(value)) {
      issues.push(issue("error", "FORMAT_URI_INVALID", pointer, "Expected an http(s) URI."));
    }
    if (schema.format === "date-time" && Number.isNaN(Date.parse(value))) {
      issues.push(issue("error", "FORMAT_DATETIME_INVALID", pointer, "Expected parseable date-time."));
    }
  }

  if (typeof value === "number") {
    if (schema.minimum !== undefined && value < schema.minimum) {
      issues.push(issue("error", "MINIMUM", pointer, `Number must be >= ${schema.minimum}.`));
    }
    if (schema.maximum !== undefined && value > schema.maximum) {
      issues.push(issue("error", "MAXIMUM", pointer, `Number must be <= ${schema.maximum}.`));
    }
    if (typeof schema.exclusiveMinimum === "number" && value <= schema.exclusiveMinimum) {
      issues.push(issue("error", "EXCLUSIVE_MINIMUM", pointer, `Number must be > ${schema.exclusiveMinimum}.`));
    }
    if (typeof schema.exclusiveMaximum === "number" && value >= schema.exclusiveMaximum) {
      issues.push(issue("error", "EXCLUSIVE_MAXIMUM", pointer, `Number must be < ${schema.exclusiveMaximum}.`));
    }
  }

  const hasObjectKeywords = schema.type === "object" ||
    schema.required !== undefined ||
    schema.properties !== undefined ||
    schema.additionalProperties !== undefined ||
    schema.minProperties !== undefined ||
    schema.maxProperties !== undefined;
  if (hasObjectKeywords && value && typeof value === "object" && !Array.isArray(value)) {
    const propertyCount = Object.keys(value).length;
    if (schema.minProperties !== undefined &&
        propertyCount < schema.minProperties) {
      issues.push(issue(
        "error",
        "MIN_PROPERTIES",
        pointer,
        `Object must contain at least ${schema.minProperties} properties.`
      ));
    }
    if (schema.maxProperties !== undefined &&
        propertyCount > schema.maxProperties) {
      issues.push(issue(
        "error",
        "MAX_PROPERTIES",
        pointer,
        `Object must contain at most ${schema.maxProperties} properties.`
      ));
    }
    for (const required of schema.required || []) {
      if (!Object.hasOwn(value, required)) {
        issues.push(issue("error", "MISSING_REQUIRED", `${pointer}.${required}`, `Missing required field ${required}.`));
      }
    }
    const props = schema.properties || {};
    for (const [key, child] of Object.entries(value)) {
      if (Object.hasOwn(props, key)) {
        issues.push(...validateSchema(child, props[key], schemas, `${pointer}.${key}`, new Set(seen), rootSchema));
      } else if (schema.additionalProperties === false) {
        issues.push(issue("error", "ADDITIONAL_PROPERTY", `${pointer}.${key}`, `Unexpected field ${key}.`));
      } else if (schema.additionalProperties && typeof schema.additionalProperties === "object") {
        issues.push(...validateSchema(child, schema.additionalProperties, schemas, `${pointer}.${key}`, new Set(seen), rootSchema));
      }
    }
  }

  const hasArrayKeywords = schema.type === "array" ||
    schema.minItems !== undefined ||
    schema.maxItems !== undefined ||
    schema.uniqueItems !== undefined ||
    schema.prefixItems !== undefined ||
    schema.items !== undefined ||
    schema.contains !== undefined;
  if (hasArrayKeywords && Array.isArray(value)) {
    if (schema.minItems !== undefined && value.length < schema.minItems) {
      issues.push(issue("error", "MIN_ITEMS", pointer, `Array must contain at least ${schema.minItems} item(s).`));
    }
    if (schema.maxItems !== undefined && value.length > schema.maxItems) {
      issues.push(issue("error", "MAX_ITEMS", pointer, `Array must contain at most ${schema.maxItems} item(s).`));
    }
    if (schema.uniqueItems === true) {
      const serialized = value.map(item => JSON.stringify(item));
      if (new Set(serialized).size !== serialized.length) {
        issues.push(issue("error", "UNIQUE_ITEMS", pointer, "Array items must be unique."));
      }
    }
    const prefixItems = Array.isArray(schema.prefixItems)
      ? schema.prefixItems
      : [];
    for (let index = 0;
      index < Math.min(value.length, prefixItems.length);
      index += 1) {
      issues.push(...validateSchema(
        value[index],
        prefixItems[index],
        schemas,
        `${pointer}[${index}]`,
        new Set(seen),
        rootSchema
      ));
    }
    if (schema.items === false &&
        value.length > prefixItems.length) {
      issues.push(issue(
        "error",
        "ITEMS_NOT_ALLOWED",
        pointer,
        "Array contains items beyond the allowed positional schema."
      ));
    } else if (schema.items &&
        typeof schema.items === "object") {
      for (let index = prefixItems.length;
        index < value.length;
        index += 1) {
        issues.push(...validateSchema(
          value[index],
          schema.items,
          schemas,
          `${pointer}[${index}]`,
          new Set(seen),
          rootSchema
        ));
      }
    }
    if (schema.contains && typeof schema.contains === "object") {
      const matchingItems = value.filter((itemValue, index) =>
        !hasSchemaErrors(validateSchema(
          itemValue,
          schema.contains,
          schemas,
          `${pointer}[${index}]`,
          new Set(seen),
          rootSchema
        )));
      const minimumMatches = schema.minContains === undefined
        ? 1
        : schema.minContains;
      const maximumMatches = schema.maxContains === undefined
        ? Number.POSITIVE_INFINITY
        : schema.maxContains;
      if (matchingItems.length < minimumMatches ||
          matchingItems.length > maximumMatches) {
        issues.push(issue(
          "error",
          "CONTAINS_MISMATCH",
          pointer,
          "Array does not satisfy its required contained-item count."
        ));
      }
    }
  }

  return issues;
}

function isEmptyArray(value) {
  return Array.isArray(value) && value.length === 0;
}

function hasSubstantiveItems(value) {
  return Array.isArray(value) && value.some(item => !/^none$/i.test(String(item).trim()));
}

function sortedJsonValue(value) {
  if (Array.isArray(value)) return value.map(sortedJsonValue);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.keys(value).sort().map(key => [key, sortedJsonValue(value[key])]));
}

function sameJson(left, right) {
  return JSON.stringify(sortedJsonValue(left)) === JSON.stringify(sortedJsonValue(right));
}

function isNoneArtifactRef(ref) {
  return Boolean(ref && ref.artifact_id === "none" && ref.relative_path === "none" && ref.sha256 === "none");
}

function artifactRefKind(ref) {
  if (!ref || typeof ref !== "object" || Array.isArray(ref)) return "malformed";
  const keys = Object.keys(ref).sort();
  if (!sameJson(keys, ["artifact_id", "relative_path", "sha256"])) return "malformed";
  const values = [ref.artifact_id, ref.relative_path, ref.sha256];
  if (values.every(value => value === "none")) return "none";
  if (values.some(value => value === "none")) return "malformed";
  if (!/^[A-Z]+-[A-Za-z0-9_-]+$/.test(ref.artifact_id || "") ||
      typeof ref.relative_path !== "string" || ref.relative_path.length === 0 ||
      !/^[a-f0-9]{64}$/.test(ref.sha256 || "")) {
    return "malformed";
  }
  return "concrete";
}

function retainedAuthorityDrift(authority) {
  return !authority ||
    authority.human_final_decision_authority !== "USER" ||
    authority.self_approval_prohibited !== true ||
    authority.release_authorized !== false;
}

const DISPATCH_PROTECTED_PATHS = [
  ".git",
  ".cannae",
  ".codex",
  ".claude/settings.json",
  ".claude/settings.local.json"
];

function safeRepositoryPrefix(value) {
  if (typeof value !== "string" || value.length === 0 || value !== value.trim() ||
      value.includes("\0") || value.includes("\\") || path.isAbsolute(value) ||
      /^[A-Za-z]:[\\/]/.test(value) || value.startsWith("./") || value.endsWith("/") ||
      value.includes("//") || /[*?[\]{}]/.test(value)) {
    return false;
  }
  if (value === ".") return true;
  const segments = value.split("/");
  if (segments.some(segment => segment.length === 0 || segment === "." || segment === "..")) {
    return false;
  }
  return !DISPATCH_PROTECTED_PATHS.some(prefix =>
    value === prefix || value.startsWith(`${prefix}/`));
}

function validJsonPointer(value) {
  return typeof value === "string" &&
    value.length > 0 &&
    /^(?:\/(?:[^~/]|~[01])*)+$/.test(value);
}

function resolveLocalArtifactRef(ref) {
  if (artifactRefKind(ref) !== "concrete") return { status: "unavailable" };
  if (path.isAbsolute(ref.relative_path) ||
      ref.relative_path.split(/[\\/]+/).includes("..")) {
    return { status: "mismatch" };
  }
  const candidates = [
    path.resolve(ROOT, ref.relative_path),
    path.resolve(ROOT, ".cannae", "artifacts", ref.relative_path)
  ];
  const candidate = candidates.find(filePath => fs.existsSync(filePath) && fs.statSync(filePath).isFile());
  if (!candidate) return { status: "unavailable" };
  try {
    const bytes = fs.readFileSync(candidate);
    const digest = crypto.createHash("sha256").update(bytes).digest("hex");
    const payload = JSON.parse(bytes.toString("utf8"));
    if (digest !== ref.sha256 || payload.id !== ref.artifact_id) {
      return { status: "mismatch" };
    }
    return { status: "resolved", payload };
  } catch (error) {
    return { status: "mismatch" };
  }
}

function isValidDate(value) {
  return typeof value === "string" && value.length > 0 && !Number.isNaN(Date.parse(value));
}

function isBefore(left, right) {
  return isValidDate(left) && isValidDate(right) && Date.parse(left) < Date.parse(right);
}

function canonicalDigestWithout(value, fieldPath) {
  const clone = JSON.parse(JSON.stringify(value));
  let cursor = clone;
  for (let index = 0; index < fieldPath.length - 1; index += 1) cursor = cursor && cursor[fieldPath[index]];
  if (cursor) delete cursor[fieldPath.at(-1)];
  return crypto.createHash("sha256").update(`${JSON.stringify(clone, null, 2)}\n`).digest("hex");
}

function canonicalObjectDigestWithout(value, fields) {
  const copy = JSON.parse(JSON.stringify(value));
  for (const field of fields) delete copy[field];
  return crypto.createHash("sha256").update(canonicalJsonBytes(copy)).digest("hex");
}

function canonicalControlDigestWithout(value, fields) {
  const copy = JSON.parse(JSON.stringify(value));
  for (const field of fields) delete copy[field];
  return crypto.createHash("sha256")
    .update(`${JSON.stringify(sortedJsonValue(copy))}\n`)
    .digest("hex");
}

function sandboxProfileDigest(policy) {
  return canonicalControlDigestWithout({
    image: policy && policy.image,
    process_controls: policy && policy.process_controls,
    filesystem_controls: policy && policy.filesystem_controls,
    seccomp: policy && policy.seccomp,
    resource_controls: policy && policy.resource_controls
  }, []);
}

function networkPolicyDigest(networkControls) {
  return canonicalControlDigestWithout(
    networkControls || {},
    ["network_policy_sha256"]
  );
}

function runtimeConfigDigest(runtimeConfig) {
  return canonicalControlDigestWithout(
    runtimeConfig || {},
    ["config_sha256"]
  );
}

function safeProtectedCwd(value) {
  if (typeof value !== "string" || value.length === 0 ||
      value.includes("\\") || value.includes("\0")) return false;
  if (value === ".") return true;
  if (value.startsWith("/") || value.endsWith("/")) return false;
  return value.split("/").every(part => part && part !== "." && part !== "..");
}

function validEd25519Signature(signature) {
  try {
    return Boolean(signature &&
      signature.algorithm === "ed25519" &&
      /^[a-f0-9]{64}$/.test(signature.key_id || "") &&
      strictBase64(signature.signature_base64).length === 64);
  } catch (error) {
    return false;
  }
}

const ROE_RANK = { Green: 0, Amber: 1, Red: 2, Black: 3 };
const RISK_RANK = { low: 0, medium: 1, high: 2, critical: 3 };
const AUTHORITY_RANK = { L0: 0, L1: 1, L2: 2, L3: 3, L4: 4, L5: 5 };
const READINESS_RANK = { X: 0, U: 1, P: 2, T: 3 };
const CLASSIFICATION_RANK = { public: 0, internal: 1, sensitive: 2, restricted: 3 };

function authorityAtLeast(actual, minimum) {
  return AUTHORITY_RANK[actual] >= AUTHORITY_RANK[minimum];
}

function semanticRules(payload, type, options = {}) {
  const issues = [];

  if (type === "implementation-candidate-registry") {
    const fail = (code, location, message) => issues.push(issue("error", code, location, message));
    const unique = (items, key, location) => {
      const values = (Array.isArray(items) ? items : []).map(item => item?.[key]);
      if (new Set(values).size !== values.length) fail("CANDIDATE_DUPLICATE_IDENTITY", location, `Duplicate ${key}.`);
    };
    unique(payload.sources, "document", "$.sources");
    unique(payload.workstreams, "id", "$.workstreams");
    unique(payload.entries, "id", "$.entries");
    const sources = new Set((Array.isArray(payload.sources) ? payload.sources : []).map(item => item?.document));
    const streams = new Set((Array.isArray(payload.workstreams) ? payload.workstreams : []).map(item => item?.id));
    for (const [index, entry] of (Array.isArray(payload.entries) ? payload.entries : []).entries()) {
      if (!entry || typeof entry !== "object") continue;
      const location = `$.entries[${index}]`;
      if (!sources.has(entry.source_document) || !streams.has(entry.workstream_id)) {
        fail("CANDIDATE_REFERENCE_UNKNOWN", location, "Entry must reference a registered source and workstream.");
      }
      if (typeof entry.source_document === "string" && typeof entry.candidate_key === "string") {
        const expected = `IC-${crypto.createHash("sha256").update(`${entry.source_document}\0${entry.candidate_key}`).digest("hex").slice(0, 16)}`;
        if (entry.id !== expected) fail("CANDIDATE_ID_BINDING_MISMATCH", `${location}.id`, "ID must bind the exact source document and candidate key.");
      }
      unique(entry.acceptance_criteria, "id", `${location}.acceptance_criteria`);
      const paths = Array.isArray(entry.implementation_paths) ? entry.implementation_paths : [];
      const remaining = Array.isArray(entry.remaining_work) ? entry.remaining_work : [];
      const criteria = Array.isArray(entry.acceptance_criteria) ? entry.acceptance_criteria : [];
      if (entry.implementation_status === "implemented" && (!paths.length || remaining.length || !criteria.length ||
          criteria.some(item => !Array.isArray(item?.validation_commands) || !item.validation_commands.length))) {
        fail("CANDIDATE_COMPLETION_UNPROVEN", location, "Implemented requires mapped files, a check for every criterion, and no remaining work.");
      }
      if (["planned", "partial"].includes(entry.implementation_status) && !remaining.length) {
        fail("CANDIDATE_REMAINING_WORK_REQUIRED", location, "Unfinished candidates must state remaining work.");
      }
      if (entry.implementation_status === "partial" && !paths.length) {
        fail("CANDIDATE_PARTIAL_MAPPING_REQUIRED", location, "Partial implementation must identify existing related files.");
      }
    }
  }

  if (type === "mission") {
    if (!payload.intent || !payload.intent.purpose) {
      issues.push(issue("critical", "MISSING_INTENT", "$.intent.purpose", "Mission requires explicit intent purpose.", "Add intent.purpose."));
    }
    if (payload.mission_statement && /well|properly|optimally|better/i.test(payload.mission_statement)) {
      issues.push(issue("warning", "VAGUE_MISSION", "$.mission_statement", "Mission statement appears vague.", "Use an observable end state."));
    }
  }

  if (type === "warno") {
    if (isEmptyArray(payload.preparation_tasks)) {
      issues.push(issue("error", "WARNO_WITHOUT_PREPARATION_TASKS", "$.preparation_tasks", "WARNO must direct at least one preparation task."));
    }
    if (isValidDate(payload.issued_at) && isValidDate(payload.earliest_execution_at) &&
        !isBefore(payload.issued_at, payload.earliest_execution_at)) {
      issues.push(issue("error", "WARNO_EXECUTION_BEFORE_ISSUE", "$.earliest_execution_at", "WARNO earliest execution time must be after issue time."));
    }
  }

  if (type === "readiness-event") {
    const decisionByRating = {
      X: { Green: "draft_only", Amber: "draft_only", Red: "approval_required", Black: "prohibit" },
      U: { Green: "draft_only", Amber: "draft_only", Red: "approval_required", Black: "prohibit" },
      P: { Green: "allow", Amber: "approval_required", Red: "approval_required", Black: "prohibit" },
      T: { Green: "allow", Amber: "report_required", Red: "approval_required", Black: "prohibit" }
    };
    const previousRank = READINESS_RANK[payload.previous_rating];
    const nextRank = READINESS_RANK[payload.new_rating];
    const promotion = Number.isInteger(previousRank) && Number.isInteger(nextRank) && nextRank > previousRank;

    if (payload.actor !== "EVALUATOR") {
      issues.push(issue("critical", "READINESS_UNAUTHORIZED_ACTOR", "$.actor", "Only EVALUATOR may issue a readiness transition; an agent cannot rate itself."));
    }
    if (promotion && nextRank - previousRank !== 1) {
      issues.push(issue("critical", "READINESS_PROMOTION_STAGE_JUMP", "$.new_rating", "Readiness promotion must advance exactly one stage."));
    }
    if (promotion && (!Array.isArray(payload.evidence) || payload.evidence.length < 3)) {
      issues.push(issue("critical", "READINESS_PROMOTION_EVIDENCE_INSUFFICIENT", "$.evidence", "Readiness promotion requires at least three distinct evidence references."));
    }

    const effects = payload.authority_impact && Array.isArray(payload.authority_impact.roe_effects)
      ? payload.authority_impact.roe_effects
      : [];
    const byClass = new Map();
    effects.forEach((effect, index) => {
      if (byClass.has(effect.roe_class)) {
        issues.push(issue("critical", "READINESS_DUPLICATE_ROE_EFFECT", `$.authority_impact.roe_effects[${index}].roe_class`, "Each ROE class must appear exactly once."));
      }
      byClass.set(effect.roe_class, { effect, index });
    });
    for (const roeClass of ["Green", "Amber", "Red", "Black"]) {
      const entry = byClass.get(roeClass);
      if (!entry) {
        issues.push(issue("critical", "READINESS_MISSING_ROE_EFFECT", "$.authority_impact.roe_effects", `Readiness transition must state the ${roeClass} authority effect.`));
        continue;
      }
      const expectedPrevious = decisionByRating[payload.previous_rating] && decisionByRating[payload.previous_rating][roeClass];
      const expectedNext = decisionByRating[payload.new_rating] && decisionByRating[payload.new_rating][roeClass];
      if (expectedPrevious && entry.effect.previous_decision !== expectedPrevious) {
        issues.push(issue("critical", "READINESS_PREVIOUS_AUTHORITY_MISMATCH", `$.authority_impact.roe_effects[${entry.index}].previous_decision`, `${roeClass} previous decision must be derived from rating ${payload.previous_rating}.`));
      }
      if (expectedNext && entry.effect.new_decision !== expectedNext) {
        issues.push(issue("critical", "READINESS_AUTHORITY_ESCALATION", `$.authority_impact.roe_effects[${entry.index}].new_decision`, `${roeClass} new decision exceeds or conflicts with the ceiling for rating ${payload.new_rating}.`));
      }
    }
  }

  if (type === "board-decision") {
    if (["approve", "approve_with_constraints"].includes(payload.decision) && !payload.selected_option) {
      issues.push(issue("critical", "BOARD_DECISION_OPTION_REQUIRED", "$.selected_option", "An approving board decision must name the selected option."));
    }
    if (payload.decision === "approve_with_constraints" && !hasSubstantiveItems(payload.constraints)) {
      issues.push(issue("critical", "BOARD_DECISION_CONSTRAINTS_REQUIRED", "$.constraints", "approve_with_constraints requires at least one substantive constraint."));
    }
    if (payload.decision !== "defer" && !hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "BOARD_DECISION_EVIDENCE_REQUIRED", "$.evidence", "A disposition other than defer requires evidence."));
    }
  }

  if (type === "battle-rhythm-event") {
    const cadence = payload.cadence || {};
    if (cadence.kind === "interval" && (!Number.isInteger(cadence.interval_minutes) || cadence.cron_expression !== undefined)) {
      issues.push(issue("error", "BATTLE_RHYTHM_INTERVAL_CADENCE_INVALID", "$.cadence", "Interval cadence requires interval_minutes and must not carry cron_expression."));
    }
    if (cadence.kind === "cron" && (!cadence.cron_expression || cadence.interval_minutes !== undefined)) {
      issues.push(issue("error", "BATTLE_RHYTHM_CRON_CADENCE_INVALID", "$.cadence", "Cron cadence requires cron_expression and must not carry interval_minutes."));
    }
    const participants = payload.participants || [];
    const participantSet = new Set(participants);
    if (participantSet.size !== participants.length) {
      issues.push(issue("error", "BATTLE_RHYTHM_DUPLICATE_PARTICIPANT", "$.participants", "Battle rhythm participants must be unique."));
    }
    if (payload.chair && !participantSet.has(payload.chair)) {
      issues.push(issue("critical", "BATTLE_RHYTHM_CHAIR_NOT_PARTICIPANT", "$.chair", "The event chair must be a participant."));
    }
    const requiredRoles = payload.quorum && payload.quorum.required_roles || [];
    if (requiredRoles.some(role => !participantSet.has(role))) {
      issues.push(issue("critical", "BATTLE_RHYTHM_QUORUM_ROLE_MISSING", "$.quorum.required_roles", "Every required quorum role must be an event participant."));
    }
    if (payload.quorum && payload.quorum.minimum_participants > participantSet.size) {
      issues.push(issue("critical", "BATTLE_RHYTHM_QUORUM_IMPOSSIBLE", "$.quorum.minimum_participants", "Minimum quorum cannot exceed the unique participant count."));
    }
  }

  if (type === "battle-rhythm-scheduler") {
    const proposalById = new Map((payload.proposals || []).map(item => [item.event_id, item]));
    for (const [index, proposal] of (payload.proposals || []).entries()) {
      if (proposal.state === "proposed" &&
          (proposal.proposed_occurrence === null || hasSubstantiveItems(proposal.inputs_missing) || hasSubstantiveItems(proposal.blocking_reasons))) {
        issues.push(issue("critical", "SCHEDULER_PROPOSAL_STATE_INCONSISTENT", `$.proposals[${index}]`, "A proposed event requires an occurrence and no missing inputs or blockers."));
      }
      if (proposal.state === "blocked" && !hasSubstantiveItems(proposal.blocking_reasons)) {
        issues.push(issue("error", "SCHEDULER_BLOCK_WITHOUT_REASON", `$.proposals[${index}].blocking_reasons`, "A blocked event requires a blocking reason."));
      }
    }
    for (const [index, queued] of (payload.confirmation_queue || []).entries()) {
      for (const eventId of queued.event_ids || []) {
        const proposal = proposalById.get(eventId);
        if (!proposal) {
          issues.push(issue("error", "SCHEDULER_QUEUE_UNKNOWN_EVENT", `$.confirmation_queue[${index}].event_ids`, `Confirmation queue references unknown event ${eventId}.`));
        } else if (queued.action === "confirm_schedule" && proposal.state !== "proposed") {
          issues.push(issue("error", "SCHEDULER_CONFIRM_BLOCKED_EVENT", `$.confirmation_queue[${index}].action`, "Only proposed events may enter confirm_schedule."));
        }
      }
    }
  }

  if (type === "agent-metl") {
    const taskIds = (payload.essential_tasks || []).map(task => task.task_id);
    if (new Set(taskIds).size !== taskIds.length) {
      issues.push(issue("critical", "AGENT_METL_DUPLICATE_TASK", "$.essential_tasks", "METL task ids must be unique."));
    }
    for (const [index, task] of (payload.essential_tasks || []).entries()) {
      if (!hasSubstantiveItems(task.supporting_fixtures) || !hasSubstantiveItems(task.supporting_runners)) {
        issues.push(issue("error", "AGENT_METL_UNVERIFIABLE_TASK", `$.essential_tasks[${index}]`, "Every essential task requires at least one fixture and runner."));
      }
      if (["P", "T"].includes(task.current_proficiency) && !hasSubstantiveItems(task.evaluation_evidence)) {
        issues.push(issue("critical", "AGENT_METL_RATING_WITHOUT_EVIDENCE", `$.essential_tasks[${index}].evaluation_evidence`, "P and T proficiency ratings require evaluation evidence."));
      }
    }
  }

  if (type === "source-plan") {
    const sourceIds = (payload.planned_sources || []).map(source => source.source_id);
    const sourceSet = new Set(sourceIds);
    if (sourceSet.size !== sourceIds.length) {
      issues.push(issue("error", "SOURCE_PLAN_DUPLICATE_SOURCE", "$.planned_sources", "Planned source ids must be unique."));
    }
    const sequence = payload.collection_sequence || [];
    const steps = sequence.map(item => item.step);
    if (!sameJson(steps, steps.map((unused, index) => index + 1))) {
      issues.push(issue("error", "SOURCE_PLAN_SEQUENCE_NONCONTIGUOUS", "$.collection_sequence", "Collection steps must be unique and contiguous from 1 in listed order."));
    }
    for (const [index, item] of sequence.entries()) {
      if (!sourceSet.has(item.source_id)) {
        issues.push(issue("critical", "SOURCE_PLAN_UNKNOWN_SOURCE", `$.collection_sequence[${index}].source_id`, `Collection sequence references unplanned source ${item.source_id}.`));
      }
    }
    const collectedIds = new Set(sequence.map(item => item.source_id));
    if (sourceIds.some(sourceId => !collectedIds.has(sourceId))) {
      issues.push(issue("error", "SOURCE_PLAN_UNSCHEDULED_SOURCE", "$.collection_sequence", "Every planned source must appear in the collection sequence."));
    }
  }

  if (type === "resource-status") {
    if (Number.isFinite(payload.capacity) && Number.isFinite(payload.current_level) && payload.current_level > payload.capacity) {
      issues.push(issue("critical", "RESOURCE_LEVEL_EXCEEDS_CAPACITY", "$.current_level", "Resource current_level cannot exceed capacity."));
    }
    const bands = payload.threshold_bands || {};
    const green = bands.green && bands.green.min_remaining_ratio;
    const amber = bands.amber && bands.amber.min_remaining_ratio;
    const red = bands.red && bands.red.min_remaining_ratio;
    if ([green, amber, red].every(Number.isFinite) && !(green > amber && amber > red)) {
      issues.push(issue("critical", "RESOURCE_THRESHOLD_ORDER_INVALID", "$.threshold_bands", "Resource thresholds must descend strictly from Green to Amber to Red."));
    }
  }

  if (type === "decision-log") {
    if (Array.isArray(payload.options_considered) && payload.chosen_option && !payload.options_considered.includes(payload.chosen_option)) {
      issues.push(issue("critical", "DECISION_CHOICE_NOT_CONSIDERED", "$.chosen_option", "chosen_option must be one of options_considered."));
    }
    if (["risk_acceptance", "release"].includes(payload.decision_type) && !["USER", "COMMANDER"].includes(payload.decision_maker)) {
      issues.push(issue("critical", "DECISION_RETAINED_AUTHORITY_REQUIRED", "$.decision_maker", "Risk acceptance and release decisions require USER or COMMANDER authority."));
    }
  }

  if (type === "source-record") {
    if (!hasSubstantiveItems(payload.linked_documents)) {
      issues.push(issue("error", "SOURCE_RECORD_WITHOUT_DOCUMENT", "$.linked_documents", "A source record must link at least one doctrine or evidence document."));
    }
    if (!hasSubstantiveItems(payload.reliability_notes)) {
      issues.push(issue("error", "SOURCE_RECORD_WITHOUT_RELIABILITY_NOTES", "$.reliability_notes", "A source record must explain its reliability assessment."));
    }
  }

  if (type === "eefi-alert") {
    if (["Red", "Black"].includes(payload.severity) && payload.blocks_release !== true) {
      issues.push(issue("critical", "EEFI_SEVERE_ALERT_MUST_BLOCK_RELEASE", "$.blocks_release", "Red and Black EEFI alerts must block release."));
    }
    if (payload.blocks_release === true && payload.status !== "blocked") {
      issues.push(issue("critical", "EEFI_RELEASE_BLOCK_STATUS_MISMATCH", "$.status", "An EEFI alert that blocks release must have blocked status."));
    }
  }

  if (type === "classification-label") {
    const labelingAuthorities = new Set(["USER", "COMMANDER", "COS", "S2", "S6"]);
    if (!labelingAuthorities.has(payload.labeling_authority)) {
      issues.push(issue("critical", "CLASSIFICATION_LABEL_UNAUTHORIZED_ACTOR", "$.labeling_authority", "Classification labels may be issued only by USER, COMMANDER, COS, S2, or S6."));
    }
    if (payload.classification === "restricted" && isEmptyArray(payload.need_to_know_roles)) {
      issues.push(issue("error", "RESTRICTED_LABEL_WITHOUT_NEED_TO_KNOW", "$.need_to_know_roles", "Restricted labels must name at least one need-to-know role."));
    }
    if (options.evaluatedAt && isValidDate(payload.review_by) &&
        Date.parse(payload.review_by) <= Date.parse(options.evaluatedAt)) {
      issues.push(issue("critical", "CLASSIFICATION_LABEL_EXPIRED", "$.review_by", "Classification label review_by must be later than the evaluation time."));
    }
  }

  if (type === "releasability-review") {
    const externalAudience = payload.requested_audience === "public" || payload.requested_audience === "partner";
    const blockingFindings = (payload.findings || []).filter(item => item.severity === "error" || item.severity === "critical");
    const labels = payload.labels || [];
    const outputForbidden = labels.some(item => item.eefi_class === "output_forbidden");
    const restricted = labels.some(item => item.classification === "restricted");
    const nonPublic = labels.some(item => item.classification !== "public");

    if (!isValidDate(payload.reviewed_at) || !isValidDate(payload.expires_at) ||
        !isBefore(payload.reviewed_at, payload.expires_at)) {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_INVALID_VALIDITY", "$.expires_at", "Releasability review expiry must be later than reviewed_at."));
    }
    if (options.evaluatedAt && isValidDate(options.evaluatedAt)) {
      if (isValidDate(payload.reviewed_at) && Date.parse(payload.reviewed_at) > Date.parse(options.evaluatedAt)) {
        issues.push(issue("critical", "RELEASABILITY_REVIEW_FUTURE_DATED", "$.reviewed_at", "Releasability review cannot be issued after the evaluation time."));
      }
      if (isValidDate(payload.expires_at) && Date.parse(payload.expires_at) <= Date.parse(options.evaluatedAt)) {
        issues.push(issue("critical", "RELEASABILITY_REVIEW_EXPIRED", "$.expires_at", "Releasability review is expired at the evaluation time."));
      }
    }
    if (externalAudience && payload.reviewer !== "USER" && payload.reviewer !== "COMMANDER") {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_EXTERNAL_AUTHORITY_REQUIRED", "$.reviewer", "Partner and public release require USER or COMMANDER review authority."));
    }
    if ((payload.decision === "release" || payload.decision === "redact") && !payload.release_review_id) {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_FINAL_REVIEW_MISSING", "$.release_review_id", "Release or redaction must bind the downstream ReleaseReview id."));
    }
    if ((payload.decision === "release" || payload.decision === "redact") && blockingFindings.length > 0) {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_BLOCKING_FINDINGS", "$.findings", "A review with error or critical findings cannot release or redact content for delivery."));
    }
    if (outputForbidden && payload.decision !== "deny" && payload.decision !== "escalate") {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_OUTPUT_FORBIDDEN", "$.decision", "Output-forbidden EEFI must be denied or escalated."));
    }
    if (externalAudience && restricted && payload.decision === "release") {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_RESTRICTED_EXTERNAL_RELEASE", "$.decision", "Restricted content cannot be released to a partner or public audience."));
    }
    if (payload.requested_audience === "public" && nonPublic && payload.decision === "release") {
      issues.push(issue("critical", "RELEASABILITY_REVIEW_NON_PUBLIC_RAW_RELEASE", "$.decision", "Non-public content must be redacted or denied for public release."));
    }
  }

  if (type === "context-release") {
    const external = payload.recipient && payload.recipient.kind === "external_party";
    const releaseRefs = [payload.classification_label_id, payload.releasability_review_id, payload.release_review_id];
    if (!isValidDate(payload.released_at) || !isValidDate(payload.expires_at) ||
        !isBefore(payload.released_at, payload.expires_at)) {
      issues.push(issue("critical", "CONTEXT_RELEASE_INVALID_VALIDITY", "$.expires_at", "Context release expiry must be later than released_at."));
    }
    if (options.evaluatedAt && isValidDate(payload.expires_at) &&
        Date.parse(payload.expires_at) <= Date.parse(options.evaluatedAt)) {
      issues.push(issue("critical", "CONTEXT_RELEASE_EXPIRED", "$.expires_at", "Context release is expired at the evaluation time."));
    }
    if (external && payload.released_by !== "USER" && payload.released_by !== "COMMANDER") {
      issues.push(issue("critical", "CONTEXT_RELEASE_EXTERNAL_AUTHORITY_REQUIRED", "$.released_by", "External context release requires USER or COMMANDER authority."));
    }
    if (external && payload.packet_form === "raw") {
      issues.push(issue("critical", "CONTEXT_RELEASE_EXTERNAL_RAW_PROHIBITED", "$.packet_form", "External ContextRelease packets cannot carry raw context; use the final ReleaseReview path."));
    }
    if ((external || payload.packet_form === "raw") && releaseRefs.some(value => typeof value !== "string" || value.length === 0)) {
      issues.push(issue("critical", "CONTEXT_RELEASE_REVIEW_BINDINGS_MISSING", "$", "External or raw context release must bind classification, releasability, and final release review ids."));
    }
    const revocation = payload.revocation || {};
    if (revocation.revoked === true) {
      if (!revocation.revoked_at || !revocation.revoked_by || !revocation.reason) {
        issues.push(issue("critical", "CONTEXT_RELEASE_REVOCATION_INCOMPLETE", "$.revocation", "Revoked context release requires revoked_at, revoked_by, and reason."));
      }
      issues.push(issue("critical", "CONTEXT_RELEASE_REVOKED", "$.revocation.revoked", "A revoked context release cannot execute."));
    } else if (revocation.revoked_at || revocation.revoked_by || revocation.reason) {
      issues.push(issue("error", "CONTEXT_RELEASE_FALSE_REVOCATION_DETAILS", "$.revocation", "A non-revoked release cannot carry revocation details."));
    }
  }

  if (type === "opord") {
    const authority = payload.command_and_signal && payload.command_and_signal.authority;
    if (!authority) {
      issues.push(issue("critical", "MISSING_AUTHORITY", "$.command_and_signal.authority", "OPORD cannot execute without authority boundaries."));
    } else {
      if (isEmptyArray(authority.prohibited)) {
        issues.push(issue("error", "EMPTY_PROHIBITED_ACTIONS", "$.command_and_signal.authority.prohibited", "Prohibited actions must be explicit."));
      }
    }
    const assessment = payload.assessment || {};
    if (isEmptyArray(assessment.moe)) {
      issues.push(issue("warning", "MOP_ONLY", "$.assessment.moe", "OPORD has no MOE; output may be assessed only by activity."));
    }
  }

  if (type === "tool-request") {
    if (payload.roe_class === "Black") {
      issues.push(issue("critical", "BLACK_ACTION_REQUESTED", "$.roe_class", "Black actions are prohibited and cannot be approved."));
    }
    if (payload.roe_class === "Red" && payload.approval_required !== true) {
      issues.push(issue("critical", "RED_WITHOUT_APPROVAL", "$.approval_required", "Red tool request requires approval."));
    }
    if (/secret|token|private_key|password/i.test(`${payload.action} ${payload.target}`)) {
      issues.push(issue("critical", "POSSIBLE_EEFI", "$.target", "Possible sensitive data exposure; suppress output and escalate."));
    }
  }

  if (type === "dispatch-tool-policy") {
    if (!isValidDate(payload.approved_at) || !isValidDate(payload.valid_until) ||
        !isBefore(payload.approved_at, payload.valid_until)) {
      issues.push(issue("critical", "DISPATCH_POLICY_INVALID_VALIDITY", "$.valid_until", "Dispatch policy validity must end after approval."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "DISPATCH_POLICY_AUTHORITY_DRIFT", "$.authority", "Dispatch policy must retain USER authority, prohibit self-approval, and deny release."));
    }
    const authorization = payload.authorization || {};
    if (authorization.source !== "mission_plan_policy_digest" ||
        authorization.authorized_by !== "USER" ||
        authorization.compiled_by !== "controls_dispatch_controller" ||
        authorization.enforcement_level !== "guardrail" ||
        authorization.gateway_exclusive !== false) {
      issues.push(issue("critical", "DISPATCH_POLICY_UNTRUSTED_ISSUER", "$.authorization", "Local dispatch policy must be controller-compiled from exact mission-plan authority and describe project-hook enforcement only as a guardrail."));
    }

    const rules = Array.isArray(payload.tool_rules) ? payload.tool_rules : [];
    const ruleIds = rules.map(rule => rule && rule.rule_id);
    if (new Set(ruleIds).size !== ruleIds.length) {
      issues.push(issue("critical", "DISPATCH_POLICY_DUPLICATE_RULE_ID", "$.tool_rules", "Dispatch policy rule_id values must be unique."));
    }

    const modeFields = {
      exact_sha256: ["allowed_sha256"],
      path_prefix: ["path_fields", "allowed_path_prefixes"],
      patch_paths: ["allowed_path_prefixes"]
    };
    for (const [index, rule] of rules.entries()) {
      const pointer = `$.tool_rules[${index}]`;
      if (typeof rule.mission_action !== "string" || rule.mission_action.trim().length === 0) {
        issues.push(issue("critical", "DISPATCH_POLICY_MISSION_ACTION_MISSING", `${pointer}.mission_action`, "Each tool rule must bind one exact allowed action from the mission plan."));
      }
      if (typeof rule.tool_name !== "string" ||
          !/^[A-Za-z0-9][A-Za-z0-9._:+/-]*$/.test(rule.tool_name) ||
          /[*?[\]{}]/.test(rule.tool_name)) {
        issues.push(issue("critical", "DISPATCH_POLICY_NONEXACT_TOOL", `${pointer}.tool_name`, "Tool rules must bind one exact, non-glob tool name."));
      }

      const inputMatch = rule.input_match || {};
      const expected = modeFields[inputMatch.mode];
      const controlledFields = ["allowed_sha256", "path_fields", "allowed_path_prefixes"];
      const present = controlledFields.filter(field =>
        Object.prototype.hasOwnProperty.call(inputMatch, field));
      if (expected && (expected.some(field => !present.includes(field)) ||
          present.some(field => !expected.includes(field)))) {
        issues.push(issue("critical", "DISPATCH_POLICY_INPUT_MATCH_FIELDS", `${pointer}.input_match`, `Input match mode ${inputMatch.mode} has missing or mixed mode fields.`));
      }

      for (const [pathIndex, jsonPointerValue] of
        (Array.isArray(inputMatch.path_fields) ? inputMatch.path_fields : []).entries()) {
        if (!validJsonPointer(jsonPointerValue)) {
          issues.push(issue("critical", "DISPATCH_POLICY_INVALID_PATH_FIELD", `${pointer}.input_match.path_fields[${pathIndex}]`, "Path fields must be non-root RFC 6901 JSON pointers."));
        }
      }
      for (const [prefixIndex, prefix] of
        (Array.isArray(inputMatch.allowed_path_prefixes) ? inputMatch.allowed_path_prefixes : []).entries()) {
        if (!safeRepositoryPrefix(prefix)) {
          issues.push(issue("critical", "DISPATCH_POLICY_UNSAFE_PATH_PREFIX", `${pointer}.input_match.allowed_path_prefixes[${prefixIndex}]`, "Allowed path prefixes must be canonical repository-relative paths outside protected control state."));
        }
      }

      if (inputMatch.mode === "path_prefix" &&
          !["repository_read", "repository_write"].includes(rule.operation_class)) {
        issues.push(issue("critical", "DISPATCH_POLICY_MODE_OPERATION_MISMATCH", `${pointer}.operation_class`, "path_prefix matching is limited to repository read or write operations."));
      }
      if (inputMatch.mode === "patch_paths" && rule.operation_class !== "repository_write") {
        issues.push(issue("critical", "DISPATCH_POLICY_MODE_OPERATION_MISMATCH", `${pointer}.operation_class`, "patch_paths matching is limited to repository write operations."));
      }
      if (["network_access", "delegation"].includes(rule.operation_class) &&
          authorization.enforcement_level === "guardrail") {
        issues.push(issue("critical", "DISPATCH_POLICY_EXTERNAL_GATEWAY_REQUIRED", `${pointer}.operation_class`, "Project-hook guardrails cannot authorize network or delegation operation classes."));
      }
    }
  }

  if (type === "agent-dispatch-lease") {
    const issuedAt = Date.parse(payload.issued_at);
    const notBefore = Date.parse(payload.not_before);
    const expiresAt = Date.parse(payload.expires_at);
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.not_before) ||
        !isValidDate(payload.expires_at) || issuedAt > notBefore || notBefore >= expiresAt) {
      issues.push(issue("critical", "DISPATCH_LEASE_INVALID_VALIDITY", "$.expires_at", "Lease time order must satisfy issued_at <= not_before < expires_at."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "DISPATCH_LEASE_AUTHORITY_DRIFT", "$.authority", "Dispatch lease must retain USER authority, prohibit self-approval, and deny release."));
    }

    const previousKind = artifactRefKind(payload.previous_lease_ref);
    if (previousKind === "malformed") {
      issues.push(issue("critical", "DISPATCH_LEASE_MALFORMED_NONE_REF", "$.previous_lease_ref", "Previous lease reference must be concrete or the exact all-none sentinel."));
    }
    if ((payload.issuance_reason === "initial" && previousKind !== "none") ||
        (payload.issuance_reason === "resume" && previousKind !== "concrete")) {
      issues.push(issue("critical", "DISPATCH_LEASE_REASON_REF_MISMATCH", "$.previous_lease_ref", "Initial leases require the none sentinel; resumed leases require one concrete previous lease reference."));
    }
    if (!Number.isInteger(payload.request_budget) || payload.request_budget < 1) {
      issues.push(issue("critical", "DISPATCH_LEASE_BUDGET_MISMATCH", "$.request_budget", "Lease request budget must be a positive policy-derived integer."));
    }

    const resolvedPolicy = resolveLocalArtifactRef(payload.tool_policy_ref);
    if (resolvedPolicy.status === "mismatch") {
      issues.push(issue("critical", "DISPATCH_LEASE_POLICY_REF_MISMATCH", "$.tool_policy_ref", "Locally available tool policy bytes must match the exact artifact reference."));
    }
    if (resolvedPolicy.status === "resolved") {
      const policy = resolvedPolicy.payload;
      if (policy.type !== "DispatchToolPolicy" ||
          policy.mission_id !== payload.mission_id ||
          policy.wave_id !== payload.wave_id ||
          policy.agent_id !== payload.agent_id ||
          policy.provider !== payload.provider) {
        issues.push(issue("critical", "DISPATCH_LEASE_POLICY_BINDING_MISMATCH", "$.tool_policy_ref", "Resolved tool policy identity must match the lease."));
      }
      if (payload.request_budget !== policy.max_total_admissions) {
        issues.push(issue("critical", "DISPATCH_LEASE_BUDGET_MISMATCH", "$.request_budget", "Lease request budget must equal the resolved policy admission budget."));
      }
      if (payload.issuance_reason === "initial" &&
          policy.repository_state && policy.repository_state.require_clean_start === true &&
          payload.initial_repository_state && payload.initial_repository_state.dirty === true) {
        issues.push(issue("critical", "DISPATCH_LEASE_DIRTY_CLEAN_START", "$.initial_repository_state.dirty", "A policy requiring clean start cannot issue an initial lease from dirty repository state."));
      }
    }
  }

  if (type === "tool-admission-event") {
    if (!Number.isInteger(payload.sequence) || payload.sequence < 1) {
      issues.push(issue("critical", "TOOL_ADMISSION_SEQUENCE_INVALID", "$.sequence", "Tool admission sequence must be a positive integer."));
    }
    if (payload.decision === "allow" && payload.rule_id === "none") {
      issues.push(issue("critical", "TOOL_ADMISSION_ALLOW_WITHOUT_RULE", "$.rule_id", "An allowed request must bind the exact admitting rule."));
    }
    if (payload.decision === "deny" && !hasSubstantiveItems(payload.reason_codes)) {
      issues.push(issue("critical", "TOOL_ADMISSION_DENY_WITHOUT_REASON", "$.reason_codes", "A denied request must record at least one substantive reason code."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "TOOL_ADMISSION_AUTHORITY_DRIFT", "$.authority", "Tool admission cannot expand authority or authorize release."));
    }
    if (!isValidDate(payload.decided_at)) {
      issues.push(issue("critical", "TOOL_ADMISSION_INVALID_TIMESTAMP", "$.decided_at", "Tool admission requires a valid decision timestamp."));
    }
  }

  if (type === "tool-effect-scope" || type === "gateway-effect-scope") {
    const created = Date.parse(payload.created_at);
    const expires = Date.parse(payload.expires_at);
    if (!Number.isFinite(created) || !Number.isFinite(expires) || expires <= created || expires - created > 3600000) {
      issues.push(issue("critical", "TOOL_EFFECT_SCOPE_TIME_INVALID", "$", "An effect scope must have a positive validity of at most one hour."));
    }
    const resources = Array.isArray(payload.resources) ? payload.resources : [];
    if (new Set(resources.map(item => item && item.id)).size !== resources.length ||
        new Set(resources.map(item => item && item.target)).size !== resources.length) {
      issues.push(issue("critical", "TOOL_EFFECT_SCOPE_DUPLICATE_RESOURCE", "$.resources", "Resource identifiers and exact targets must be unique."));
    }
  }

  if (type === "gateway-effect-subject") {
    const digest = canonicalControlDigestWithout(payload, ["id"]);
    if (payload.id !== `GESUB-${digest.slice(0, 32)}`) {
      issues.push(issue("critical", "GATEWAY_EFFECT_SUBJECT_DIGEST_MISMATCH", "$.id", "Gateway effect subject identity must bind its exact canonical projection."));
    }
    if (payload.containment_history && (payload.schema_version !== "0.2" ||
        payload.execution_mode !== "oci_linux_sandbox_reference" ||
        artifactRefKind(payload.containment_history.latest_ref) !== "concrete")) {
      issues.push(issue("critical", "GATEWAY_EFFECT_CONTAINMENT_HISTORY_INVALID", "$.containment_history", "Containment history requires a v0.2 OCI subject and exact latest observation reference."));
    }
  }

  if (type === "gateway-effect-scope" && payload.subject && typeof payload.subject === "object") {
    for (const nested of validatePayload(payload.subject, "gateway-effect-subject").issues) {
      issues.push({ ...nested, path: `$.subject${nested.path.slice(1)}` });
    }
    if (["mission_id", "wave_id", "agent_id"].some(key => payload[key] !== payload.subject[key]) ||
        canonicalControlDigestWithout(payload.repository_binding || {}, []) !==
          canonicalControlDigestWithout(payload.subject.repository_binding || {}, [])) {
      issues.push(issue("critical", "GATEWAY_EFFECT_SCOPE_SUBJECT_MISMATCH", "$.subject", "An effect scope must preserve the exact gateway subject identity."));
    }
  }

  if (type === "tool-effect-review" || type === "gateway-effect-review") {
    const codes = Array.isArray(payload.reason_codes) ? payload.reason_codes : [];
    if ((payload.status === "evidence_bound" && codes.length !== 0) || (payload.status === "blocked" && codes.length === 0)) {
      issues.push(issue("critical", "TOOL_EFFECT_REVIEW_STATUS_INVALID", "$", "Only a review with no blocking codes can be evidence_bound; neither status settles effects."));
    }
  }

  if (type === "tool-effect-settlement" || type === "gateway-effect-settlement") {
    if (payload.request && typeof payload.request === "object") {
      const digest = canonicalControlDigestWithout(payload.request, []);
      const prefix = type === "gateway-effect-settlement" ? "GESL" : "TESL";
      if (payload.request_sha256 !== digest || payload.id !== `${prefix}-${digest.slice(0, 32)}`) {
        issues.push(issue("critical", "TOOL_EFFECT_SETTLEMENT_REQUEST_BINDING_MISMATCH", "$.request_sha256", "Settlement identity must bind its exact canonical request."));
      }
    }
    if (!isValidDate(payload.settled_at) || !isValidDate(payload.admission_valid_until) ||
        Date.parse(payload.settled_at) >= Date.parse(payload.admission_valid_until)) {
      issues.push(issue("critical", "TOOL_EFFECT_SETTLEMENT_TIME_INVALID", "$", "Settlement must occur inside its exact proof and decision admission window."));
    }
  }

  if (type === "gateway-effect-settlement-request" || type === "gateway-effect-settlement") {
    const request = type === "gateway-effect-settlement" ? payload.request || {} : payload;
    for (const reference of [request.review_ref, request.campaign_ref, request.cycle_order_ref, request.decision_ref,
      ...(Array.isArray(request.attestation_refs) ? request.attestation_refs : [])]) {
      if (artifactRefKind(reference) !== "concrete") issues.push(issue("critical", "GATEWAY_SETTLEMENT_REFERENCE_INVALID", "$", "Settlement proof references must be concrete."));
    }
    if (artifactRefKind(request.containment_observation_ref) === "malformed") {
      issues.push(issue("critical", "GATEWAY_SETTLEMENT_CONTAINMENT_INVALID", "$", "Containment must use a concrete reference or the exact none sentinel."));
    }
    if (type === "gateway-effect-settlement") {
      for (const key of ["gateway_request_ref", "scope_ref", "lease_ref", "checkpoint_ref", "admission_ref"]) {
        if (artifactRefKind(payload[key]) !== "concrete") issues.push(issue("critical", "GATEWAY_SETTLEMENT_REFERENCE_INVALID", `$.${key}`, "Settlement discharge requires an exact reference."));
      }
      if (artifactRefKind(payload.effect_checkpoint_ref) === "malformed" ||
          payload.containment_required !== payload.containment_verified ||
          (payload.containment_required ? artifactRefKind(request.containment_observation_ref) !== "concrete"
            : artifactRefKind(request.containment_observation_ref) !== "none")) {
        issues.push(issue("critical", "GATEWAY_SETTLEMENT_CONTAINMENT_INVALID", "$", "A required containment boundary must be verified, never omitted or inferred from a none reference."));
      }
    }
  }

  if (type === "agent-execution-checkpoint") {
    const previousKind = artifactRefKind(payload.previous_checkpoint_ref);
    const admissionKind = artifactRefKind(payload.tool_admission_ref);
    if (previousKind === "malformed" || admissionKind === "malformed") {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_MALFORMED_NONE_REF", "$", "Checkpoint references must be concrete or use the exact all-none sentinel."));
    }

    if (payload.checkpoint_kind === "baseline" &&
        (payload.sequence !== 0 || payload.lease_status !== "active" ||
         previousKind !== "none" || admissionKind !== "none")) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_BASELINE_INVALID", "$", "Baseline checkpoints require sequence 0, active status, and none references."));
    }
    if (payload.checkpoint_kind !== "baseline" &&
        (!Number.isInteger(payload.sequence) || payload.sequence < 1 || previousKind !== "concrete")) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_CHAIN_INVALID", "$.previous_checkpoint_ref", "Every non-baseline checkpoint requires a positive sequence and concrete predecessor."));
    }
    if (payload.checkpoint_kind === "post_tool" &&
        (payload.sequence < 1 || admissionKind !== "concrete")) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_POST_TOOL_INVALID", "$.tool_admission_ref", "post_tool checkpoints require a positive sequence and concrete tool admission reference."));
    }
    const executionResult = payload.execution_result || {};
    if (payload.checkpoint_kind === "post_tool" &&
        (executionResult.status === "not_applicable" ||
         executionResult.provider_result_sha256 === "none")) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_RESULT_MISSING", "$.execution_result", "post_tool checkpoints require a concrete provider-result digest and execution status."));
    }
    if (payload.checkpoint_kind !== "post_tool" &&
        (executionResult.status !== "not_applicable" ||
         executionResult.provider_result_sha256 !== "none" ||
         executionResult.external_effects !== "none")) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_RESULT_UNEXPECTED", "$.execution_result", "Lifecycle checkpoints must use the exact not-applicable execution-result sentinel."));
    }
    if (["failed", "unknown"].includes(executionResult.status) &&
        payload.lease_status !== "blocked") {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_UNRESOLVED_EFFECT_ACTIVE", "$.lease_status", "Failed or unknown tool effects must block the lease for reconciliation."));
    }
    if (!["baseline", "post_tool"].includes(payload.checkpoint_kind) && admissionKind !== "none") {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_TRANSITION_TOOL_REF", "$.tool_admission_ref", "Lifecycle transition checkpoints must use the none tool-admission sentinel."));
    }
    if (["interruption", "revocation", "supersession", "completion"].includes(payload.checkpoint_kind) &&
        payload.lease_status === "active") {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_ACTIVE_TERMINAL_KIND", "$.lease_status", "Interruption and terminal checkpoint kinds must map to non-active lease status."));
    }
    if (payload.resume_authorized !== false || retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_AUTHORITY_EXPANSION", "$.authority", "Checkpoint state cannot authorize resume, self-approval, or release."));
    }
    if (!isValidDate(payload.recorded_at)) {
      issues.push(issue("critical", "EXECUTION_CHECKPOINT_INVALID_TIMESTAMP", "$.recorded_at", "Execution checkpoint requires a valid recorded timestamp."));
    }
  }

  if (type === "gateway-identity-policy") {
    if (!isValidDate(payload.valid_from) || !isValidDate(payload.expires_at) ||
        Date.parse(payload.valid_from) >= Date.parse(payload.expires_at)) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_VALIDITY_INVALID", "$.expires_at", "Gateway identity policy expiry must be later than its activation time."));
    }
    try {
      const signingKey = crypto.createPublicKey(payload.adapter_profile && payload.adapter_profile.signing_public_key_pem);
      if (signingKey.asymmetricKeyType !== "ed25519" ||
          publicKeyId(signingKey) !== payload.adapter_profile.signing_key_id) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_SIGNING_KEY_INVALID", "$.adapter_profile.signing_key_id", "Gateway adapter signing key must be Ed25519 and match its SHA-256 SPKI key ID."));
      }
    } catch (error) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_SIGNING_KEY_INVALID", "$.adapter_profile.signing_public_key_pem", "Gateway adapter signing key must be valid SPKI PEM."));
    }
    const rootIds = new Set();
    for (const [index, root] of (payload.trusted_x509_roots || []).entries()) {
      const pointer = `$.trusted_x509_roots[${index}]`;
      if (rootIds.has(root.id)) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_DUPLICATE_ROOT", `${pointer}.id`, "Trusted X.509 root IDs must be unique."));
      }
      rootIds.add(root.id);
      if (!isValidDate(root.valid_until) ||
          (isValidDate(payload.valid_from) &&
           Date.parse(root.valid_until) <= Date.parse(payload.valid_from))) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_ROOT_VALIDITY_INVALID", `${pointer}.valid_until`, "A trusted root must remain valid after policy activation."));
      }
      try {
        const certificate = new crypto.X509Certificate(root.certificate_pem);
        if (certificate.ca !== true || !certificate.verify(certificate.publicKey)) {
          issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_ROOT_INVALID", `${pointer}.certificate_pem`, "A trusted X.509 root must be a self-signed CA certificate."));
        }
        if (certificateSha256(certificate) !== root.certificate_sha256) {
          issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_ROOT_DIGEST_MISMATCH", `${pointer}.certificate_sha256`, "Trusted-root digest must match the certificate DER bytes."));
        }
      } catch (error) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_ROOT_INVALID", `${pointer}.certificate_pem`, "Trusted root must be a valid PEM certificate."));
      }
    }
    const principalIds = new Set();
    const spiffeIds = new Set();
    const agentBindings = new Set();
    for (const [index, principal] of (payload.principals || []).entries()) {
      const pointer = `$.principals[${index}]`;
      const agentBinding = `${principal.agent_id}:${principal.provider}`;
      if (principalIds.has(principal.id) || spiffeIds.has(principal.spiffe_id) ||
          agentBindings.has(agentBinding)) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_DUPLICATE_PRINCIPAL", pointer, "Principal IDs, SPIFFE IDs, and agent-provider bindings must each be unique."));
      }
      principalIds.add(principal.id);
      spiffeIds.add(principal.spiffe_id);
      agentBindings.add(agentBinding);
      const root = (payload.trusted_x509_roots || [])
        .find(item => item.id === principal.trust_root_id);
      if (!root) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_ROOT_REF_INVALID", `${pointer}.trust_root_id`, "Every principal must reference exactly one trusted X.509 root."));
      }
      try {
        const parsed = new URL(principal.spiffe_id);
        if (parsed.protocol !== "spiffe:" || !parsed.hostname ||
            parsed.pathname === "/" || parsed.search || parsed.hash ||
            parsed.href !== principal.spiffe_id ||
            (root && parsed.hostname !== root.trust_domain)) {
          issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_SPIFFE_ID_INVALID", `${pointer}.spiffe_id`, "SPIFFE ID must use its selected trust domain and a non-root path."));
        }
      } catch (error) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_SPIFFE_ID_INVALID", `${pointer}.spiffe_id`, "Principal SPIFFE ID must be a valid SPIFFE URI."));
      }
    }
    for (const principalId of payload.revocations && payload.revocations.principal_ids || []) {
      if (!principalIds.has(principalId)) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_REVOCATION_UNKNOWN", "$.revocations.principal_ids", "Principal revocations must name principals retained by this exact policy."));
      }
    }
    const gatewayAssuranceValid = Boolean(payload.gateway &&
      ((payload.schema_version === "0.1" &&
        payload.gateway.assurance_level === "authenticated_reference" &&
        payload.gateway.exclusive_path_verified === false) ||
       (payload.schema_version === "0.2" &&
        payload.gateway.assurance_level === "managed_exclusive" &&
        payload.gateway.exclusive_path_verified === true)));
    if (!gatewayAssuranceValid ||
        retainedAuthorityDrift(payload.authority) ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_POLICY_AUTHORITY_OVERCLAIM", "$.authority", "Gateway identity policy assurance must match its version and remain non-production, USER-controlled authority."));
    }
  }

  if (type === "gateway-identity-challenge") {
    const issuedAt = Date.parse(payload.issued_at);
    const expiresAt = Date.parse(payload.expires_at);
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) ||
        issuedAt >= expiresAt || expiresAt > issuedAt + 300000) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_CHALLENGE_VALIDITY_INVALID", "$.expires_at", "Gateway identity challenge must have a positive validity window no longer than five minutes."));
    }
    if (gatewayChallengeDigest(payload) !== payload.challenge_sha256) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_CHALLENGE_DIGEST_MISMATCH", "$.challenge_sha256", "Challenge digest must bind the complete signed challenge."));
    }
    if (!strictBase64(payload.signature && payload.signature.signature_base64)) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_CHALLENGE_SIGNATURE_ENCODING_INVALID", "$.signature.signature_base64", "Challenge signature must be strict base64."));
    }
    if (artifactRefKind(payload.identity_policy_ref) !== "concrete") {
      issues.push(issue("critical", "GATEWAY_IDENTITY_CHALLENGE_POLICY_REF_INVALID", "$.identity_policy_ref", "Challenge requires one concrete identity-policy reference."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_CHALLENGE_AUTHORITY_DRIFT", "$.authority", "Gateway challenge cannot authorize production execution, self-approval, or release."));
    }
  }

  if (type === "gateway-principal-evidence") {
    const observedAt = Date.parse(payload.observed_at);
    const expiresAt = Date.parse(payload.expires_at);
    if (!isValidDate(payload.observed_at) || !isValidDate(payload.expires_at) ||
        observedAt >= expiresAt || expiresAt > observedAt + 900000) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_VALIDITY_INVALID", "$.expires_at", "Gateway principal evidence must have a positive validity window no longer than fifteen minutes."));
    }
    if (gatewayEvidenceDigest(payload) !== payload.evidence_sha256) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_DIGEST_MISMATCH", "$.evidence_sha256", "Evidence digest must bind the complete signed evidence."));
    }
    if (!strictBase64(payload.signature && payload.signature.signature_base64)) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_SIGNATURE_ENCODING_INVALID", "$.signature.signature_base64", "Evidence signature must be strict base64."));
    }
    if (artifactRefKind(payload.identity_policy_ref) !== "concrete" ||
        artifactRefKind(payload.identity_challenge_ref) !== "concrete") {
      issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_REF_INVALID", "$", "Principal evidence requires concrete identity-policy and challenge references."));
    }
    try {
      const leaf = new crypto.X509Certificate(payload.transport && payload.transport.leaf_certificate_pem);
      const spiffeId = parseSpiffeId(leaf);
      if (leaf.ca || !spiffeId || spiffeId !== payload.transport.spiffe_id) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_LEAF_INVALID", "$.transport.leaf_certificate_pem", "Evidence leaf certificate must be a non-CA certificate with exactly the declared SPIFFE URI SAN."));
      }
      if (certificateSha256(leaf) !== payload.transport.client_certificate_sha256) {
        issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_LEAF_DIGEST_MISMATCH", "$.transport.client_certificate_sha256", "Client-certificate digest must match the leaf DER bytes."));
      }
    } catch (error) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_LEAF_INVALID", "$.transport.leaf_certificate_pem", "Evidence leaf certificate must be valid PEM."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "GATEWAY_IDENTITY_EVIDENCE_AUTHORITY_DRIFT", "$.authority", "Gateway principal evidence cannot authorize production execution, self-approval, or release."));
    }
  }

  if (type === "production-sandbox-policy") {
    const verification = validateProductionSandboxPolicy(payload);
    for (const code of verification.codes) {
      issues.push(issue(
        "critical",
        code,
        "$",
        "Production sandbox policy failed structural trust validation."
      ));
    }
  }

  if (type === "production-sandbox-evidence") {
    if (artifactRefKind(payload.policy_ref) !== "concrete") {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_POLICY_REF_MISMATCH",
        "$.policy_ref",
        "Production sandbox evidence requires one concrete policy reference."
      ));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_SIGNATURE_INVALID",
        "$.signature",
        "Production sandbox evidence requires a canonical Ed25519 signature."
      ));
    }
    if (productionSandboxEvidenceDigest(payload) !==
        payload.evidence_sha256) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_DIGEST_MISMATCH",
        "$.evidence_sha256",
        "Evidence digest must bind the complete signed production appraisal."
      ));
    }
    if (productionObjectDigest(payload.deployment || {}) !==
        payload.deployment_identity_sha256) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_DEPLOYMENT_DIGEST_MISMATCH",
        "$.deployment_identity_sha256",
        "Deployment identity digest must bind every declared production layer."
      ));
    }
    if (!payload.attestation_result ||
        payload.attestation_result.freshness_nonce !== payload.nonce ||
        payload.attestation_result.appraisal !== "pass") {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_ATTESTATION_RESULT_INVALID",
        "$.attestation_result",
        "RATS appraisal must pass and bind the exact fresh evidence nonce."
      ));
    }
    if (!isBefore(payload.observed_at, payload.expires_at)) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_NOT_ACTIVE",
        "$.expires_at",
        "Production sandbox evidence requires an ordered positive validity window."
      ));
    }
    if (!payload.authority ||
        payload.authority.human_final_decision_authority !== "USER" ||
        payload.authority.self_approval_prohibited !== true ||
        payload.authority.production_execution_authorized !== false ||
        payload.authority.release_authorized !== false) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_EVIDENCE_AUTHORITY_INVALID",
        "$.authority",
        "One appraiser observation cannot authorize production or release."
      ));
    }
  }

  if (type === "production-sandbox-admission") {
    if (artifactRefKind(payload.policy_ref) !== "concrete" ||
        !Array.isArray(payload.evidence_refs) ||
        payload.evidence_refs.some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_ADMISSION_EVIDENCE_REF_MISMATCH",
        "$",
        "Production admission requires one concrete policy and only concrete evidence references."
      ));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_ADMISSION_SIGNATURE_INVALID",
        "$.signature",
        "Production admission requires a canonical policy-pinned Ed25519 signature."
      ));
    }
    if (productionSandboxAdmissionDigest(payload) !==
        payload.admission_sha256) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_ADMISSION_DIGEST_MISMATCH",
        "$.admission_sha256",
        "Admission digest must bind the signed quorum projection."
      ));
    }
    const quorum = payload.quorum || {};
    if (quorum.satisfied !== true ||
        quorum.valid_evidence_count !==
          (quorum.valid_evidence_ids || []).length ||
        quorum.valid_evidence_count !==
          (quorum.appraiser_ids || []).length ||
        quorum.distinct_key_count !== (quorum.key_ids || []).length ||
        quorum.independent_domain_count !==
          (quorum.independence_domains || []).length ||
        quorum.valid_evidence_count < quorum.minimum_valid_evidence ||
        quorum.independent_domain_count <
          quorum.minimum_independent_domains) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_ADMISSION_PROJECTION_MISMATCH",
        "$.quorum",
        "Production admission quorum counts must be internally consistent and satisfied."
      ));
    }
    if (!isBefore(payload.issued_at, payload.expires_at)) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_ADMISSION_NOT_ACTIVE",
        "$.expires_at",
        "Production admission requires an ordered positive validity window."
      ));
    }
    if (payload.assurance_level !== "managed_exclusive" ||
        payload.production_execution_authorized !== true ||
        payload.production_deployment_verified !== true ||
        payload.release_authorized !== false ||
        !payload.authority ||
        payload.authority.human_final_decision_authority !== "USER" ||
        payload.authority.self_approval_prohibited !== true ||
        payload.authority.production_execution_authorized !== true ||
        payload.authority.release_authorized !== false) {
      issues.push(issue(
        "critical",
        "PRODUCTION_SANDBOX_ADMISSION_AUTHORITY_INVALID",
        "$.authority",
        "Production admission may authorize only the appraised managed deployment; USER and release boundaries remain fixed."
      ));
    }
  }

  if (type === "tool-gateway-request") {
    const gateway = payload.gateway || {};
    const principal = payload.authenticated_principal || {};
    const productionRefKind = artifactRefKind(
      payload.production_sandbox_admission_ref
    );
    const productionRefPresent = Object.prototype.hasOwnProperty.call(
      payload,
      "production_sandbox_admission_ref"
    );
    const executionModePresent = Object.prototype.hasOwnProperty.call(
      payload.tool_call || {},
      "execution_mode"
    );
    const identityRefKinds = [
      artifactRefKind(payload.identity_policy_ref),
      artifactRefKind(payload.identity_challenge_ref),
      artifactRefKind(payload.principal_evidence_ref)
    ];
    const authenticatedAt = Date.parse(principal.authenticated_at);
    const principalExpiresAt = Date.parse(principal.expires_at);
    const requestedAt = Date.parse(payload.requested_at);
    const validUntil = Date.parse(payload.valid_until);
    if (!isValidDate(principal.authenticated_at) ||
        !isValidDate(principal.expires_at) ||
        !isValidDate(payload.requested_at) ||
        !isValidDate(payload.valid_until) ||
        authenticatedAt > requestedAt ||
        requestedAt >= validUntil ||
        validUntil > principalExpiresAt) {
      issues.push(issue("critical", "GATEWAY_REQUEST_INVALID_VALIDITY", "$.valid_until", "Gateway request validity must satisfy authenticated_at <= requested_at < valid_until <= principal expiry."));
    }
    if (gateway.audience !== principal.audience) {
      issues.push(issue("critical", "GATEWAY_REQUEST_AUDIENCE_MISMATCH", "$.authenticated_principal.audience", "Authenticated principal audience must match the exact gateway audience."));
    }
    if ((["contract_reference", "authenticated_reference"].includes(gateway.assurance_level) &&
         gateway.exclusive_path_verified !== false) ||
        (gateway.assurance_level === "managed_exclusive" && gateway.exclusive_path_verified !== true)) {
      issues.push(issue("critical", "GATEWAY_REQUEST_ASSURANCE_MISMATCH", "$.gateway", "Reference assurance must not claim exclusivity; managed-exclusive assurance must carry verified exclusivity."));
    }
    if (gateway.assurance_level === "managed_exclusive" &&
        principal.authentication_method === "fixture") {
      issues.push(issue("critical", "GATEWAY_REQUEST_FIXTURE_IDENTITY_FOR_MANAGED", "$.authenticated_principal.authentication_method", "Fixture identity cannot enter a managed-exclusive gateway."));
    }
    if ((payload.schema_version === "0.2" &&
         (productionRefPresent || executionModePresent ||
          gateway.assurance_level === "managed_exclusive")) ||
        (payload.schema_version === "0.3" &&
         (!productionRefPresent || !executionModePresent ||
          productionRefKind === "malformed"))) {
      issues.push(issue("critical", "GATEWAY_REQUEST_VERSION_BINDING_INVALID", "$", "Gateway request v0.2 is reference-only; v0.3 requires an exact production-admission sentinel and requested execution mode."));
    }
    if (gateway.assurance_level === "managed_exclusive" &&
        (payload.schema_version !== "0.3" ||
         productionRefKind !== "concrete" ||
         (payload.tool_call || {}).execution_mode !==
           "oci_linux_sandbox_reference")) {
      issues.push(issue("critical", "GATEWAY_REQUEST_PRODUCTION_ADMISSION_MISSING", "$.production_sandbox_admission_ref", "Managed-exclusive admission requires request v0.3, one concrete production sandbox admission, and OCI sandbox execution mode."));
    }
    if (gateway.assurance_level !== "managed_exclusive" &&
        payload.schema_version === "0.3" &&
        productionRefKind !== "none") {
      issues.push(issue("critical", "GATEWAY_REQUEST_PRODUCTION_REF_UNEXPECTED", "$.production_sandbox_admission_ref", "A non-managed request must carry the exact none production-admission sentinel."));
    }
    if ((gateway.assurance_level === "contract_reference" &&
         identityRefKinds.some(kind => kind !== "none")) ||
        (["authenticated_reference", "managed_exclusive"].includes(gateway.assurance_level) &&
         identityRefKinds.some(kind => kind !== "concrete")) ||
        (["authenticated_reference", "managed_exclusive"].includes(gateway.assurance_level) &&
         principal.authentication_method !== "mtls") ||
        identityRefKinds.includes("malformed")) {
      issues.push(issue("critical", "GATEWAY_REQUEST_IDENTITY_EVIDENCE_MISMATCH", "$", "Contract-reference requests require all-none identity references; stronger assurance requires three concrete references and mTLS for authenticated-reference admission."));
    }
    if (principal.proof_verified !== true) {
      issues.push(issue("critical", "GATEWAY_REQUEST_PRINCIPAL_UNVERIFIED", "$.authenticated_principal.proof_verified", "Gateway admission requires a verified principal proof."));
    }
    if (payload.raw_input_retained !== false) {
      issues.push(issue("critical", "GATEWAY_REQUEST_RAW_INPUT_RETAINED", "$.raw_input_retained", "Gateway audit artifacts must retain the exact input digest, not raw tool input."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "GATEWAY_REQUEST_AUTHORITY_DRIFT", "$.authority", "Gateway request cannot expand authority or authorize release."));
    }
  }

  if (type === "tool-gateway-decision") {
    const admissionKind = artifactRefKind(payload.admission_ref);
    const productionRefKind = artifactRefKind(
      payload.production_sandbox_admission_ref
    );
    const productionRefPresent = Object.prototype.hasOwnProperty.call(
      payload,
      "production_sandbox_admission_ref"
    );
    const identityRefKinds = [
      artifactRefKind(payload.identity_policy_ref),
      artifactRefKind(payload.identity_challenge_ref),
      artifactRefKind(payload.principal_evidence_ref)
    ];
    if (admissionKind === "malformed") {
      issues.push(issue("critical", "GATEWAY_DECISION_ADMISSION_REF_MALFORMED", "$.admission_ref", "Admission reference must be concrete or use the exact all-none sentinel."));
    }
    if (identityRefKinds.includes("malformed") ||
        new Set(identityRefKinds).size !== 1) {
      issues.push(issue("critical", "GATEWAY_DECISION_IDENTITY_REF_MISMATCH", "$", "Decision must preserve either three concrete identity references or three exact none sentinels."));
    }
    if ((payload.schema_version === "0.2" &&
         (productionRefPresent ||
          payload.production_execution_authorized !== false)) ||
        (payload.schema_version === "0.3" &&
         (!productionRefPresent || productionRefKind === "malformed"))) {
      issues.push(issue("critical", "GATEWAY_DECISION_VERSION_BINDING_INVALID", "$", "Decision v0.2 is non-production; v0.3 must preserve one exact production-admission reference or none sentinel."));
    }
    if (payload.decision === "allow" &&
        (payload.execution_permitted !== true ||
         admissionKind !== "concrete" ||
         payload.matched_rule_id === "none")) {
      issues.push(issue("critical", "GATEWAY_DECISION_ALLOW_UNBOUND", "$", "An allow decision requires execution permission, a concrete admission, and an exact matched rule."));
    }
    if (payload.decision === "allow" &&
        ((payload.production_execution_authorized === true &&
          (payload.schema_version !== "0.3" ||
           productionRefKind !== "concrete" ||
           (payload.tool_call || {}).execution_mode !==
             "oci_linux_sandbox_reference")) ||
         (payload.production_execution_authorized === false &&
          payload.schema_version === "0.3" &&
          productionRefKind !== "none"))) {
      issues.push(issue("critical", "GATEWAY_DECISION_PRODUCTION_BINDING_INVALID", "$", "Production allow requires one concrete managed admission and OCI execution; non-production allow requires the exact none sentinel."));
    }
    if (payload.decision === "deny" &&
        (payload.execution_permitted !== false ||
         payload.production_execution_authorized !== false ||
         payload.matched_rule_id !== "none")) {
      issues.push(issue("critical", "GATEWAY_DECISION_DENY_PERMITS_EXECUTION", "$", "A deny decision must prohibit execution and use the none rule sentinel."));
    }
    if (!hasSubstantiveItems(payload.reason_codes)) {
      issues.push(issue("critical", "GATEWAY_DECISION_REASON_MISSING", "$.reason_codes", "Gateway decision requires at least one substantive reason code."));
    }
    if (!isBefore(payload.decided_at, payload.valid_until)) {
      issues.push(issue("critical", "GATEWAY_DECISION_INVALID_VALIDITY", "$.valid_until", "Gateway decision validity must end after the decision."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "GATEWAY_DECISION_AUTHORITY_DRIFT", "$.authority", "Gateway decision cannot expand authority or authorize release."));
    }
  }

  if (type === "tool-execution-receipt") {
    const admissionKind = artifactRefKind(payload.admission_ref);
    const checkpointKind = artifactRefKind(payload.checkpoint_ref);
    const productionRefKind = artifactRefKind(
      payload.production_sandbox_admission_ref
    );
    const productionRefPresent = Object.prototype.hasOwnProperty.call(
      payload,
      "production_sandbox_admission_ref"
    );
    const identityRefKinds = [
      artifactRefKind(payload.identity_policy_ref),
      artifactRefKind(payload.identity_challenge_ref),
      artifactRefKind(payload.principal_evidence_ref)
    ];
    const execution = payload.execution || {};
    const executor = payload.executor || {};
    const executorRefKinds = [
      artifactRefKind(executor.executor_policy_ref),
      artifactRefKind(executor.execution_envelope_ref),
      artifactRefKind(executor.execution_observation_ref)
    ];
    const retainedExecutionMode = [
      "bounded_process_reference",
      "oci_linux_sandbox_reference"
    ].includes(executor.execution_mode);
    if (executor.execution_mode === "oci_linux_sandbox_reference" &&
        !/^[a-f0-9]{64}$/.test(String(executor.probe_sha256 || ""))) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_PROBE_UNBOUND", "$.executor.probe_sha256", "OCI sandbox execution requires the exact probe digest."));
    }
    if (executor.execution_mode !== "oci_linux_sandbox_reference" &&
        Object.prototype.hasOwnProperty.call(executor, "probe_sha256")) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_PROBE_MODE_MISMATCH", "$.executor.probe_sha256", "Only OCI sandbox execution may carry a probe digest."));
    }
    if (admissionKind === "malformed" || checkpointKind === "malformed") {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_REF_MALFORMED", "$", "Receipt admission and checkpoint references must be concrete or use the exact all-none sentinel."));
    }
    if (admissionKind !== "concrete" || checkpointKind !== "concrete") {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_REF_UNBOUND", "$", "Every execution receipt requires concrete admission and checkpoint references."));
    }
    if (identityRefKinds.includes("malformed") ||
        new Set(identityRefKinds).size !== 1) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_IDENTITY_REF_MISMATCH", "$", "Receipt must preserve either three concrete identity references or three exact none sentinels."));
    }
    if ((payload.schema_version === "0.4" &&
         (productionRefPresent ||
          payload.production_deployment_verified !== false)) ||
        (payload.schema_version === "0.5" &&
         (!productionRefPresent || productionRefKind === "malformed"))) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_PRODUCTION_BINDING_INVALID", "$", "Receipt v0.4 is non-production; v0.5 must preserve one exact production-admission reference or none sentinel."));
    }
    if (payload.production_deployment_verified === true &&
        (payload.schema_version !== "0.5" ||
         productionRefKind !== "concrete" ||
         (payload.tool_call || {}).execution_mode !==
           "oci_linux_sandbox_reference")) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_PRODUCTION_OVERCLAIM", "$.production_deployment_verified", "Verified production deployment requires receipt v0.5, one concrete managed admission, and OCI sandbox execution mode."));
    }
    if (payload.schema_version === "0.5" &&
        payload.production_deployment_verified === false &&
        productionRefKind !== "none") {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_PRODUCTION_OVERCLAIM", "$.production_sandbox_admission_ref", "A non-production receipt cannot retain a concrete production admission."));
    }
    if (executorRefKinds.includes("malformed") ||
        new Set(executorRefKinds).size !== 1 ||
        (retainedExecutionMode &&
          executorRefKinds[0] !== "concrete") ||
        (!retainedExecutionMode &&
          executorRefKinds[0] !== "none")) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_EXECUTOR_REF_MISMATCH", "$.executor", "Retained process or OCI sandbox execution requires three concrete evidence references; every other mode requires three exact none sentinels."));
    }
    if (execution.transaction_state === "committed" &&
        (admissionKind !== "concrete" ||
         checkpointKind !== "concrete" ||
         !["succeeded", "failed"].includes(execution.status) ||
         !payload.executor || payload.executor.execution_mode === "none" ||
         execution.result_sha256 === "none" ||
         !isValidDate(execution.started_at) ||
         !isValidDate(execution.finished_at) ||
         Date.parse(execution.started_at) > Date.parse(execution.finished_at))) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_COMMIT_INCOMPLETE", "$.execution", "Committed execution requires concrete admission/checkpoint/result bindings and ordered execution timestamps."));
    }
    if (execution.transaction_state === "committed" &&
        Object.prototype.hasOwnProperty.call(
          payload.tool_call || {},
          "execution_mode"
        ) &&
        payload.tool_call.execution_mode !== executor.execution_mode) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_EXECUTOR_MODE_MISMATCH", "$.executor.execution_mode", "Committed executor mode must equal the mode fixed in the gateway request."));
    }
    if (execution.transaction_state === "aborted" &&
        (execution.status !== "not_executed" ||
         !payload.executor || payload.executor.execution_mode !== "none" ||
         execution.result_sha256 !== "none" ||
         execution.started_at !== "none" ||
         execution.finished_at !== "none" ||
         execution.exit_code !== "none" ||
         execution.external_effects !== "none")) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_ABORT_INVALID", "$.execution", "An aborted transaction must prove that execution did not start and no effect was observed."));
    }
    if (execution.transaction_state === "recovery_required" &&
        (execution.status !== "unknown" ||
         !payload.executor || payload.executor.execution_mode !== "none" ||
         execution.result_sha256 !== "none" ||
         (execution.started_at !== "none" && !isValidDate(execution.started_at)) ||
         execution.finished_at !== "none" ||
         execution.exit_code !== "none" ||
         execution.external_effects !== "unknown")) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_RECOVERY_INVALID", "$.execution", "Recovery-required state must preserve an unknown result and effect disposition."));
    }
    if (!hasSubstantiveItems(payload.reason_codes)) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_REASON_MISSING", "$.reason_codes", "Execution receipt requires at least one substantive reason code."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_AUTHORITY_DRIFT", "$.authority", "Execution receipt cannot expand authority or authorize release."));
    }
    const recordedAt = Date.parse(payload.recorded_at);
    const finishedAt = Date.parse(execution.finished_at);
    const startedAt = Date.parse(execution.started_at);
    if (!isValidDate(payload.recorded_at) ||
        (isValidDate(execution.finished_at) && finishedAt > recordedAt) ||
        (execution.transaction_state === "recovery_required" &&
         isValidDate(execution.started_at) && startedAt > recordedAt)) {
      issues.push(issue("critical", "TOOL_EXECUTION_RECEIPT_TIMESTAMP_INVALID", "$.recorded_at", "Receipt recording must be valid and no earlier than a known execution timestamp."));
    }
  }

  if (type === "protected-executor-policy") {
    const adapter = payload.adapter_profile || {};
    const processControls = payload.process_controls || {};
    const networkControls = payload.network_controls || {};
    if (!isBefore(payload.valid_from, payload.expires_at)) {
      issues.push(issue("critical", "PROTECTED_EXECUTOR_POLICY_INVALID_VALIDITY", "$.expires_at", "Protected executor policy validity must have an ordered, non-empty interval."));
    }
    try {
      const publicKey = crypto.createPublicKey(adapter.signing_public_key_pem);
      if (publicKey.asymmetricKeyType !== "ed25519" ||
          publicKeyId(publicKey) !== adapter.signing_key_id) {
        throw new Error("key mismatch");
      }
    } catch (error) {
      issues.push(issue("critical", "PROTECTED_EXECUTOR_POLICY_SIGNING_KEY_INVALID", "$.adapter_profile", "Protected executor policy requires a matching Ed25519 public key and key identifier."));
    }
    if (canonicalControlDigestWithout(
      processControls,
      ["sandbox_profile_sha256"]
    ) !== processControls.sandbox_profile_sha256) {
      issues.push(issue("critical", "PROTECTED_EXECUTOR_SANDBOX_PROFILE_DIGEST_MISMATCH", "$.process_controls.sandbox_profile_sha256", "Sandbox profile digest must bind the exact declared process controls."));
    }
    if (canonicalControlDigestWithout(
      networkControls,
      ["network_policy_sha256"]
    ) !== networkControls.network_policy_sha256) {
      issues.push(issue("critical", "PROTECTED_EXECUTOR_NETWORK_POLICY_DIGEST_MISMATCH", "$.network_controls.network_policy_sha256", "Network policy digest must bind the exact declared network controls."));
    }
    const rules = Array.isArray(payload.rules) ? payload.rules : [];
    const ruleIds = rules.map(rule => rule && rule.rule_id);
    if (new Set(ruleIds).size !== ruleIds.length) {
      issues.push(issue("critical", "PROTECTED_EXECUTOR_POLICY_DUPLICATE_RULE", "$.rules", "Protected executor rule identifiers must be unique."));
    }
    for (const [index, rule] of rules.entries()) {
      if (!safeProtectedCwd(rule && rule.cwd_relative)) {
        issues.push(issue("critical", "PROTECTED_EXECUTOR_POLICY_CWD_UNSAFE", `$.rules[${index}].cwd_relative`, "Protected executor cwd must be canonical and repository-relative."));
      }
    }
    if (retainedAuthorityDrift(payload.authority) ||
        !payload.authority ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "PROTECTED_EXECUTOR_POLICY_AUTHORITY_DRIFT", "$.authority", "Protected executor policy cannot expand USER authority or claim production execution."));
    }
  }

  if (type === "protected-process-tool-input") {
    if (artifactRefKind(payload.executor_policy_ref) !== "concrete") {
      issues.push(issue("critical", "PROTECTED_PROCESS_POLICY_REF_UNBOUND", "$.executor_policy_ref", "Protected process input requires one concrete executor policy reference."));
    }
  }

  if (type === "protected-execution-envelope") {
    const refs = [
      payload.request_ref,
      payload.decision_ref,
      payload.execution_event_ref,
      payload.executor_policy_ref
    ];
    if (refs.some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_ENVELOPE_REF_UNBOUND", "$", "Protected execution envelope requires concrete request, decision, event, and policy references."));
    }
    if (!isBefore(payload.issued_at, payload.expires_at)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_ENVELOPE_INVALID_VALIDITY", "$.expires_at", "Protected execution envelope must expire after issuance."));
    }
    if (!safeProtectedCwd(payload.command && payload.command.cwd_relative)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_ENVELOPE_CWD_UNSAFE", "$.command.cwd_relative", "Protected execution envelope cwd must be canonical and repository-relative."));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_ENVELOPE_SIGNATURE_MALFORMED", "$.signature", "Protected execution envelope requires a canonical Ed25519 signature."));
    }
    if (canonicalObjectDigestWithout(payload, ["envelope_sha256"]) !==
        payload.envelope_sha256) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_ENVELOPE_DIGEST_MISMATCH", "$.envelope_sha256", "Envelope digest must bind the complete signed artifact."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        !payload.authority ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_ENVELOPE_AUTHORITY_DRIFT", "$.authority", "Protected execution envelope cannot expand USER authority or claim production execution."));
    }
  }

  if (type === "protected-execution-observation") {
    const refs = [
      payload.request_ref,
      payload.decision_ref,
      payload.execution_event_ref,
      payload.executor_policy_ref,
      payload.execution_envelope_ref
    ];
    if (refs.some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_OBSERVATION_REF_UNBOUND", "$", "Protected execution observation requires concrete transaction, policy, and envelope references."));
    }
    if (!isValidDate(payload.started_at) ||
        !isValidDate(payload.finished_at) ||
        Date.parse(payload.started_at) > Date.parse(payload.finished_at)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_OBSERVATION_TIME_INVALID", "$.finished_at", "Protected execution observation requires ordered process timestamps."));
    }
    if (!safeProtectedCwd(payload.command && payload.command.cwd_relative)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_OBSERVATION_CWD_UNSAFE", "$.command.cwd_relative", "Protected execution observation cwd must be canonical and repository-relative."));
    }
    for (const name of ["stdout", "stderr"]) {
      const output = payload[name] || {};
      if (!Number.isInteger(output.observed_bytes) ||
          !Number.isInteger(output.retained_bytes) ||
          output.retained_bytes > output.observed_bytes ||
          output.truncated !== (output.observed_bytes > output.retained_bytes)) {
        issues.push(issue("critical", "PROTECTED_EXECUTION_OUTPUT_ACCOUNTING_INVALID", `$.${name}`, "Observed, retained, and truncated output fields must agree."));
      }
    }
    const processResult = payload.process || {};
    if (processResult.timed_out !==
          (processResult.termination_reason === "timeout") ||
        processResult.output_limit_exceeded !==
          ["stdout_limit", "stderr_limit"].includes(
            processResult.termination_reason
          )) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_PROCESS_STATE_INVALID", "$.process", "Process flags must agree with the recorded termination reason."));
    }
    if ((processResult.termination_reason === "spawn_error" &&
          processResult.spawned !== false) ||
        (processResult.termination_reason !== "spawn_error" &&
          processResult.spawned !== true)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_SPAWN_STATE_INVALID", "$.process.spawned", "Spawn state must agree with the recorded termination reason."));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_OBSERVATION_SIGNATURE_MALFORMED", "$.signature", "Protected execution observation requires a canonical Ed25519 signature."));
    }
    if (canonicalObjectDigestWithout(payload, ["observation_sha256"]) !==
        payload.observation_sha256) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_OBSERVATION_DIGEST_MISMATCH", "$.observation_sha256", "Observation digest must bind the complete signed artifact."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        !payload.authority ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "PROTECTED_EXECUTION_OBSERVATION_AUTHORITY_DRIFT", "$.authority", "Protected execution observation cannot expand USER authority or claim production execution."));
    }
  }

  if (type === "oci-linux-sandbox-policy") {
    const adapter = payload.adapter_profile || {};
    const network = payload.network_controls || {};
    if (!isBefore(payload.valid_from, payload.expires_at)) {
      issues.push(issue("critical", "OCI_SANDBOX_POLICY_INVALID_VALIDITY", "$.expires_at", "OCI sandbox policy validity must have an ordered, non-empty interval."));
    }
    try {
      const publicKey = crypto.createPublicKey(adapter.signing_public_key_pem);
      if (publicKey.asymmetricKeyType !== "ed25519" ||
          publicKeyId(publicKey) !== adapter.signing_key_id) {
        throw new Error("key mismatch");
      }
    } catch (error) {
      issues.push(issue("critical", "OCI_SANDBOX_POLICY_SIGNING_KEY_INVALID", "$.adapter_profile", "OCI sandbox policy requires a matching Ed25519 public key and key identifier."));
    }
    if (sandboxProfileDigest(payload) !== payload.sandbox_profile_sha256) {
      issues.push(issue("critical", "OCI_SANDBOX_PROFILE_DIGEST_MISMATCH", "$.sandbox_profile_sha256", "Sandbox profile digest must bind the exact image, process, filesystem, seccomp, and resource controls."));
    }
    if (networkPolicyDigest(network) !== network.network_policy_sha256) {
      issues.push(issue("critical", "OCI_SANDBOX_NETWORK_POLICY_DIGEST_MISMATCH", "$.network_controls.network_policy_sha256", "Network policy digest must bind the exact declared network controls."));
    }
    const ruleIds = (payload.rules || []).map(rule => rule && rule.rule_id);
    if (new Set(ruleIds).size !== ruleIds.length) {
      issues.push(issue("critical", "OCI_SANDBOX_POLICY_DUPLICATE_RULE", "$.rules", "OCI sandbox rule identifiers must be unique."));
    }
    for (const [index, rule] of (payload.rules || []).entries()) {
      if (!rule || rule.executable_path !== "/cannae-probe" ||
          rule.executable_sha256 !== adapter.probe_sha256 ||
          rule.cwd !== "/workspace" ||
          rule.expected_repository_effect !== "none") {
        issues.push(issue("critical", "OCI_SANDBOX_RULE_UNSUPPORTED", `$.rules[${index}]`, "The reference provider supports only the pinned static probe target in the read-only repository workspace."));
      }
    }
    const profilePath = payload.seccomp &&
      payload.seccomp.profile_relative_path;
    if (typeof profilePath !== "string" ||
        profilePath.startsWith("/") ||
        profilePath.includes("\\") ||
        profilePath.split("/").some(part =>
          !part || part === "." || part === "..")) {
      issues.push(issue("critical", "OCI_SANDBOX_SECCOMP_PATH_UNSAFE", "$.seccomp.profile_relative_path", "Seccomp profile path must be canonical and repository-relative."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        !payload.authority ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "OCI_SANDBOX_POLICY_AUTHORITY_DRIFT", "$.authority", "OCI sandbox policy cannot expand USER authority or claim production execution."));
    }
  }

  if (type === "oci-sandbox-tool-input") {
    if (artifactRefKind(payload.sandbox_policy_ref) !== "concrete") {
      issues.push(issue("critical", "OCI_SANDBOX_POLICY_REF_UNBOUND", "$.sandbox_policy_ref", "OCI sandbox input requires one concrete policy reference."));
    }
  }

  if (type === "oci-sandbox-execution-envelope") {
    const refs = [
      payload.request_ref,
      payload.decision_ref,
      payload.execution_event_ref,
      payload.sandbox_policy_ref
    ];
    if (refs.some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue("critical", "OCI_SANDBOX_ENVELOPE_REF_UNBOUND", "$", "OCI sandbox envelope requires concrete request, decision, event, and policy references."));
    }
    if (!isBefore(payload.issued_at, payload.expires_at)) {
      issues.push(issue("critical", "OCI_SANDBOX_ENVELOPE_INVALID_VALIDITY", "$.expires_at", "OCI sandbox envelope must expire after issuance."));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue("critical", "OCI_SANDBOX_ENVELOPE_SIGNATURE_MALFORMED", "$.signature", "OCI sandbox envelope requires a canonical Ed25519 signature."));
    }
    if (canonicalObjectDigestWithout(payload, ["envelope_sha256"]) !==
        payload.envelope_sha256) {
      issues.push(issue("critical", "OCI_SANDBOX_ENVELOPE_DIGEST_MISMATCH", "$.envelope_sha256", "Envelope digest must bind the complete signed artifact."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        !payload.authority ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "OCI_SANDBOX_ENVELOPE_AUTHORITY_DRIFT", "$.authority", "OCI sandbox envelope cannot expand USER authority or claim production execution."));
    }
  }

  if (type === "oci-sandbox-probe-observation") {
    const status = payload.status || {};
    const capabilityValues = Object.values(status.capabilities || {});
    if (status.no_new_privs !== 1 ||
        status.seccomp_mode !== 2 ||
        status.seccomp_filters < 1 ||
        capabilityValues.length !== 5 ||
        capabilityValues.some(value => value !== "0000000000000000")) {
      issues.push(issue("critical", "OCI_SANDBOX_PROBE_PRIVILEGE_INVALID", "$.status", "Probe must observe no-new-privileges, filter-mode seccomp, and empty capability sets."));
    }
    const mounts = payload.mounts || {};
    if (!(mounts.root || {}).read_only ||
        !(mounts.workspace || {}).read_only ||
        (mounts.tmp || {}).read_only ||
        mounts.workspace_recursive_read_only !== true ||
        !(payload.write_tests || {}).root_denied ||
        !(payload.write_tests || {}).workspace_denied ||
        !(payload.write_tests || {}).tmp_writable) {
      issues.push(issue("critical", "OCI_SANDBOX_PROBE_FILESYSTEM_INVALID", "$.mounts", "Probe must observe a read-only root and repository with a writable constrained tmpfs."));
    }
    const probeNetwork = payload.network || {};
    if (probeNetwork.default_route_count !== 0 ||
        probeNetwork.outbound_connect_denied !== true ||
        !Array.isArray(probeNetwork.non_loopback_addresses) ||
        probeNetwork.non_loopback_addresses.length !== 0) {
      issues.push(issue("critical", "OCI_SANDBOX_PROBE_NETWORK_INVALID", "$.network", "Probe must observe no default route and no non-loopback IP address."));
    }
    const child = payload.child || {};
    for (const name of ["stdout", "stderr"]) {
      const output = child[name] || {};
      let bytes = null;
      try {
        bytes = output.base64 === ""
          ? Buffer.alloc(0)
          : strictBase64(output.base64);
      } catch (error) {
        bytes = null;
      }
      if (!bytes ||
          output.retained_bytes > output.observed_bytes ||
          output.retained_bytes !== bytes.length ||
          output.truncated !==
            (output.observed_bytes > output.retained_bytes) ||
          crypto.createHash("sha256").update(bytes).digest("hex") !==
            output.sha256) {
        issues.push(issue("critical", "OCI_SANDBOX_PROBE_OUTPUT_INVALID", `$.child.${name}`, "Probe output bytes, digest, retention, and truncation fields must agree."));
      }
    }
    if (!isValidDate(child.started_at) ||
        !isValidDate(child.finished_at) ||
        Date.parse(child.started_at) > Date.parse(child.finished_at) ||
        !isValidDate(payload.collected_at) ||
        Date.parse(child.finished_at) > Date.parse(payload.collected_at)) {
      issues.push(issue("critical", "OCI_SANDBOX_PROBE_TIME_INVALID", "$.collected_at", "Probe collection must follow an ordered child execution interval."));
    }
  }

  if (type === "oci-sandbox-containment-observation") {
    for (const key of ["request_ref", "decision_ref", "execution_event_ref", "terminal_event_ref", "sandbox_policy_ref", "execution_envelope_ref"]) {
      if (artifactRefKind(payload[key]) !== "concrete") {
        issues.push(issue("critical", "OCI_CONTAINMENT_REF_UNBOUND", `$.${key}`, "Containment observation requires exact retained references."));
      }
    }
    if (![payload.started_at, payload.observed_at, payload.expires_at].every(isValidDate) ||
        Date.parse(payload.started_at) > Date.parse(payload.observed_at) ||
        !isBefore(payload.observed_at, payload.expires_at) ||
        Date.parse(payload.expires_at) - Date.parse(payload.started_at) > 300000) {
      issues.push(issue("critical", "OCI_CONTAINMENT_TIME_INVALID", "$", "Containment observations require ordered timestamps within a five-minute window."));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue("critical", "OCI_CONTAINMENT_SIGNATURE_MALFORMED", "$.signature", "Containment observation requires a canonical Ed25519 signature."));
    }
    if (canonicalObjectDigestWithout(payload, ["observation_sha256"]) !== payload.observation_sha256) {
      issues.push(issue("critical", "OCI_CONTAINMENT_DIGEST_MISMATCH", "$.observation_sha256", "Digest must bind the signed containment observation."));
    }
  }

  if (type === "oci-sandbox-execution-observation") {
    const refs = [
      payload.request_ref,
      payload.decision_ref,
      payload.execution_event_ref,
      payload.sandbox_policy_ref,
      payload.execution_envelope_ref,
      payload.probe_observation_ref
    ];
    if (refs.some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue("critical", "OCI_SANDBOX_OBSERVATION_REF_UNBOUND", "$", "OCI sandbox observation requires concrete transaction, policy, envelope, and probe references."));
    }
    if (!isValidDate(payload.started_at) ||
        !isValidDate(payload.finished_at) ||
        Date.parse(payload.started_at) > Date.parse(payload.finished_at) ||
        !(payload.cleanup || {}).container_removed) {
      issues.push(issue("critical", "OCI_SANDBOX_OBSERVATION_STATE_INVALID", "$", "OCI sandbox observation requires ordered execution timestamps and verified container cleanup."));
    }
    if (runtimeConfigDigest(payload.runtime_config || {}) !==
        (payload.runtime_config || {}).config_sha256) {
      issues.push(issue("critical", "OCI_SANDBOX_RUNTIME_CONFIG_DIGEST_MISMATCH", "$.runtime_config.config_sha256", "Runtime config digest must bind the exact normalized Docker inspection."));
    }
    if (!validEd25519Signature(payload.signature)) {
      issues.push(issue("critical", "OCI_SANDBOX_OBSERVATION_SIGNATURE_MALFORMED", "$.signature", "OCI sandbox observation requires a canonical Ed25519 signature."));
    }
    if (canonicalObjectDigestWithout(payload, ["observation_sha256"]) !==
        payload.observation_sha256) {
      issues.push(issue("critical", "OCI_SANDBOX_OBSERVATION_DIGEST_MISMATCH", "$.observation_sha256", "Observation digest must bind the complete signed artifact."));
    }
    if (retainedAuthorityDrift(payload.authority) ||
        !payload.authority ||
        payload.authority.production_execution_authorized !== false) {
      issues.push(issue("critical", "OCI_SANDBOX_OBSERVATION_AUTHORITY_DRIFT", "$.authority", "OCI sandbox observation cannot expand USER authority or claim production execution."));
    }
  }

  if (type === "tool-gateway-transaction-event") {
    const previousKind = artifactRefKind(payload.previous_event_ref);
    const decisionKind = artifactRefKind(payload.decision_ref);
    const receiptKind = artifactRefKind(payload.receipt_ref);
    const admissionKind = artifactRefKind(payload.admission_ref);
    const productionRefKind = artifactRefKind(
      payload.production_sandbox_admission_ref
    );
    const productionRefPresent = Object.prototype.hasOwnProperty.call(
      payload,
      "production_sandbox_admission_ref"
    );
    const identityRefKinds = [
      artifactRefKind(payload.identity_policy_ref),
      artifactRefKind(payload.identity_challenge_ref),
      artifactRefKind(payload.principal_evidence_ref)
    ];
    if ([previousKind, decisionKind, receiptKind, admissionKind].includes("malformed")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_REF_MALFORMED", "$", "Transaction references must be concrete or use the exact all-none sentinel."));
    }
    if (identityRefKinds.includes("malformed") ||
        new Set(identityRefKinds).size !== 1) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_IDENTITY_REF_MISMATCH", "$", "Transaction events must preserve either three concrete identity references or three exact none sentinels."));
    }
    if ((payload.schema_version === "0.2" && productionRefPresent) ||
        (payload.schema_version === "0.3" &&
         (!productionRefPresent || productionRefKind === "malformed"))) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_PRODUCTION_REF_INVALID", "$.production_sandbox_admission_ref", "Transaction event v0.3 must preserve the request's exact production admission or none sentinel; v0.2 cannot carry it."));
    }
    if (payload.state === "received" &&
        (payload.sequence !== 1 ||
         previousKind !== "none" ||
         decisionKind !== "none" ||
         receiptKind !== "none" ||
         admissionKind !== "none")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_RECEIVED_INVALID", "$", "Received must be sequence one with no predecessor, decision, receipt, or admission."));
    }
    if (payload.state !== "received" &&
        (!Number.isInteger(payload.sequence) || payload.sequence < 2 || previousKind !== "concrete")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_CHAIN_INVALID", "$.previous_event_ref", "Every post-receipt event requires a positive next sequence and concrete predecessor."));
    }
    if (payload.state === "authorized" &&
        (decisionKind !== "concrete" || admissionKind !== "concrete" || receiptKind !== "none")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_AUTHORIZED_INVALID", "$", "Authorized requires concrete decision and admission references without a receipt."));
    }
    if (payload.state === "denied" &&
        (decisionKind !== "concrete" || receiptKind !== "none")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_DENIED_INVALID", "$", "Denied requires a concrete decision and no receipt."));
    }
    if (payload.state === "executing" &&
        (payload.sequence < 3 || decisionKind !== "concrete" ||
         admissionKind !== "concrete" || receiptKind !== "none")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_EXECUTING_INVALID", "$", "Executing requires a prior authorized decision and admission without a receipt."));
    }
    const terminalSequenceInvalid =
      (payload.state === "committed" && payload.sequence < 4) ||
      (["aborted", "recovery_required"].includes(payload.state) && payload.sequence < 3);
    if (["committed", "aborted", "recovery_required"].includes(payload.state) &&
        (terminalSequenceInvalid || decisionKind !== "concrete" || receiptKind !== "concrete")) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_TERMINAL_INVALID", "$", "Terminal transaction events require concrete decision and receipt references."));
    }
    if (!hasSubstantiveItems(payload.reason_codes)) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_REASON_MISSING", "$.reason_codes", "Transaction event requires at least one substantive reason code."));
    }
    if (retainedAuthorityDrift(payload.authority)) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_AUTHORITY_DRIFT", "$.authority", "Gateway transaction event cannot expand authority or authorize release."));
    }
    if (!isValidDate(payload.recorded_at)) {
      issues.push(issue("critical", "GATEWAY_TRANSACTION_TIMESTAMP_INVALID", "$.recorded_at", "Gateway transaction event requires a valid timestamp."));
    }
  }

  if (type === "authority-matrix") {
    if (payload.default_decision === "allow") {
      issues.push(issue("error", "DEFAULT_ALLOW_TOO_BROAD", "$.default_decision", "Authority matrix must not default to allow.", "Use report_required, approval_required, or prohibit."));
    }
    if (!payload.rules || isEmptyArray(payload.rules)) {
      issues.push(issue("critical", "MISSING_AUTHORITY_RULES", "$.rules", "Authority matrix requires explicit scoped rules."));
    }
    for (const [index, rule] of (payload.rules || []).entries()) {
      const pointer = `$.rules[${index}]`;
      if (rule.roe_class === "Red") {
        if (rule.decision !== "approval_required") {
          issues.push(issue("critical", "RED_NOT_APPROVAL_REQUIRED", `${pointer}.decision`, "Red authority rule must require approval."));
        }
        if (!rule.approval_authority) {
          issues.push(issue("critical", "RED_WITHOUT_APPROVAL_AUTHORITY", `${pointer}.approval_authority`, "Red authority rule must name an approval authority."));
        }
      }
      if (rule.roe_class === "Black") {
        if (rule.decision !== "prohibit") {
          issues.push(issue("critical", "BLACK_NOT_PROHIBITED", `${pointer}.decision`, "Black authority rule must prohibit execution."));
        }
        if (rule.approval_authority) {
          issues.push(issue("critical", "BLACK_CANNOT_BE_APPROVED", `${pointer}.approval_authority`, "Black actions cannot be made approvable."));
        }
      }
      if ((rule.roe_class === "Red" || rule.roe_class === "Black") && rule.decision === "allow") {
        issues.push(issue("critical", "HIGH_RISK_ALLOW", `${pointer}.decision`, "High-risk authority rule cannot allow direct execution."));
      }
      if (rule.decision === "approval_required" && !rule.approval_authority) {
        issues.push(issue("error", "APPROVAL_WITHOUT_AUTHORITY", `${pointer}.approval_authority`, "Approval-required rule must name who can approve."));
      }
      if (isEmptyArray(rule.evidence_required)) {
        issues.push(issue("warning", "NO_EVIDENCE_REQUIREMENT", `${pointer}.evidence_required`, "Authority rule should state post-action evidence requirement."));
      }
    }
  }

  if (type === "decision-packet") {
    if (!payload.options || isEmptyArray(payload.options)) {
      issues.push(issue("critical", "DECISION_PACKET_WITHOUT_OPTIONS", "$.options", "Decision packet must present at least one decision option."));
    }
    const optionIds = new Set((payload.options || []).map(option => option.option_id));
    if (payload.recommended_option && !optionIds.has(payload.recommended_option)) {
      issues.push(issue("error", "RECOMMENDATION_NOT_IN_OPTIONS", "$.recommended_option", "Recommended option must match one of the packet options."));
    }
    if ((payload.decision_type === "approval" || payload.decision_type === "risk_acceptance") && isEmptyArray(payload.authority_required)) {
      issues.push(issue("critical", "AUTHORITY_REQUIRED_EMPTY", "$.authority_required", "Approval and risk-acceptance packets must state required authority."));
    }
    if (isEmptyArray(payload.evidence)) {
      issues.push(issue("error", "DECISION_WITHOUT_EVIDENCE", "$.evidence", "Decision packet must cite evidence or source-of-truth files."));
    }
  }

  if (type === "working-group") {
    if (!payload.participants || !payload.participants.includes(payload.chair)) {
      issues.push(issue("error", "CHAIR_NOT_IN_PARTICIPANTS", "$.participants", "Working group chair must be listed as a participant."));
    }
    if (isEmptyArray(payload.deliverables)) {
      issues.push(issue("error", "WORKING_GROUP_WITHOUT_DELIVERABLE", "$.deliverables", "Working group requires a deliverable such as a decision packet."));
    }
    if (isEmptyArray(payload.disband_condition)) {
      issues.push(issue("critical", "NO_DISBAND_CONDITION", "$.disband_condition", "Working group must have an explicit disband condition."));
    }
  }

  if (type === "department-collaboration-charter") {
    const departments = payload.departments || [];
    const departmentIds = new Set(departments.map(department => department.id));
    const relationships = payload.relationships || [];
    const liaisonRules = payload.liaison_rules || [];

    if (departments.length < 4) {
      issues.push(issue("error", "COLLABORATION_TOO_FEW_DEPARTMENTS", "$.departments", "Cross-functional collaboration should involve at least four functional departments."));
    }
    if (!departmentIds.has("command")) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_COMMAND", "$.departments", "Collaboration charter requires command/CoS integration department."));
    }
    if (!departmentIds.has("recorder")) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_RECORDER", "$.departments", "Collaboration charter requires Recorder/KM department for source-of-truth and handoff."));
    }
    if (!departmentIds.has("protection")) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_PROTECTION", "$.departments", "Collaboration charter requires protection/release department."));
    }

    for (const [index, department] of departments.entries()) {
      const pointer = `$.departments[${index}]`;
      if (!hasSubstantiveItems(department.responsibilities)) {
        issues.push(issue("error", "DEPARTMENT_WITHOUT_RESPONSIBILITIES", `${pointer}.responsibilities`, "Department must state responsibilities."));
      }
      if (!hasSubstantiveItems(department.outputs)) {
        issues.push(issue("error", "DEPARTMENT_WITHOUT_OUTPUTS", `${pointer}.outputs`, "Department must state output contract."));
      }
      if (!hasSubstantiveItems(department.authority_boundary)) {
        issues.push(issue("critical", "DEPARTMENT_WITHOUT_AUTHORITY_BOUNDARY", `${pointer}.authority_boundary`, "Department must state authority boundary."));
      }
      if (!hasSubstantiveItems(department.ccir)) {
        issues.push(issue("warning", "DEPARTMENT_WITHOUT_CCIR", `${pointer}.ccir`, "Department should state reporting triggers."));
      }
      if (!hasSubstantiveItems(department.source_of_truth_files)) {
        issues.push(issue("critical", "DEPARTMENT_WITHOUT_SOURCE_OF_TRUTH", `${pointer}.source_of_truth_files`, "Department must name source-of-truth files."));
      }
    }

    function hasLiaison(left, right) {
      return liaisonRules.some(rule => {
        const between = new Set(rule.between || []);
        return between.has(left) && between.has(right);
      });
    }

    for (const [index, rel] of relationships.entries()) {
      const pointer = `$.relationships[${index}]`;
      if (!departmentIds.has(rel.supported_department)) {
        issues.push(issue("critical", "RELATIONSHIP_UNKNOWN_SUPPORTED_DEPARTMENT", `${pointer}.supported_department`, "Supported department must exist in departments."));
      }
      if (!departmentIds.has(rel.supporting_department)) {
        issues.push(issue("critical", "RELATIONSHIP_UNKNOWN_SUPPORTING_DEPARTMENT", `${pointer}.supporting_department`, "Supporting department must exist in departments."));
      }
      if (rel.supported_department === rel.supporting_department) {
        issues.push(issue("error", "RELATIONSHIP_SELF_SUPPORTING", pointer, "A department cannot be both supported and supporting for the same relationship."));
      }
      if (!hasSubstantiveItems(rel.required_outputs)) {
        issues.push(issue("critical", "RELATIONSHIP_WITHOUT_REQUIRED_OUTPUTS", `${pointer}.required_outputs`, "Supporting relationship requires output contract."));
      }
      if (!hasSubstantiveItems(rel.quality_gate)) {
        issues.push(issue("error", "RELATIONSHIP_WITHOUT_QUALITY_GATE", `${pointer}.quality_gate`, "Supporting output needs a quality gate."));
      }
      if (/^none$/i.test(String(rel.handoff_interface || "").trim())) {
        issues.push(issue("critical", "RELATIONSHIP_WITHOUT_HANDOFF_INTERFACE", `${pointer}.handoff_interface`, "Supporting relationship requires a real handoff interface."));
      }
      if (!hasSubstantiveItems(rel.escalation_trigger)) {
        issues.push(issue("error", "RELATIONSHIP_WITHOUT_ESCALATION_TRIGGER", `${pointer}.escalation_trigger`, "Supporting relationship needs escalation trigger."));
      }
      if (departmentIds.has(rel.supported_department) && departmentIds.has(rel.supporting_department) && !hasLiaison(rel.supported_department, rel.supporting_department)) {
        issues.push(issue("critical", "RELATIONSHIP_WITHOUT_LIAISON", pointer, "Every supported/supporting relationship requires a liaison rule."));
      }
    }

    for (const [index, rule] of liaisonRules.entries()) {
      const pointer = `$.liaison_rules[${index}]`;
      if (!Array.isArray(rule.between) || rule.between.length !== 2) {
        issues.push(issue("error", "LIAISON_NOT_PAIRWISE", `${pointer}.between`, "Liaison rule should connect exactly two departments."));
      }
      for (const department of rule.between || []) {
        if (!departmentIds.has(department)) {
          issues.push(issue("critical", "LIAISON_UNKNOWN_DEPARTMENT", `${pointer}.between`, "Liaison rule references unknown department."));
        }
      }
      if (!hasSubstantiveItems(rule.information_to_exchange)) {
        issues.push(issue("error", "LIAISON_WITHOUT_INFORMATION_EXCHANGE", `${pointer}.information_to_exchange`, "Liaison must define information to exchange."));
      }
      if (/^none$/i.test(String(rule.update_cadence || "").trim())) {
        issues.push(issue("warning", "LIAISON_WITHOUT_CADENCE", `${pointer}.update_cadence`, "Liaison should define update cadence."));
      }
      if (!hasSubstantiveItems(rule.conflict_route)) {
        issues.push(issue("error", "LIAISON_WITHOUT_CONFLICT_ROUTE", `${pointer}.conflict_route`, "Liaison must define conflict route."));
      }
    }

    const sync = payload.synchronization || {};
    if (!hasSubstantiveItems(sync.battle_rhythm_events)) {
      issues.push(issue("error", "COLLABORATION_WITHOUT_BATTLE_RHYTHM", "$.synchronization.battle_rhythm_events", "Collaboration requires battle rhythm events."));
    }
    if (!hasSubstantiveItems(sync.decision_points)) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_DECISION_POINTS", "$.synchronization.decision_points", "Collaboration requires decision points."));
    }
    for (const [index, dependency] of (sync.dependency_matrix || []).entries()) {
      const pointer = `$.synchronization.dependency_matrix[${index}]`;
      if (!departmentIds.has(dependency.from_department) || !departmentIds.has(dependency.to_department)) {
        issues.push(issue("critical", "DEPENDENCY_UNKNOWN_DEPARTMENT", pointer, "Dependency matrix references unknown department."));
      }
    }

    const conflict = payload.conflict_resolution || {};
    if (!["COMMANDER", "COS"].includes(conflict.authority)) {
      issues.push(issue("critical", "COLLABORATION_CONFLICT_AUTHORITY_TOO_LOW", "$.conflict_resolution.authority", "Cross-department conflict resolution must route through Commander or CoS."));
    }
    if (conflict.decision_packet_required !== true) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_DECISION_PACKET_ROUTE", "$.conflict_resolution.decision_packet_required", "Mission, authority, risk, or release conflicts require decision packet route."));
    }
    const commanderEscalation = (conflict.commander_escalation || []).join("\n").toLowerCase();
    for (const [needle, code] of [
      ["red", "COLLABORATION_WITHOUT_RED_ESCALATION"],
      ["release", "COLLABORATION_WITHOUT_RELEASE_ESCALATION"],
      ["risk", "COLLABORATION_WITHOUT_RISK_ESCALATION"],
      ["scope", "COLLABORATION_WITHOUT_SCOPE_ESCALATION"]
    ]) {
      if (!commanderEscalation.includes(needle)) {
        issues.push(issue("critical", code, "$.conflict_resolution.commander_escalation", `Commander escalation must include ${needle} decisions.`));
      }
    }

    const controls = payload.collaboration_controls || {};
    for (const [field, code] of [
      ["no_silent_scope_change", "COLLABORATION_ALLOWS_SILENT_SCOPE_CHANGE"],
      ["source_map_required", "COLLABORATION_WITHOUT_SOURCE_MAP"],
      ["shared_glossary_required", "COLLABORATION_WITHOUT_SHARED_GLOSSARY"],
      ["handoff_required", "COLLABORATION_WITHOUT_HANDOFF"],
      ["aar_required", "COLLABORATION_WITHOUT_AAR"]
    ]) {
      if (controls[field] !== true) {
        issues.push(issue("error", code, `$.collaboration_controls.${field}`, `Collaboration control ${field} must be true.`));
      }
    }

    const infoPolicy = payload.information_policy || {};
    if (!hasSubstantiveItems(infoPolicy.need_to_know)) {
      issues.push(issue("error", "COLLABORATION_WITHOUT_NEED_TO_KNOW", "$.information_policy.need_to_know", "Collaboration must define need-to-know information policy."));
    }
    if (!hasSubstantiveItems(infoPolicy.context_sharing)) {
      issues.push(issue("error", "COLLABORATION_WITHOUT_CONTEXT_SHARING", "$.information_policy.context_sharing", "Collaboration must define context sharing policy."));
    }
    if (!hasSubstantiveItems(infoPolicy.eefi_controls)) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_EEFI_CONTROLS", "$.information_policy.eefi_controls", "Collaboration must define EEFI controls."));
    }

    const exit = payload.exit_criteria || {};
    if (!hasSubstantiveItems(exit.abort)) {
      issues.push(issue("critical", "COLLABORATION_WITHOUT_ABORT_CRITERIA", "$.exit_criteria.abort", "Collaboration must define abort criteria."));
    }
    if (!hasSubstantiveItems(exit.handoff)) {
      issues.push(issue("error", "COLLABORATION_WITHOUT_HANDOFF_CRITERIA", "$.exit_criteria.handoff", "Collaboration must define handoff criteria."));
    }
  }

  if (type === "force-structure-change-order") {
    const changeType = payload.change_type;
    const capability = payload.capability_gap || {};
    if (!hasSubstantiveItems(capability.evidence)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_EVIDENCE", "$.capability_gap.evidence", "Force structure change requires evidence for the capability gap, overload, redundancy, or risk."));
    }
    if (!hasSubstantiveItems(capability.operational_impact)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_OPERATIONAL_IMPACT", "$.capability_gap.operational_impact", "Force structure change must state operational impact."));
    }

    const alternatives = payload.alternatives_considered || [];
    if (alternatives.length < 2) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_ALTERNATIVES", "$.alternatives_considered", "Force structure change requires multiple alternatives before organization change."));
    }
    if (!alternatives.some(option => option.type !== "organization" && option.type !== "no_change")) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_NON_ORG_ALTERNATIVE", "$.alternatives_considered", "Consider SOP, training, tooling, authority, policy, or automation before changing organization."));
    }
    for (const [index, option] of alternatives.entries()) {
      const pointer = `$.alternatives_considered[${index}]`;
      if (/^none$/i.test(String(option.option || "").trim()) || /^none$/i.test(String(option.reason_not_sufficient || "").trim())) {
        issues.push(issue("error", "FORCE_CHANGE_PLACEHOLDER_ALTERNATIVE", pointer, "Alternatives must not be placeholder 'none' entries."));
      }
    }

    const dotmlpf = payload.dotmlpf_p || {};
    for (const [field, value] of Object.entries(dotmlpf)) {
      if (!hasSubstantiveItems(value)) {
        issues.push(issue("error", "FORCE_CHANGE_INCOMPLETE_DOTMLPF", `$.dotmlpf_p.${field}`, "DOTMLPF-P section must be substantively addressed."));
      }
    }

    const authority = payload.authority || {};
    if (["create", "activate", "expand", "merge", "split", "reduce", "deactivate", "disband"].includes(changeType) && authority.approving_authority !== "COMMANDER") {
      issues.push(issue("critical", "FORCE_CHANGE_REQUIRES_COMMANDER", "$.authority.approving_authority", "Force structure changes require Commander approval."));
    }
    const retained = (authority.commander_retained_decisions || []).join("\n").toLowerCase();
    for (const [needle, code] of [
      ["release", "FORCE_CHANGE_WITHOUT_RELEASE_RETAINED"],
      ["risk", "FORCE_CHANGE_WITHOUT_RISK_RETAINED"],
      ["scope", "FORCE_CHANGE_WITHOUT_SCOPE_RETAINED"]
    ]) {
      if (!retained.includes(needle)) {
        issues.push(issue("critical", code, "$.authority.commander_retained_decisions", `Commander-retained decisions must include ${needle}.`));
      }
    }
    if (!hasSubstantiveItems(authority.prohibited_changes)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_PROHIBITIONS", "$.authority.prohibited_changes", "Force structure change must state prohibited changes."));
    }
    if (!hasSubstantiveItems(authority.approval_evidence)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_APPROVAL_EVIDENCE", "$.authority.approval_evidence", "Force structure change needs approval evidence."));
    }

    const resources = payload.resources || {};
    if (!hasSubstantiveItems(resources.maintainer_roles)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_MAINTAINER", "$.resources.maintainer_roles", "New or changed organization needs maintainer roles."));
    }
    if (!hasSubstantiveItems(resources.tooling)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_TOOLING", "$.resources.tooling", "Force structure change must name required tooling or runner support."));
    }
    if (/unbounded/i.test(`${resources.context_budget || ""} ${resources.time_budget || ""}`)) {
      issues.push(issue("error", "FORCE_CHANGE_UNBOUNDED_RESOURCE", "$.resources", "Context/time budget must be bounded."));
    }
    if (!hasSubstantiveItems(resources.fallback)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_FALLBACK", "$.resources.fallback", "Force structure change requires fallback plan."));
    }

    const readiness = payload.readiness || {};
    if (readiness.required_rating === "U" || readiness.required_rating === "X") {
      issues.push(issue("critical", "FORCE_CHANGE_LOW_READINESS_TARGET", "$.readiness.required_rating", "Cannot activate or expand force structure with U/X readiness requirement."));
    }
    if (!hasSubstantiveItems(readiness.metl_tasks)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_METL", "$.readiness.metl_tasks", "Force structure change must define METL tasks."));
    }
    if (!hasSubstantiveItems(readiness.evidence)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_READINESS_EVIDENCE", "$.readiness.evidence", "Force structure change requires readiness evidence."));
    }
    if (!hasSubstantiveItems(readiness.backup_or_successor)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_SUCCESSOR", "$.readiness.backup_or_successor", "Changed organization requires backup or successor plan."));
    }
    if (!hasSubstantiveItems(readiness.validation_fixture)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_VALIDATION_FIXTURE", "$.readiness.validation_fixture", "Force structure change requires validation fixture."));
    }

    const transition = payload.transition_plan || {};
    if (!hasSubstantiveItems(transition.activation_steps)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_ACTIVATION_STEPS", "$.transition_plan.activation_steps", "Force structure change requires activation or execution steps."));
    }
    if (transition.handoff_required !== true) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_HANDOFF", "$.transition_plan.handoff_required", "Force structure change requires handoff."));
    }
    if (!hasSubstantiveItems(transition.data_migration)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_DATA_MIGRATION", "$.transition_plan.data_migration", "Force structure change must preserve or migrate source-of-truth data."));
    }
    if (!hasSubstantiveItems(transition.deactivation_or_sunset)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_SUNSET", "$.transition_plan.deactivation_or_sunset", "Force structure change requires deactivation or sunset conditions."));
    }
    if (!hasSubstantiveItems(transition.rollback)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_ROLLBACK", "$.transition_plan.rollback", "Force structure change requires rollback plan."));
    }

    const docs = payload.documentation_updates || {};
    for (const [field, value] of Object.entries(docs)) {
      if (!hasSubstantiveItems(value)) {
        issues.push(issue("error", "FORCE_CHANGE_WITHOUT_DOC_UPDATE", `$.documentation_updates.${field}`, "Force structure change must update schema/sample/runner/index documentation as applicable."));
      }
    }

    const assessment = payload.assessment || {};
    if (!hasSubstantiveItems(assessment.mop)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_MOP", "$.assessment.mop", "Force structure change must define MOP."));
    }
    if (!hasSubstantiveItems(assessment.moe)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_MOE", "$.assessment.moe", "Force structure change must define MOE."));
    }
    if (!hasSubstantiveItems(assessment.aar_trigger)) {
      issues.push(issue("error", "FORCE_CHANGE_WITHOUT_AAR_TRIGGER", "$.assessment.aar_trigger", "Force structure change must define AAR triggers."));
    }
    if (!isBefore(payload.created_at, assessment.review_at)) {
      issues.push(issue("error", "FORCE_CHANGE_REVIEW_NOT_FUTURE", "$.assessment.review_at", "Review date must be after order creation."));
    }
    if (!hasSubstantiveItems(assessment.sunset_condition)) {
      issues.push(issue("critical", "FORCE_CHANGE_WITHOUT_SUNSET_CONDITION", "$.assessment.sunset_condition", "Force structure change must define sunset/disband condition."));
    }

    if ((changeType === "reduce" || changeType === "deactivate" || changeType === "disband") && !hasSubstantiveItems(transition.data_migration)) {
      issues.push(issue("critical", "FORCE_REDUCTION_WITHOUT_TRANSFER", "$.transition_plan.data_migration", "Reduction/deactivation/disband must transfer essential functions and records."));
    }
  }

  if (type === "document-access-manifest") {
    if (payload.default_decision !== "deny") {
      issues.push(issue("critical", "DOCUMENT_ACCESS_DEFAULT_NOT_DENY", "$.default_decision", "Document access manifest must default to deny."));
    }

    const controls = payload.controls || {};
    if (controls.need_to_know !== true) {
      issues.push(issue("critical", "DOCUMENT_ACCESS_WITHOUT_NEED_TO_KNOW", "$.controls.need_to_know", "Document access must enforce need-to-know."));
    }
    if (controls.no_bulk_read !== true) {
      issues.push(issue("critical", "DOCUMENT_ACCESS_ALLOWS_BULK_READ", "$.controls.no_bulk_read", "Document access must prohibit bulk read."));
    }
    if (controls.audit_required !== true) {
      issues.push(issue("critical", "DOCUMENT_ACCESS_WITHOUT_AUDIT", "$.controls.audit_required", "Document access must require audit events."));
    }
    if (controls.exception_requires_approval !== true) {
      issues.push(issue("critical", "DOCUMENT_ACCESS_EXCEPTION_WITHOUT_APPROVAL", "$.controls.exception_requires_approval", "Document access exceptions must require approval."));
    }
    if (!controls.source_of_truth || /^none$/i.test(String(controls.source_of_truth).trim())) {
      issues.push(issue("error", "DOCUMENT_ACCESS_WITHOUT_SOURCE_OF_TRUTH", "$.controls.source_of_truth", "Document access manifest must name a source-of-truth policy."));
    }

    const documents = payload.documents || [];
    const documentByPath = new Map();
    for (const [index, document] of documents.entries()) {
      const pointer = `$.documents[${index}]`;
      documentByPath.set(document.path, document);
      if (document.path === "*" || /\/\*$/.test(document.path || "")) {
        issues.push(issue("critical", "DOCUMENT_ACCESS_WILDCARD_PATH", `${pointer}.path`, "Document access must name explicit files, not wildcard paths."));
      }
      if (/^https?:\/\//.test(document.path || "") || path.isAbsolute(document.path || "") || (document.path || "").includes("..")) {
        issues.push(issue("error", "DOCUMENT_ACCESS_NONLOCAL_PATH", `${pointer}.path`, "Document access manifest should point to controlled local repository paths."));
      }
      if (document.path && document.path !== "*" && !/^https?:\/\//.test(document.path) && !path.isAbsolute(document.path) && !document.path.includes("..")) {
        if (!fs.existsSync(path.join(ROOT, document.path))) {
          issues.push(issue("error", "DOCUMENT_ACCESS_DOC_PATH_MISSING", `${pointer}.path`, "Declared document path does not exist."));
        }
      }
      if (!hasSubstantiveItems(document.allowed_roles)) {
        issues.push(issue("critical", "DOCUMENT_ACCESS_WITHOUT_ALLOWED_ROLES", `${pointer}.allowed_roles`, "Each document must list allowed roles."));
      }
      if (!hasSubstantiveItems(document.duties)) {
        issues.push(issue("critical", "DOCUMENT_ACCESS_WITHOUT_DUTIES", `${pointer}.duties`, "Each document must list allowed duties."));
      }
      if (document.classification === "restricted" && document.delivery_mode === "raw") {
        issues.push(issue("critical", "DOCUMENT_ACCESS_RESTRICTED_RAW", `${pointer}.delivery_mode`, "Restricted documents cannot be delivered raw by manifest."));
      }
      if (document.classification === "sensitive" && document.delivery_mode === "raw") {
        const roles = document.allowed_roles || [];
        if (roles.includes("EXECUTOR") || roles.length > 3) {
          issues.push(issue("critical", "DOCUMENT_ACCESS_SENSITIVE_RAW_TOO_BROAD", `${pointer}.delivery_mode`, "Sensitive raw access must not be broad or defaulted to executors."));
        }
      }
    }

    for (const [index, profile] of (payload.role_profiles || []).entries()) {
      const pointer = `$.role_profiles[${index}]`;
      if (!hasSubstantiveItems(profile.required_documents)) {
        issues.push(issue("critical", "DOCUMENT_ACCESS_PROFILE_WITHOUT_REQUIRED_DOCS", `${pointer}.required_documents`, "Each role profile must define required reading."));
      }
      if (profile.escalation_role === profile.role) {
        issues.push(issue("critical", "DOCUMENT_ACCESS_ESCALATION_SELF", `${pointer}.escalation_role`, "Document access exceptions must escalate to another role."));
      }

      const denied = new Set(profile.denied_documents || []);
      for (const docPath of profile.required_documents || []) {
        if (denied.has(docPath)) {
          issues.push(issue("critical", "DOCUMENT_ACCESS_DENIED_DOC_REQUIRED", `${pointer}.required_documents`, "Required reading cannot include a denied document."));
        }
        const document = documentByPath.get(docPath);
        if (!document) {
          issues.push(issue("critical", "DOCUMENT_ACCESS_REQUIRED_DOC_NOT_DECLARED", `${pointer}.required_documents`, "Required document must be declared in documents list."));
          continue;
        }
        const roleAllowed = (document.allowed_roles || []).includes(profile.role);
        const dutyAllowed = (document.duties || []).includes(profile.duty) || (document.duties || []).includes("mission_common");
        const authorityAllowed = authorityAtLeast(profile.authority_level, document.minimum_authority_level);
        const restrictedRaw = document.classification === "restricted" && document.delivery_mode === "raw";
        if (!roleAllowed || !dutyAllowed || !authorityAllowed || restrictedRaw) {
          issues.push(issue("critical", "DOCUMENT_ACCESS_REQUIRED_DOC_NOT_READABLE", `${pointer}.required_documents`, "Required document is not readable by the profile role, duty, authority, or delivery rule."));
        }
      }

      for (const docPath of profile.optional_documents || []) {
        if (!documentByPath.has(docPath)) {
          issues.push(issue("error", "DOCUMENT_ACCESS_OPTIONAL_DOC_NOT_DECLARED", `${pointer}.optional_documents`, "Optional document must be declared in documents list."));
        }
      }
    }
  }

  if (type === "ccir-alert") {
    if ((payload.severity === "Red" || payload.severity === "Black") && !payload.blocks_execution) {
      issues.push(issue("critical", "HIGH_SEVERITY_ALERT_NOT_BLOCKING", "$.blocks_execution", "Red and Black alerts must block execution until disposition."));
    }
    if ((payload.severity === "Red" || payload.severity === "Black") && !payload.required_decision) {
      issues.push(issue("critical", "HIGH_SEVERITY_WITHOUT_DECISION", "$.required_decision", "Red and Black alerts must state the required commander decision."));
    }
    if (payload.ccir_type === "EEFI" && payload.sensitive !== true) {
      issues.push(issue("error", "EEFI_NOT_MARKED_SENSITIVE", "$.sensitive", "EEFI alerts must be marked sensitive."));
    }
  }

  if (type === "handoff-packet") {
    if (!payload.source_of_truth_files || isEmptyArray(payload.source_of_truth_files)) {
      issues.push(issue("critical", "HANDOFF_WITHOUT_SOURCE_OF_TRUTH", "$.source_of_truth_files", "Handoff packet must identify source-of-truth files."));
    }
    if (payload.blocked && payload.blocked.length > 0 && isEmptyArray(payload.pending_decisions)) {
      issues.push(issue("critical", "BLOCKED_WITHOUT_PENDING_DECISION", "$.pending_decisions", "Blocked handoff items must name pending commander decisions."));
    }
    if (isEmptyArray(payload.do_not_do)) {
      issues.push(issue("warning", "HANDOFF_WITHOUT_PROHIBITIONS", "$.do_not_do", "Handoff should restate do-not-do boundaries."));
    }
  }

  if (type === "continuity-plan") {
    const successionByRole = new Map((payload.succession_rules || []).map(rule => [rule.from_role, rule]));
    for (const [index, fn] of (payload.essential_functions || []).entries()) {
      const pointer = `$.essential_functions[${index}]`;
      if (!hasSubstantiveItems(fn.backup_roles) || fn.backup_roles.length < 2) {
        issues.push(issue("critical", "ESSENTIAL_FUNCTION_NOT_TWO_DEEP", `${pointer}.backup_roles`, "Essential functions require at least two backup roles."));
      }
      if ((fn.backup_roles || []).includes(fn.owner_role)) {
        issues.push(issue("critical", "SUCCESSOR_CANNOT_BE_SELF", `${pointer}.backup_roles`, "Backup roles cannot be the same as the unavailable owner role."));
      }
      if (fn.handoff_required !== true) {
        issues.push(issue("error", "ESSENTIAL_FUNCTION_WITHOUT_HANDOFF", `${pointer}.handoff_required`, "Essential function continuity requires a handoff packet."));
      }
      if (!hasSubstantiveItems(fn.source_of_truth_files)) {
        issues.push(issue("error", "ESSENTIAL_FUNCTION_WITHOUT_VITAL_RECORDS", `${pointer}.source_of_truth_files`, "Essential function needs source-of-truth files."));
      }
      if (!successionByRole.has(fn.owner_role)) {
        issues.push(issue("critical", "ESSENTIAL_FUNCTION_WITHOUT_SUCCESSION_RULE", `${pointer}.owner_role`, "Essential function owner must have a succession rule."));
      }
    }
    for (const [index, rule] of (payload.succession_rules || []).entries()) {
      const pointer = `$.succession_rules[${index}]`;
      if (!hasSubstantiveItems(rule.successors) || rule.successors.length < 2) {
        issues.push(issue("critical", "SUCCESSION_RULE_NOT_TWO_DEEP", `${pointer}.successors`, "Succession rule requires at least two successors."));
      }
      if ((rule.successors || []).includes(rule.from_role)) {
        issues.push(issue("critical", "SUCCESSION_RULE_SELF_SUCCESSOR", `${pointer}.successors`, "A role cannot succeed itself after loss or unavailability."));
      }
      if (!hasSubstantiveItems(rule.activation_triggers)) {
        issues.push(issue("error", "SUCCESSION_WITHOUT_TRIGGER", `${pointer}.activation_triggers`, "Succession rule needs activation triggers."));
      }
      if (!hasSubstantiveItems(rule.authority_limits)) {
        issues.push(issue("critical", "SUCCESSION_WITHOUT_AUTHORITY_LIMITS", `${pointer}.authority_limits`, "Successor authority must be bounded."));
      }
      if (!hasSubstantiveItems(rule.notification_roles)) {
        issues.push(issue("warning", "SUCCESSION_WITHOUT_NOTIFICATION", `${pointer}.notification_roles`, "Succession should notify affected command and KM roles."));
      }
    }
    for (const [index, rotation] of (payload.rotation_windows || []).entries()) {
      const pointer = `$.rotation_windows[${index}]`;
      if (rotation.overlap_required !== true) {
        issues.push(issue("error", "ROTATION_WITHOUT_OVERLAP", `${pointer}.overlap_required`, "Role rotation requires overlap."));
      }
      if (rotation.backbrief_required !== true) {
        issues.push(issue("error", "ROTATION_WITHOUT_BACKBRIEF", `${pointer}.backbrief_required`, "Incoming role must backbrief before assuming duties."));
      }
      if (rotation.handoff_packet_required !== true) {
        issues.push(issue("error", "ROTATION_WITHOUT_HANDOFF_PACKET", `${pointer}.handoff_packet_required`, "Rotation requires a handoff packet."));
      }
      if (rotation.rehearsal_required !== true) {
        issues.push(issue("warning", "ROTATION_WITHOUT_REHEARSAL", `${pointer}.rehearsal_required`, "High-risk rotations should rehearse before execution."));
      }
    }
    const vitalRecords = (payload.vital_records || []).join("\n").toLowerCase();
    if (!/authority/.test(vitalRecords)) {
      issues.push(issue("critical", "CONTINUITY_WITHOUT_AUTHORITY_RECORD", "$.vital_records", "Continuity vital records must include authority source of truth."));
    }
    if (!/handoff/.test(vitalRecords)) {
      issues.push(issue("critical", "CONTINUITY_WITHOUT_HANDOFF_RECORD", "$.vital_records", "Continuity vital records must include handoff source of truth."));
    }
    const degradation = payload.degradation_policy || {};
    if (!hasSubstantiveItems(degradation.functions_to_pause)) {
      issues.push(issue("critical", "DEGRADED_MODE_WITHOUT_PAUSED_FUNCTIONS", "$.degradation_policy.functions_to_pause", "Continuity plan must pause high-risk functions in degraded mode."));
    }
    if (!hasSubstantiveItems(degradation.commander_retained_decisions)) {
      issues.push(issue("critical", "CONTINUITY_WITHOUT_COMMANDER_RETAINED_DECISIONS", "$.degradation_policy.commander_retained_decisions", "Continuity plan must preserve commander-retained decisions."));
    }
    if (!hasSubstantiveItems(degradation.recovery_actions)) {
      issues.push(issue("error", "CONTINUITY_WITHOUT_RECOVERY_ACTIONS", "$.degradation_policy.recovery_actions", "Continuity plan needs recovery actions."));
    }
    if (!hasSubstantiveItems(payload.validation && payload.validation.tested_scenarios)) {
      issues.push(issue("warning", "CONTINUITY_WITHOUT_DRILL_SCENARIOS", "$.validation.tested_scenarios", "Continuity plan should be drill-tested."));
    }
  }

  if (type === "sof-tf-charter") {
    const trigger = payload.trigger || {};
    if (!hasSubstantiveItems(trigger.conditions) || /^none$/i.test(String(trigger.why_general_workflow_insufficient || "").trim())) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_TRIGGER", "$.trigger", "SOF TF activation requires a concrete trigger and reason general workflow is insufficient."));
    }
    if (!hasSubstantiveItems(payload.activity_mapping)) {
      issues.push(issue("error", "SOF_TF_WITHOUT_ACTIVITY_MAPPING", "$.activity_mapping", "SOF TF must map the mission to a safe AI activity category."));
    }
    if (trigger.risk_level === "low" && trigger.urgency === "routine") {
      issues.push(issue("warning", "SOF_TF_LOW_RISK_ACTIVATION", "$.trigger.risk_level", "Routine low-risk work should normally use the standard workflow, not SOF TF."));
    }

    const authority = payload.authority || {};
    const retained = (authority.retained_by_commander || []).join("\n").toLowerCase();
    if (!/red/.test(retained)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_RED_RETAINED_AUTHORITY", "$.authority.retained_by_commander", "Red approval must remain commander-retained."));
    }
    if (!/release/.test(retained)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_RELEASE_RETAINED_AUTHORITY", "$.authority.retained_by_commander", "External release approval must remain commander-retained."));
    }
    if (!/risk/.test(retained)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_RISK_RETAINED_AUTHORITY", "$.authority.retained_by_commander", "High or critical residual risk acceptance must remain commander-retained."));
    }
    if (isEmptyArray(authority.prohibited)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_PROHIBITIONS", "$.authority.prohibited", "SOF TF charter must state prohibited actions."));
    }
    if ((payload.activity_mapping || []).includes("direct_action") && !hasSubstantiveItems(authority.approval_required)) {
      issues.push(issue("critical", "SOF_TF_DIRECT_ACTION_WITHOUT_APPROVAL", "$.authority.approval_required", "Direct-action-like AI work requires explicit approval-required actions."));
    }

    const cells = payload.cells || {};
    if (cells.red_team && [cells.lead, cells.s3_execution, cells.opsec_release].includes(cells.red_team)) {
      issues.push(issue("critical", "SOF_TF_RED_TEAM_NOT_INDEPENDENT", "$.cells.red_team", "Red Team must be independent from lead, executor, and release reviewer."));
    }
    if (cells.opsec_release && cells.opsec_release === cells.s3_execution) {
      issues.push(issue("critical", "SOF_TF_RELEASE_REVIEW_NOT_INDEPENDENT", "$.cells.opsec_release", "OPSEC/release reviewer cannot be the execution cell."));
    }
    if (cells.recorder !== "RECORDER") {
      issues.push(issue("error", "SOF_TF_WITHOUT_RECORDER", "$.cells.recorder", "SOF TF requires a Recorder/KM cell for audit and handoff."));
    }
    if (!["S4", "S6"].includes(cells.s4_s6_enabler)) {
      issues.push(issue("error", "SOF_TF_WITHOUT_SUSTAINMENT_ENABLER", "$.cells.s4_s6_enabler", "SOF TF requires an S4/S6 enabler, not only an executor."));
    }

    const ccir = payload.ccir || {};
    if (!hasSubstantiveItems(ccir.eefi)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_EEFI", "$.ccir.eefi", "SOF TF must define EEFI before distributing context."));
    }
    if (!hasSubstantiveItems(ccir.decision_points)) {
      issues.push(issue("error", "SOF_TF_WITHOUT_DECISION_POINTS", "$.ccir.decision_points", "SOF TF must define commander decision points."));
    }

    const isolation = payload.isolation || {};
    if (!hasSubstantiveItems(isolation.context_rules)) {
      issues.push(issue("error", "SOF_TF_WITHOUT_CONTEXT_RULES", "$.isolation.context_rules", "SOF TF needs need-to-know context distribution rules."));
    }
    if (!hasSubstantiveItems(isolation.eefi_controls)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_EEFI_CONTROLS", "$.isolation.eefi_controls", "SOF TF must define EEFI controls."));
    }

    const enablers = payload.enablers || {};
    if (enablers.source_map_required !== true) {
      issues.push(issue("critical", "SOF_TF_SOURCE_MAP_NOT_REQUIRED", "$.enablers.source_map_required", "SOF TF requires source-map discipline."));
    }
    if (enablers.release_review_required !== true) {
      issues.push(issue("critical", "SOF_TF_RELEASE_REVIEW_NOT_REQUIRED", "$.enablers.release_review_required", "SOF TF output requires release review."));
    }
    if (enablers.maintenance_check_required !== true) {
      issues.push(issue("error", "SOF_TF_WITHOUT_MAINTENANCE_CHECK", "$.enablers.maintenance_check_required", "SOF TF requires tool/resource readiness check."));
    }
    if (!hasSubstantiveItems(enablers.fallback_plan)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_FALLBACK_PLAN", "$.enablers.fallback_plan", "SOF TF requires PACE/fallback plan."));
    }
    const supportRoles = new Set(enablers.support_roles || []);
    if (!supportRoles.has("S6") && !supportRoles.has("S4")) {
      issues.push(issue("error", "SOF_TF_WITHOUT_SUPPORT_ROLE", "$.enablers.support_roles", "SOF TF needs S4/S6 support roles."));
    }

    const rehearsal = payload.rehearsal || {};
    if (rehearsal.backbrief_required !== true) {
      issues.push(issue("error", "SOF_TF_WITHOUT_BACKBRIEF", "$.rehearsal.backbrief_required", "SOF TF activation requires backbrief."));
    }
    if (rehearsal.rehearsal_required !== true) {
      issues.push(issue("error", "SOF_TF_WITHOUT_REHEARSAL", "$.rehearsal.rehearsal_required", "SOF TF activation requires rehearsal."));
    }
    if (rehearsal.dry_run_required !== true) {
      issues.push(issue("error", "SOF_TF_WITHOUT_DRY_RUN", "$.rehearsal.dry_run_required", "SOF TF activation requires dry run before execution."));
    }

    const exit = payload.exit_criteria || {};
    if (!hasSubstantiveItems(exit.abort)) {
      issues.push(issue("critical", "SOF_TF_WITHOUT_ABORT_CRITERIA", "$.exit_criteria.abort", "SOF TF must define abort criteria."));
    }
    if (!hasSubstantiveItems(exit.handoff)) {
      issues.push(issue("error", "SOF_TF_WITHOUT_HANDOFF_CRITERIA", "$.exit_criteria.handoff", "SOF TF must define handoff criteria."));
    }
  }

  if (type === "doctrine-consistency-review") {
    const sourceFamilies = payload.source_families || [];
    const nonUsFamilies = sourceFamilies.filter(source => String(source.family_id || "").toUpperCase() !== "US");
    if (sourceFamilies.length < 4) {
      issues.push(issue("critical", "DOCTRINE_REVIEW_TOO_FEW_SOURCE_FAMILIES", "$.source_families", "Doctrine consistency review must compare at least four official source families."));
    }
    if (nonUsFamilies.length < 3) {
      issues.push(issue("critical", "DOCTRINE_REVIEW_TOO_FEW_NON_US_FAMILIES", "$.source_families", "Doctrine consistency review must include at least three non-US source families."));
    }
    for (const [index, source] of sourceFamilies.entries()) {
      const pointer = `$.source_families[${index}]`;
      if (!hasSubstantiveItems(source.official_source_urls)) {
        issues.push(issue("critical", "DOCTRINE_REVIEW_SOURCE_WITHOUT_OFFICIAL_URL", `${pointer}.official_source_urls`, "Each source family must cite official source URLs."));
      }
      if (!hasSubstantiveItems(source.doctrine_scope)) {
        issues.push(issue("error", "DOCTRINE_REVIEW_SOURCE_WITHOUT_SCOPE", `${pointer}.doctrine_scope`, "Each source family must state doctrine or policy scope."));
      }
      if (!hasSubstantiveItems(source.comparison_use)) {
        issues.push(issue("error", "DOCTRINE_REVIEW_SOURCE_WITHOUT_COMPARISON_USE", `${pointer}.comparison_use`, "Each source family must state how it is used in comparison."));
      }
    }

    for (const [index, finding] of (payload.policy_findings || []).entries()) {
      const pointer = `$.policy_findings[${index}]`;
      if (finding.disposition === "adopt_us_only") {
        issues.push(issue("critical", "DOCTRINE_REVIEW_US_ONLY_DISPOSITION", `${pointer}.disposition`, "US-only adoption is not a valid disposition for multinational consistency review."));
      }
      if ((finding.consistency_risk === "medium" || finding.consistency_risk === "high" || finding.consistency_risk === "critical") && !hasSubstantiveItems(finding.policy_update_targets)) {
        issues.push(issue("critical", "DOCTRINE_REVIEW_FINDING_WITHOUT_POLICY_TARGET", `${pointer}.policy_update_targets`, "Medium or higher consistency findings require policy update targets."));
      }
      if (finding.verification && finding.verification.status !== "verified") {
        issues.push(issue("error", "DOCTRINE_REVIEW_UNVERIFIED_FINDING", `${pointer}.verification.status`, "Doctrine consistency findings must be verified before the review is complete."));
      }
      if (finding.category === "role_staff_terminology" && !/alias|local|terminology/i.test(`${finding.resolution || ""} ${(finding.policy_update_targets || []).join(" ")}`)) {
        issues.push(issue("critical", "DOCTRINE_REVIEW_ROLE_ALIAS_MISSING", `${pointer}.resolution`, "Role/staff terminology conflicts require alias or local terminology handling."));
      }
      if (finding.category === "roe_legal_authority" && !/jurisdiction|legal|local/i.test(`${finding.resolution || ""} ${(finding.policy_update_targets || []).join(" ")}`)) {
        issues.push(issue("critical", "DOCTRINE_REVIEW_JURISDICTION_GATE_MISSING", `${pointer}.resolution`, "ROE/legal authority conflicts require local jurisdiction review."));
      }
      if (finding.category === "force_structure" && !/capability|lifecycle|DOTMLPF/i.test(finding.resolution || "")) {
        issues.push(issue("warning", "DOCTRINE_REVIEW_FORCE_STRUCTURE_NOT_GENERALIZED", `${pointer}.resolution`, "Force structure findings should translate US terms into a capability lifecycle review."));
      }
    }

    const controls = payload.resolution_controls || {};
    for (const [field, value] of Object.entries(controls)) {
      if (value !== true) {
        issues.push(issue("critical", "DOCTRINE_REVIEW_CONTROL_DISABLED", `$.resolution_controls.${field}`, `Doctrine consistency control ${field} must be true.`));
      }
    }

    const docs = payload.documentation_updates || {};
    for (const [field, value] of Object.entries(docs)) {
      if (!hasSubstantiveItems(value)) {
        issues.push(issue("error", "DOCTRINE_REVIEW_PLACEHOLDER_DOC_UPDATE", `$.documentation_updates.${field}`, "Doctrine consistency review must name documentation updates, not placeholder none."));
      }
    }
  }

  if (type === "context-item") {
    if (payload.eefi === true && payload.release_to_final === true) {
      issues.push(issue("critical", "EEFI_RELEASE_TO_FINAL", "$.release_to_final", "EEFI context cannot be released directly to final output."));
    }
    if (payload.classification === "restricted" && payload.release_to_final === true) {
      issues.push(issue("critical", "RESTRICTED_RELEASE_TO_FINAL", "$.release_to_final", "Restricted context cannot be released directly to final output."));
    }
    if (isEmptyArray(payload.allowed_roles)) {
      issues.push(issue("error", "NO_ALLOWED_ROLES", "$.allowed_roles", "Context item must name allowed receiving roles."));
    }
    if (payload.eefi === true && /password|token|secret|private[_-]?key|credential/i.test(payload.raw_value || "")) {
      issues.push(issue("warning", "RAW_EEFI_PRESENT", "$.raw_value", "Raw EEFI is present; prefer redacted source storage."));
    }
  }

  if (type === "release-review") {
    if (isEmptyArray(payload.items)) {
      issues.push(issue("critical", "RELEASE_REVIEW_WITHOUT_ITEMS", "$.items", "Release review must evaluate at least one context item."));
    }
    if (isEmptyArray(payload.output_constraints)) {
      issues.push(issue("error", "NO_RELEASE_CONSTRAINTS", "$.output_constraints", "Release review must state output constraints."));
    }
    for (const [index, item] of (payload.items || []).entries()) {
      const pointer = `$.items[${index}]`;
      if ((item.eefi === true || item.classification === "restricted") && item.delivery_mode === "raw") {
        issues.push(issue("critical", "RESTRICTED_OR_EEFI_RAW_RELEASE", `${pointer}.delivery_mode`, "Restricted or EEFI item cannot be released raw."));
      }
      if (payload.target === "final_output" && item.delivery_mode === "raw" && item.classification !== "public") {
        issues.push(issue("error", "NON_PUBLIC_RAW_FINAL_OUTPUT", `${pointer}.delivery_mode`, "Final output should not include raw non-public context."));
      }
      if ((item.delivery_mode === "redacted" || item.delivery_mode === "denied") && isEmptyArray(item.redactions)) {
        issues.push(issue("warning", "REDACTION_NOT_EXPLAINED", `${pointer}.redactions`, "Redacted or denied item should explain redactions."));
      }
    }
  }

  if (type === "release-gate-decision-event") {
    const authority = payload.authority || {};
    const release = payload.release_review || {};
    const allowingDecision = payload.final_decision === "allow_scoped_execution" || payload.final_decision === "allow_scoped_execution_and_release";
    const blockingDecision = payload.final_decision === "prohibit" || payload.final_decision === "blocked_pending_authority" || payload.final_decision === "blocked_pending_release_review";

    if (payload.blocked !== blockingDecision) {
      issues.push(issue("critical", "RELEASE_GATE_BLOCKED_FLAG_MISMATCH", "$.blocked", "Release gate blocked flag must match final_decision."));
    }
    if (authority.blocked === true && allowingDecision) {
      issues.push(issue("critical", "RELEASE_GATE_ALLOW_WITH_AUTHORITY_BLOCK", "$.final_decision", "Release gate cannot allow when authority integration is blocked."));
    }
    if (authority.blocked === true && !(payload.final_decision === "blocked_pending_authority" || payload.final_decision === "prohibit")) {
      issues.push(issue("critical", "RELEASE_GATE_AUTHORITY_BLOCK_NOT_FINAL", "$.final_decision", "Authority block must drive the final release gate decision."));
    }
    if (authority.allowed === true && release.required === true && release.valid !== true && payload.final_decision !== "blocked_pending_release_review") {
      issues.push(issue("critical", "RELEASE_GATE_RELEASE_BLOCK_NOT_FINAL", "$.final_decision", "Failed or missing release review must block otherwise authorized execution."));
    }
    if (authority.allowed === true && release.required === true && release.valid === true && payload.final_decision !== "allow_scoped_execution_and_release") {
      issues.push(issue("error", "RELEASE_GATE_VALID_REVIEW_NOT_RELEASED", "$.final_decision", "Authorized execution with valid required release review should allow scoped execution and release."));
    }
    if (authority.allowed === true && release.required !== true && payload.final_decision !== "allow_scoped_execution") {
      issues.push(issue("error", "RELEASE_GATE_UNREQUIRED_REVIEW_DECISION_MISMATCH", "$.final_decision", "When release review is not required, final decision should mirror scoped execution."));
    }
    if (release.required === true && release.valid === true && !release.review_id) {
      issues.push(issue("error", "RELEASE_GATE_VALID_REVIEW_WITHOUT_ID", "$.release_review.review_id", "Valid release gate review must reference the release review id."));
    }
    if (release.required === true && release.valid !== true && allowingDecision) {
      issues.push(issue("critical", "RELEASE_GATE_ALLOW_WITH_FAILED_RELEASE_REVIEW", "$.final_decision", "Release gate cannot allow final/external output with a failed or missing release review."));
    }
    if (payload.blocked === true && !hasSubstantiveItems(payload.reasons)) {
      issues.push(issue("error", "RELEASE_GATE_BLOCK_WITHOUT_REASONS", "$.reasons", "Blocked release gate decision must include reasons."));
    }
    if (!hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "RELEASE_GATE_WITHOUT_EVIDENCE", "$.evidence", "Release gate decision event must include evidence."));
    }
  }

  if (type === "github-release-authorization") {
    for (const releaseIssue of validateGitHubReleaseAuthorization(payload)) {
      issues.push(issue(
        "critical",
        releaseIssue.code,
        releaseIssue.path,
        releaseIssue.message
      ));
    }
  }

  if (type === "github-release-receipt") {
    for (const releaseIssue of validateGitHubReleaseReceipt(payload)) {
      issues.push(issue(
        "critical",
        releaseIssue.code,
        releaseIssue.path,
        releaseIssue.message
      ));
    }
  }

  if (type === "github-release-immutability-authorization") {
    for (const policyIssue of validateGitHubReleaseImmutabilityAuthorization(payload)) {
      issues.push(issue(
        "critical",
        policyIssue.code,
        policyIssue.path,
        policyIssue.message
      ));
    }
  }

  if (type === "github-release-immutability-receipt") {
    for (const policyIssue of validateGitHubReleaseImmutabilityReceipt(payload)) {
      issues.push(issue(
        "critical",
        policyIssue.code,
        policyIssue.path,
        policyIssue.message
      ));
    }
  }

  if (type === "github-release-integrity-policy") {
    for (const policyIssue of validateGitHubReleaseIntegrityPolicy(payload)) {
      issues.push(issue(
        "critical",
        policyIssue.code,
        policyIssue.path,
        policyIssue.message
      ));
    }
  }

  if (type === "github-release-integrity-observation") {
    for (const observationIssue of
      validateGitHubReleaseIntegrityObservation(payload)) {
      issues.push(issue(
        "critical",
        observationIssue.code,
        observationIssue.path,
        observationIssue.message
      ));
    }
  }

  if (type === "github-release-trusted-root") {
    for (const trustIssue of validateGitHubReleaseTrustedRoot(payload, {
      evaluatedAt: options.evaluatedAt
    })) {
      issues.push(issue(
        "critical",
        trustIssue.code,
        trustIssue.path,
        trustIssue.message
      ));
    }
  }

  if (type === "github-release-trust-checkpoint") {
    for (const checkpointIssue of
      validateGitHubReleaseTrustCheckpoint(payload, {
        evaluatedAt: options.evaluatedAt
      })) {
      issues.push(issue(
        "critical",
        checkpointIssue.code,
        checkpointIssue.path,
        checkpointIssue.message
      ));
    }
  }

  if (type === "github-release-bootstrap-recovery") {
    for (const recoveryIssue of
      validateGitHubReleaseBootstrapRecovery(payload, {
        evaluatedAt: options.evaluatedAt
      })) {
      issues.push(issue(
        "critical",
        recoveryIssue.code,
        recoveryIssue.path,
        recoveryIssue.message
      ));
    }
  }

  if (type === "github-release-independent-verification") {
    if (payload && payload.verification_sha256 !==
        independentVerificationDigest(payload)) {
      issues.push(issue(
        "critical",
        "GITHUB_RELEASE_INDEPENDENT_EVIDENCE_DIGEST_MISMATCH",
        "$.verification_sha256",
        "Independent verification digest must bind the complete evidence."
      ));
    }
    if (!payload || payload.cryptographic_verification_succeeded !== true ||
        payload.release_authorized !== false ||
        !payload.authority ||
        payload.authority.human_final_decision_authority !== "USER" ||
        payload.authority.monitoring_only !== true ||
        payload.authority.release_authorized !== false) {
      issues.push(issue(
        "critical",
        "GITHUB_RELEASE_INDEPENDENT_EVIDENCE_AUTHORITY_DRIFT",
        "$.authority",
        "Independent verification evidence is monitoring-only and cannot grant release authority."
      ));
    }
  }

  if (type === "mission-wave-plan") {
    if (!isValidDate(payload.created_at) || !isValidDate(payload.valid_until) || !isBefore(payload.created_at, payload.valid_until)) {
      issues.push(issue("critical", "MISSION_WAVE_INVALID_VALIDITY", "$.valid_until", "Mission wave validity must end after its valid creation time."));
    }
    const agents = payload.agents || [];
    const agentIds = agents.map(agent => agent.agent_id);
    if (new Set(agentIds).size !== agentIds.length) {
      issues.push(issue("critical", "MISSION_WAVE_DUPLICATE_AGENT", "$.agents", "A mission wave cannot assign the same agent more than once."));
    }
    for (const [index, agent] of agents.entries()) {
      const pointer = `$.agents[${index}]`;
      if (["USER", "COMMANDER"].includes(agent.operational_role)) {
        issues.push(issue("critical", "MISSION_WAVE_AI_COMMAND_AUTHORITY", `${pointer}.operational_role`, "A delegated AI agent cannot occupy USER or COMMANDER final-decision authority."));
      }
      for (const field of ["allowed_actions", "approval_required", "prohibited_actions"]) {
        if (!hasSubstantiveItems(agent[field])) {
          issues.push(issue("error", "MISSION_WAVE_EMPTY_AUTHORITY_BOUNDARY", `${pointer}.${field}`, `Agent ${agent.agent_id || index} must declare substantive ${field}.`));
        }
      }
      const allowed = (agent.allowed_actions || []).join(" ");
      if (/\b(?:approve|release|merge|push|commit|accept\s+risk|change\s+(?:policy|authority))\b/i.test(allowed)) {
        issues.push(issue("critical", "MISSION_WAVE_RETAINED_ACTION_DELEGATED", `${pointer}.allowed_actions`, "Retained approval, release, repository publication, risk, policy, or authority actions cannot be delegated as ordinary execution."));
      }
      if ((CLASSIFICATION_RANK[agent.context_scope] ?? 99) >
          (CLASSIFICATION_RANK[payload.mission_profile && payload.mission_profile.classification] ?? -1)) {
        issues.push(issue("critical", "MISSION_WAVE_CONTEXT_EXCEEDS_MISSION", `${pointer}.context_scope`, "Agent context scope cannot exceed the mission classification."));
      }
    }
    const dispatchControl = payload.dispatch_control;
    if (dispatchControl) {
      const authorizations = Array.isArray(dispatchControl.policy_authorizations)
        ? dispatchControl.policy_authorizations
        : [];
      const policyIds = authorizations.map(item => item && item.policy_id);
      if (new Set(policyIds).size !== policyIds.length) {
        issues.push(issue("critical", "MISSION_WAVE_DUPLICATE_DISPATCH_POLICY", "$.dispatch_control.policy_authorizations", "Dispatch policy IDs must be unique within one wave."));
      }
      for (const [index, authorization] of authorizations.entries()) {
        if (!agentIds.includes(authorization.agent_id)) {
          issues.push(issue("critical", "MISSION_WAVE_UNKNOWN_DISPATCH_AGENT", `$.dispatch_control.policy_authorizations[${index}].agent_id`, "Dispatch policy authorization must name one assigned mission agent."));
        }
      }
      for (const agentId of agentIds) {
        const agentAuthorizations = authorizations
          .filter(item => item && item.agent_id === agentId);
        if (agentAuthorizations.length === 0) {
          issues.push(issue("critical", "MISSION_WAVE_DISPATCH_POLICY_MISSING", "$.dispatch_control.policy_authorizations", `Dispatch enforcement requires a policy authorization for ${agentId}.`));
        } else if (agentAuthorizations.length > 1) {
          issues.push(issue("critical", "MISSION_WAVE_MULTIPLE_DISPATCH_POLICIES", "$.dispatch_control.policy_authorizations", `Dispatch enforcement permits exactly one policy authorization for ${agentId} in one wave.`));
        }
      }
    }
    if (payload.mission_profile && payload.mission_profile.roe_class === "Black") {
      issues.push(issue("critical", "MISSION_WAVE_BLACK_PROHIBITED", "$.mission_profile.roe_class", "Black actions cannot enter an operational mission wave."));
    }
    if (payload.adaptive_work && payload.adaptive_work.enabled === true && !hasSubstantiveItems(payload.adaptive_work.acceptance_criteria)) {
      issues.push(issue("critical", "MISSION_WAVE_ADAPTIVE_WITHOUT_CRITERIA", "$.adaptive_work.acceptance_criteria", "Adaptive work requires observable acceptance criteria."));
    }
    const modelAssignment = payload.model_assignment || {};
    const modelRef = modelAssignment.integrated_preflight_ref || {};
    const modelRefMissing = modelRef.artifact_id === "none" || modelRef.relative_path === "none" || modelRef.sha256 === "none";
    if (modelRefMissing && !(modelRef.artifact_id === "none" && modelRef.relative_path === "none" && modelRef.sha256 === "none")) {
      issues.push(issue("critical", "MISSION_WAVE_PARTIAL_MODEL_PREFLIGHT_REF", "$.model_assignment.integrated_preflight_ref", "A missing model preflight reference must use none in every field."));
    }
    if (modelAssignment.required === true && modelRefMissing) {
      issues.push(issue("critical", "MISSION_WAVE_MODEL_PREFLIGHT_REQUIRED", "$.model_assignment.integrated_preflight_ref", "Required model assignment needs an exact integrated preflight reference."));
    }
    if (modelAssignment.required !== true && !modelRefMissing) {
      issues.push(issue("error", "MISSION_WAVE_UNUSED_MODEL_PREFLIGHT", "$.model_assignment.integrated_preflight_ref", "A model preflight reference must not be attached when model assignment is not required."));
    }
    for (const [index, agent] of agents.entries()) {
      if (modelAssignment.required === true && agent.model_billet_id === "not_required") {
        issues.push(issue("critical", "MISSION_WAVE_MODEL_BILLET_REQUIRED", `$.agents[${index}].model_billet_id`, "Every agent requires a billet when model assignment is required."));
      }
      if (modelAssignment.required !== true && agent.model_billet_id !== "not_required") {
        issues.push(issue("error", "MISSION_WAVE_UNUSED_MODEL_BILLET", `$.agents[${index}].model_billet_id`, "Use not_required when the wave does not require model assignment."));
      }
    }
  }

  if (type === "agent-context-pack") {
    if (!isValidDate(payload.created_at) || !isValidDate(payload.valid_until) || !isBefore(payload.created_at, payload.valid_until)) {
      issues.push(issue("critical", "AGENT_CONTEXT_INVALID_VALIDITY", "$.valid_until", "Agent context must have a bounded validity window."));
    }
    if (["USER", "COMMANDER"].includes(payload.operational_role)) {
      issues.push(issue("critical", "AGENT_CONTEXT_AI_COMMAND_AUTHORITY", "$.operational_role", "An AI context pack cannot assign USER or COMMANDER final-decision authority."));
    }
    const documentPaths = (payload.documents || []).map(document => document.path);
    if (new Set(documentPaths).size !== documentPaths.length) {
      issues.push(issue("error", "AGENT_CONTEXT_DUPLICATE_DOCUMENT", "$.documents", "Agent context documents must be unique."));
    }
    for (const baseline of ["README.md", "docs/source-map.md"]) {
      if (!documentPaths.includes(baseline)) {
        issues.push(issue("critical", "AGENT_CONTEXT_MISSING_BASELINE", "$.documents", `Agent context must retain ${baseline}.`));
      }
    }
    const validationCommands = payload.validation_commands || [];
    const requiredControls = payload.required_controls || [];
    const controlCommands = requiredControls.map(control => control.command);
    const controlIds = requiredControls.map(control => control.control_id);
    issues.push(...validateCapabilityRouting(payload, {
      pathPrefix: "$.capability_routing",
      routeIds: payload.capability_routing && payload.capability_routing.matched_capability_routes,
      documentPaths,
      commands: validationCommands,
      requireRouteEvidence: false,
      capabilityQuery: payload.capability_query,
      missionId: payload.mission_id
    }));
    if (validationCommands.length !== requiredControls.length ||
        validationCommands.some(command => !controlCommands.includes(command))) {
      issues.push(issue("critical", "AGENT_CONTEXT_CONTROL_SET_MISMATCH", "$.required_controls", "Every routed validation command must compile to exactly one mandatory control."));
    }
    if (new Set(controlIds).size !== controlIds.length || new Set(controlCommands).size !== controlCommands.length) {
      issues.push(issue("critical", "AGENT_CONTEXT_DUPLICATE_CONTROL", "$.required_controls", "Mandatory control ids and commands must be unique."));
    }
    for (const [index, control] of requiredControls.entries()) {
      const pointer = `$.required_controls[${index}]`;
      const digest = crypto.createHash("sha256").update(control.command || "").digest("hex");
      if (control.command_sha256 !== digest) {
        issues.push(issue("critical", "AGENT_CONTEXT_CONTROL_DIGEST_MISMATCH", `${pointer}.command_sha256`, "Mandatory control digest must bind the exact command string."));
      }
      if (control.runner === "node" &&
          (!/^[A-Za-z0-9._/-]+\.js$/.test(control.script_path || "") ||
           path.isAbsolute(control.script_path || "") ||
           String(control.script_path || "").split("/").includes(".."))) {
        issues.push(issue("critical", "AGENT_CONTEXT_UNSAFE_CONTROL_SCRIPT", `${pointer}.script_path`, "Node control script must be a safe repository-relative JavaScript path."));
      }
      if (/[;&|`<>\n\r]/.test(control.command || "")) {
        issues.push(issue("critical", "AGENT_CONTEXT_UNSAFE_CONTROL_COMMAND", `${pointer}.command`, "Mandatory controls cannot contain shell operators."));
      }
    }
    const authority = payload.authority || {};
    const allowed = new Set(authority.allowed_actions || []);
    const prohibited = new Set(authority.prohibited_actions || []);
    const overlaps = [...allowed].filter(action => prohibited.has(action));
    if (overlaps.length > 0) {
      issues.push(issue("critical", "AGENT_CONTEXT_AUTHORITY_CONFLICT", "$.authority", `Actions cannot be both allowed and prohibited: ${overlaps.join(", ")}.`));
    }
    const modelAssignment = payload.model_assignment || {};
    const modelRef = modelAssignment.integrated_preflight_ref || {};
    const modelMissing = modelRef.artifact_id === "none" || modelRef.relative_path === "none" || modelRef.sha256 === "none";
    if (modelAssignment.required === true && (modelMissing || [modelAssignment.billet_id, modelAssignment.model_profile_id, modelAssignment.model_family, modelAssignment.model_version, modelAssignment.harness_version].includes("not_required"))) {
      issues.push(issue("critical", "AGENT_CONTEXT_MODEL_BINDING_MISSING", "$.model_assignment", "Required model assignment must bind a ready integrated preflight and immutable dispatch identity."));
    }
    if (modelAssignment.required !== true && (!modelMissing || [modelAssignment.billet_id, modelAssignment.model_profile_id, modelAssignment.model_family, modelAssignment.model_version, modelAssignment.harness_version].some(value => value !== "not_required"))) {
      issues.push(issue("error", "AGENT_CONTEXT_UNUSED_MODEL_BINDING", "$.model_assignment", "A wave without model assignment must use the not_required sentinel consistently."));
    }
  }

  if (type === "control-execution-receipt") {
    const control = payload.control || {};
    const commandDigest = crypto.createHash("sha256").update(control.command || "").digest("hex");
    if (control.command_sha256 !== commandDigest) {
      issues.push(issue("critical", "CONTROL_RECEIPT_COMMAND_DIGEST_MISMATCH", "$.control.command_sha256", "Control receipt must bind the exact command string."));
    }
    const expectedReceiptId = controlExecutionReceiptId({
      reportId: payload.report_id,
      reportInputSha256: payload.report_input_sha256,
      commandSha256: control.command_sha256
    });
    if (payload.id !== expectedReceiptId) {
      issues.push(issue("critical", "CONTROL_RECEIPT_ID_BINDING_MISMATCH", "$.id", "Control receipt ID must derive from the exact report-input and command digests."));
    }
    try {
      if (!canonicalJsonBytes(controlExecutionDescriptor(control.command)).equals(canonicalJsonBytes(control))) {
        issues.push(issue("critical", "CONTROL_RECEIPT_DESCRIPTOR_MISMATCH", "$.control", "Control descriptor must derive exactly from its shell-free command."));
      }
    } catch (error) {
      issues.push(issue("critical", "CONTROL_RECEIPT_DESCRIPTOR_MISMATCH", "$.control", "Control descriptor must derive exactly from one allowlisted shell-free command."));
    }
    if (!isValidDate(payload.started_at) || !isValidDate(payload.finished_at) ||
        Date.parse(payload.finished_at) < Date.parse(payload.started_at)) {
      issues.push(issue("critical", "CONTROL_RECEIPT_INVALID_TIME", "$.finished_at", "Control receipt must finish at or after its start time."));
    }
    const agentIds = (payload.agent_bindings || []).map(item => item.agent_id);
    if (new Set(agentIds).size !== agentIds.length) {
      issues.push(issue("critical", "CONTROL_RECEIPT_DUPLICATE_AGENT", "$.agent_bindings", "Control receipt agent bindings must be unique."));
    }
    const repositoryStatesMatch = payload.repository_state_before_sha256 === payload.repository_state_after_sha256;
    const doctrineStatesMatch = payload.doctrine_state_before_sha256 === payload.doctrine_state_after_sha256;
    if (payload.repository_unchanged !== repositoryStatesMatch || payload.doctrine_unchanged !== doctrineStatesMatch) {
      issues.push(issue("critical", "CONTROL_RECEIPT_STATE_BINDING_MISMATCH", "$.repository_unchanged", "Unchanged flags must equal the bound before/after state digests."));
    }
    const passed = payload.exit_code === 0 && repositoryStatesMatch && doctrineStatesMatch &&
      payload.repository_unchanged === true && payload.doctrine_unchanged === true && !payload.failure_code;
    if ((payload.status === "passed") !== passed) {
      issues.push(issue("critical", "CONTROL_RECEIPT_STATUS_MISMATCH", "$.status", "Passed status requires exit zero, unchanged repository and doctrine state, and no failure code."));
    }
    if (payload.status === "failed" && !payload.failure_code) {
      issues.push(issue("error", "CONTROL_RECEIPT_FAILURE_CODE_MISSING", "$.failure_code", "Failed control receipt must identify its failure class."));
    }
  }

  if (type === "mission-wave-report") {
    if (!isValidDate(payload.recorded_at)) {
      issues.push(issue("critical", "MISSION_WAVE_REPORT_INVALID_TIMESTAMP", "$.recorded_at", "Mission wave report requires a valid timestamp."));
    }
    const results = payload.agent_results || [];
    const agentIds = results.map(result => result.agent_id);
    const controlRefs = payload.control_receipt_refs || [];
    const controlRefKeys = controlRefs.map(ref => `${ref.artifact_id}:${ref.relative_path}:${ref.sha256}`);
    if (new Set(controlRefKeys).size !== controlRefKeys.length) {
      issues.push(issue("error", "MISSION_WAVE_DUPLICATE_CONTROL_RECEIPT", "$.control_receipt_refs", "Control receipt references must be unique."));
    }
    if (new Set(agentIds).size !== agentIds.length) {
      issues.push(issue("critical", "MISSION_WAVE_REPORT_DUPLICATE_AGENT", "$.agent_results", "A mission wave report cannot contain duplicate agent results."));
    }
    for (const [index, result] of results.entries()) {
      const pointer = `$.agent_results[${index}]`;
      if (result.status === "complete" && !hasSubstantiveItems(result.evidence_refs || [])) {
        issues.push(issue("critical", "MISSION_WAVE_REPORT_COMPLETE_WITHOUT_EVIDENCE", `${pointer}.evidence_refs`, "A completed agent result requires manifest-backed evidence."));
      }
      if (result.status === "complete" && hasSubstantiveItems(result.blockers)) {
        issues.push(issue("critical", "MISSION_WAVE_REPORT_COMPLETE_WITH_BLOCKER", `${pointer}.blockers`, "A completed agent result cannot retain blockers."));
      }
      if (["blocked", "failed"].includes(result.status) && !hasSubstantiveItems(result.blockers)) {
        issues.push(issue("error", "MISSION_WAVE_REPORT_BLOCKED_WITHOUT_REASON", `${pointer}.blockers`, "Blocked or failed agent results must state their blockers."));
      }
    }
    const expectedStatus = results.some(result => result.status === "failed")
      ? "failed"
      : results.some(result => result.status === "blocked")
        ? "blocked"
        : "complete";
    if (payload.wave_status !== expectedStatus) {
      issues.push(issue("critical", "MISSION_WAVE_REPORT_STATUS_MISMATCH", "$.wave_status", `Wave status must be ${expectedStatus} for the reported agent results.`));
    }
    if (payload.wave_status === "complete" && hasSubstantiveItems(payload.human_decisions_required)) {
      issues.push(issue("critical", "MISSION_WAVE_REPORT_COMPLETE_PENDING_DECISION", "$.human_decisions_required", "A wave awaiting a human decision cannot be reported complete."));
    }
  }

  if (["campaign-successor-proposal-request", "campaign-successor-proposal", "campaign-successor-activation-request", "campaign-successor-admission"].includes(type)) {
    const proposal = type.startsWith("campaign-successor-proposal");
    const record = ["campaign-successor-proposal", "campaign-successor-admission"].includes(type);
    const request = record ? payload.request || {} : payload;
    const refs = proposal ? [request.terminal_ref] : [request.proposal_ref];
    if (!proposal && (record || artifactRefKind(request.decision_ref) !== "none")) refs.push(request.decision_ref);
    if (!proposal && record) refs.push(payload.successor_campaign_ref, ...(payload.covered_stop_refs || []));
    if (refs.some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue("critical", "CAMPAIGN_SUCCESSOR_REFERENCE_INVALID", "$", "Successor admission requires exact terminal/proposal/candidate/stop references and a real decision; only an activation draft may use a none decision."));
    }
    const digest = value => canonicalControlDigestWithout(value || {}, []);
    if (record && (payload.request_sha256 !== digest(request) || payload.mission_id !== request.mission_id ||
        payload.id !== `${proposal ? "CSP" : "CSA"}-${digest(request).slice(0, 32)}`)) {
      issues.push(issue("critical", "CAMPAIGN_SUCCESSOR_BINDING_INVALID", "$", "Successor records bind the canonical request and exact mission identity."));
    }
    if (proposal) {
      const campaign = request.successor_campaign || {};
      const nested = validatePayload(campaign, "self-improvement-campaign");
      if (!nested.valid || campaign.status !== "active" || campaign.mission_id !== request.mission_id ||
          campaign.repository_binding?.baseline_revision !== request.repository_state?.head_commit) {
        issues.push(issue("critical", "CAMPAIGN_SUCCESSOR_CANDIDATE_INVALID", "$", "The exact active candidate must satisfy campaign semantics and bind the mission and proposed repository baseline."));
      }
      if (record) {
        const end = Date.parse(campaign.created_at) + (campaign.budgets?.max_elapsed_minutes || 0) * 60000;
        const recorded = Date.parse(payload.recorded_at);
        const expires = Date.parse(payload.expires_at);
        if (![end, recorded, expires].every(Number.isFinite) || recorded < Date.parse(campaign.created_at) ||
            expires <= recorded || expires !== Math.min(recorded + 3600000, end)) {
          issues.push(issue("critical", "CAMPAIGN_SUCCESSOR_VALIDITY_INVALID", "$", "Proposal validity cannot renew candidate time or exceed its finite campaign budget and one-hour consent ceremony."));
        }
      }
    }
  }

  if (["campaign-terminal-request", "campaign-terminal-record"].includes(type)) {
    const request = type === "campaign-terminal-record" ? payload.request || {} : payload;
    if ([request.campaign_ref, request.stop_ref].some(ref => artifactRefKind(ref) !== "concrete")) {
      issues.push(issue("critical", "CAMPAIGN_TERMINAL_REFERENCE_INVALID", "$", "Terminal reconciliation requires exact campaign and USER stop references."));
    }
    if (type === "campaign-terminal-record") {
      const digest = value => canonicalControlDigestWithout(value || {}, []);
      const inventory = payload.inventory || {};
      const retained = inventory.retained_artifact_refs || [];
      const waves = inventory.waves || [];
      const expectedId = `CTR-${digest({ request, observed_manifest: payload.observed_manifest }).slice(0, 32)}`;
      if (payload.request_sha256 !== digest(request) || payload.inventory_sha256 !== digest(inventory) || payload.id !== expectedId ||
          payload.mission_id !== request.mission_id || payload.campaign_id !== request.campaign_ref?.artifact_id ||
          !(inventory.stop_refs || []).some(ref => sameJson(ref, request.stop_ref)) ||
          [request.campaign_ref, ...(inventory.stop_refs || []), ...waves.flatMap(wave => [wave.plan_ref, wave.disposition_ref])]
            .some(ref => !retained.some(item => sameJson(ref, item))) ||
          new Set(waves.map(wave => wave.wave_id)).size !== waves.length) {
        issues.push(issue("critical", "CAMPAIGN_TERMINAL_RECORD_BINDING_INVALID", "$", "Terminal records bind the exact request, observed history and complete unique wave/reference inventory."));
      }
    }
  }

  if (["campaign-stop-request", "campaign-stop-record"].includes(type)) {
    const request = type === "campaign-stop-record" ? payload.request || {} : payload;
    if (artifactRefKind(request.campaign_ref) !== "concrete" ||
        artifactRefKind(request.decision_ref) === "malformed" ||
        (type === "campaign-stop-record" && artifactRefKind(request.decision_ref) !== "concrete")) {
      issues.push(issue("critical", "CAMPAIGN_STOP_REFERENCE_INVALID", "$", "Stop requires an exact campaign; only a request draft may omit its USER decision."));
    }
    if (type === "campaign-stop-record") {
      if (payload.request_sha256 !== canonicalControlDigestWithout(request, []) ||
          payload.id !== `CSR-${canonicalControlDigestWithout(request.campaign_ref || {}, []).slice(0, 32)}` ||
          payload.mission_id !== request.mission_id || payload.campaign_id !== request.campaign_ref?.artifact_id) {
        issues.push(issue("critical", "CAMPAIGN_STOP_RECORD_BINDING_INVALID", "$", "A stop must preserve its canonical request and exact campaign/mission identity."));
      }
    }
  }

  if (["mission-wave-termination", "mission-wave-termination-request"].includes(type)) {
    const successor = !isNoneArtifactRef(payload.successor_plan_ref);
    const decision = !isNoneArtifactRef(payload.decision_ref);
    if (successor !== (payload.status === "superseded")) {
      issues.push(issue("critical", "MISSION_TERMINATION_SUCCESSOR_MISMATCH", "$.successor_plan_ref", "Only supersession requires a concrete successor plan reference."));
    }
    if (decision !== (payload.status !== "expired")) {
      issues.push(issue("critical", "MISSION_TERMINATION_DECISION_REQUIRED", "$.decision_ref", "Abort and supersession require an exact USER decision; expiry derives only from plan validity."));
    }
    if (type === "mission-wave-termination") {
      if (!isValidDate(payload.terminated_at) || !isValidDate(payload.plan_valid_until) ||
          (payload.status === "expired" && Date.parse(payload.terminated_at) < Date.parse(payload.plan_valid_until))) {
        issues.push(issue("critical", "MISSION_TERMINATION_INVALID_TIME", "$.terminated_at", "Expiration cannot precede the retained plan expiry."));
      }
      if (!(payload.retained_artifact_refs || []).some(ref => sameJson(ref, payload.plan_ref))) {
        issues.push(issue("critical", "MISSION_TERMINATION_PLAN_NOT_RETAINED", "$.retained_artifact_refs", "Termination must preserve its exact plan reference."));
      }
    }
  }

  if (type === "mission-wave-closeout") {
    if (!isValidDate(payload.closed_at)) {
      issues.push(issue("critical", "MISSION_WAVE_CLOSEOUT_INVALID_TIMESTAMP", "$.closed_at", "Mission wave closeout requires a valid timestamp."));
    }
    const campaignRef = payload.campaign_ref || {};
    const campaignMissing = campaignRef.artifact_id === "none" || campaignRef.relative_path === "none" || campaignRef.sha256 === "none";
    if (campaignMissing && !(campaignRef.artifact_id === "none" && campaignRef.relative_path === "none" && campaignRef.sha256 === "none")) {
      issues.push(issue("critical", "MISSION_WAVE_CLOSEOUT_PARTIAL_CAMPAIGN_REF", "$.campaign_ref", "A missing campaign reference must use none in every field."));
    }
    if (campaignMissing && (payload.improvement_actions || []).some(action => action.disposition === "queued_in_bounded_campaign")) {
      issues.push(issue("critical", "MISSION_WAVE_CLOSEOUT_UNBACKED_IMPROVEMENT", "$.improvement_actions", "An improvement cannot be queued in a bounded campaign without an exact campaign reference."));
    }
    if (payload.status !== "complete" && (!payload.next_wave || payload.next_wave.required !== true)) {
      issues.push(issue("critical", "MISSION_WAVE_CLOSEOUT_BLOCKED_WITHOUT_NEXT_WAVE", "$.next_wave.required", "A blocked closeout must require a follow-on wave."));
    }
    if (payload.status === "blocked_pending_human_decision" && payload.next_wave && payload.next_wave.trigger !== "human_decision") {
      issues.push(issue("critical", "MISSION_WAVE_CLOSEOUT_DECISION_TRIGGER_MISMATCH", "$.next_wave.trigger", "A human-decision block must use the human_decision trigger."));
    }
  }

  if (type === "routing-receipt") {
    if (!isValidDate(payload.created_at)) {
      issues.push(issue("critical", "ROUTING_RECEIPT_INVALID_TIMESTAMP", "$.created_at", "Routing receipt must have a valid timestamp."));
    }
    if (!hasSubstantiveItems((payload.matched_routes || []).map(route => route.id))) {
      issues.push(issue("critical", "ROUTING_RECEIPT_WITHOUT_MATCHED_ROUTES", "$.matched_routes", "Routing receipt must record at least one matched route."));
    }
    if (!hasSubstantiveItems((payload.recommended_documents || []).map(document => document.path))) {
      issues.push(issue("critical", "ROUTING_RECEIPT_WITHOUT_RECOMMENDED_DOCS", "$.recommended_documents", "Routing receipt must record recommended documents."));
    }
    const recommendedPaths = new Set((payload.recommended_documents || []).map(document => document.path));
    issues.push(...validateCapabilityRouting(payload, {
      pathPrefix: "$.capability_routing",
      routeIds: (payload.matched_routes || []).map(route => route.id),
      documentPaths: [...recommendedPaths],
      commands: payload.validation_commands || [],
      capabilityQuery: payload.capability_query,
      missionId: payload.mission_id
    }));
    if (!recommendedPaths.has("docs/source-map.md")) {
      issues.push(issue("error", "ROUTING_RECEIPT_WITHOUT_SOURCE_MAP", "$.recommended_documents", "Routing receipt must keep source-map visible as a baseline document."));
    }
    if (!recommendedPaths.has("README.md")) {
      issues.push(issue("error", "ROUTING_RECEIPT_WITHOUT_README", "$.recommended_documents", "Routing receipt must keep README visible as an orientation document."));
    }
    const inventory = payload.route_inventory || {};
    if (inventory.unrouted_artifact_count !== 0) {
      issues.push(issue("critical", "ROUTING_RECEIPT_UNROUTED_ARTIFACTS", "$.route_inventory.unrouted_artifact_count", "Routing receipt cannot be accepted while corpus artifacts are unrouted."));
    }
    if (!/route_controls_docs\.js/.test(payload.router_command || "")) {
      issues.push(issue("critical", "ROUTING_RECEIPT_NOT_FROM_CONTROLS_ROUTER", "$.router_command", "Routing receipt must be produced by the Controls document router."));
    }
    if (!/--actor(?:=|\s+)ai\b/.test(payload.router_command || "")) {
      issues.push(issue("critical", "ROUTING_RECEIPT_NOT_AI_ACTOR", "$.router_command", "Delegated routing receipt must be produced with --actor=ai."));
    }
    const capabilityArgument = renderedCommandArgument(`--capability-query=${payload.capability_query}`);
    if (!String(payload.router_command || "").includes(capabilityArgument)) {
      issues.push(issue("critical", "ROUTING_RECEIPT_CAPABILITY_QUERY_NOT_REPLAYABLE", "$.router_command", "Routing receipt command must include the exact separate capability query."));
    }
    if (payload.actor !== "ai" || payload.routing_mode !== "delegated_ai_role_department_authority") {
      issues.push(issue("critical", "ROUTING_RECEIPT_NOT_DELEGATED_AI", "$.actor", "Routing receipt for agent preflight must be delegated AI routing."));
    }

    if (payload.wave_scope === "wave") {
      if (payload.agent_role !== "COS") {
        issues.push(issue("critical", "WAVE_ROUTING_NOT_COS", "$.agent_role", "Wave-level routing must be opened by COS."));
      }
      if (payload.department !== "coordination") {
        issues.push(issue("critical", "WAVE_ROUTING_WRONG_DEPARTMENT", "$.department", "Wave-level routing must use coordination department."));
      }
      if (payload.authority_scope !== "tasking") {
        issues.push(issue("critical", "WAVE_ROUTING_WRONG_AUTHORITY", "$.authority_scope", "Wave-level routing must use tasking authority."));
      }
    }

    if (payload.wave_scope === "agent") {
      if (payload.agent_role !== "S3") {
        issues.push(issue("critical", "AGENT_ROUTING_NOT_S3", "$.agent_role", "Agent work receipt must route through S3 execution role."));
      }
      if (payload.department !== "operations") {
        issues.push(issue("critical", "AGENT_ROUTING_WRONG_DEPARTMENT", "$.department", "Agent work receipt must use operations department."));
      }
      if (payload.authority_scope !== "scoped-execution") {
        issues.push(issue("critical", "AGENT_ROUTING_WRONG_AUTHORITY", "$.authority_scope", "Agent work receipt must use scoped-execution authority."));
      }
    }
  }

  if (type === "maintenance-readiness") {
    if (!payload.assets || isEmptyArray(payload.assets)) {
      issues.push(issue("critical", "NO_MAINTENANCE_ASSETS", "$.assets", "Maintenance readiness report must include critical assets."));
    }
    const unavailable = (payload.assets || []).filter(asset => asset.readiness === "Unavailable");
    const degraded = (payload.assets || []).filter(asset => asset.readiness === "Poorly" || asset.readiness === "Unknown");
    if (payload.overall_readiness === "Fully" && (unavailable.length > 0 || degraded.length > 0)) {
      issues.push(issue("critical", "OVERALL_FULLY_WITH_BAD_ASSETS", "$.overall_readiness", "Overall readiness cannot be Fully when any asset is degraded or unavailable."));
    }
    for (const [index, asset] of (payload.assets || []).entries()) {
      const pointer = `$.assets[${index}]`;
      if (asset.last_result === "fail" && (!asset.fallback || asset.fallback.length < 1)) {
        issues.push(issue("critical", "FAILED_ASSET_WITHOUT_FALLBACK", `${pointer}.fallback`, "Failed asset must have a fallback."));
      }
      if (asset.readiness === "Unavailable" && (!asset.ccir_trigger || asset.ccir_trigger.length < 1)) {
        issues.push(issue("critical", "UNAVAILABLE_WITHOUT_CCIR", `${pointer}.ccir_trigger`, "Unavailable critical asset must define a CCIR trigger."));
      }
    }
    if ((unavailable.length > 0 || degraded.length > 0) && payload.summary && payload.summary.commander_decision_required !== true) {
      issues.push(issue("warning", "BAD_ASSETS_WITHOUT_COMMANDER_DECISION_FLAG", "$.summary.commander_decision_required", "Bad assets should be reviewed for commander decision or FRAGO need."));
    }
  }

  if (type === "backbrief") {
    if (!hasSubstantiveItems(payload.planned_actions)) {
      issues.push(issue("critical", "BACKBRIEF_WITHOUT_ACTIONS", "$.planned_actions", "Backbrief must state planned actions before execution."));
    }
    if (!hasSubstantiveItems(payload.stop_conditions)) {
      issues.push(issue("critical", "BACKBRIEF_WITHOUT_STOP_CONDITIONS", "$.stop_conditions", "Backbrief must state stop conditions to prevent distorted execution."));
    }
    if (!hasSubstantiveItems(payload.risk_controls)) {
      issues.push(issue("error", "BACKBRIEF_WITHOUT_RISK_CONTROLS", "$.risk_controls", "Backbrief should state risk controls."));
    }
    const approval = payload.approval_awareness || {};
    if (!hasSubstantiveItems(approval.approval_required_actions)) {
      issues.push(issue("warning", "BACKBRIEF_WITHOUT_APPROVAL_BOUNDARIES", "$.approval_awareness.approval_required_actions", "Backbrief should restate actions that require approval."));
    }
    if (!hasSubstantiveItems(approval.prohibited_actions)) {
      issues.push(issue("warning", "BACKBRIEF_WITHOUT_PROHIBITIONS", "$.approval_awareness.prohibited_actions", "Backbrief should restate prohibited actions."));
    }
    if (payload.confidence === "low" && !hasSubstantiveItems(payload.requested_clarifications)) {
      issues.push(issue("error", "LOW_CONFIDENCE_WITHOUT_CLARIFICATION", "$.requested_clarifications", "Low-confidence backbrief must request clarification."));
    }
    if (approval.commander_decision_needed === true && !hasSubstantiveItems(payload.requested_clarifications)) {
      issues.push(issue("error", "DECISION_NEEDED_WITHOUT_QUESTION", "$.requested_clarifications", "Backbrief that needs commander decision must state the question."));
    }
  }

  if (type === "rehearsal") {
    if (!hasSubstantiveItems(payload.backbriefs)) {
      issues.push(issue("critical", "REHEARSAL_WITHOUT_BACKBRIEF", "$.backbriefs", "Rehearsal must reference at least one backbrief."));
    }
    if (!payload.sequence || isEmptyArray(payload.sequence)) {
      issues.push(issue("critical", "REHEARSAL_WITHOUT_SEQUENCE", "$.sequence", "Rehearsal must walk the execution sequence before approval."));
    }
    if (payload.disposition === "execute" && hasSubstantiveItems(payload.required_changes)) {
      issues.push(issue("critical", "EXECUTE_WITH_UNRESOLVED_CHANGES", "$.required_changes", "Rehearsal cannot clear execution while required changes remain."));
    }
    const highFriction = (payload.friction_points || []).some(point => point.severity === "high" || point.severity === "critical");
    if (highFriction && !hasSubstantiveItems(payload.decision_points)) {
      issues.push(issue("critical", "HIGH_FRICTION_WITHOUT_DECISION_POINT", "$.decision_points", "High-friction rehearsal requires a decision point or commander question."));
    }
    if (payload.disposition === "request_approval" && !hasSubstantiveItems(payload.decision_points)) {
      issues.push(issue("error", "APPROVAL_REHEARSAL_WITHOUT_DECISION_POINT", "$.decision_points", "Approval disposition must state the decision point."));
    }
  }

  if (type === "approval-scope") {
    const approvingDecision = payload.decision === "approve_once" || payload.decision === "approve_with_constraints";
    const terminalStatusForNonApproval = {
      reject: "rejected",
      revise: "revision_required",
      issue_frago: "frago_required",
      revoke: "revoked"
    };
    const scope = payload.scope || {};

    if (approvingDecision) {
      if (!isValidDate(scope.expires_at)) {
        issues.push(issue("critical", "APPROVAL_WITHOUT_EXPIRY", "$.scope.expires_at", "Approval scope must have a valid expiry."));
      }
      if (isValidDate(scope.valid_from) && isValidDate(scope.expires_at) && !isBefore(scope.valid_from, scope.expires_at)) {
        issues.push(issue("critical", "APPROVAL_EXPIRY_NOT_AFTER_START", "$.scope.expires_at", "Approval expiry must be after valid_from."));
      }
      if (payload.decision === "approve_once" && scope.max_executions !== 1) {
        issues.push(issue("critical", "APPROVE_ONCE_NOT_SINGLE_USE", "$.scope.max_executions", "approve_once must allow exactly one execution."));
      }
      if (!hasSubstantiveItems(payload.conditions)) {
        issues.push(issue("warning", "APPROVAL_WITHOUT_CONDITIONS", "$.conditions", "Approval should state execution conditions."));
      }
      if (!hasSubstantiveItems(payload.rollback)) {
        issues.push(issue("critical", "APPROVAL_WITHOUT_ROLLBACK", "$.rollback", "Approval for high-risk action must include rollback or compensation plan."));
      }
      if (!hasSubstantiveItems(payload.evidence_required)) {
        issues.push(issue("error", "APPROVAL_WITHOUT_EVIDENCE", "$.evidence_required", "Approval must state post-action evidence requirements."));
      }
    }

    if (payload.status === "consumed" && (!payload.consumed_by || !payload.consumed_at)) {
      issues.push(issue("critical", "CONSUMED_APPROVAL_WITHOUT_CONSUMPTION_EVENT", "$.consumed_at", "Consumed approval must record consumed_by and consumed_at."));
    }
    if (payload.status === "active" && (payload.consumed_by || payload.consumed_at)) {
      issues.push(issue("error", "ACTIVE_APPROVAL_HAS_CONSUMPTION_EVENT", "$.status", "Active approval must not already have consumption metadata."));
    }
    if (!approvingDecision && payload.status !== terminalStatusForNonApproval[payload.decision]) {
      issues.push(issue("error", "NON_APPROVAL_STATUS_MISMATCH", "$.status", "Non-approval decision must use the matching terminal status."));
    }
    if (/credential|secret|password|private[_-]?key|restricted|external/i.test(`${scope.action || ""} ${scope.target || ""}`) && payload.release_review_required !== true) {
      issues.push(issue("warning", "SENSITIVE_APPROVAL_WITHOUT_RELEASE_REVIEW_FLAG", "$.release_review_required", "Sensitive or external approval should flag whether release review is required."));
    }
  }

  if (type === "approval-consumption-event") {
    const snapshot = payload.scope_snapshot || {};
    if (snapshot.status_before !== "active") {
      issues.push(issue("critical", "APPROVAL_ALREADY_CONSUMED_OR_INACTIVE", "$.scope_snapshot.status_before", "Approval must be active before it can be consumed."));
    }
    if (payload.actor !== snapshot.granted_to) {
      issues.push(issue("critical", "APPROVAL_CONSUMED_BY_WRONG_ACTOR", "$.actor", "Consumption actor must match granted_to."));
    }
    if (payload.action !== snapshot.action) {
      issues.push(issue("critical", "APPROVAL_CONSUMPTION_ACTION_MISMATCH", "$.action", "Consumption action must match approval scope."));
    }
    if (payload.tool !== snapshot.tool) {
      issues.push(issue("critical", "APPROVAL_CONSUMPTION_TOOL_MISMATCH", "$.tool", "Consumption tool must match approval scope."));
    }
    if (payload.target !== snapshot.target) {
      issues.push(issue("critical", "APPROVAL_CONSUMPTION_TARGET_MISMATCH", "$.target", "Consumption target must match approval scope."));
    }
    if (!isValidDate(payload.consumed_at) || !isValidDate(snapshot.valid_from) || !isValidDate(snapshot.expires_at) || Date.parse(payload.consumed_at) < Date.parse(snapshot.valid_from) || Date.parse(payload.consumed_at) >= Date.parse(snapshot.expires_at)) {
      issues.push(issue("critical", "APPROVAL_CONSUMED_OUTSIDE_WINDOW", "$.consumed_at", "Approval consumption must occur inside the valid approval window."));
    }
    if (snapshot.decision === "approve_once" && payload.execution_count_after !== 1) {
      issues.push(issue("critical", "APPROVE_ONCE_CONSUMPTION_COUNT_INVALID", "$.execution_count_after", "approve_once consumption must leave execution_count_after at exactly 1."));
    }
    if (payload.result === "executed" && payload.approval_status_after !== "consumed") {
      issues.push(issue("critical", "EXECUTED_APPROVAL_NOT_MARKED_CONSUMED", "$.approval_status_after", "Executed approval must be marked consumed after execution."));
    }
    if (payload.result === "executed" && !hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "APPROVAL_CONSUMPTION_WITHOUT_EVIDENCE", "$.evidence", "Executed approval consumption must include evidence."));
    }
  }

  if (type === "approval-revocation-event") {
    const snapshot = payload.scope_snapshot || {};

    if (payload.approval_status_before !== "active" || snapshot.status_before !== "active") {
      issues.push(issue("critical", "APPROVAL_REVOCATION_NOT_ACTIVE", "$.approval_status_before", "Approval must be active before it can be revoked."));
    }
    if (payload.revocation_authority !== "COMMANDER") {
      issues.push(issue("critical", "APPROVAL_REVOCATION_REQUIRES_COMMANDER", "$.revocation_authority", "Approval revocation requires Commander authority."));
    }
    if (snapshot.granted_by && payload.revocation_authority !== snapshot.granted_by) {
      issues.push(issue("critical", "APPROVAL_REVOCATION_AUTHORITY_MISMATCH", "$.revocation_authority", "Revocation authority must match the granting authority."));
    }
    if (payload.action !== snapshot.action) {
      issues.push(issue("critical", "APPROVAL_REVOCATION_ACTION_MISMATCH", "$.action", "Revocation action must match approval scope."));
    }
    if (payload.tool !== snapshot.tool) {
      issues.push(issue("critical", "APPROVAL_REVOCATION_TOOL_MISMATCH", "$.tool", "Revocation tool must match approval scope."));
    }
    if (payload.target !== snapshot.target) {
      issues.push(issue("critical", "APPROVAL_REVOCATION_TARGET_MISMATCH", "$.target", "Revocation target must match approval scope."));
    }
    if (!isValidDate(payload.revoked_at) || !isValidDate(snapshot.valid_from) || !isValidDate(snapshot.expires_at) || Date.parse(payload.revoked_at) < Date.parse(snapshot.valid_from) || Date.parse(payload.revoked_at) >= Date.parse(snapshot.expires_at)) {
      issues.push(issue("critical", "APPROVAL_REVOKED_OUTSIDE_WINDOW", "$.revoked_at", "Approval revocation must occur inside the valid approval window."));
    }
    if (payload.approval_status_after !== "revoked") {
      issues.push(issue("critical", "APPROVAL_REVOCATION_NOT_MARKED_REVOKED", "$.approval_status_after", "Revocation event must mark the approval as revoked."));
    }
    if (!payload.reason || payload.reason.trim().length === 0) {
      issues.push(issue("error", "APPROVAL_REVOCATION_WITHOUT_REASON", "$.reason", "Approval revocation must state a reason."));
    }
    if (!hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "APPROVAL_REVOCATION_WITHOUT_EVIDENCE", "$.evidence", "Approval revocation must include evidence."));
    }
    if (payload.notification_required === true && !hasSubstantiveItems(payload.notified_roles)) {
      issues.push(issue("error", "APPROVAL_REVOCATION_WITHOUT_NOTIFICATION", "$.notified_roles", "Approval revocation requiring notification must list notified roles."));
    }
  }

  if (type === "approval-renewal-event") {
    const snapshot = payload.scope_snapshot || {};

    if (payload.approval_status_before !== "active" || snapshot.status_before !== "active") {
      issues.push(issue("critical", "APPROVAL_RENEWAL_NOT_ACTIVE", "$.approval_status_before", "Approval must be active before it can be renewed."));
    }
    if (payload.renewal_authority !== "COMMANDER") {
      issues.push(issue("critical", "APPROVAL_RENEWAL_REQUIRES_COMMANDER", "$.renewal_authority", "Approval renewal requires Commander authority."));
    }
    if (snapshot.granted_by && payload.renewal_authority !== snapshot.granted_by) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_AUTHORITY_MISMATCH", "$.renewal_authority", "Renewal authority must match the granting authority."));
    }
    if (payload.action !== snapshot.action) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_ACTION_MISMATCH", "$.action", "Renewal action must match approval scope."));
    }
    if (payload.tool !== snapshot.tool) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_TOOL_MISMATCH", "$.tool", "Renewal tool must match approval scope."));
    }
    if (payload.target !== snapshot.target) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_TARGET_MISMATCH", "$.target", "Renewal target must match approval scope."));
    }
    if (!isValidDate(payload.renewed_at) || !isValidDate(payload.previous_valid_from) || !isValidDate(payload.previous_expires_at) || Date.parse(payload.renewed_at) < Date.parse(payload.previous_valid_from) || Date.parse(payload.renewed_at) >= Date.parse(payload.previous_expires_at)) {
      issues.push(issue("critical", "APPROVAL_RENEWED_OUTSIDE_WINDOW", "$.renewed_at", "Approval renewal must occur inside the current approval window."));
    }
    if (payload.previous_valid_from !== snapshot.valid_from || payload.previous_expires_at !== snapshot.expires_at) {
      issues.push(issue("error", "APPROVAL_RENEWAL_WINDOW_SNAPSHOT_MISMATCH", "$.previous_expires_at", "Renewal must snapshot the current approval window."));
    }
    if (!isValidDate(payload.new_expires_at) || !isValidDate(payload.previous_expires_at) || Date.parse(payload.new_expires_at) <= Date.parse(payload.previous_expires_at)) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_NOT_EXTENSION", "$.new_expires_at", "Renewal must extend expires_at beyond the previous expiry."));
    }
    if (!isValidDate(payload.new_expires_at) || !isValidDate(payload.renewed_at) || Date.parse(payload.new_expires_at) <= Date.parse(payload.renewed_at)) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_EXPIRES_BEFORE_RENEWED_AT", "$.new_expires_at", "Renewed expiry must be after renewed_at."));
    }
    if (payload.max_executions_before !== snapshot.max_executions || payload.max_executions_after !== snapshot.max_executions) {
      issues.push(issue("critical", "APPROVAL_RENEWAL_EXPANDS_EXECUTIONS", "$.max_executions_after", "Renewal must not change max executions; request a new approval instead."));
    }
    if (snapshot.decision === "approve_once" && payload.execution_count_before !== 0) {
      issues.push(issue("critical", "APPROVE_ONCE_ALREADY_USED_BEFORE_RENEWAL", "$.execution_count_before", "approve_once renewal must occur before the approval is used."));
    }
    if (payload.approval_status_after !== "active") {
      issues.push(issue("critical", "APPROVAL_RENEWAL_NOT_MARKED_ACTIVE", "$.approval_status_after", "Renewal event must leave the approval active."));
    }
    if (!payload.reason || payload.reason.trim().length === 0) {
      issues.push(issue("error", "APPROVAL_RENEWAL_WITHOUT_REASON", "$.reason", "Approval renewal must state a reason."));
    }
    if (!hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "APPROVAL_RENEWAL_WITHOUT_EVIDENCE", "$.evidence", "Approval renewal must include evidence."));
    }
    if (payload.notification_required === true && !hasSubstantiveItems(payload.notified_roles)) {
      issues.push(issue("error", "APPROVAL_RENEWAL_WITHOUT_NOTIFICATION", "$.notified_roles", "Approval renewal requiring notification must list notified roles."));
    }
  }

  if (type === "approval-delegation-event") {
    const scope = payload.delegation_scope || {};

    if (payload.delegator !== "COMMANDER") {
      issues.push(issue("critical", "DELEGATION_REQUIRES_COMMANDER", "$.delegator", "Approval delegation requires Commander authority."));
    }
    if (payload.actor !== payload.delegator) {
      issues.push(issue("critical", "DELEGATION_ACTOR_NOT_DELEGATOR", "$.actor", "Delegation actor must be the delegator."));
    }
    if (payload.delegatee === payload.delegator) {
      issues.push(issue("error", "DELEGATION_SELF_DELEGATION", "$.delegatee", "Delegator and delegatee must be different roles."));
    }
    if ((payload.approving_for_roles || []).includes(payload.delegatee)) {
      issues.push(issue("critical", "DELEGATEE_CANNOT_APPROVE_SELF_ROLE", "$.approving_for_roles", "Delegatee cannot approve its own role through this delegation."));
    }
    if (scope.max_roe_class === "Red" || scope.max_roe_class === "Black") {
      issues.push(issue("critical", "DELEGATION_CANNOT_INCLUDE_COMMANDER_RETAINED_ROE", "$.delegation_scope.max_roe_class", "Delegation cannot include Red or Black approvals."));
    }
    if (RISK_RANK[scope.max_residual_risk] >= RISK_RANK.high) {
      issues.push(issue("critical", "DELEGATION_CANNOT_ACCEPT_HIGH_RISK", "$.delegation_scope.max_residual_risk", "High or critical residual risk remains Commander-retained."));
    }
    if (isEmptyArray(scope.task_scope)) {
      issues.push(issue("error", "DELEGATION_WITHOUT_TASK_SCOPE", "$.delegation_scope.task_scope", "Delegation must state task scope."));
    }
    if (!isValidDate(scope.valid_from) || !isValidDate(scope.expires_at) || !isBefore(scope.valid_from, scope.expires_at)) {
      issues.push(issue("critical", "DELEGATION_EXPIRY_NOT_AFTER_START", "$.delegation_scope.expires_at", "Delegation expiry must be after valid_from."));
    }
    if (!Number.isInteger(scope.max_approval_duration_minutes) || scope.max_approval_duration_minutes <= 0 || !Number.isInteger(scope.max_approvals) || scope.max_approvals <= 0) {
      issues.push(issue("critical", "DELEGATION_WITHOUT_LIMITS", "$.delegation_scope", "Delegation must include positive duration and approval-count limits."));
    }
    if (payload.subdelegation_allowed === true) {
      issues.push(issue("critical", "DELEGATION_ALLOWS_SUBDELEGATION", "$.subdelegation_allowed", "Delegated approval authority cannot be subdelegated."));
    }
    if (!hasSubstantiveItems(scope.retained_authorities)) {
      issues.push(issue("critical", "DELEGATION_WITHOUT_RETAINED_AUTHORITIES", "$.delegation_scope.retained_authorities", "Delegation must state Commander-retained authorities."));
    }
    if (!(scope.prohibited_context_classes || []).includes("restricted")) {
      issues.push(issue("error", "DELEGATION_WITHOUT_RESTRICTED_CONTEXT_GUARD", "$.delegation_scope.prohibited_context_classes", "Delegation must prohibit restricted context release."));
    }
    if (payload.release_review_required_for_sensitive !== true) {
      issues.push(issue("error", "DELEGATION_SENSITIVE_RELEASE_WITHOUT_REVIEW", "$.release_review_required_for_sensitive", "Delegation must preserve release review for sensitive context."));
    }
    if (payload.requires_backbrief !== true) {
      issues.push(issue("warning", "DELEGATION_WITHOUT_BACKBRIEF", "$.requires_backbrief", "Delegated approval should require a backbrief."));
    }
    if (payload.requires_post_action_evidence !== true) {
      issues.push(issue("error", "DELEGATION_WITHOUT_POST_ACTION_EVIDENCE", "$.requires_post_action_evidence", "Delegated approval must require post-action evidence."));
    }
    if (payload.delegation_status_after !== "active") {
      issues.push(issue("critical", "DELEGATION_NOT_MARKED_ACTIVE", "$.delegation_status_after", "Delegation creation must leave the delegation active."));
    }
    if (payload.notification_required === true && !hasSubstantiveItems(payload.notified_roles)) {
      issues.push(issue("error", "DELEGATION_WITHOUT_NOTIFICATION", "$.notified_roles", "Delegation requiring notification must list notified roles."));
    }
    if (!payload.reason || payload.reason.trim().length === 0) {
      issues.push(issue("error", "DELEGATION_WITHOUT_REASON", "$.reason", "Delegation must state the reason."));
    }
    if (!hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "DELEGATION_WITHOUT_EVIDENCE", "$.evidence", "Delegation must include evidence."));
    }
  }

  if (type === "approval-delegation-revocation-event") {
    const snapshot = payload.delegation_snapshot || {};

    if (payload.delegation_status_before !== "active") {
      issues.push(issue("critical", "DELEGATION_TERMINATION_NOT_ACTIVE", "$.delegation_status_before", "Delegation must be active before termination."));
    }
    if (payload.delegation_status_after !== payload.termination_kind) {
      issues.push(issue("critical", "DELEGATION_TERMINATION_STATUS_MISMATCH", "$.delegation_status_after", "Delegation status after termination must match termination kind."));
    }
    if (payload.termination_authority !== snapshot.delegator) {
      issues.push(issue("critical", "DELEGATION_TERMINATION_AUTHORITY_MISMATCH", "$.termination_authority", "Termination authority must match the delegator."));
    }
    if (payload.delegatee !== snapshot.delegatee) {
      issues.push(issue("critical", "DELEGATION_TERMINATION_DELEGATEE_MISMATCH", "$.delegatee", "Termination delegatee must match the delegation snapshot."));
    }
    if (payload.termination_kind === "revoked" && payload.termination_authority !== "COMMANDER") {
      issues.push(issue("critical", "DELEGATION_REVOCATION_REQUIRES_COMMANDER", "$.termination_authority", "Delegation revocation requires Commander authority."));
    }
    if (payload.termination_kind === "revoked" && payload.actor !== payload.termination_authority) {
      issues.push(issue("critical", "DELEGATION_REVOCATION_ACTOR_MISMATCH", "$.actor", "Revocation actor must be the termination authority."));
    }
    if (payload.termination_kind === "expired" && !(payload.actor === "RECORDER" || payload.actor === payload.termination_authority)) {
      issues.push(issue("error", "DELEGATION_EXPIRY_ACTOR_INVALID", "$.actor", "Expiry projection must be recorded by RECORDER or the termination authority."));
    }
    if (payload.termination_kind === "revoked" && (!isValidDate(payload.terminated_at) || !isValidDate(snapshot.valid_from) || !isValidDate(snapshot.expires_at) || Date.parse(payload.terminated_at) < Date.parse(snapshot.valid_from) || Date.parse(payload.terminated_at) >= Date.parse(snapshot.expires_at))) {
      issues.push(issue("critical", "DELEGATION_REVOKED_OUTSIDE_WINDOW", "$.terminated_at", "Delegation revocation must occur inside the active delegation window."));
    }
    if (payload.termination_kind === "expired" && (!isValidDate(payload.terminated_at) || !isValidDate(snapshot.expires_at) || Date.parse(payload.terminated_at) < Date.parse(snapshot.expires_at))) {
      issues.push(issue("critical", "DELEGATION_EXPIRY_BEFORE_EXPIRY", "$.terminated_at", "Delegation expiry projection must occur at or after expiry."));
    }
    if (snapshot.subdelegation_allowed === true) {
      issues.push(issue("warning", "TERMINATED_DELEGATION_HAD_SUBDELEGATION", "$.delegation_snapshot.subdelegation_allowed", "Terminated delegation snapshot shows subdelegation was allowed."));
    }
    if (snapshot.release_review_required_for_sensitive !== true) {
      issues.push(issue("warning", "TERMINATED_DELEGATION_WITHOUT_RELEASE_REVIEW", "$.delegation_snapshot.release_review_required_for_sensitive", "Terminated delegation snapshot did not preserve sensitive release review."));
    }
    if (!payload.reason || payload.reason.trim().length === 0) {
      issues.push(issue("error", "DELEGATION_TERMINATION_WITHOUT_REASON", "$.reason", "Delegation termination must state a reason."));
    }
    if (!hasSubstantiveItems(payload.evidence)) {
      issues.push(issue("error", "DELEGATION_TERMINATION_WITHOUT_EVIDENCE", "$.evidence", "Delegation termination must include evidence."));
    }
    if (payload.notification_required === true && !hasSubstantiveItems(payload.notified_roles)) {
      issues.push(issue("error", "DELEGATION_TERMINATION_WITHOUT_NOTIFICATION", "$.notified_roles", "Delegation termination requiring notification must list notified roles."));
    }
  }

  if (type === "risk-acceptance") {
    const commanderRetained = payload.residual_risk === "high" || payload.residual_risk === "critical" || payload.reversibility === "irreversible";
    const accepting = payload.decision === "accept";
    const duration = payload.duration || {};

    if (accepting && commanderRetained && payload.accepted_by !== "COMMANDER") {
      issues.push(issue("critical", "RISK_ACCEPTANCE_REQUIRES_COMMANDER", "$.accepted_by", "High, critical, or irreversible residual risk requires Commander acceptance."));
    }
    if (accepting && !isValidDate(duration.expires_at)) {
      issues.push(issue("critical", "RISK_ACCEPTANCE_WITHOUT_EXPIRY", "$.duration.expires_at", "Risk acceptance must have a valid expiry."));
    }
    if (isValidDate(duration.valid_from) && isValidDate(duration.expires_at) && !isBefore(duration.valid_from, duration.expires_at)) {
      issues.push(issue("critical", "RISK_ACCEPTANCE_EXPIRY_NOT_AFTER_START", "$.duration.expires_at", "Risk acceptance expiry must be after valid_from."));
    }
    if (accepting && !hasSubstantiveItems(payload.controls)) {
      issues.push(issue("critical", "RISK_ACCEPTANCE_WITHOUT_CONTROLS", "$.controls", "Risk cannot be accepted without controls."));
    }
    if (accepting && !hasSubstantiveItems(payload.supervision_plan)) {
      issues.push(issue("error", "RISK_ACCEPTANCE_WITHOUT_SUPERVISION", "$.supervision_plan", "Risk acceptance must state supervision plan."));
    }
    if (accepting && !hasSubstantiveItems(payload.evidence_required)) {
      issues.push(issue("error", "RISK_ACCEPTANCE_WITHOUT_EVIDENCE", "$.evidence_required", "Risk acceptance must state evidence requirements."));
    }
    if (accepting && !hasSubstantiveItems(payload.aar_trigger)) {
      issues.push(issue("warning", "RISK_ACCEPTANCE_WITHOUT_AAR_TRIGGER", "$.aar_trigger", "Risk acceptance should state AAR triggers."));
    }
    if (!accepting && payload.status === "active") {
      issues.push(issue("error", "NON_ACCEPTED_RISK_ACTIVE", "$.status", "Rejected or revise risk decision cannot be active."));
    }
  }

  if (type === "evidence") {
    if (payload.claim && payload.interpretation && payload.claim === payload.interpretation) {
      issues.push(issue("warning", "SOURCE_INTERPRETATION_MERGED", "$.interpretation", "Claim and interpretation should be separated."));
    }
  }

  if (type === "aar") {
    if (isEmptyArray(payload.sop_updates)) {
      issues.push(issue("warning", "NO_SOP_UPDATE", "$.sop_updates", "AAR should state whether SOP updates are needed."));
    }
  }

  if (type === "aar-readiness-update") {
    if (!hasSubstantiveItems((payload.readiness_recommendations || []).map(item => item.rationale))) {
      issues.push(issue("critical", "AAR_UPDATE_WITHOUT_RECOMMENDATION", "$.readiness_recommendations", "AAR readiness update must contain at least one readiness recommendation."));
    }
    const downgrade = (payload.readiness_recommendations || []).some(item => item.readiness_action === "downgrade_or_hold");
    if (downgrade && payload.commander_decision_required !== true) {
      issues.push(issue("critical", "DOWNGRADE_WITHOUT_COMMANDER_REVIEW", "$.commander_decision_required", "Downgrade or hold recommendations require commander review."));
    }
    if (payload.commander_decision_required === true && !hasSubstantiveItems(payload.ccir_triggers)) {
      issues.push(issue("error", "COMMANDER_REVIEW_WITHOUT_CCIR", "$.ccir_triggers", "Commander review must include CCIR trigger text."));
    }
    if (!hasSubstantiveItems([...(payload.sop_updates || []), ...(payload.maintenance_actions || []).map(item => item.description)])) {
      issues.push(issue("warning", "AAR_UPDATE_WITHOUT_ACTION", "$.maintenance_actions", "AAR readiness update should create at least one SOP or maintenance action."));
    }
  }

  if (type === "self-improvement-campaign") {
    const commandTeam = payload.command_team || {};
    const authority = payload.authority_envelope || {};
    const quality = payload.quality_model || {};
    const dimensions = quality.dimensions || [];
    const checkpoints = (payload.checkpoint_policy && payload.checkpoint_policy.required_triggers) || [];
    const verification = payload.verification_policy || {};
    if (payload.final_decision_authority !== "USER") {
      issues.push(issue("critical", "SELF_IMPROVEMENT_HUMAN_AUTHORITY_MISSING", "$.final_decision_authority", "Bounded self-improvement must preserve the human user as final decision authority."));
    }
    if (commandTeam.improvement_controller === commandTeam.independent_evaluator) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_EVALUATOR_NOT_INDEPENDENT", "$.command_team", "The improvement controller cannot independently approve its own control-plane changes."));
    }
    if (!hasSubstantiveItems(payload.protected_invariants)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_WITHOUT_INVARIANTS", "$.protected_invariants", "A self-improvement campaign must state protected invariants."));
    }
    if (!hasSubstantiveItems(payload.stop_conditions)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_WITHOUT_STOP_CONDITIONS", "$.stop_conditions", "A self-improvement campaign must state stop conditions."));
    }
    if (!hasSubstantiveItems(payload.objective && payload.objective.acceptance_criteria)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_WITHOUT_ACCEPTANCE_CRITERIA", "$.objective.acceptance_criteria", "A self-improvement campaign requires observable acceptance criteria."));
    }
    if (!["local_reversible", "bounded_structural"].includes(authority.max_change_class)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_ENVELOPE_TOO_BROAD", "$.authority_envelope.max_change_class", "Autonomous change authority cannot include authority changes, release, or destructive action."));
    }
    for (const field of ["push_requires_human", "merge_requires_human", "release_requires_human", "authority_change_requires_human", "policy_change_requires_human", "destructive_action_prohibited", "self_approval_prohibited"]) {
      if (authority[field] !== true) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_RETAINED_AUTHORITY_MISSING", `$.authority_envelope.${field}`, `${field} must remain human-retained or prohibited.`));
      }
    }
    const dimensionIds = dimensions.map(item => item.id);
    if (new Set(dimensionIds).size !== dimensionIds.length) {
      issues.push(issue("error", "SELF_IMPROVEMENT_DUPLICATE_QUALITY_DIMENSION", "$.quality_model.dimensions", "Quality dimension IDs must be unique."));
    }
    const weightSum = dimensions.reduce((sum, item) => sum + Number(item.weight || 0), 0);
    if (Math.abs(weightSum - 1) > 0.000001) {
      issues.push(issue("error", "SELF_IMPROVEMENT_QUALITY_WEIGHTS_INVALID", "$.quality_model.dimensions", "Quality dimension weights must sum to 1."));
    }
    for (const [index, dimension] of dimensions.entries()) {
      if (dimension.target < 0 || dimension.target > 1) {
        issues.push(issue("error", "SELF_IMPROVEMENT_TARGET_NOT_NORMALIZED", `$.quality_model.dimensions[${index}].target`, "Quality targets must use the normalized 0..1 scale."));
      }
      if (!hasSubstantiveItems(dimension.evidence_required)) {
        issues.push(issue("error", "SELF_IMPROVEMENT_DIMENSION_WITHOUT_EVIDENCE", `$.quality_model.dimensions[${index}].evidence_required`, "Every quality dimension requires external evidence."));
      }
    }
    for (const required of ["before_completion", "scope_change", "validation_failure"]) {
      if (!checkpoints.includes(required)) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_CHECKPOINT_TRIGGER_MISSING", "$.checkpoint_policy.required_triggers", `Checkpoint trigger ${required} is mandatory.`));
      }
    }
    if (verification.proof_required !== true || verification.repository_state_must_remain_unchanged !== true || verification.receipt_persistence_required !== true) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_PROOF_POLICY_MISSING", "$.verification_policy", "Adaptive work requires persisted verification receipts and an unchanged repository state during checks."));
    }
    if ((verification.allowed_executables || []).some(item => ["sh", "bash", "zsh", "fish", "cmd", "powershell", "pwsh", "sudo", "env"].includes(String(item).toLowerCase()))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_SHELL_VERIFIER_ALLOWED", "$.verification_policy.allowed_executables", "Campaign verification cannot authorize shells or privilege wrappers."));
    }
    const comparative = payload.comparative_evaluation_policy;
    if (comparative) {
      const requiredTargets = comparative.required_target_types || [];
      if (requiredTargets.length !== 2 || !requiredTargets.includes("runtime_control") || !requiredTargets.includes("skill")) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_TARGETS_WEAK", "$.comparative_evaluation_policy.required_target_types", "Comparative evaluation must cover both runtime-control and skill candidates."));
      }
      if (comparative.same_evaluation_set_required !== true || comparative.identical_harness_required !== true || comparative.independent_evaluator_required !== true) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_POLICY_WEAK", "$.comparative_evaluation_policy", "Comparative evaluation requires one immutable evaluation set, one identical harness, and an independent evaluator."));
      }
      const thresholdIds = (comparative.dimension_thresholds || []).map(item => item.dimension_id);
      if (new Set(thresholdIds).size !== thresholdIds.length || thresholdIds.length !== dimensionIds.length || dimensionIds.some(id => !thresholdIds.includes(id))) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_THRESHOLDS_INCOMPLETE", "$.comparative_evaluation_policy.dimension_thresholds", "Every quality dimension requires exactly one maximum-regression threshold."));
      }
    }
    if (payload.schema_version === "0.4" && !comparative) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_V04_COMPARATIVE_POLICY_MISSING", "$.comparative_evaluation_policy", "v0.4 requires the comparative policy used by signed control-plane evaluation."));
    }
    if (["0.3", "0.4"].includes(payload.schema_version)) {
      const attestation = payload.attestation_policy || {};
      const trustRef = attestation.trust_policy_ref || {};
      if (attestation.required !== true || !trustRef.artifact_id || !/^[a-f0-9]{64}$/.test(trustRef.sha256 || "")) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_ATTESTATION_POLICY_MISSING", "$.attestation_policy", "v0.3+ campaigns require a hash-bound verifier trust policy."));
      }
      if (path.isAbsolute(trustRef.relative_path || "") || String(trustRef.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_TRUST_POLICY_PATH_INVALID", "$.attestation_policy.trust_policy_ref.relative_path", "Trust policy references must remain repository-artifact-relative."));
      }
      if (!Number.isInteger(attestation.minimum_valid_attestations) || attestation.minimum_valid_attestations < 2 ||
          !Number.isInteger(attestation.minimum_independence_groups) || attestation.minimum_independence_groups < 2 ||
          attestation.minimum_independence_groups > attestation.minimum_valid_attestations || attestation.require_distinct_key_ids !== true) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_ATTESTATION_QUORUM_WEAK", "$.attestation_policy", "v0.3+ requires at least two distinct verifier keys from at least two independence groups."));
      }
    } else if (payload.attestation_policy !== undefined) {
      issues.push(issue("error", "SELF_IMPROVEMENT_V02_ATTESTATION_POLICY", "$.attestation_policy", "Signed quorum policy requires campaign schema version 0.3 or later."));
    }
  }

  if (type === "self-improvement-checkpoint") {
    const target = payload.target || {};
    const candidate = payload.candidate || {};
    const externalities = payload.externalities || {};
    const approval = payload.approval_binding || {};
    const parentRef = payload.parent_decision_ref || {};
    if (payload.cycle_number === 1 && (payload.parent_decision_id !== "none" || parentRef.decision_id !== "none" || parentRef.relative_path !== "none" || parentRef.sha256 !== "none")) {
      issues.push(issue("error", "SELF_IMPROVEMENT_FIRST_CYCLE_HAS_PARENT", "$.parent_decision_id", "The first cycle must start from the campaign baseline, not a prior decision."));
    }
    if (payload.cycle_number > 1 && /^none$/i.test(String(payload.parent_decision_id || ""))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_PARENT_DECISION_MISSING", "$.parent_decision_id", "Follow-on cycles must identify the accepted parent decision."));
    }
    const unsafePaths = [...(target.artifact_paths || []), ...(candidate.changed_files || [])]
      .filter(value => typeof value !== "string" || path.isAbsolute(value) || /^[A-Za-z]:[\\/]/.test(value) || value.split(/[\\/]+/).includes(".."));
    if (unsafePaths.length > 0) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_PATH_TRAVERSAL", "$.target.artifact_paths", "Self-improvement targets and changed files must stay inside the bound repository."));
    }
    if (new Set(candidate.changed_files || []).size !== (candidate.changed_files || []).length) {
      issues.push(issue("error", "SELF_IMPROVEMENT_DUPLICATE_CHANGED_FILE", "$.candidate.changed_files", "Changed file paths must be unique."));
    }
    if (hasSubstantiveItems(candidate.protected_invariants_affected)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_PROTECTED_INVARIANT_CHANGE", "$.candidate.protected_invariants_affected", "A candidate that affects a protected invariant cannot be promoted by this campaign."));
    }
    if (candidate.disposition !== "no_change" && !hasSubstantiveItems(candidate.rollback_steps)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_ROLLBACK_MISSING", "$.candidate.rollback_steps", "Every change candidate requires a rollback plan."));
    }
    for (const [index, metric] of (payload.metric_results || []).entries()) {
      if (metric.before < 0 || metric.before > 1 || metric.after < 0 || metric.after > 1) {
        issues.push(issue("error", "SELF_IMPROVEMENT_METRIC_NOT_NORMALIZED", `$.metric_results[${index}]`, "Checkpoint metrics must use the normalized 0..1 scale."));
      }
      if (!hasSubstantiveItems(metric.evidence_receipt_ids)) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_METRIC_WITHOUT_VERIFICATION_RECEIPT", `$.metric_results[${index}].evidence_receipt_ids`, "Checkpoint metrics must cite persisted verification receipt IDs."));
      }
    }
    const receiptIds = (payload.verification_receipts || []).map(item => item.receipt_id);
    if (new Set(receiptIds).size !== receiptIds.length) {
      issues.push(issue("error", "SELF_IMPROVEMENT_DUPLICATE_RECEIPT", "$.verification_receipts", "Checkpoint verification receipt IDs must be unique."));
    }
    for (const [index, receipt] of (payload.verification_receipts || []).entries()) {
      if (path.isAbsolute(receipt.relative_path || "") || String(receipt.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_RECEIPT_PATH_INVALID", `$.verification_receipts[${index}].relative_path`, "Verification receipt references must remain repository-artifact-relative."));
      }
    }
    const controlPlaneTarget = ["runtime_control", "skill", "policy"].includes(target.target_type);
    const comparativeTarget = ["runtime_control", "skill"].includes(target.target_type);
    const independent = payload.independent_evaluation || {};
    if (controlPlaneTarget && (independent.required !== true || independent.evaluator === "S3" || independent.status === "not_required" || !hasSubstantiveItems(independent.evidence_receipt_ids))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_CONTROL_PLANE_SELF_REVIEW", "$.independent_evaluation", "Runtime, skill, and policy candidates require independent evaluation."));
    }
    const comparisonRef = payload.comparative_evaluation_ref || {};
    if (comparativeTarget && (comparisonRef.required !== true || comparisonRef.report_id === "none" || comparisonRef.relative_path === "none" || comparisonRef.sha256 === "none")) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_EVALUATION_MISSING", "$.comparative_evaluation_ref", "Runtime-control and skill candidates require a manifest-backed baseline-versus-candidate report."));
    }
    if (comparisonRef.required === true && (path.isAbsolute(comparisonRef.relative_path || "") || String(comparisonRef.relative_path || "").split(/[\\/]+/).includes(".."))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_REPORT_PATH_INVALID", "$.comparative_evaluation_ref.relative_path", "Comparative report references must remain repository-artifact-relative."));
    }
    const humanRetained = externalities.scope_changed || externalities.authority_changed || externalities.policy_changed || externalities.release_requested ||
      ["authority_affecting", "external_release", "destructive"].includes(candidate.change_class) || target.target_type === "policy";
    if (humanRetained && !(approval.required === true && approval.action === "promote_self_improvement_candidate" &&
        approval.tool === "autonomous-improvement-controller" && approval.target === candidate.id &&
        approval.approval_scope_ref && approval.approval_scope_ref.sha256 !== "none" &&
        approval.consumption_event_ref && approval.consumption_event_ref.sha256 !== "none")) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_CONSUMED_APPROVAL_MISSING", "$.approval_binding", "Human-retained candidates require references to an exact approval scope and its consumed execution event."));
    }
    if (externalities.destructive_action || externalities.cross_repository_write || candidate.change_class === "destructive") {
      issues.push(issue("critical", "SELF_IMPROVEMENT_PROHIBITED_EXTERNALITY", "$.externalities", "Destructive and cross-repository self-improvement actions are prohibited."));
    }
    if (!humanRetained && approval.required === true) {
      issues.push(issue("error", "SELF_IMPROVEMENT_UNNECESSARY_APPROVAL_BINDING", "$.approval_binding", "A checkpoint cannot attach unrelated approval evidence."));
    }
    if (["0.3", "0.4"].includes(payload.schema_version)) {
      const attestations = payload.verification_attestations || [];
      if (attestations.length < 2) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_SIGNED_QUORUM_MISSING", "$.verification_attestations", "v0.3+ checkpoints require at least two signed verification attestations."));
      }
      const ids = attestations.map(item => item.attestation_id);
      if (new Set(ids).size !== ids.length) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_DUPLICATE_ATTESTATION", "$.verification_attestations", "Checkpoint attestation IDs must be unique."));
      }
      for (const [index, attestation] of attestations.entries()) {
        if (!receiptIds.includes(attestation.receipt_id)) {
          issues.push(issue("critical", "SELF_IMPROVEMENT_ATTESTATION_RECEIPT_UNKNOWN", `$.verification_attestations[${index}].receipt_id`, "Every attestation must bind a receipt cited by the checkpoint."));
        }
        if (path.isAbsolute(attestation.relative_path || "") || String(attestation.relative_path || "").split(/[\\/]+/).includes("..")) {
          issues.push(issue("critical", "SELF_IMPROVEMENT_ATTESTATION_PATH_INVALID", `$.verification_attestations[${index}].relative_path`, "Attestation references must remain repository-artifact-relative."));
        }
      }
    } else if (payload.verification_attestations !== undefined) {
      issues.push(issue("error", "SELF_IMPROVEMENT_V02_ATTESTATIONS", "$.verification_attestations", "Signed attestations require checkpoint schema version 0.3 or later."));
    }
    const comparativeAttestations = payload.comparative_evaluation_attestations || [];
    if (payload.schema_version === "0.4" && comparativeTarget) {
      if (comparativeAttestations.length < 2) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_SIGNED_QUORUM_MISSING", "$.comparative_evaluation_attestations", "v0.4 comparative checkpoints require at least two signed report attestations."));
      }
      const ids = comparativeAttestations.map(item => item.attestation_id);
      if (new Set(ids).size !== ids.length) {
        issues.push(issue("critical", "SELF_IMPROVEMENT_DUPLICATE_COMPARATIVE_ATTESTATION", "$.comparative_evaluation_attestations", "Comparative attestation IDs must be unique."));
      }
      for (const [index, attestation] of comparativeAttestations.entries()) {
        if (attestation.report_id !== comparisonRef.report_id) {
          issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_ATTESTATION_REPORT_UNKNOWN", `$.comparative_evaluation_attestations[${index}].report_id`, "Every comparative attestation must bind the checkpoint report."));
        }
        if (path.isAbsolute(attestation.relative_path || "") || String(attestation.relative_path || "").split(/[\\/]+/).includes("..")) {
          issues.push(issue("critical", "SELF_IMPROVEMENT_COMPARATIVE_ATTESTATION_PATH_INVALID", `$.comparative_evaluation_attestations[${index}].relative_path`, "Comparative attestation references must remain repository-artifact-relative."));
        }
      }
    } else if (payload.comparative_evaluation_attestations !== undefined) {
      issues.push(issue("error", "SELF_IMPROVEMENT_COMPARATIVE_ATTESTATION_VERSION_MISMATCH", "$.comparative_evaluation_attestations", "Comparative report attestations are allowed only for v0.4 comparative checkpoints."));
    }
  }

  if (type === "comparative-evaluation-set") {
    const fixtureIds = (payload.fixtures || []).map(item => item.id);
    if (new Set(fixtureIds).size !== fixtureIds.length) {
      issues.push(issue("critical", "COMPARATIVE_EVALUATION_DUPLICATE_FIXTURE", "$.fixtures", "Comparative fixture IDs must be unique and order-stable."));
    }
    const controls = payload.contamination_controls || {};
    if (controls.sealed_before_candidate_execution !== true || controls.candidate_context_excludes_expected_outputs !== true || controls.same_fixture_order_required !== true) {
      issues.push(issue("critical", "COMPARATIVE_EVALUATION_CONTAMINATION_CONTROL_MISSING", "$.contamination_controls", "The fixture set must be sealed before execution and exclude expected outputs from candidate context."));
    }
  }

  if (type === "comparative-evaluation-plan") {
    const baseline = payload.subjects && payload.subjects.baseline;
    const candidateSubject = payload.subjects && payload.subjects.candidate;
    const check = payload.harness && payload.harness.check;
    if (baseline && candidateSubject && baseline.candidate_id === candidateSubject.candidate_id) {
      issues.push(issue("critical", "COMPARATIVE_EVALUATION_SUBJECTS_NOT_DISTINCT", "$.subjects", "Baseline and candidate must have distinct immutable identities."));
    }
    if (baseline && candidateSubject && payload.evaluation_purpose === "candidate_promotion" && baseline.revision === candidateSubject.revision) {
      issues.push(issue("critical", "COMPARATIVE_EVALUATION_PROMOTION_REVISIONS_NOT_DISTINCT", "$.subjects", "Candidate promotion requires distinct baseline and candidate revisions."));
    }
    if (baseline && candidateSubject && payload.evaluation_purpose === "completion_revalidation" && baseline.revision !== candidateSubject.revision) {
      issues.push(issue("critical", "COMPARATIVE_EVALUATION_COMPLETION_REVISIONS_MISMATCH", "$.subjects", "Completion revalidation must execute the same accepted revision in both isolated worktrees."));
    }
    for (const [subjectName, subject] of Object.entries(payload.subjects || {})) {
      const state = subject.expected_repository_state || {};
      if (subject.revision !== state.head_commit && subject.revision !== `WT-${state.worktree_fingerprint}`) {
        issues.push(issue("critical", "COMPARATIVE_EVALUATION_REVISION_STATE_MISMATCH", `$.subjects.${subjectName}.revision`, "A subject revision must be its Git head or exact worktree fingerprint identity."));
      }
    }
    if (check) {
      const cwd = String(check.working_directory || "");
      if (path.isAbsolute(cwd) || /^[A-Za-z]:[\\/]/.test(cwd) || cwd.split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "COMPARATIVE_EVALUATION_WORKDIR_INVALID", "$.harness.check.working_directory", "Comparative harness working directories must remain repository-relative."));
      }
      if (!check.args || !check.args[0] || check.args[0].startsWith("-") || !check.args[0].endsWith(".js") || check.args[0].split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "COMPARATIVE_EVALUATION_HARNESS_INVALID", "$.harness.check.args", "Comparative evaluation requires a repository-relative JavaScript harness."));
      }
    }
    const ref = payload.evaluation_set_ref || {};
    if (path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
      issues.push(issue("critical", "COMPARATIVE_EVALUATION_SET_PATH_INVALID", "$.evaluation_set_ref.relative_path", "Evaluation-set references must remain repository-artifact-relative."));
    }
  }

  if (type === "comparative-evaluation-report") {
    const baseline = payload.executions && payload.executions.baseline;
    const candidateExecution = payload.executions && payload.executions.candidate;
    const comparisonIds = (payload.comparisons || []).map(item => item.dimension_id);
    if (new Set(comparisonIds).size !== comparisonIds.length) {
      issues.push(issue("critical", "COMPARATIVE_REPORT_DUPLICATE_DIMENSION", "$.comparisons", "Comparative report dimensions must be unique."));
    }
    for (const [subject, execution] of Object.entries(payload.executions || {})) {
      if (execution.observation) {
        const bytes = Buffer.from(`${JSON.stringify(execution.observation, null, 2)}\n`);
        const digest = crypto.createHash("sha256").update(bytes).digest("hex");
        if (!execution.stdout || execution.stdout.truncated !== false || execution.stdout.byte_size !== bytes.length || execution.stdout.sha256 !== digest) {
          issues.push(issue("critical", "COMPARATIVE_REPORT_OBSERVATION_OUTPUT_MISMATCH", `$.executions.${subject}.stdout`, "Parsed observations must match the exact structured stdout bytes recorded by the execution."));
        }
      }
    }
    if (payload.outcome === "promotable" && (payload.working_state_promotion_recommended !== true || (payload.blocking_codes || []).length > 0 ||
        !baseline || !candidateExecution || baseline.status !== "passed" || candidateExecution.status !== "passed" ||
        baseline.repository_state_unchanged !== true || candidateExecution.repository_state_unchanged !== true ||
        (payload.comparisons || []).length === 0 || payload.comparisons.some(item => item.passed !== true))) {
      issues.push(issue("critical", "COMPARATIVE_REPORT_FALSE_PROMOTION", "$.outcome", "A promotable report requires two unchanged passing executions and every comparison threshold to pass."));
    }
    if (payload.outcome !== "promotable" && payload.working_state_promotion_recommended !== false) {
      issues.push(issue("critical", "COMPARATIVE_REPORT_UNSAFE_RECOMMENDATION", "$.working_state_promotion_recommended", "Rollback and inconclusive reports cannot recommend promotion."));
    }
    if (payload.execution_authorized !== false || payload.release_authorized !== false) {
      issues.push(issue("critical", "COMPARATIVE_REPORT_AUTHORITY_EXPANSION", "$", "Comparative evaluation never authorizes execution or release."));
    }
    if (!isValidDate(payload.started_at) || !isValidDate(payload.finished_at) || Date.parse(payload.finished_at) < Date.parse(payload.started_at)) {
      issues.push(issue("error", "COMPARATIVE_REPORT_TIME_INVALID", "$.finished_at", "Comparative evaluation finish time cannot precede start time."));
    }
    if (payload.report_sha256 !== canonicalDigestWithout(payload, ["report_sha256"])) {
      issues.push(issue("critical", "COMPARATIVE_REPORT_DIGEST_INVALID", "$.report_sha256", "Comparative report digest must match its canonical content."));
    }
  }

  if (type === "verification-plan") {
    const ids = (payload.checks || []).map(item => item.id);
    if (new Set(ids).size !== ids.length) issues.push(issue("error", "VERIFICATION_PLAN_DUPLICATE_CHECK", "$.checks", "Verification check IDs must be unique."));
    for (const [index, check] of (payload.checks || []).entries()) {
      const executable = String(check.executable || "").toLowerCase();
      if (["sh", "bash", "zsh", "fish", "cmd", "powershell", "pwsh", "sudo", "env"].includes(executable)) {
        issues.push(issue("critical", "VERIFICATION_PLAN_SHELL_PROHIBITED", `$.checks[${index}].executable`, "Verification plans cannot use a shell or privilege wrapper."));
      }
      const cwd = String(check.working_directory || "");
      if (path.isAbsolute(cwd) || /^[A-Za-z]:[\\/]/.test(cwd) || cwd.split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "VERIFICATION_PLAN_WORKDIR_INVALID", `$.checks[${index}].working_directory`, "Verification working directories must remain repository-relative."));
      }
      if (executable === "node" && (!check.args || !check.args[0] || check.args[0].startsWith("-") || !check.args[0].endsWith(".js") || check.args[0].split(/[\\/]+/).includes(".."))) {
        issues.push(issue("critical", "VERIFICATION_PLAN_NODE_SCRIPT_INVALID", `$.checks[${index}].args`, "Node verification must name a repository-relative JavaScript file, not inline code or loader flags."));
      }
    }
  }

  if (type === "verification-receipt") {
    if (payload.runner && payload.runner.shell_used !== false) issues.push(issue("critical", "VERIFICATION_RECEIPT_SHELL_USED", "$.runner.shell_used", "A proof receipt is invalid if a shell was used."));
    if (payload.overall_status === "passed" && (payload.repository_state_unchanged !== true || (payload.checks || []).some(item => item.status !== "passed"))) {
      issues.push(issue("critical", "VERIFICATION_RECEIPT_FALSE_PASS", "$.overall_status", "A passed receipt requires every check to pass without repository mutation."));
    }
    if (payload.repository_state_unchanged === true && JSON.stringify(payload.repository_state_before) !== JSON.stringify(payload.repository_state_after)) {
      issues.push(issue("critical", "VERIFICATION_RECEIPT_STATE_MISMATCH", "$.repository_state_unchanged", "An unchanged claim must have identical before and after repository state."));
    }
    if (!isValidDate(payload.started_at) || !isValidDate(payload.finished_at) || Date.parse(payload.finished_at) < Date.parse(payload.started_at)) {
      issues.push(issue("error", "VERIFICATION_RECEIPT_TIME_INVALID", "$.finished_at", "Verification finish time cannot precede start time."));
    }
    if (payload.receipt_sha256 !== canonicalDigestWithout(payload, ["receipt_sha256"])) {
      issues.push(issue("critical", "VERIFICATION_RECEIPT_DIGEST_INVALID", "$.receipt_sha256", "Verification receipt digest must match its canonical content."));
    }
  }

  if (type === "transparency-policy") {
    const witnessById = new Map((payload.witnesses || []).map(item => [item.id, item]));
    const monitorById = new Map((payload.monitors || []).map(item => [item.id, item]));
    for (const [kind, field, registry] of [["witness", "witnesses", payload.witnesses || []], ["monitor", "monitors", payload.monitors || []]]) {
      const ids = new Set();
      const keys = new Set();
      for (const [index, item] of registry.entries()) {
        const pointer = `$.${field}[${index}]`;
        if (ids.has(item.id) || keys.has(item.key_id)) {
          issues.push(issue("critical", "TRANSPARENCY_OBSERVER_DUPLICATE", pointer, "Observer IDs and keys must be unique within each registry."));
        }
        ids.add(item.id);
        keys.add(item.key_id);
        try {
          const key = crypto.createPublicKey(item.public_key_pem);
          if (key.asymmetricKeyType !== "ed25519" || publicKeyId(key) !== item.key_id) throw new Error("mismatch");
        } catch (error) {
          issues.push(issue("critical", "TRANSPARENCY_OBSERVER_KEY_INVALID", `${pointer}.key_id`, "Observer keys must be Ed25519 SPKI keys matching key_id."));
        }
        if (!isValidDate(item.valid_from) || !isValidDate(item.valid_until) || Date.parse(item.valid_until) <= Date.parse(item.valid_from)) {
          issues.push(issue("critical", "TRANSPARENCY_OBSERVER_WINDOW_INVALID", pointer, "Observer validity must have an ordered start and end."));
        }
      }
    }
    const logIds = new Set();
    for (const [index, log] of (payload.logs || []).entries()) {
      const pointer = `$.logs[${index}]`;
      if (logIds.has(log.id)) issues.push(issue("critical", "TRANSPARENCY_LOG_DUPLICATE", `${pointer}.id`, "Transparency log IDs must be unique."));
      logIds.add(log.id);
      try {
        const key = crypto.createPublicKey(log.public_key_pem);
        if (key.asymmetricKeyType !== "ed25519" || publicKeyId(key) !== log.key_id) throw new Error("mismatch");
      } catch (error) {
        issues.push(issue("critical", "TRANSPARENCY_LOG_KEY_INVALID", `${pointer}.key_id`, "Log keys must be Ed25519 SPKI keys matching key_id."));
      }
      const witnesses = (log.witness_ids || []).map(id => witnessById.get(id)).filter(Boolean);
      const monitors = (log.monitor_ids || []).map(id => monitorById.get(id)).filter(Boolean);
      const witnessOperators = new Set(witnesses.filter(item => item.status === "active").map(item => item.operator_id));
      const monitorOperators = new Set(monitors.filter(item => item.status === "active").map(item => item.operator_id));
      if (witnesses.length !== (log.witness_ids || []).length || log.minimum_witnesses > witnesses.filter(item => item.status === "active").length ||
          log.minimum_witness_operators > witnessOperators.size) {
        issues.push(issue("critical", "TRANSPARENCY_WITNESS_POLICY_IMPOSSIBLE", `${pointer}.witness_ids`, "Configured active witnesses and operators must be able to satisfy the log threshold."));
      }
      if (monitors.length !== (log.monitor_ids || []).length || log.minimum_monitors > monitors.filter(item => item.status === "active").length ||
          log.minimum_monitor_operators > monitorOperators.size) {
        issues.push(issue("critical", "TRANSPARENCY_MONITOR_POLICY_IMPOSSIBLE", `${pointer}.monitor_ids`, "Configured active monitors and operators must be able to satisfy the log threshold."));
      }
      if ([...witnessOperators].some(operator => monitorOperators.has(operator))) {
        issues.push(issue("critical", "TRANSPARENCY_OBSERVER_OPERATOR_CORRELATION", pointer, "Witness and monitor operator sets must not overlap for the same log."));
      }
    }
    const rootIds = (payload.trusted_roots || []).map(item => item.id);
    const rootRefs = (payload.trusted_roots || []).map(item => item.trusted_root_ref && item.trusted_root_ref.artifact_id);
    if (new Set(rootIds).size !== rootIds.length || new Set(rootRefs).size !== rootRefs.length) {
      issues.push(issue("critical", "TRANSPARENCY_TRUST_ROOT_DUPLICATE", "$.trusted_roots", "Trusted-root IDs and artifact references must be unique."));
    }
    if ((payload.trusted_roots || []).some(item => !isValidDate(item.tuf_root_expires_at) ||
        Date.parse(item.tuf_root_expires_at) <= Date.parse(payload.created_at))) {
      issues.push(issue("critical", "TRANSPARENCY_TUF_ROOT_EXPIRY_INVALID", "$.trusted_roots", "Every initial TUF root must remain current after policy creation."));
    }
    if (!isValidDate(payload.created_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.created_at)) {
      issues.push(issue("critical", "TRANSPARENCY_POLICY_WINDOW_INVALID", "$.expires_at", "Transparency policy expiry must be later than creation."));
    }
  }

  if (type === "transparency-observation") {
    if (payload.observation_sha256 !== observationDigest(payload)) {
      issues.push(issue("critical", "TRANSPARENCY_OBSERVATION_DIGEST_INVALID", "$.observation_sha256", "Observation digest must match its canonical content."));
    }
    if (payload.log_id !== (payload.checkpoint && payload.checkpoint.log_id)) {
      issues.push(issue("critical", "TRANSPARENCY_OBSERVATION_LOG_MISMATCH", "$.checkpoint.log_id", "Observation and checkpoint log IDs must match."));
    }
    if (!isValidDate(payload.observed_at) || !isValidDate(payload.expires_at) ||
        !isValidDate(payload.checkpoint && payload.checkpoint.issued_at) ||
        Date.parse(payload.expires_at) <= Date.parse(payload.observed_at) ||
        Date.parse(payload.checkpoint.issued_at) > Date.parse(payload.observed_at)) {
      issues.push(issue("critical", "TRANSPARENCY_OBSERVATION_TIME_INVALID", "$.observed_at", "Checkpoint, observation, and expiry times must be ordered."));
    }
    for (const [field, idField] of [["witness_signatures", "witness_id"], ["monitor_signatures", "monitor_id"]]) {
      const ids = (payload[field] || []).map(item => item[idField]);
      if (new Set(ids).size !== ids.length) {
        issues.push(issue("critical", "TRANSPARENCY_OBSERVER_SIGNATURE_DUPLICATE", `$.${field}`, "One observer identity may sign an observation only once."));
      }
      if ((payload[field] || []).some(item => item.observed_at !== payload.observed_at)) {
        issues.push(issue("critical", "TRANSPARENCY_OBSERVER_TIME_UNBOUND", `$.${field}`, "Observer timestamps must exactly match the signed observation timestamp."));
      }
    }
  }

  if (type === "trust-root-rotation") {
    if (payload.rotation_sha256 !== rotationDigest(payload)) {
      issues.push(issue("critical", "TRUST_ROOT_ROTATION_DIGEST_INVALID", "$.rotation_sha256", "Rotation digest must match its canonical content."));
    }
    const previousVersion = payload.previous_tuf_root && payload.previous_tuf_root.signed && payload.previous_tuf_root.signed.version;
    const nextVersion = payload.next_tuf_root && payload.next_tuf_root.signed && payload.next_tuf_root.signed.version;
    if (nextVersion !== previousVersion + 1) {
      issues.push(issue("critical", "TRUST_ROOT_ROTATION_VERSION_INVALID", "$.next_tuf_root.signed.version", "TUF root rotation must advance exactly from N to N+1."));
    }
    if (payload.approved_by !== "USER" || !isValidDate(payload.approved_at) || !isValidDate(payload.effective_at) ||
        Date.parse(payload.effective_at) < Date.parse(payload.approved_at)) {
      issues.push(issue("critical", "TRUST_ROOT_ROTATION_AUTHORITY_INVALID", "$.approved_by", "Root rotation requires USER authority and ordered approval/effective times."));
    }
    if (payload.reason === "compromise" && (payload.revoked_tuf_root_key_ids || []).length === 0) {
      issues.push(issue("critical", "TRUST_ROOT_ROTATION_COMPROMISE_REVOCATION_REQUIRED", "$.revoked_tuf_root_key_ids", "Compromise rotation must name revoked TUF root keys."));
    }
  }

  if (type === "transparency-incident") {
    if (payload.incident_sha256 !== incidentDigest(payload)) {
      issues.push(issue("critical", "TRANSPARENCY_INCIDENT_DIGEST_INVALID", "$.incident_sha256", "Incident digest must match its canonical content."));
    }
    if (payload.authority !== "USER" || !isValidDate(payload.detected_at)) {
      issues.push(issue("critical", "TRANSPARENCY_INCIDENT_AUTHORITY_INVALID", "$.authority", "Transparency incident disposition remains USER authority."));
    }
    if (payload.status === "resolved" && (!payload.supersedes_incident_ref || !payload.resolution ||
        payload.resolution.authority !== "USER" || !isValidDate(payload.resolution.resolved_at) ||
        Date.parse(payload.resolution.resolved_at) < Date.parse(payload.detected_at) ||
        !Array.isArray(payload.resolution.evidence_refs) || payload.resolution.evidence_refs.length === 0)) {
      issues.push(issue("critical", "TRANSPARENCY_INCIDENT_RESOLUTION_INVALID", "$.resolution", "Resolved incidents require a later USER-authorized immutable supersession record with remediation evidence."));
    }
    if (payload.status !== "resolved" && (payload.supersedes_incident_ref !== undefined || payload.resolution !== undefined)) {
      issues.push(issue("critical", "TRANSPARENCY_INCIDENT_PREMATURE_RESOLUTION", "$", "Only a resolved incident record may supersede an earlier incident."));
    }
  }

  if (type === "transparency-state") {
    if (payload.state_sha256 !== stateDigest(payload)) {
      issues.push(issue("critical", "TRANSPARENCY_STATE_DIGEST_INVALID", "$.state_sha256", "Transparency-state digest must match its canonical content."));
    }
    const ready = payload.status === "ready";
    if ((ready && ((payload.blocking_codes || []).length > 0 || payload.valid_until === "none" ||
        (payload.logs || []).some(item => item.status !== "consistent" || (item.blocking_codes || []).length > 0))) ||
        (!ready && (payload.blocking_codes || []).length === 0)) {
      issues.push(issue("critical", "TRANSPARENCY_STATE_FALSE_STATUS", "$.status", "Ready state requires consistent logs, a validity boundary, and no blocking codes; blocked state requires a reason."));
    }
    if (payload.sequence_number === 1 && !isNoneArtifactRef(payload.previous_state_ref)) {
      issues.push(issue("critical", "TRANSPARENCY_STATE_GENESIS_INVALID", "$.previous_state_ref", "The first transparency state must use the none reference."));
    }
    if (payload.sequence_number > 1 && isNoneArtifactRef(payload.previous_state_ref)) {
      issues.push(issue("critical", "TRANSPARENCY_STATE_LINEAGE_MISSING", "$.previous_state_ref", "Later transparency states must cite the immediately previous state."));
    }
  }

  if (type === "verifier-trust-policy") {
    const verifiers = payload.verifiers || [];
    const ids = new Set();
    const keyIds = new Set();
    const activeGroups = new Set();
    const spiffeIds = new Set();
    const identityAssurance = payload.identity_assurance || {};
    const trustedRootIds = new Set();
    const trustedLogIds = new Set();

    if (["0.2", "0.3", "0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version) && !payload.identity_assurance) {
      issues.push(issue("critical", "VERIFIER_POLICY_IDENTITY_ASSURANCE_REQUIRED", "$.identity_assurance", "Policy v0.2+ requires workload identity assurance."));
    }
    if (payload.schema_version === "0.1" && (payload.identity_assurance || verifiers.some(item => item.workload_identity))) {
      issues.push(issue("error", "VERIFIER_POLICY_VERSION_CONTRACT_INVALID", "$.schema_version", "Workload identity assurance requires policy schema v0.2 or later."));
    }
    const sigstoreRootRefs = identityAssurance.sigstore_trusted_root_refs || [];
    const sigstoreRootIds = new Set();
    for (const [index, ref] of sigstoreRootRefs.entries()) {
      const pointer = `$.identity_assurance.sigstore_trusted_root_refs[${index}]`;
      if (sigstoreRootIds.has(ref.artifact_id)) issues.push(issue("critical", "VERIFIER_POLICY_DUPLICATE_SIGSTORE_ROOT", `${pointer}.artifact_id`, "Sigstore TrustedRoot references must be unique."));
      sigstoreRootIds.add(ref.artifact_id);
      if (path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "VERIFIER_POLICY_SIGSTORE_ROOT_PATH_INVALID", `${pointer}.relative_path`, "Sigstore TrustedRoot references must remain repository-artifact-relative."));
      }
    }
    if (["0.3", "0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version) && (sigstoreRootRefs.length === 0 || !Number.isInteger(identityAssurance.max_trusted_root_age_seconds))) {
      issues.push(issue("critical", "VERIFIER_POLICY_SIGSTORE_ROOT_REQUIRED", "$.identity_assurance", "Policy v0.3+ requires a manifest-bound Sigstore TrustedRoot and freshness limit."));
    }
    const executionAssurance = payload.execution_assurance;
    if (["0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version)) {
      const runtimeRef = executionAssurance && executionAssurance.runtime_policy_ref;
      if (!executionAssurance || executionAssurance.required !== true || !runtimeRef) {
        issues.push(issue("critical", "VERIFIER_POLICY_EXECUTION_ASSURANCE_REQUIRED", "$.execution_assurance", "Policy v0.4+ requires an exact verifier runtime policy reference."));
      } else if (path.isAbsolute(runtimeRef.relative_path || "") || String(runtimeRef.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "VERIFIER_POLICY_RUNTIME_POLICY_PATH_INVALID", "$.execution_assurance.runtime_policy_ref.relative_path", "Runtime policy references must remain repository-artifact-relative."));
      }
    } else if (executionAssurance !== undefined) {
      issues.push(issue("error", "VERIFIER_POLICY_EXECUTION_ASSURANCE_VERSION_INVALID", "$.execution_assurance", "Execution assurance requires trust-policy schema v0.4 or later."));
    }
    const challengeAssurance = payload.challenge_assurance;
    if (["0.5", "0.6", "0.7"].includes(payload.schema_version)) {
      if (!challengeAssurance || challengeAssurance.required !== true || challengeAssurance.single_use !== true ||
          !Number.isInteger(challengeAssurance.nonce_bytes) || challengeAssurance.nonce_bytes < 32 ||
          !Number.isInteger(challengeAssurance.response_timeout_seconds)) {
        issues.push(issue("critical", "VERIFIER_POLICY_CHALLENGE_ASSURANCE_REQUIRED", "$.challenge_assurance", "Policy v0.5 requires a single-use challenge with at least 32 random bytes and a finite response timeout."));
      }
      try {
        const issuerKey = crypto.createPublicKey(challengeAssurance.issuer_public_key_pem);
        if (issuerKey.asymmetricKeyType !== "ed25519" || publicKeyId(issuerKey) !== challengeAssurance.issuer_key_id) {
          issues.push(issue("critical", "VERIFIER_POLICY_CHALLENGE_ISSUER_KEY_INVALID", "$.challenge_assurance.issuer_key_id", "Challenge issuer key must be Ed25519 and match the SHA-256 SPKI key ID."));
        }
        if (verifiers.some(item => item.key_id === challengeAssurance.issuer_key_id)) {
          issues.push(issue("critical", "VERIFIER_POLICY_CHALLENGE_ISSUER_KEY_CORRELATED", "$.challenge_assurance.issuer_key_id", "The supervisor challenge issuer key must be distinct from every verifier key."));
        }
      } catch (error) {
        issues.push(issue("critical", "VERIFIER_POLICY_CHALLENGE_ISSUER_KEY_INVALID", "$.challenge_assurance.issuer_public_key_pem", "Challenge issuer public key must be valid SPKI PEM."));
      }
    } else if (challengeAssurance !== undefined) {
      issues.push(issue("error", "VERIFIER_POLICY_CHALLENGE_ASSURANCE_VERSION_INVALID", "$.challenge_assurance", "Pre-dispatch challenge assurance requires trust-policy schema v0.5 or later."));
    }
    const independenceAssurance = payload.independence_assurance;
    if (["0.6", "0.7"].includes(payload.schema_version)) {
      if (!independenceAssurance || independenceAssurance.required !== true ||
          independenceAssurance.correlation_rule !== "shared_required_component" ||
          !exactDimensions(independenceAssurance.required_dimensions) ||
          !Number.isInteger(independenceAssurance.minimum_independent_domains) ||
          independenceAssurance.minimum_independent_domains < (payload.quorum && payload.quorum.minimum_independence_groups || 0)) {
        issues.push(issue("critical", "VERIFIER_POLICY_INDEPENDENCE_ASSURANCE_INVALID", "$.independence_assurance", "Policy v0.6+ requires the complete ordered failure-domain dimensions and a threshold at least as strong as the attestation quorum."));
      }
    } else if (independenceAssurance !== undefined) {
      issues.push(issue("error", "VERIFIER_POLICY_INDEPENDENCE_ASSURANCE_VERSION_INVALID", "$.independence_assurance", "Failure-domain assurance requires trust-policy schema v0.6 or later."));
    }
    const transparencyAssurance = payload.transparency_assurance;
    if (payload.schema_version === "0.7") {
      const policyRef = transparencyAssurance && transparencyAssurance.transparency_policy_ref;
      if (!transparencyAssurance || transparencyAssurance.required !== true || !policyRef ||
          policyRef.artifact_id === "none" || !Number.isInteger(transparencyAssurance.max_state_age_seconds) ||
          transparencyAssurance.max_state_age_seconds < 60 || !transparencyAssurance.state_stream_id) {
        issues.push(issue("critical", "VERIFIER_POLICY_TRANSPARENCY_ASSURANCE_INVALID", "$.transparency_assurance", "Policy v0.7 requires an exact transparency policy, state stream, and finite state freshness bound."));
      } else if (path.isAbsolute(policyRef.relative_path || "") || String(policyRef.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "VERIFIER_POLICY_TRANSPARENCY_POLICY_PATH_INVALID", "$.transparency_assurance.transparency_policy_ref.relative_path", "Transparency policy references must remain repository-artifact-relative."));
      }
    } else if (transparencyAssurance !== undefined) {
      issues.push(issue("error", "VERIFIER_POLICY_TRANSPARENCY_ASSURANCE_VERSION_INVALID", "$.transparency_assurance", "Continuous transparency assurance requires trust-policy schema v0.7."));
    }
    for (const [index, root] of (identityAssurance.trusted_x509_roots || []).entries()) {
      const pointer = `$.identity_assurance.trusted_x509_roots[${index}]`;
      if (trustedRootIds.has(root.id)) issues.push(issue("critical", "VERIFIER_POLICY_DUPLICATE_TRUST_ROOT", `${pointer}.id`, "Trusted X.509 root IDs must be unique."));
      trustedRootIds.add(root.id);
      try {
        const certificate = new crypto.X509Certificate(root.certificate_pem);
        if (certificate.ca !== true || !certificate.verify(certificate.publicKey)) {
          issues.push(issue("critical", "VERIFIER_POLICY_TRUST_ROOT_INVALID", `${pointer}.certificate_pem`, "Trusted X.509 roots must be self-signed CA certificates."));
        }
        if (certificateSha256(certificate) !== root.certificate_sha256) {
          issues.push(issue("critical", "VERIFIER_POLICY_TRUST_ROOT_DIGEST_MISMATCH", `${pointer}.certificate_sha256`, "Trusted X.509 root digest must match the certificate DER bytes."));
        }
      } catch (error) {
        issues.push(issue("critical", "VERIFIER_POLICY_TRUST_ROOT_INVALID", `${pointer}.certificate_pem`, "Trusted X.509 root must be a valid PEM certificate."));
      }
    }
    for (const [index, log] of (identityAssurance.trusted_transparency_logs || []).entries()) {
      const pointer = `$.identity_assurance.trusted_transparency_logs[${index}]`;
      if (trustedLogIds.has(log.id)) issues.push(issue("critical", "VERIFIER_POLICY_DUPLICATE_TRANSPARENCY_LOG", `${pointer}.id`, "Trusted transparency-log IDs must be unique."));
      trustedLogIds.add(log.id);
      try {
        const key = crypto.createPublicKey(log.public_key_pem);
        if (key.asymmetricKeyType !== "ed25519" || publicKeyId(key) !== log.key_id) {
          issues.push(issue("critical", "VERIFIER_POLICY_TRANSPARENCY_KEY_INVALID", `${pointer}.key_id`, "Transparency-log keys must be Ed25519 keys whose SPKI digest matches key_id."));
        }
      } catch (error) {
        issues.push(issue("critical", "VERIFIER_POLICY_TRANSPARENCY_KEY_INVALID", `${pointer}.public_key_pem`, "Transparency-log public key must be valid SPKI PEM."));
      }
    }
    for (const [index, verifier] of verifiers.entries()) {
      const pointer = `$.verifiers[${index}]`;
      if (ids.has(verifier.id)) issues.push(issue("critical", "VERIFIER_POLICY_DUPLICATE_ID", `${pointer}.id`, "Verifier IDs must be unique."));
      if (keyIds.has(verifier.key_id)) issues.push(issue("critical", "VERIFIER_POLICY_DUPLICATE_KEY", `${pointer}.key_id`, "One public key cannot satisfy more than one verifier identity."));
      ids.add(verifier.id);
      keyIds.add(verifier.key_id);
      if (verifier.status === "active") activeGroups.add(verifier.independence_group);
      try {
        if (publicKeyId(verifier.public_key_pem) !== verifier.key_id) {
          issues.push(issue("critical", "VERIFIER_POLICY_KEY_ID_MISMATCH", `${pointer}.key_id`, "Verifier key_id must be the SHA-256 digest of the Ed25519 SPKI public key."));
        }
        if (crypto.createPublicKey(verifier.public_key_pem).asymmetricKeyType !== "ed25519") {
          issues.push(issue("critical", "VERIFIER_POLICY_KEY_NOT_ED25519", `${pointer}.public_key_pem`, "Verifier keys must use Ed25519."));
        }
      } catch (error) {
        issues.push(issue("critical", "VERIFIER_POLICY_PUBLIC_KEY_INVALID", `${pointer}.public_key_pem`, "Verifier public key must be valid SPKI PEM."));
      }
      if (!isValidDate(verifier.valid_from) || !isValidDate(verifier.valid_until) || Date.parse(verifier.valid_until) <= Date.parse(verifier.valid_from)) {
        issues.push(issue("critical", "VERIFIER_POLICY_KEY_WINDOW_INVALID", pointer, "Verifier validity must end after it begins."));
      }
      if (!(verifier.allowed_repository_keys || []).includes(payload.repository_binding && payload.repository_binding.repository_key)) {
        issues.push(issue("critical", "VERIFIER_POLICY_REPOSITORY_NOT_ALLOWED", `${pointer}.allowed_repository_keys`, "Every trusted verifier must explicitly allow the policy repository."));
      }
      if (["0.2", "0.3", "0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version)) {
        const workload = verifier.workload_identity;
        if (!workload) {
          issues.push(issue("critical", "VERIFIER_POLICY_WORKLOAD_IDENTITY_REQUIRED", `${pointer}.workload_identity`, "Every verifier in policy v0.2+ requires a workload identity."));
        } else if (workload.type === "spiffe_x509") {
          if (spiffeIds.has(workload.spiffe_id)) issues.push(issue("critical", "VERIFIER_POLICY_DUPLICATE_SPIFFE_ID", `${pointer}.workload_identity.spiffe_id`, "SPIFFE IDs must be unique across verifier identities."));
          spiffeIds.add(workload.spiffe_id);
          if (!trustedRootIds.has(workload.trust_root_id)) issues.push(issue("critical", "VERIFIER_POLICY_TRUST_ROOT_REFERENCE_INVALID", `${pointer}.workload_identity.trust_root_id`, "Verifier workload identity must reference a trusted X.509 root."));
          if (!trustedLogIds.has(workload.transparency_log_id)) issues.push(issue("critical", "VERIFIER_POLICY_TRANSPARENCY_LOG_REFERENCE_INVALID", `${pointer}.workload_identity.transparency_log_id`, "Verifier workload identity must reference a trusted transparency log."));
          try {
            const spiffe = new URL(workload.spiffe_id);
            const root = (identityAssurance.trusted_x509_roots || []).find(item => item.id === workload.trust_root_id);
            if (spiffe.protocol !== "spiffe:" || !spiffe.hostname || spiffe.pathname === "/" || spiffe.search || spiffe.hash ||
                spiffe.href !== workload.spiffe_id || (root && spiffe.hostname !== root.trust_domain)) {
              issues.push(issue("critical", "VERIFIER_POLICY_SPIFFE_ID_INVALID", `${pointer}.workload_identity.spiffe_id`, "SPIFFE ID must use the selected root's trust domain and a non-root path."));
            }
          } catch (error) {
            issues.push(issue("critical", "VERIFIER_POLICY_SPIFFE_ID_INVALID", `${pointer}.workload_identity.spiffe_id`, "Verifier workload identity must be a valid SPIFFE URI."));
          }
        } else if (["0.3", "0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version) && workload.type === "sigstore_bundle") {
          const requiredFields = ["certificate_identity_type", "certificate_identity", "certificate_issuer", "trust_root_id", "bundle_media_type", "ctlog_threshold", "tlog_threshold", "timestamp_threshold"];
          if (requiredFields.some(field => workload[field] === undefined)) {
            issues.push(issue("critical", "VERIFIER_POLICY_SIGSTORE_IDENTITY_INCOMPLETE", `${pointer}.workload_identity`, "Sigstore identity requires exact SAN, issuer, root, bundle media type, and nonzero verification thresholds."));
          }
          if (!sigstoreRootIds.has(workload.trust_root_id)) {
            issues.push(issue("critical", "VERIFIER_POLICY_SIGSTORE_ROOT_REFERENCE_INVALID", `${pointer}.workload_identity.trust_root_id`, "Sigstore workload identity must reference a manifest-bound TrustedRoot."));
          }
        } else {
          issues.push(issue("critical", "VERIFIER_POLICY_WORKLOAD_IDENTITY_TYPE_INVALID", `${pointer}.workload_identity.type`, "Policy workload identity type is not supported by this schema version."));
        }
      }
    }
    const active = verifiers.filter(item => item.status === "active");
    const quorum = payload.quorum || {};
    if (quorum.minimum_valid_attestations > active.length) {
      issues.push(issue("critical", "VERIFIER_POLICY_QUORUM_IMPOSSIBLE", "$.quorum.minimum_valid_attestations", "The active verifier population cannot satisfy the required attestation quorum."));
    }
    if ((!["0.6", "0.7"].includes(payload.schema_version) && quorum.minimum_independence_groups > activeGroups.size) ||
        quorum.minimum_independence_groups > quorum.minimum_valid_attestations) {
      issues.push(issue("critical", "VERIFIER_POLICY_GROUP_QUORUM_IMPOSSIBLE", "$.quorum.minimum_independence_groups", "The active independence groups cannot satisfy the group quorum."));
    }
    if (!isValidDate(payload.created_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.created_at)) {
      issues.push(issue("critical", "VERIFIER_POLICY_WINDOW_INVALID", "$.expires_at", "Trust policy expiry must be later than creation."));
    }
  }

  if (type === "verifier-runtime-policy") {
    const profiles = payload.profiles || [];
    const assignments = payload.assignments || [];
    const profileIds = new Set();
    const assignedVerifiers = new Set();
    for (const [index, profile] of profiles.entries()) {
      const pointer = `$.profiles[${index}]`;
      if (profileIds.has(profile.id)) issues.push(issue("critical", "VERIFIER_RUNTIME_PROFILE_DUPLICATE", `${pointer}.id`, "Runtime profile IDs must be unique."));
      profileIds.add(profile.id);
      try {
        const key = crypto.createPublicKey(profile.builder && profile.builder.public_key_pem);
        if (key.asymmetricKeyType !== "ed25519" || publicKeyId(key) !== (profile.builder && profile.builder.key_id)) {
          issues.push(issue("critical", "VERIFIER_RUNTIME_BUILDER_KEY_INVALID", `${pointer}.builder.key_id`, "Builder keys must be Ed25519 keys whose SPKI digest matches key_id."));
        }
      } catch (error) {
        issues.push(issue("critical", "VERIFIER_RUNTIME_BUILDER_KEY_INVALID", `${pointer}.builder.public_key_pem`, "Builder public key must be valid SPKI PEM."));
      }
      const requiredClaims = providerRequiredClaims(profile);
      const pinnedClaims = profile.provider_identity && profile.provider_identity.required_claims || {};
      if (requiredClaims.some(key => typeof pinnedClaims[key] !== "string" || pinnedClaims[key].length === 0)) {
        issues.push(issue("critical", "VERIFIER_RUNTIME_PROVIDER_CLAIMS_INCOMPLETE", `${pointer}.provider_identity.required_claims`, "Provider-specific stable execution identity claims must be pinned exactly."));
      }
      if (["0.2", "0.3"].includes(payload.schema_version) && (!validClaims(profile.independence) || !profileClaimsMatchProvider(profile))) {
        issues.push(issue("critical", "VERIFIER_RUNTIME_INDEPENDENCE_CLAIMS_INVALID", `${pointer}.independence`, "Runtime-policy v0.2+ requires complete identities and canonical provider/project/runner mappings from pinned provider claims."));
      }
      if (payload.schema_version === "0.1" && profile.independence !== undefined) {
        issues.push(issue("error", "VERIFIER_RUNTIME_INDEPENDENCE_VERSION_INVALID", `${pointer}.independence`, "Failure-domain claims require runtime-policy schema v0.2."));
      }
      if (payload.schema_version === "0.3") {
        const native = profile.native_identity || {};
        if (profile.provider === "github_actions") {
          const reusableSha = pinnedClaims.job_workflow_sha;
          const nativePinnedClaims = [
            "job_workflow_ref", "job_workflow_sha", "ref", "repository", "repository_id",
            "repository_owner", "repository_owner_id", "runner_environment", "sha", "workflow_ref", "workflow_sha"
          ];
          if (native.adapter !== "github_actions_oidc_v1" || native.algorithm !== "RS256" ||
              native.required_runner_environment !== "github-hosted" || native.require_reusable_workflow !== true) {
            issues.push(issue("critical", "VERIFIER_RUNTIME_NATIVE_PROFILE_INVALID", `${pointer}.native_identity`, "GitHub native profiles require the strict GitHub Actions reusable-workflow OIDC adapter."));
          }
          if (nativePinnedClaims.some(name => typeof pinnedClaims[name] !== "string" || pinnedClaims[name].length === 0) ||
              profile.provider_identity && profile.provider_identity.issuer !== "https://token.actions.githubusercontent.com" ||
              pinnedClaims.runner_environment !== "github-hosted" || !/^[a-f0-9]{40}$/.test(pinnedClaims.sha || "") ||
              pinnedClaims.workflow_sha !== pinnedClaims.sha || !/^[a-f0-9]{40}$/.test(reusableSha || "") ||
              !String(pinnedClaims.job_workflow_ref || "").endsWith(`@${reusableSha || "missing"}`)) {
            issues.push(issue("critical", "VERIFIER_RUNTIME_NATIVE_CLAIMS_INVALID", `${pointer}.provider_identity`, "GitHub native profiles must pin the public issuer, immutable IDs, exact commit, GitHub-hosted runner, and reusable workflow by commit SHA."));
          }
        } else if (profile.provider === "gitlab_ci") {
          const stableIds = ["project_id", "namespace_id", "job_project_id", "job_namespace_id"];
          const sameProject = pinnedClaims.project_id === pinnedClaims.job_project_id &&
            pinnedClaims.project_path === pinnedClaims.job_project_path &&
            pinnedClaims.namespace_id === pinnedClaims.job_namespace_id &&
            pinnedClaims.namespace_path === pinnedClaims.job_namespace_path;
          const configPrefix = `gitlab.com/${pinnedClaims.job_project_path || "missing"}//`;
          if (native.adapter !== "gitlab_ci_oidc_v1" || native.algorithm !== "RS256" ||
              native.required_runner_environment !== "gitlab-hosted" || native.require_protected_ref !== true ||
              native.require_same_project_config !== true) {
            issues.push(issue("critical", "VERIFIER_RUNTIME_NATIVE_PROFILE_INVALID", `${pointer}.native_identity`, "GitLab native profiles require the strict GitLab.com hosted-runner OIDC adapter."));
          }
          if (profile.provider_identity && profile.provider_identity.issuer !== "https://gitlab.com" ||
              stableIds.some(name => !/^[1-9]\d*$/.test(pinnedClaims[name] || "")) || !sameProject ||
              pinnedClaims.runner_environment !== "gitlab-hosted" || pinnedClaims.ref_protected !== "true" ||
              pinnedClaims.ref_type !== "branch" || pinnedClaims.ref_path !== `refs/heads/${pinnedClaims.ref || "missing"}` ||
              !/^[a-f0-9]{40}$/.test(pinnedClaims.sha || "") || pinnedClaims.ci_config_sha !== pinnedClaims.sha ||
              !String(pinnedClaims.ci_config_ref_uri || "").startsWith(configPrefix) ||
              !String(pinnedClaims.ci_config_ref_uri || "").endsWith(`@${pinnedClaims.ref_path || "missing"}`)) {
            issues.push(issue("critical", "VERIFIER_RUNTIME_NATIVE_CLAIMS_INVALID", `${pointer}.provider_identity`, "GitLab native profiles must pin GitLab.com, stable source and job IDs, one protected branch, same-project CI config and commit, and GitLab-hosted execution."));
          }
        } else {
          issues.push(issue("critical", "VERIFIER_RUNTIME_NATIVE_PROFILE_INVALID", `${pointer}.native_identity`, "Runtime-policy v0.3 requires a supported native GitHub Actions or GitLab CI adapter."));
        }
        const ref = native.trust_bundle_ref || {};
        if (path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
          issues.push(issue("critical", "VERIFIER_RUNTIME_NATIVE_TRUST_REFERENCE_INVALID", `${pointer}.native_identity.trust_bundle_ref`, "Native trust-bundle references must remain repository-artifact-relative."));
        }
      } else if (profile.native_identity !== undefined) {
        issues.push(issue("error", "VERIFIER_RUNTIME_NATIVE_PROFILE_VERSION_INVALID", `${pointer}.native_identity`, "Native provider identity requires runtime-policy schema v0.3."));
      }
      const execution = profile.execution || {};
      const image = execution.container_image || {};
      const imageDigest = image.digest && image.digest.sha256;
      if (!imageDigest || !String(image.uri || "").endsWith(`@sha256:${imageDigest}`)) {
        issues.push(issue("critical", "VERIFIER_RUNTIME_IMAGE_NOT_DIGEST_PINNED", `${pointer}.execution.container_image`, "OCI images must use a manifest digest URI matching the descriptor digest."));
      }
      if (!(execution.tool_allowlist || []).includes((execution.argv || [])[0])) {
        issues.push(issue("critical", "VERIFIER_RUNTIME_ENTRYPOINT_NOT_ALLOWED", `${pointer}.execution.tool_allowlist`, "The exact argv entrypoint must be present in the tool allowlist."));
      }
      const network = execution.network_policy || {};
      if ((network.mode === "denied" && (network.allowed_endpoints || []).length !== 0) ||
          (network.mode === "allowlist" && (network.allowed_endpoints || []).length === 0)) {
        issues.push(issue("critical", "VERIFIER_RUNTIME_NETWORK_POLICY_INVALID", `${pointer}.execution.network_policy`, "Denied networking requires an empty list; allowlist mode requires explicit endpoints."));
      }
    }
    for (const [index, assignment] of assignments.entries()) {
      const pointer = `$.assignments[${index}]`;
      if (assignedVerifiers.has(assignment.verifier_id)) issues.push(issue("critical", "VERIFIER_RUNTIME_ASSIGNMENT_DUPLICATE", `${pointer}.verifier_id`, "Each verifier must have exactly one runtime profile assignment."));
      assignedVerifiers.add(assignment.verifier_id);
      if (!profileIds.has(assignment.profile_id)) issues.push(issue("critical", "VERIFIER_RUNTIME_PROFILE_REFERENCE_INVALID", `${pointer}.profile_id`, "Runtime assignments must reference an existing profile."));
    }
    if (!isValidDate(payload.created_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.created_at)) {
      issues.push(issue("critical", "VERIFIER_RUNTIME_POLICY_WINDOW_INVALID", "$.expires_at", "Runtime policy expiry must be later than creation."));
    }
  }

  if (type === "verifier-challenge-set") {
    const challenges = payload.challenges || [];
    const verifierIds = challenges.map(item => item.verifier_id);
    const nonces = challenges.map(item => item.nonce);
    if (new Set(verifierIds).size !== verifierIds.length) {
      issues.push(issue("critical", "CHALLENGE_SET_DUPLICATE_VERIFIER", "$.challenges", "A verifier may receive only one nonce in a challenge set."));
    }
    if (new Set(nonces).size !== nonces.length) {
      issues.push(issue("critical", "CHALLENGE_SET_DUPLICATE_NONCE", "$.challenges", "Every verifier challenge nonce must be unique."));
    }
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) ||
        Date.parse(payload.expires_at) <= Date.parse(payload.issued_at)) {
      issues.push(issue("critical", "CHALLENGE_SET_WINDOW_INVALID", "$.expires_at", "Challenge expiry must be later than issuance."));
    }
    if (payload.single_use !== true || payload.release_authorized !== false) {
      issues.push(issue("critical", "CHALLENGE_SET_AUTHORITY_INVALID", "$", "A challenge set must be single-use and cannot grant release authority."));
    }
    for (const field of ["trust_policy_ref", "runtime_policy_ref"]) {
      const ref = payload[field] || {};
      if (path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "CHALLENGE_SET_REFERENCE_INVALID", `$.${field}.relative_path`, "Challenge policy references must remain repository-artifact-relative."));
      }
    }
  }

  if (type === "verifier-execution-evidence") {
    if (payload.evidence_sha256 !== verifierExecutionEvidenceDigest(payload)) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_DIGEST_INVALID", "$.evidence_sha256", "Execution evidence digest must match its canonical content."));
    }
    if (payload.builder_key_id === payload.verifier_key_id) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_SIGNER_CORRELATION", "$.builder_key_id", "Builder and verifier signatures require distinct keys."));
    }
    if (["0.2", "0.3"].includes(payload.schema_version) && !validClaims(payload.independence)) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_INDEPENDENCE_CLAIMS_INVALID", "$.independence", "Execution evidence v0.2 requires the complete observed failure-domain identity."));
    }
    const invocation = payload.invocation || {};
    if (!isValidDate(invocation.started_at) || !isValidDate(invocation.finished_at) ||
        !isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) ||
        Date.parse(invocation.finished_at) < Date.parse(invocation.started_at) ||
        Date.parse(payload.issued_at) < Date.parse(invocation.finished_at) ||
        Date.parse(payload.expires_at) <= Date.parse(payload.issued_at)) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_TIME_INVALID", "$.invocation", "Execution, issue, and expiry times must be ordered."));
    }
    const network = payload.execution && payload.execution.network_policy || {};
    if ((network.mode === "denied" && (network.allowed_endpoints || []).length !== 0) ||
        (network.mode === "allowlist" && (network.allowed_endpoints || []).length === 0)) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_NETWORK_POLICY_INVALID", "$.execution.network_policy", "Observed network policy must be internally consistent."));
    }
    const envelope = payload.envelope || {};
    const envelopePayload = strictBase64(envelope.payload);
    const signatures = envelope.signatures || [];
    if (signatures.length !== 2 || new Set(signatures.map(item => item.keyid)).size !== 2 ||
        !signatures.some(item => item.keyid === payload.builder_key_id) ||
        !signatures.some(item => item.keyid === payload.verifier_key_id)) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_DSSE_SIGNERS_INVALID", "$.envelope.signatures", "Execution evidence requires exactly one trusted-builder and one verifier signature."));
    }
    if (!envelopePayload) {
      issues.push(issue("critical", "EXECUTION_EVIDENCE_STATEMENT_INVALID", "$.envelope.payload", "Execution evidence must contain a strict base64 in-toto statement."));
    } else {
      try {
        const statement = JSON.parse(envelopePayload.toString("utf8"));
        const subject = Array.isArray(statement.subject) && statement.subject.length === 1 ? statement.subject[0] : {};
        const predicate = statement.predicate || {};
        const verifier = predicate.verifier || {};
        const expectedPredicateType = payload.schema_version === "0.3" ? EXECUTION_PREDICATE_TYPE_V3 :
          payload.schema_version === "0.2" ? EXECUTION_PREDICATE_TYPE_V2 : EXECUTION_PREDICATE_TYPE;
        if (statement._type !== "https://in-toto.io/Statement/v1" || statement.predicateType !== expectedPredicateType ||
            subject.name !== payload.subject_ref.artifact_id || !subject.digest || subject.digest.sha256 !== payload.subject_ref.sha256) {
          issues.push(issue("critical", "EXECUTION_EVIDENCE_STATEMENT_SUBJECT_INVALID", "$.envelope.payload", "The in-toto subject must bind the exact persisted receipt or report digest."));
        }
        if (predicate.trust_policy_id !== payload.trust_policy_id || verifier.id !== payload.verifier_id ||
            verifier.key_id !== payload.verifier_key_id || verifier.profile_id !== payload.profile_id ||
            verifier.purpose !== payload.purpose || !sameJson(predicate.repository_binding, payload.repository_binding) ||
            !sameJson(predicate.repository_state, payload.repository_state) ||
            !sameJson(predicate.verification_target, payload.verification_target) ||
            (["0.2", "0.3"].includes(payload.schema_version) && !sameJson(predicate.cannae_environment && predicate.cannae_environment.independence, payload.independence)) ||
            (payload.schema_version === "0.3" && !sameJson(predicate.native_provider_evidence_ref, payload.native_provider_evidence_ref))) {
          issues.push(issue("critical", "EXECUTION_EVIDENCE_STATEMENT_BINDING_INVALID", "$.envelope.payload", "The signed statement must bind policy, verifier, repository, purpose, and target fields exactly."));
        }
      } catch (error) {
        issues.push(issue("critical", "EXECUTION_EVIDENCE_STATEMENT_INVALID", "$.envelope.payload", "Execution evidence payload must be valid JSON."));
      }
    }
    if (payload.schema_version === "0.3") {
      const ref = payload.native_provider_evidence_ref || {};
      if (path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "EXECUTION_EVIDENCE_NATIVE_REFERENCE_INVALID", "$.native_provider_evidence_ref", "Native provider evidence references must remain repository-artifact-relative."));
      }
    } else if (payload.native_provider_evidence_ref !== undefined) {
      issues.push(issue("error", "EXECUTION_EVIDENCE_NATIVE_VERSION_INVALID", "$.native_provider_evidence_ref", "Native provider evidence requires execution-evidence schema v0.3."));
    }
  }

  if (type === "github-actions-oidc-trust-bundle") {
    if (payload.bundle_sha256 !== trustBundleDigest(payload)) {
      issues.push(issue("critical", "GITHUB_OIDC_TRUST_BUNDLE_DIGEST_INVALID", "$.bundle_sha256", "Trust-bundle digest must match the canonical artifact."));
    }
    const result = verifyGitHubActionsOIDCTrustBundle(payload, payload.source && payload.source.retrieved_at);
    for (const code of result.codes) {
      issues.push(issue("critical", code, "$", "GitHub Actions OIDC trust material failed semantic validation."));
    }
  }

  if (type === "github-actions-oidc-evidence") {
    if (payload.evidence_sha256 !== nativeEvidenceDigest(payload)) {
      issues.push(issue("critical", "GITHUB_OIDC_EVIDENCE_DIGEST_INVALID", "$.evidence_sha256", "Native OIDC evidence digest must match the canonical artifact."));
    }
    const parsed = parseCompactJwt(payload.compact_jwt);
    if (!parsed || crypto.createHash("sha256").update(payload.compact_jwt || "").digest("hex") !== payload.token_sha256) {
      issues.push(issue("critical", "GITHUB_OIDC_EVIDENCE_TOKEN_INVALID", "$.compact_jwt", "Native evidence must retain the exact compact JWT and its digest."));
    } else {
      const claims = parsed.claims;
      const projected = payload.provider_identity || {};
      const expectedClaims = Object.fromEntries(Object.keys(projected.claims || {}).map(key => [key, claims[key]]));
      if (!sameJson(payload.header, parsed.header) || projected.issuer !== claims.iss || projected.subject !== claims.sub ||
          projected.audience !== claims.aud || !sameJson(projected.claims, expectedClaims) ||
          !sameJson(payload.independence, deriveGitHubActionsIndependence(claims))) {
        issues.push(issue("critical", "GITHUB_OIDC_EVIDENCE_PROJECTION_INVALID", "$.provider_identity", "Native evidence projections must match the signed JWT claims exactly."));
      }
    }
  }

  if (type === "gitlab-ci-oidc-trust-bundle") {
    if (payload.bundle_sha256 !== gitlabTrustBundleDigest(payload)) {
      issues.push(issue("critical", "GITLAB_OIDC_TRUST_BUNDLE_DIGEST_INVALID", "$.bundle_sha256", "Trust-bundle digest must match the canonical artifact."));
    }
    const result = verifyGitLabCIOIDCTrustBundle(payload, payload.source && payload.source.retrieved_at);
    for (const code of result.codes) {
      issues.push(issue("critical", code, "$", "GitLab CI OIDC trust material failed semantic validation."));
    }
  }

  if (type === "gitlab-ci-oidc-evidence") {
    if (payload.evidence_sha256 !== gitlabNativeEvidenceDigest(payload)) {
      issues.push(issue("critical", "GITLAB_OIDC_EVIDENCE_DIGEST_INVALID", "$.evidence_sha256", "Native OIDC evidence digest must match the canonical artifact."));
    }
    const parsed = parseGitLabCompactJwt(payload.compact_jwt);
    if (!parsed || crypto.createHash("sha256").update(payload.compact_jwt || "").digest("hex") !== payload.token_sha256) {
      issues.push(issue("critical", "GITLAB_OIDC_EVIDENCE_TOKEN_INVALID", "$.compact_jwt", "Native evidence must retain the exact compact JWT and its digest."));
    } else {
      const claims = parsed.claims;
      const projected = payload.provider_identity || {};
      if (!sameJson(payload.header, parsed.header) || projected.issuer !== claims.iss || projected.subject !== claims.sub ||
          projected.audience !== claims.aud || !sameJson(projected.claims, projectedGitLabClaims(claims)) ||
          !sameJson(payload.independence, deriveGitLabCIIndependence(claims))) {
        issues.push(issue("critical", "GITLAB_OIDC_EVIDENCE_PROJECTION_INVALID", "$.provider_identity", "Native evidence projections must match the signed JWT claims exactly."));
      }
    }
  }

  if (type === "verifier-identity-evidence") {
    if (payload.evidence_sha256 !== identityEvidenceDigest(payload)) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_DIGEST_INVALID", "$.evidence_sha256", "Identity evidence digest must match its canonical content."));
    }
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.issued_at)) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_TIME_INVALID", "$.expires_at", "Identity evidence expiry must be later than issue time."));
    }
    const statement = payload.binding_statement || {};
    const expected = {
      schema_version: "0.1",
      type: "VerifierIdentityBinding",
      evidence_id: payload.id,
      verifier_id: payload.verifier_id,
      verifier_key_id: payload.signatures && payload.signatures.verifier_key_id,
      spiffe_id: payload.workload_identity && payload.workload_identity.spiffe_id,
      trust_root_id: payload.workload_identity && payload.workload_identity.trust_root_id,
      transparency_log_id: payload.transparency && payload.transparency.log_id,
      repository_binding: payload.repository_binding,
      purposes: payload.purposes,
      nonce: statement.nonce,
      issued_at: payload.issued_at,
      expires_at: payload.expires_at
    };
    if (!canonicalJsonBytes(statement).equals(canonicalJsonBytes(expected))) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_STATEMENT_MISMATCH", "$.binding_statement", "Signed identity statement must exactly bind all top-level policy, identity, repository, purpose, and time fields."));
    }
    try {
      const leaf = new crypto.X509Certificate(payload.workload_identity.leaf_certificate_pem);
      if (leaf.ca || parseSpiffeId(leaf) !== payload.workload_identity.spiffe_id || leaf.publicKey.asymmetricKeyType !== "ed25519" ||
          publicKeyId(leaf.publicKey) !== payload.signatures.workload_key_id) {
        issues.push(issue("critical", "IDENTITY_EVIDENCE_LEAF_CERTIFICATE_INVALID", "$.workload_identity.leaf_certificate_pem", "Leaf certificate must be a non-CA Ed25519 certificate with exactly the bound SPIFFE URI SAN."));
      }
    } catch (error) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_LEAF_CERTIFICATE_INVALID", "$.workload_identity.leaf_certificate_pem", "Leaf certificate must be valid X.509 PEM."));
    }
    const workloadSignature = payload.signatures && strictBase64(payload.signatures.workload_signature_base64);
    const verifierSignature = payload.signatures && strictBase64(payload.signatures.verifier_signature_base64);
    if (!workloadSignature || !verifierSignature) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_SIGNATURE_ENCODING_INVALID", "$.signatures", "Identity signatures must use strict canonical base64 encoding."));
    }
    try {
      const expectedEntry = canonicalJsonBytes(transparencyEntry(payload));
      const suppliedEntry = strictBase64(payload.transparency.canonicalized_entry_base64);
      if (!suppliedEntry || !suppliedEntry.equals(expectedEntry) || payload.transparency.leaf_hash !== merkleLeafHash(expectedEntry)) {
        issues.push(issue("critical", "IDENTITY_EVIDENCE_TRANSPARENCY_ENTRY_INVALID", "$.transparency", "Transparency entry and leaf hash must bind the certificate, statement, and both signatures."));
      }
    } catch (error) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_TRANSPARENCY_ENTRY_INVALID", "$.transparency", "Transparency entry must be parseable and canonically bound."));
    }
    const transparency = payload.transparency || {};
    const checkpoint = transparency.checkpoint || {};
    if (checkpoint.log_id !== transparency.log_id || checkpoint.tree_size !== transparency.tree_size ||
        !isValidDate(checkpoint.issued_at) || (isValidDate(payload.issued_at) && Date.parse(checkpoint.issued_at) < Date.parse(payload.issued_at)) ||
        (isValidDate(payload.expires_at) && Date.parse(checkpoint.issued_at) >= Date.parse(payload.expires_at))) {
      issues.push(issue("critical", "IDENTITY_EVIDENCE_CHECKPOINT_BINDING_INVALID", "$.transparency.checkpoint", "Checkpoint must bind the same log and tree and fall inside the evidence validity window."));
    }
  }

  if (type === "sigstore-trusted-root") {
    const result = verifySigstoreTrustedRoot(payload);
    for (const code of result.codes) {
      issues.push(issue("critical", code, "$", "Sigstore TrustedRoot must be normalized, complete, source-attributed, and digest-valid."));
    }
  }

  if (type === "sigstore-verifier-identity-evidence") {
    if (payload.evidence_sha256 !== sigstoreEvidenceDigest(payload)) {
      issues.push(issue("critical", "SIGSTORE_IDENTITY_EVIDENCE_DIGEST_INVALID", "$.evidence_sha256", "Sigstore identity evidence digest must match its canonical content."));
    }
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.issued_at)) {
      issues.push(issue("critical", "SIGSTORE_IDENTITY_EVIDENCE_TIME_INVALID", "$.expires_at", "Sigstore identity evidence expiry must be later than issue time."));
    }
    if (!canonicalJsonBytes(payload.binding_statement || {}).equals(canonicalJsonBytes(expectedSigstoreIdentityStatement(payload)))) {
      issues.push(issue("critical", "SIGSTORE_IDENTITY_EVIDENCE_STATEMENT_MISMATCH", "$.binding_statement", "Sigstore and static signatures must bind the same policy, identity, repository, purpose, nonce, root, and validity statement."));
    }
    if (!strictBase64(payload.signatures && payload.signatures.verifier_signature_base64)) {
      issues.push(issue("critical", "SIGSTORE_IDENTITY_EVIDENCE_SIGNATURE_ENCODING_INVALID", "$.signatures.verifier_signature_base64", "Static verifier signature must use strict canonical base64."));
    }
    try {
      const normalized = normalizeBundle(payload.sigstore.bundle);
      if (!canonicalJsonBytes(normalized).equals(canonicalJsonBytes(payload.sigstore.bundle)) ||
          payload.sigstore.bundle_media_type !== normalized.mediaType ||
          payload.sigstore.bundle_sha256 !== crypto.createHash("sha256").update(canonicalJsonBytes(normalized)).digest("hex")) {
        issues.push(issue("critical", "SIGSTORE_IDENTITY_EVIDENCE_BUNDLE_BINDING_INVALID", "$.sigstore", "Bundle media type, normalized bytes, and digest must match."));
      }
    } catch (error) {
      issues.push(issue("critical", "SIGSTORE_IDENTITY_EVIDENCE_BUNDLE_INVALID", "$.sigstore.bundle", "Sigstore bundle must parse under the pinned official library."));
    }
  }

  if (type === "verification-attestation") {
    if (payload.attestation_sha256 !== attestationDigest(payload)) {
      issues.push(issue("critical", "ATTESTATION_DIGEST_INVALID", "$.attestation_sha256", "Attestation digest must match the complete signed envelope and bindings."));
    }
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.issued_at)) {
      issues.push(issue("critical", "ATTESTATION_TIME_INVALID", "$.expires_at", "Attestation expiry must be later than issue time."));
    }
    if (path.isAbsolute(payload.receipt_relative_path || "") || String(payload.receipt_relative_path || "").split(/[\\/]+/).includes("..")) {
      issues.push(issue("critical", "ATTESTATION_RECEIPT_PATH_INVALID", "$.receipt_relative_path", "Attestation receipt paths must remain repository-artifact-relative."));
    }
    if (payload.schema_version === "0.2") {
      const ref = payload.execution_evidence_ref;
      if (!ref || path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "ATTESTATION_EXECUTION_EVIDENCE_REFERENCE_INVALID", "$.execution_evidence_ref", "Attestation v0.2 requires an exact repository-artifact-relative execution evidence reference."));
      }
    } else if (payload.execution_evidence_ref !== undefined) {
      issues.push(issue("error", "ATTESTATION_EXECUTION_EVIDENCE_VERSION_INVALID", "$.execution_evidence_ref", "Execution evidence references require attestation schema v0.2."));
    }
    let statement = null;
    try { statement = JSON.parse(Buffer.from(payload.envelope.payload, "base64").toString("utf8")); } catch (error) { /* reported below */ }
    const subject = statement && Array.isArray(statement.subject) && statement.subject.length === 1 ? statement.subject[0] : {};
    const predicate = (statement && statement.predicate) || {};
    const receipt = predicate.receipt || {};
    const verifier = predicate.verifier || {};
    if (!statement || statement._type !== "https://in-toto.io/Statement/v1" ||
        statement.predicateType !== "https://cannae.dev/attestations/verification-receipt/v0.3") {
      issues.push(issue("critical", "ATTESTATION_STATEMENT_INVALID", "$.envelope.payload", "DSSE payload must contain the Cannae verification in-toto statement."));
    } else if (predicate.schema_version !== payload.schema_version ||
        (payload.schema_version === "0.2" && !sameJson(predicate.execution_evidence_ref, payload.execution_evidence_ref)) ||
        subject.name !== payload.receipt_id || !subject.digest || subject.digest.sha256 !== payload.receipt_sha256 ||
        receipt.id !== payload.receipt_id || receipt.relative_path !== payload.receipt_relative_path ||
        receipt.campaign_id !== payload.campaign_id || receipt.mission_id !== payload.mission_id ||
        receipt.cycle_number !== payload.cycle_number || receipt.candidate_id !== payload.candidate_id ||
        receipt.candidate_revision !== payload.candidate_revision || verifier.id !== payload.verifier_id || verifier.key_id !== payload.key_id ||
        verifier.independence_group !== payload.independence_group || verifier.execution_origin !== payload.execution_origin ||
        verifier.invocation_id !== payload.invocation_id || predicate.issued_at !== payload.issued_at || predicate.expires_at !== payload.expires_at ||
        JSON.stringify(predicate.repository_binding) !== JSON.stringify(payload.repository_binding)) {
      issues.push(issue("critical", "ATTESTATION_STATEMENT_BINDING_MISMATCH", "$.envelope.payload", "Signed statement fields must exactly match the exposed attestation bindings."));
    }
    if (!payload.envelope || !Array.isArray(payload.envelope.signatures) || payload.envelope.signatures.length !== 1 ||
        payload.envelope.signatures[0].keyid !== payload.key_id) {
      issues.push(issue("critical", "ATTESTATION_SIGNATURE_BINDING_INVALID", "$.envelope.signatures", "Attestation must contain exactly one signature from its declared key."));
    }
  }

  if (type === "comparative-evaluation-attestation") {
    if (payload.attestation_sha256 !== comparativeAttestationDigest(payload)) {
      issues.push(issue("critical", "COMPARATIVE_ATTESTATION_DIGEST_INVALID", "$.attestation_sha256", "Comparative attestation digest must match its envelope and exposed bindings."));
    }
    if (!isValidDate(payload.issued_at) || !isValidDate(payload.expires_at) || Date.parse(payload.expires_at) <= Date.parse(payload.issued_at)) {
      issues.push(issue("critical", "COMPARATIVE_ATTESTATION_TIME_INVALID", "$.expires_at", "Comparative attestation expiry must be later than issue time."));
    }
    if (path.isAbsolute(payload.report_relative_path || "") || String(payload.report_relative_path || "").split(/[\\/]+/).includes("..")) {
      issues.push(issue("critical", "COMPARATIVE_ATTESTATION_REPORT_PATH_INVALID", "$.report_relative_path", "Attested report paths must remain repository-artifact-relative."));
    }
    if (payload.schema_version === "0.2") {
      const ref = payload.execution_evidence_ref;
      if (!ref || path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "COMPARATIVE_ATTESTATION_EXECUTION_EVIDENCE_REFERENCE_INVALID", "$.execution_evidence_ref", "Comparative attestation v0.2 requires an exact execution evidence reference."));
      }
    } else if (payload.execution_evidence_ref !== undefined) {
      issues.push(issue("error", "COMPARATIVE_ATTESTATION_EXECUTION_EVIDENCE_VERSION_INVALID", "$.execution_evidence_ref", "Execution evidence references require comparative attestation schema v0.2."));
    }
    let statement = null;
    try { statement = JSON.parse(Buffer.from(payload.envelope.payload, "base64").toString("utf8")); } catch (error) { /* reported below */ }
    const subject = statement && Array.isArray(statement.subject) && statement.subject.length === 1 ? statement.subject[0] : {};
    const predicate = (statement && statement.predicate) || {};
    const report = predicate.report || {};
    const subjects = predicate.subjects || {};
    const baseline = subjects.baseline || {};
    const candidate = subjects.candidate || {};
    const evaluator = predicate.evaluator || {};
    const verifier = predicate.verifier || {};
    if (!statement || statement._type !== "https://in-toto.io/Statement/v1" || statement.predicateType !== COMPARATIVE_PREDICATE_TYPE) {
      issues.push(issue("critical", "COMPARATIVE_ATTESTATION_STATEMENT_INVALID", "$.envelope.payload", "DSSE payload must contain the Cannae comparative-report in-toto statement."));
    } else if (predicate.schema_version !== payload.schema_version ||
        (payload.schema_version === "0.2" && !sameJson(predicate.execution_evidence_ref, payload.execution_evidence_ref)) ||
        subject.name !== payload.report_id || !subject.digest || subject.digest.sha256 !== payload.report_sha256 ||
        report.id !== payload.report_id || report.relative_path !== payload.report_relative_path ||
        report.report_sha256 !== payload.report_content_sha256 || report.plan_id !== payload.plan_id ||
        report.evaluation_set_id !== payload.evaluation_set_id || report.campaign_id !== payload.campaign_id ||
        report.mission_id !== payload.mission_id || report.cycle_number !== payload.cycle_number || report.target_type !== payload.target_type ||
        baseline.candidate_id !== payload.baseline_candidate_id || baseline.revision !== payload.baseline_revision ||
        candidate.candidate_id !== payload.candidate_id || candidate.revision !== payload.candidate_revision ||
        evaluator.id !== payload.evaluator_id || evaluator.invocation_id !== payload.evaluator_invocation_id ||
        verifier.id !== payload.verifier_id || verifier.key_id !== payload.key_id || verifier.independence_group !== payload.independence_group ||
        verifier.execution_origin !== payload.execution_origin || verifier.invocation_id !== payload.invocation_id ||
        predicate.issued_at !== payload.issued_at || predicate.expires_at !== payload.expires_at ||
        JSON.stringify(predicate.repository_binding) !== JSON.stringify(payload.repository_binding)) {
      issues.push(issue("critical", "COMPARATIVE_ATTESTATION_STATEMENT_BINDING_MISMATCH", "$.envelope.payload", "Signed comparative statement fields must exactly match the exposed attestation bindings."));
    }
    if (!payload.envelope || !Array.isArray(payload.envelope.signatures) || payload.envelope.signatures.length !== 1 ||
        payload.envelope.signatures[0].keyid !== payload.key_id) {
      issues.push(issue("critical", "COMPARATIVE_ATTESTATION_SIGNATURE_BINDING_INVALID", "$.envelope.signatures", "Comparative attestation must contain exactly one signature from its declared key."));
    }
  }

  if (type === "self-improvement-decision") {
    if (payload.release_authorized !== false) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_SELF_RELEASE", "$.release_authorized", "The improvement controller cannot authorize merge, push, or external release."));
    }
    if (["escalate", "terminate", "complete"].includes(payload.decision) && payload.execution_authorized === true) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_DECISION_EXECUTION_MISMATCH", "$.execution_authorized", "Escalation, termination, and completion decisions cannot authorize candidate execution."));
    }
    if (payload.decision !== "rollback" && payload.blocking_codes && payload.blocking_codes.length > 0 && payload.execution_authorized === true) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_BLOCKED_EXECUTION", "$.blocking_codes", "A decision with blocking codes cannot authorize candidate execution."));
    }
    if (payload.human_decision_required === true && /^none$/i.test(String(payload.required_human_decision || ""))) {
      issues.push(issue("error", "SELF_IMPROVEMENT_HUMAN_DECISION_UNSPECIFIED", "$.required_human_decision", "Human escalation must state the required decision."));
    }
    if (payload.decision === "accept_working_state" && (payload.execution_authorized !== true || payload.promotion_scope === "none")) {
      issues.push(issue("error", "SELF_IMPROVEMENT_ACCEPT_WITHOUT_PROMOTION", "$", "An accepted working state must authorize a bounded promotion scope."));
    }
    if (["accept_working_state", "complete"].includes(payload.decision) && /^none$/i.test(String(payload.accepted_revision || ""))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_ACCEPTED_REVISION_MISSING", "$.accepted_revision", "Promoted states must identify the exact accepted revision."));
    }
    if (payload.decision === "accept_working_state" && !hasSubstantiveItems(payload.proof && payload.proof.verification_receipt_ids)) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_DECISION_WITHOUT_PROOF", "$.proof.verification_receipt_ids", "Accepted working states require verified receipt IDs."));
    }
    if (["0.3", "0.4"].includes(payload.schema_version) && ["accept_working_state", "complete"].includes(payload.decision) &&
        (!(payload.proof && payload.proof.attestation_quorum_satisfied === true) ||
         !hasSubstantiveItems(payload.proof && payload.proof.verification_attestation_ids) ||
         !hasSubstantiveItems(payload.proof && payload.proof.verifier_key_ids) ||
         !hasSubstantiveItems(payload.proof && payload.proof.verifier_independence_groups))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_DECISION_WITHOUT_SIGNED_QUORUM", "$.proof", "v0.3+ promotion and completion decisions require a satisfied signed verifier quorum."));
    }
    if (payload.schema_version === "0.4" && ["accept_working_state", "complete"].includes(payload.decision) &&
        payload.proof && payload.proof.comparative_evaluation_report_id !== "none" &&
        (payload.proof.comparative_attestation_quorum_satisfied !== true ||
         !hasSubstantiveItems(payload.proof.comparative_evaluation_attestation_ids) ||
         !hasSubstantiveItems(payload.proof.comparative_verifier_key_ids) ||
         !hasSubstantiveItems(payload.proof.comparative_verifier_independence_groups))) {
      issues.push(issue("critical", "SELF_IMPROVEMENT_DECISION_WITHOUT_COMPARATIVE_SIGNED_QUORUM", "$.proof", "v0.4 comparative promotion and completion decisions require a signed report quorum."));
    }
  }

  if (type === "self-improvement-cycle-order") {
    const ready = payload.status === "ready";
    const parent = payload.parent_decision_ref || {};
    const sourceCheckpoint = payload.source_checkpoint_ref || {};
    const sourceDecision = payload.source_decision_ref || {};
    const proof = payload.proof_requirements || {};
    const admission = payload.trust_policy_admission || {};
    if (payload.release_authorized !== false) {
      issues.push(issue("critical", "CYCLE_ORDER_SELF_RELEASE", "$.release_authorized", "A campaign cycle order cannot authorize merge, push, or release."));
    }
    if (ready !== (payload.execution_authorized === true)) {
      issues.push(issue("critical", "CYCLE_ORDER_EXECUTION_STATUS_MISMATCH", "$.execution_authorized", "Only a ready cycle order may authorize bounded execution."));
    }
    if (ready && hasSubstantiveItems(payload.blocking_codes)) {
      issues.push(issue("critical", "CYCLE_ORDER_BLOCKED_EXECUTION", "$.blocking_codes", "A ready cycle order cannot carry blocking codes."));
    }
    if (!ready && payload.transition !== "hold") {
      issues.push(issue("error", "CYCLE_ORDER_NONREADY_TRANSITION", "$.transition", "A non-ready cycle order must hold execution."));
    }
    if (payload.status === "blocked" && payload.human_decision_required !== true) {
      issues.push(issue("error", "CYCLE_ORDER_BLOCK_WITHOUT_HUMAN_DECISION", "$.human_decision_required", "A blocked cycle order must identify a human or corrective decision."));
    }
    if (payload.human_decision_required === true && /^none$/i.test(String(payload.required_human_decision || ""))) {
      issues.push(issue("error", "CYCLE_ORDER_HUMAN_DECISION_UNSPECIFIED", "$.required_human_decision", "A human-held order must state the required decision."));
    }
    if (payload.transition === "start" &&
        (!(parent.decision_id === "none" && parent.relative_path === "none" && parent.sha256 === "none") ||
         !(sourceCheckpoint.artifact_id === "none" && sourceCheckpoint.relative_path === "none" && sourceCheckpoint.sha256 === "none") ||
         !(sourceDecision.artifact_id === "none" && sourceDecision.relative_path === "none" && sourceDecision.sha256 === "none"))) {
      issues.push(issue("critical", "CYCLE_ORDER_START_WITH_HISTORY", "$", "A start order cannot claim a parent, checkpoint, or source decision."));
    }
    if (["advance", "before_completion"].includes(payload.transition) &&
        (parent.decision_id === "none" || sourceCheckpoint.artifact_id === "none" || sourceDecision.artifact_id === "none")) {
      issues.push(issue("critical", "CYCLE_ORDER_ADVANCE_WITHOUT_ACCEPTED_PARENT", "$", "An advancing order requires exact checkpoint, decision, and accepted-parent references."));
    }
    if (payload.transition === "before_completion" && payload.checkpoint_trigger !== "before_completion") {
      issues.push(issue("error", "CYCLE_ORDER_COMPLETION_TRIGGER_MISMATCH", "$.checkpoint_trigger", "The completion transition must require a before-completion checkpoint."));
    }
    if (proof.signed_attestation_required === true &&
        (!(proof.minimum_valid_attestations >= 2) || !(proof.minimum_independence_groups >= 2) ||
         proof.require_distinct_key_ids !== true || !proof.trust_policy_ref || proof.trust_policy_ref.artifact_id === "none")) {
      issues.push(issue("critical", "CYCLE_ORDER_SIGNED_QUORUM_UNDERSPECIFIED", "$.proof_requirements", "A signed cycle order requires a distinct-key, multi-group quorum and an exact trust-policy reference."));
    }
    if (proof.signed_attestation_required === false &&
        (proof.minimum_valid_attestations !== 0 || proof.minimum_independence_groups !== 0 ||
         proof.require_distinct_key_ids !== false || !proof.trust_policy_ref || proof.trust_policy_ref.artifact_id !== "none")) {
      issues.push(issue("error", "CYCLE_ORDER_UNSIGNED_PROOF_MISMATCH", "$.proof_requirements", "An unsigned campaign order must not claim signed-quorum requirements."));
    }
    if (proof.signed_comparative_attestation_required === true && proof.signed_attestation_required !== true) {
      issues.push(issue("critical", "CYCLE_ORDER_COMPARATIVE_QUORUM_UNDERSPECIFIED", "$.proof_requirements", "Signed comparative evidence requires the campaign trust policy and signed receipt quorum."));
    }
    if (payload.schema_version === "0.1" && payload.trust_policy_admission !== undefined) {
      issues.push(issue("error", "CYCLE_ORDER_V01_ADMISSION_UNSUPPORTED", "$.trust_policy_admission", "Trust-policy admission evidence requires cycle-order schema version 0.2."));
    }
    if (["0.2", "0.3", "0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version)) {
      const receipt = admission.receipt_quorum || {};
      const comparative = admission.comparative_quorum || {};
      const requirements = admission.effective_requirements || {};
      const admissionTrustRef = admission.trust_policy_ref || {};
      const proofTrustRef = proof.trust_policy_ref || {};
      const sameTrustRef = admissionTrustRef.artifact_id === proofTrustRef.artifact_id &&
        admissionTrustRef.relative_path === proofTrustRef.relative_path &&
        admissionTrustRef.sha256 === proofTrustRef.sha256;
      const quorumCountsMatch = quorum =>
        quorum.eligible_verifier_count === (quorum.verifier_ids || []).length &&
        quorum.distinct_key_count === (quorum.key_ids || []).length &&
        quorum.independence_group_count === (quorum.independence_groups || []).length;
      const quorumSatisfied = quorum => quorum.required !== true ||
        (quorum.eligible_verifier_count >= requirements.minimum_valid_attestations &&
         quorum.independence_group_count >= requirements.minimum_independence_groups &&
         (requirements.require_distinct_key_ids !== true || quorum.distinct_key_count >= requirements.minimum_valid_attestations));
      const requiredAssurancesSatisfied = payload.schema_version !== "0.7" ||
        Boolean(admission.transparency_assurance && admission.transparency_assurance.satisfied === true);
      const expectedSatisfied = (admission.blocking_codes || []).length === 0 && quorumSatisfied(receipt) &&
        quorumSatisfied(comparative) && requiredAssurancesSatisfied;

      if (admission.required !== proof.signed_attestation_required || receipt.required !== proof.signed_attestation_required ||
          comparative.required !== proof.signed_comparative_attestation_required || !sameTrustRef) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_REQUIREMENT_MISMATCH", "$.trust_policy_admission", "Admission purpose and trust-policy bindings must exactly match the cycle-order proof requirements."));
      }
      if (requirements.minimum_valid_attestations < proof.minimum_valid_attestations ||
          requirements.minimum_independence_groups < proof.minimum_independence_groups ||
          (proof.require_distinct_key_ids === true && requirements.require_distinct_key_ids !== true)) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_THRESHOLD_WEAKENED", "$.trust_policy_admission.effective_requirements", "Admission may strengthen but cannot weaken the campaign quorum."));
      }
      if (!quorumCountsMatch(receipt) || !quorumCountsMatch(comparative)) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_COUNT_MISMATCH", "$.trust_policy_admission", "Admission counts must equal their distinct evidence lists."));
      }
      if (admission.satisfied !== expectedSatisfied || receipt.satisfied !== quorumSatisfied(receipt) ||
          comparative.satisfied !== quorumSatisfied(comparative)) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_FALSE_SATISFACTION", "$.trust_policy_admission", "Admission satisfaction must be derived from its effective thresholds, distinct identities, keys, groups, and blocking codes."));
      }
      if (payload.generated_at !== admission.evaluated_at) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_TIME_MISMATCH", "$.trust_policy_admission.evaluated_at", "Admission must be evaluated at the exact cycle-order issuance time."));
      }
      if (admission.required === true && admission.satisfied === true &&
          (!isValidDate(admission.valid_until) || Date.parse(admission.valid_until) <= Date.parse(admission.evaluated_at))) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_WINDOW_INVALID", "$.trust_policy_admission.valid_until", "A satisfied trust admission must expire after its evaluation time."));
      }
      if (admission.required === false &&
          (admission.satisfied !== true || admission.valid_until !== "none" ||
           requirements.minimum_valid_attestations !== 0 || requirements.minimum_independence_groups !== 0 ||
           requirements.require_distinct_key_ids !== false || admission.trust_policy_ref.artifact_id !== "none")) {
        issues.push(issue("error", "CYCLE_ORDER_UNSIGNED_ADMISSION_MISMATCH", "$.trust_policy_admission", "An unsigned campaign requires an explicit satisfied no-op admission with no trust policy or quorum."));
      }
      if (ready && (admission.satisfied !== true || (admission.required === true && admission.valid_until === "none"))) {
        issues.push(issue("critical", "CYCLE_ORDER_WITHOUT_TRUST_ADMISSION", "$.trust_policy_admission", "A ready cycle order requires a satisfied, time-bounded trust-policy admission."));
      }
      if (ready && (admission.blocking_codes || []).some(code => !(payload.blocking_codes || []).includes(code))) {
        issues.push(issue("critical", "CYCLE_ORDER_ADMISSION_BLOCK_NOT_PROPAGATED", "$.blocking_codes", "Ready execution cannot discard a trust-admission blocking code."));
      }
      if (["0.3", "0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version)) {
        const identity = admission.identity_assurance || {};
        const evidence = identity.evidence || [];
        const verifierIds = evidence.map(item => item.verifier_id);
        const genericIdentity = ["0.4", "0.5", "0.6", "0.7"].includes(payload.schema_version);
        const trustDomains = evidence.map(item => item.trust_domain).filter(Boolean);
        const identityAuthorities = evidence.map(item => item.identity_authority).filter(Boolean);
        const logIds = evidence.flatMap(item => item.transparency_log_ids || [item.transparency_log_id]).filter(Boolean);
        const uniqueVerifierIds = new Set(verifierIds);
        const expectedIdentitySatisfied = identity.required !== true ||
          ((identity.blocking_codes || []).length === 0 && receipt.satisfied === true && comparative.satisfied === true);
        if (!admission.identity_assurance) {
          issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_ADMISSION_REQUIRED", "$.trust_policy_admission.identity_assurance", "Cycle-order v0.3 requires an explicit workload identity admission projection."));
        } else {
          if (identity.authenticated_verifier_count !== evidence.length || uniqueVerifierIds.size !== evidence.length ||
              identity.distinct_trust_domain_count !== new Set(trustDomains).size ||
              (genericIdentity && identity.distinct_identity_authority_count !== new Set(identityAuthorities).size) ||
              identity.transparency_log_count !== new Set(logIds).size) {
            issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_COUNT_MISMATCH", "$.trust_policy_admission.identity_assurance", "Identity admission counts must equal its distinct evidence bindings."));
          }
          const expectedIdentityScope = payload.schema_version === "0.7"
            ? "continuously_transparent_failure_domain_verified_fresh_challenged_workload_and_policy_eligibility"
            : payload.schema_version === "0.6"
            ? "failure_domain_verified_fresh_challenged_workload_and_policy_eligibility"
            : payload.schema_version === "0.5" ? "fresh_challenged_workload_and_policy_eligibility"
            : "authenticated_workload_and_policy_eligibility";
          if (identity.satisfied !== expectedIdentitySatisfied || (identity.required === true && admission.assurance_scope !== expectedIdentityScope) ||
              (identity.required !== true && admission.assurance_scope !== "policy_eligibility_only")) {
            issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_FALSE_SATISFACTION", "$.trust_policy_admission.identity_assurance", "Identity satisfaction and assurance scope must be derived from authenticated workload evidence."));
          }
          const evidenceByVerifier = new Map(evidence.map(item => [item.verifier_id, item]));
          const receiptBindingsValid = (receipt.verifier_ids || []).every(id => evidenceByVerifier.has(id) && evidenceByVerifier.get(id).purposes.includes("verification_receipt"));
          const comparativeBindingsValid = (comparative.verifier_ids || []).every(id => evidenceByVerifier.has(id) && evidenceByVerifier.get(id).purposes.includes("comparative_evaluation_report"));
          if (identity.required === true && (!receiptBindingsValid || !comparativeBindingsValid)) {
            issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_PURPOSE_BINDING_INVALID", "$.trust_policy_admission.identity_assurance.evidence", "Every verifier counted for a purpose quorum requires matching authenticated identity evidence."));
          }
          for (const [index, item] of evidence.entries()) {
            const ref = item.evidence_ref || {};
            if (ref.artifact_id === "none" || path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..")) {
              issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_REFERENCE_INVALID", `$.trust_policy_admission.identity_assurance.evidence[${index}].evidence_ref`, "Identity evidence must cite an exact repository-artifact-relative manifest reference."));
            }
            if (!isValidDate(item.issued_at) || !isValidDate(item.valid_until) ||
                Date.parse(item.issued_at) > Date.parse(admission.evaluated_at) || Date.parse(item.valid_until) <= Date.parse(admission.evaluated_at) ||
                (isValidDate(admission.valid_until) && Date.parse(admission.valid_until) > Date.parse(item.valid_until))) {
              issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_WINDOW_INVALID", `$.trust_policy_admission.identity_assurance.evidence[${index}]`, "Identity evidence must be active at admission and bound the admission validity window."));
            }
          }
          if (identity.required !== true && (identity.satisfied !== true || evidence.length !== 0 ||
              identity.authenticated_verifier_count !== 0 || identity.distinct_trust_domain_count !== 0 ||
              (genericIdentity && identity.distinct_identity_authority_count !== 0) ||
              identity.transparency_log_count !== 0 || (identity.blocking_codes || []).length !== 0)) {
            issues.push(issue("error", "CYCLE_ORDER_IDENTITY_NOOP_MISMATCH", "$.trust_policy_admission.identity_assurance", "A policy-only admission requires an explicit empty, satisfied identity no-op."));
          }
          if ((identity.blocking_codes || []).some(code => !(admission.blocking_codes || []).includes(code))) {
            issues.push(issue("critical", "CYCLE_ORDER_IDENTITY_BLOCK_NOT_PROPAGATED", "$.trust_policy_admission.blocking_codes", "Identity-admission blocking codes must propagate to the trust admission."));
          }
        }
      }
      if (["0.5", "0.6", "0.7"].includes(payload.schema_version)) {
        const challenge = admission.challenge_assurance || {};
        const responses = challenge.responses || [];
        const responderIds = responses.map(item => item.verifier_id);
        const responseByVerifier = new Map(responses.map(item => [item.verifier_id, item]));
        const expectedChallengeSatisfied = challenge.required === true &&
          (challenge.blocking_codes || []).length === 0 && receipt.satisfied === true && comparative.satisfied === true;
        if (!admission.challenge_assurance) {
          issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_ADMISSION_REQUIRED", "$.trust_policy_admission.challenge_assurance", "Cycle-order v0.5 requires an explicit pre-dispatch challenge projection."));
        } else {
          if (challenge.responder_count !== responses.length || new Set(responderIds).size !== responses.length) {
            issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_RESPONSE_COUNT_MISMATCH", "$.trust_policy_admission.challenge_assurance", "Challenge responder counts must equal distinct response evidence bindings."));
          }
          if (challenge.satisfied !== expectedChallengeSatisfied || challenge.required !== true) {
            issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_FALSE_SATISFACTION", "$.trust_policy_admission.challenge_assurance", "Challenge satisfaction requires a valid response from every verifier counted in each required quorum."));
          }
          if (challenge.satisfied === true && (challenge.challenge_ref || {}).artifact_id === "none") {
            issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_REFERENCE_INVALID", "$.trust_policy_admission.challenge_assurance.challenge_ref", "Satisfied challenge admission requires an exact challenge-set reference."));
          }
          const requiredResponders = new Set([...(receipt.verifier_ids || []), ...(comparative.verifier_ids || [])]);
          if ([...requiredResponders].some(id => !responseByVerifier.has(id))) {
            issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_PURPOSE_BINDING_INVALID", "$.trust_policy_admission.challenge_assurance.responses", "Every verifier counted in a required quorum must have a challenge response."));
          }
          for (const [index, response] of responses.entries()) {
            const ref = response.identity_evidence_ref || {};
            if (path.isAbsolute(ref.relative_path || "") || String(ref.relative_path || "").split(/[\\/]+/).includes("..") ||
                !isValidDate(response.responded_at) || (isValidDate(challenge.issued_at) && Date.parse(response.responded_at) < Date.parse(challenge.issued_at)) ||
                (isValidDate(challenge.valid_until) && Date.parse(response.responded_at) >= Date.parse(challenge.valid_until))) {
              issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_RESPONSE_INVALID", `$.trust_policy_admission.challenge_assurance.responses[${index}]`, "Challenge responses require an exact identity-evidence reference inside the challenge window."));
            }
          }
          if ((challenge.blocking_codes || []).some(code => !(admission.blocking_codes || []).includes(code))) {
            issues.push(issue("critical", "CYCLE_ORDER_CHALLENGE_BLOCK_NOT_PROPAGATED", "$.trust_policy_admission.blocking_codes", "Challenge-admission blocking codes must propagate to trust admission."));
          }
        }
      }
      if (["0.6", "0.7"].includes(payload.schema_version)) {
        const independence = admission.independence_assurance || {};
        const bindings = independence.bindings || [];
        const domains = independence.domains || [];
        const trustPolicyId = admissionTrustRef.artifact_id;
        const profiles = [...new Map(bindings.map(binding => [binding.profile_id, {
          id: binding.profile_id,
          independence: binding.claims
        }])).values()];
        const projected = computeVerifierIndependence({
          schema_version: payload.schema_version,
          id: trustPolicyId,
          independence_assurance: {
            required: true,
            correlation_rule: "shared_required_component",
            required_dimensions: independence.required_dimensions,
            minimum_independent_domains: independence.minimum_independent_domains
          },
          quorum: { minimum_independence_groups: requirements.minimum_independence_groups },
          verifiers: bindings.map(binding => ({ id: binding.verifier_id, status: "active" }))
        }, {
          schema_version: "0.2",
          type: "VerifierRuntimePolicy",
          id: "VRP-projection",
          trust_policy_id: trustPolicyId,
          profiles,
          assignments: bindings.map(binding => ({ verifier_id: binding.verifier_id, profile_id: binding.profile_id }))
        });
        const bindingIds = bindings.map(binding => binding.verifier_id);
        const domainIds = new Set(domains.map(domain => domain.domain_id));
        const allQuorumBindings = [...(receipt.verifier_ids || []), ...(comparative.verifier_ids || [])];
        const bindingByVerifier = new Map(bindings.map(binding => [binding.verifier_id, binding]));
        const quorumDomainsMatch = allQuorumBindings.every(verifierId => {
          const binding = bindingByVerifier.get(verifierId);
          const quorums = [receipt, comparative].filter(quorum => (quorum.verifier_ids || []).includes(verifierId));
          return binding && quorums.every(quorum => (quorum.independence_groups || []).includes(binding.domain_id));
        });
        if (!admission.independence_assurance || !exactDimensions(independence.required_dimensions) ||
            independence.required !== true || new Set(bindingIds).size !== bindings.length ||
            independence.domain_count !== domains.length || !domains.every(domain => domainIds.has(domain.domain_id)) ||
            !sameJson(domains, projected.domains) || !sameJson(bindings, projected.bindings)) {
          issues.push(issue("critical", "CYCLE_ORDER_INDEPENDENCE_PROJECTION_INVALID", "$.trust_policy_admission.independence_assurance", "Cycle-order v0.6+ must reproduce the runtime-policy correlation graph and its deterministic failure domains exactly."));
        }
        if (independence.minimum_independent_domains !== projected.minimum_independent_domains ||
            independence.satisfied !== projected.satisfied ||
            !sameJson(independence.blocking_codes || [], projected.blocking_codes) || !quorumDomainsMatch) {
          issues.push(issue("critical", "CYCLE_ORDER_INDEPENDENCE_FALSE_SATISFACTION", "$.trust_policy_admission.independence_assurance", "Independence satisfaction and quorum groups must derive from verified failure-domain bindings."));
        }
        if ((independence.blocking_codes || []).some(code => !(admission.blocking_codes || []).includes(code))) {
          issues.push(issue("critical", "CYCLE_ORDER_INDEPENDENCE_BLOCK_NOT_PROPAGATED", "$.trust_policy_admission.blocking_codes", "Independence blocking codes must propagate to trust admission."));
        }
      }
      if (payload.schema_version === "0.7") {
        const transparency = admission.transparency_assurance || {};
        const policyRef = transparency.policy_ref || {};
        const stateRef = transparency.state_ref || {};
        const exactScope = "continuously_transparent_failure_domain_verified_fresh_challenged_workload_and_policy_eligibility";
        const validRefs = policyRef.artifact_id && policyRef.artifact_id !== "none" &&
          stateRef.artifact_id && stateRef.artifact_id !== "none" &&
          !path.isAbsolute(policyRef.relative_path || "") && !String(policyRef.relative_path || "").split(/[\\/]+/).includes("..") &&
          !path.isAbsolute(stateRef.relative_path || "") && !String(stateRef.relative_path || "").split(/[\\/]+/).includes("..");
        const expectedTransparencySatisfied = transparency.required === true && validRefs &&
          Number.isInteger(transparency.sequence_number) && transparency.sequence_number >= 1 &&
          Number.isInteger(transparency.max_state_age_seconds) && transparency.max_state_age_seconds >= 60 &&
          isValidDate(transparency.generated_at) && Date.parse(transparency.generated_at) <= Date.parse(admission.evaluated_at) &&
          Date.parse(admission.evaluated_at) - Date.parse(transparency.generated_at) <= transparency.max_state_age_seconds * 1000 &&
          (transparency.blocking_codes || []).length === 0 && isValidDate(transparency.valid_until) &&
          Date.parse(transparency.valid_until) > Date.parse(admission.evaluated_at);
        if (!admission.transparency_assurance || transparency.required !== true ||
            transparency.satisfied !== expectedTransparencySatisfied || admission.assurance_scope !== exactScope) {
          issues.push(issue("critical", "CYCLE_ORDER_TRANSPARENCY_FALSE_SATISFACTION", "$.trust_policy_admission.transparency_assurance", "Cycle-order v0.7 transparency satisfaction requires exact policy/state references, a current state window, and no transparency blockers."));
        }
        if (transparency.satisfied === true && isValidDate(admission.valid_until) &&
            Date.parse(admission.valid_until) > Date.parse(transparency.valid_until)) {
          issues.push(issue("critical", "CYCLE_ORDER_TRANSPARENCY_WINDOW_INVALID", "$.trust_policy_admission.valid_until", "Transparency state expiry must bound the overall trust-admission window."));
        }
        if ((transparency.blocking_codes || []).some(code => !(admission.blocking_codes || []).includes(code))) {
          issues.push(issue("critical", "CYCLE_ORDER_TRANSPARENCY_BLOCK_NOT_PROPAGATED", "$.trust_policy_admission.blocking_codes", "Transparency blocking codes must propagate to the trust admission."));
        }
      }
    }
  }

  if (type === "annex") {
    if (payload.intent_impact === "changes") {
      issues.push(issue("critical", "ANNEX_CHANGES_INTENT", "$.intent_impact", "Annex cannot change OPORD intent; use FRAGO scope change."));
    }
    if (payload.authority_impact === "changes") {
      issues.push(issue("critical", "ANNEX_CHANGES_AUTHORITY", "$.authority_impact", "Annex cannot change authority boundary; use FRAGO or approval scope update."));
    }
    if (!hasSubstantiveItems(payload.outputs)) {
      issues.push(issue("warning", "ANNEX_WITHOUT_OUTPUTS", "$.outputs", "Annex should state role-specific outputs."));
    }
    if (!hasSubstantiveItems(payload.verification)) {
      issues.push(issue("error", "ANNEX_WITHOUT_VERIFICATION", "$.verification", "Annex should define verification for its specialist plan."));
    }
    if (payload.classification === "restricted" && !payload.releasability) {
      issues.push(issue("error", "RESTRICTED_ANNEX_WITHOUT_RELEASABILITY", "$.releasability", "Restricted annex must define releasability."));
    }
  }

  if (type === "frago-scope-change") {
    if (!hasSubstantiveItems(payload.changed_elements)) {
      issues.push(issue("critical", "FRAGO_SCOPE_WITHOUT_CHANGED_ELEMENTS", "$.changed_elements", "FRAGO scope change must identify changed mission elements."));
    }
    if (!hasSubstantiveItems((payload.scope_changes || []).map(item => item.rationale))) {
      issues.push(issue("critical", "FRAGO_SCOPE_WITHOUT_CHANGE_DETAILS", "$.scope_changes", "FRAGO scope change must state previous, revised, and rationale for changes."));
    }
    if ((payload.changed_elements || []).includes("authority_boundary") && isEmptyArray(payload.authority_changes)) {
      issues.push(issue("critical", "AUTHORITY_CHANGE_WITHOUT_AUTHORITY_DETAILS", "$.authority_changes", "Authority boundary change must include authority change details."));
    }
    if (!hasSubstantiveItems(payload.affected_roles)) {
      issues.push(issue("error", "FRAGO_SCOPE_WITHOUT_AFFECTED_ROLES", "$.affected_roles", "FRAGO scope change must list affected roles for dissemination."));
    }
    if (payload.requires_backbrief !== true) {
      issues.push(issue("critical", "FRAGO_SCOPE_WITHOUT_BACKBRIEF", "$.requires_backbrief", "Scope-changing FRAGO requires backbrief to prevent distorted execution."));
    }
    if (payload.requires_rehearsal !== true) {
      issues.push(issue("error", "FRAGO_SCOPE_WITHOUT_REHEARSAL", "$.requires_rehearsal", "Scope-changing FRAGO should require rehearsal before execution."));
    }
    if (!payload.not_an_annex_update_reason || payload.not_an_annex_update_reason.length < 1) {
      issues.push(issue("error", "FRAGO_SCOPE_WITHOUT_ANNEX_BOUNDARY_REASON", "$.not_an_annex_update_reason", "FRAGO scope change must explain why this is not merely an annex update."));
    }
    if (payload.issued_by !== "COMMANDER" && (payload.changed_elements || []).includes("authority_boundary")) {
      issues.push(issue("critical", "AUTHORITY_FRAGO_REQUIRES_COMMANDER", "$.issued_by", "Authority boundary change requires Commander issue or approval."));
    }
  }

  if (type === "model-registry") {
    const profiles = payload.profiles || [];
    const profileIds = new Set();
    const registryTime = Date.parse(payload.created_at);

    if (/^(latest|current|default)$/i.test(String(payload.registry_version || "").trim())) {
      issues.push(issue("critical", "MODEL_REGISTRY_FLOATING_VERSION", "$.registry_version", "Registry versions must identify an immutable snapshot."));
    }

    for (const [index, profile] of profiles.entries()) {
      const pointer = `$.profiles[${index}]`;
      if (profileIds.has(profile.id)) {
        issues.push(issue("critical", "MODEL_REGISTRY_DUPLICATE_PROFILE", `${pointer}.id`, "Model registry profile IDs must be unique."));
      }
      profileIds.add(profile.id);
      for (const field of ["model_version", "harness_version", "system_prompt_version", "tool_schema_version"]) {
        if (/^(latest|current|default)$/i.test(String(profile[field] || "").trim())) {
          issues.push(issue("critical", "MODEL_REGISTRY_FLOATING_IDENTITY", `${pointer}.${field}`, "Registry identity fields must use immutable versions."));
        }
      }
      if (/api[_-]?key|token|password|private[_-]?key|plaintext[_-]?secret/i.test(String(profile.endpoint_ref || ""))) {
        issues.push(issue("critical", "MODEL_REGISTRY_SECRET_IN_ENDPOINT_REF", `${pointer}.endpoint_ref`, "Endpoint references must not contain credentials or secret values."));
      }
      const tasks = new Set();
      for (const [taskIndex, readiness] of (profile.task_readiness || []).entries()) {
        const taskPointer = `${pointer}.task_readiness[${taskIndex}]`;
        if (tasks.has(readiness.task)) {
          issues.push(issue("error", "MODEL_REGISTRY_DUPLICATE_TASK_READINESS", `${taskPointer}.task`, "A profile may have only one readiness record per task."));
        }
        tasks.add(readiness.task);
        if (["T", "P"].includes(readiness.readiness_rating) && !hasSubstantiveItems(readiness.evidence)) {
          issues.push(issue("critical", "MODEL_REGISTRY_READY_WITHOUT_EVIDENCE", `${taskPointer}.evidence`, "T/P readiness requires substantive evaluation evidence."));
        }
        if (!isValidDate(readiness.evaluated_at) || !isValidDate(readiness.expires_at) || !isBefore(readiness.evaluated_at, readiness.expires_at)) {
          issues.push(issue("critical", "MODEL_REGISTRY_INVALID_EVALUATION_WINDOW", taskPointer, "Readiness evaluation must expire after it was evaluated."));
        }
        if (["T", "P"].includes(readiness.readiness_rating) && !Number.isNaN(registryTime) && Date.parse(readiness.expires_at) <= registryTime) {
          issues.push(issue("critical", "MODEL_REGISTRY_EXPIRED_READINESS", `${taskPointer}.expires_at`, "Expired readiness cannot remain T/P in the active registry."));
        }
      }
    }
    if (!payload.governance || !["S4", "COS", "COMMANDER"].includes(payload.governance.owner_role)) {
      issues.push(issue("error", "MODEL_REGISTRY_INVALID_OWNER", "$.governance.owner_role", "Model registry governance must be owned by sustainment or command authority."));
    }
    if (!payload.governance || payload.governance.human_final_decision_authority !== true) {
      issues.push(issue("critical", "MODEL_REGISTRY_HUMAN_AUTHORITY_MISSING", "$.governance.human_final_decision_authority", "Registry governance must preserve human final decision authority."));
    }
  }

  if (type === "model-assignment-request") {
    const mission = payload.mission_profile || {};
    const billets = payload.billet_requirements || [];
    const weights = payload.selection_policy && payload.selection_policy.weights;
    const highImpact = ["high", "critical"].includes(mission.risk_level)
      || mission.roe_class === "Red"
      || ["final_output", "external_release"].includes(mission.release_target)
      || mission.tool_impact === "irreversible_mutation";
    const billetIds = new Set();

    if (/^(latest|current|default)$/i.test(String(payload.registry_version || "").trim())) {
      issues.push(issue("critical", "MODEL_REQUEST_REGISTRY_VERSION_FLOATING", "$.registry_version", "Assignment requests must target an immutable registry snapshot."));
    }

    if (weights && Object.values(weights).reduce((sum, value) => sum + value, 0) !== 100) {
      issues.push(issue("critical", "MODEL_REQUEST_WEIGHTS_NOT_100", "$.selection_policy.weights", "Selection weights must total 100."));
    }
    if (payload.classification !== mission.classification) {
      issues.push(issue("critical", "MODEL_REQUEST_CLASSIFICATION_MISMATCH", "$.classification", "Request and mission profile classifications must match."));
    }
    if (mission.roe_class === "Black") {
      issues.push(issue("critical", "MODEL_REQUEST_BLACK_PROHIBITED", "$.mission_profile.roe_class", "Black missions cannot be compiled into executable model assignments."));
    }
    for (const [index, billet] of billets.entries()) {
      const pointer = `$.billet_requirements[${index}]`;
      if (billetIds.has(billet.id)) {
        issues.push(issue("error", "MODEL_REQUEST_DUPLICATE_BILLET", `${pointer}.id`, "Billet requirement IDs must be unique."));
      }
      billetIds.add(billet.id);
      if (!["T", "P"].includes(billet.required_readiness)) {
        issues.push(issue("critical", "MODEL_REQUEST_UNREADY_TARGET", `${pointer}.required_readiness`, "Executable billet requirements must target T or P readiness."));
      }
      if ((CLASSIFICATION_RANK[billet.context_scope] ?? 99) > (CLASSIFICATION_RANK[mission.classification] ?? -1)) {
        issues.push(issue("critical", "MODEL_REQUEST_CONTEXT_EXCEEDS_MISSION", `${pointer}.context_scope`, "Billet context cannot exceed the mission classification."));
      }
      if (["command", "sof", "assurance"].includes(billet.force_class) && billet.fallback_depth < 2) {
        issues.push(issue("critical", "MODEL_REQUEST_CRITICAL_BILLET_WITHOUT_DEPTH", `${pointer}.fallback_depth`, "Command, SOF, and assurance billets require alternate and contingency depth."));
      }
    }
    if (!hasSubstantiveItems(payload.constraints && payload.constraints.allowed_deployment_boundaries)) {
      issues.push(issue("critical", "MODEL_REQUEST_WITHOUT_DEPLOYMENT_BOUNDARY", "$.constraints.allowed_deployment_boundaries", "Assignment request requires approved deployment boundaries."));
    }
    const routerBillet = billets.find(item => item.task === (payload.constraints && payload.constraints.router_task));
    if (!routerBillet || !["T", "P"].includes(payload.constraints && payload.constraints.router_required_readiness)) {
      issues.push(issue("critical", "MODEL_REQUEST_WITHOUT_READY_ROUTER", "$.constraints", "Assignment request requires a T/P router billet."));
    }
    if (highImpact && !billets.some(item => item.force_class === "command" || item.force_class === "sof")) {
      issues.push(issue("critical", "MODEL_REQUEST_MISSING_COMMAND", "$.billet_requirements", "High-impact assignment requires command or SOF integration."));
    }
    if (highImpact && (!payload.assurance || payload.assurance.required !== true)) {
      issues.push(issue("critical", "MODEL_REQUEST_REQUIRES_ASSURANCE", "$.assurance.required", "High-impact assignment requires independent assurance."));
    }
    if (payload.assurance && payload.assurance.required === true && !billets.some(item => item.force_class === "assurance")) {
      issues.push(issue("critical", "MODEL_REQUEST_MISSING_ASSURANCE_BILLET", "$.billet_requirements", "Required assurance needs an assurance billet."));
    }
    if (payload.assurance && payload.assurance.required === true && !hasSubstantiveItems(payload.assurance.deterministic_checks)) {
      issues.push(issue("critical", "MODEL_REQUEST_WITHOUT_DETERMINISTIC_CHECKS", "$.assurance.deterministic_checks", "Assurance requires deterministic checks."));
    }
    if (!payload.authority || payload.authority.inherited_from_model !== false) {
      issues.push(issue("critical", "MODEL_REQUEST_AUTHORITY_FROM_MODEL", "$.authority.inherited_from_model", "Model capability cannot create authority."));
    }
    if (!payload.authority || payload.authority.human_final_decision_authority !== true || !hasSubstantiveItems(payload.authority.commander_retained_decisions)) {
      issues.push(issue("critical", "MODEL_REQUEST_HUMAN_AUTHORITY_MISSING", "$.authority", "Human final decision authority and retained decisions are required."));
    }
  }

  if (type === "integrated-mission-preflight") {
    const pathFields = ["model_registry_path", "model_assignment_request_path", "routing_bundle_path"];
    for (const field of pathFields) {
      const value = payload[field];
      if (typeof value !== "string" || path.isAbsolute(value) || value.split(/[\\/]+/).includes("..")) {
        issues.push(issue("critical", "INTEGRATED_PREFLIGHT_PATH_TRAVERSAL", `$.${field}`, "Integrated preflight paths must stay inside the repository."));
      }
    }
    const bindings = payload.agent_bindings || [];
    for (const [field, code] of [
      ["agent_id", "INTEGRATED_PREFLIGHT_DUPLICATE_AGENT"],
      ["billet_id", "INTEGRATED_PREFLIGHT_DUPLICATE_BILLET"],
      ["routing_receipt_id", "INTEGRATED_PREFLIGHT_DUPLICATE_RECEIPT"]
    ]) {
      const values = bindings.map(item => item[field]);
      if (new Set(values).size !== values.length) {
        issues.push(issue("critical", code, "$.agent_bindings", `Integrated preflight ${field} bindings must be one-to-one.`));
      }
    }
    const controls = payload.dispatch_controls || {};
    if (controls.require_ready_routing !== true || controls.require_ready_model_assignment !== true) {
      issues.push(issue("critical", "INTEGRATED_PREFLIGHT_BYPASS", "$.dispatch_controls", "Routing and model assignment must both be ready before dispatch."));
    }
    if (controls.human_final_decision_authority !== true) {
      issues.push(issue("critical", "INTEGRATED_PREFLIGHT_HUMAN_AUTHORITY_MISSING", "$.dispatch_controls.human_final_decision_authority", "Integrated preflight must preserve human final decision authority."));
    }
  }

  if (type === "model-usage-event") {
    for (const field of ["registry_version", "model_version", "harness_version", "system_prompt_version", "tool_schema_version"]) {
      if (/^(latest|current|default)$/i.test(String(payload[field] || "").trim())) {
        issues.push(issue("critical", "MODEL_USAGE_FLOATING_VERSION", `$.${field}`, "Usage telemetry requires immutable model, harness, prompt, and tool-schema versions."));
      }
    }
    if (!hasSubstantiveItems(payload.authority_scope_snapshot)) {
      issues.push(issue("critical", "MODEL_USAGE_WITHOUT_AUTHORITY_SNAPSHOT", "$.authority_scope_snapshot", "Usage telemetry must preserve the dispatched authority scope."));
    }
    if (!hasSubstantiveItems(payload.evidence) || (payload.evidence || []).every(item => /self[- ]?(approval|confidence)|model self/i.test(item))) {
      issues.push(issue("critical", "MODEL_USAGE_WITHOUT_EXTERNAL_EVIDENCE", "$.evidence", "Usage telemetry requires routing, preflight, test, or other external evidence."));
    }
    if (["failed", "blocked"].includes(payload.event_type) && !hasSubstantiveItems(payload.failure_codes)) {
      issues.push(issue("error", "MODEL_USAGE_FAILURE_WITHOUT_CODE", "$.failure_codes", "Failed or blocked usage events require failure codes."));
    }
    if (["escalated", "fallback_activated"].includes(payload.event_type)) {
      if (!payload.previous_profile_id || !payload.next_profile_id || payload.previous_profile_id === payload.next_profile_id) {
        issues.push(issue("critical", "MODEL_USAGE_INVALID_TRANSITION", "$", "Escalation and fallback events require distinct previous and next profiles."));
      }
    }
  }

  if (type === "repository-artifact-manifest") {
    const repository = payload.repository || {};
    const expectedNamespace = `repositories/${repository.key || "missing"}`;
    const artifacts = payload.artifacts || [];
    if (payload.namespace_root !== expectedNamespace) {
      issues.push(issue("critical", "REPOSITORY_ARTIFACT_NAMESPACE_MISMATCH", "$.namespace_root", "Manifest namespace must match the repository identity key."));
    }
    if (payload.artifact_count !== artifacts.length) {
      issues.push(issue("error", "REPOSITORY_ARTIFACT_COUNT_MISMATCH", "$.artifact_count", "Manifest artifact_count must match the artifact entry count."));
    }
    if (!Number.isInteger(payload.manifest_revision) || payload.manifest_revision < artifacts.length) {
      issues.push(issue("error", "REPOSITORY_ARTIFACT_REVISION_INVALID", "$.manifest_revision", "Manifest revision must be monotonic and cannot be lower than the retained artifact count."));
    }
    if (!payload.isolation || payload.isolation.cross_process_manifest_lock !== true || payload.isolation.stale_lock_recovery_fail_closed !== true ||
        payload.isolation.cross_process_manifest_lease !== true || payload.isolation.fencing_tokens !== true || payload.isolation.write_ahead_journal !== true) {
      issues.push(issue("critical", "REPOSITORY_ARTIFACT_CONCURRENCY_GUARD_MISSING", "$.isolation", "Repository artifact manifests require a lease, fencing tokens, write-ahead journal, and fail-closed recovery."));
    }
    if (!payload.coordination || !Number.isInteger(payload.coordination.fencing_token) || payload.coordination.fencing_token < 1) {
      issues.push(issue("critical", "REPOSITORY_ARTIFACT_FENCING_TOKEN_MISSING", "$.coordination", "Manifest commits require a positive fencing token from the committing lease."));
    }
    const integrity = payload.integrity || {};
    if (!Number.isInteger(integrity.history_start_revision) || !Number.isInteger(integrity.history_length) ||
        integrity.history_start_revision + integrity.history_length - 1 !== payload.manifest_revision) {
      issues.push(issue("error", "REPOSITORY_ARTIFACT_HISTORY_RANGE_INVALID", "$.integrity", "Manifest history start and length must terminate at the current revision."));
    }
    if (integrity.pending_transaction_count !== 0) {
      issues.push(issue("critical", "REPOSITORY_ARTIFACT_PENDING_TRANSACTION", "$.integrity.pending_transaction_count", "A committed manifest cannot claim pending transactions."));
    }
    if (integrity.canonical_manifest_sha256 !== canonicalDigestWithout(payload, ["integrity", "canonical_manifest_sha256"])) {
      issues.push(issue("critical", "REPOSITORY_ARTIFACT_MANIFEST_DIGEST_INVALID", "$.integrity.canonical_manifest_sha256", "Manifest canonical digest does not match its content."));
    }
    const paths = new Set();
    for (const [index, artifact] of artifacts.entries()) {
      const pointer = `$.artifacts[${index}].relative_path`;
      const relativePath = String(artifact.relative_path || "").replace(/\\/g, "/");
      if (path.isAbsolute(relativePath) || /^[A-Za-z]:\//.test(relativePath) || relativePath.split("/").includes("..")) {
        issues.push(issue("critical", "REPOSITORY_ARTIFACT_PATH_TRAVERSAL", pointer, "Artifact paths must be relative and cannot traverse namespaces."));
      }
      const expectedPrefix = `${expectedNamespace}/missions/${artifact.mission_id}/${artifact.wave_id}/${artifact.kind}/`;
      if (!relativePath.startsWith(expectedPrefix)) {
        issues.push(issue("critical", "REPOSITORY_ARTIFACT_CROSS_REPOSITORY_PATH", pointer, "Every artifact path must remain inside its repository, mission, wave, and kind namespace."));
      }
      if (path.posix.basename(relativePath) !== artifact.file_name || !String(artifact.file_name || "").startsWith(`${artifact.artifact_id}.`)) {
        issues.push(issue("error", "REPOSITORY_ARTIFACT_ID_PATH_MISMATCH", pointer, "Artifact filename must match file_name and begin with artifact_id."));
      }
      if (paths.has(relativePath)) {
        issues.push(issue("error", "REPOSITORY_ARTIFACT_DUPLICATE_PATH", pointer, "Manifest artifact paths must be unique."));
      }
      paths.add(relativePath);
    }
  }

  if (type === "model-force-assignment-plan") {
    const mission = payload.mission_profile || {};
    const profiles = payload.model_profiles || [];
    const billets = payload.billets || [];
    const routing = payload.routing_policy || {};
    const assurance = payload.assurance || {};
    const pace = payload.pace || {};
    const authority = payload.authority || {};
    const profileById = new Map();

    for (const [index, profile] of profiles.entries()) {
      const pointer = `$.model_profiles[${index}]`;
      if (profileById.has(profile.id)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_DUPLICATE_PROFILE", `${pointer}.id`, "Model profile IDs must be unique."));
      }
      profileById.set(profile.id, profile);
      if (/^(latest|current|default)$/i.test(String(profile.model_version || "").trim())) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_FLOATING_VERSION", `${pointer}.model_version`, "Mission assignment requires an immutable model version."));
      }
      if (!hasSubstantiveItems(profile.evidence)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_WITHOUT_EVIDENCE", `${pointer}.evidence`, "Every model profile requires task-relevant readiness evidence."));
      }
    }

    for (const [index, billet] of billets.entries()) {
      const pointer = `$.billets[${index}]`;
      const profile = profileById.get(billet.model_profile_id);
      if (!profile) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_UNKNOWN_PROFILE", `${pointer}.model_profile_id`, "Billet references an unknown model profile."));
        continue;
      }
      if (profile.availability === "unavailable") {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_UNAVAILABLE_PROFILE", `${pointer}.model_profile_id`, "Unavailable model profile cannot fill an active billet."));
      }
      if (!(profile.evaluated_tasks || []).includes(billet.task)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_TASK_NOT_EVALUATED", `${pointer}.task`, "Billet task is outside the model profile's evaluated METL."));
      }
      if (!(profile.force_classes || []).includes(billet.force_class)) {
        issues.push(issue("error", "MODEL_ASSIGNMENT_FORCE_CLASS_MISMATCH", `${pointer}.force_class`, "Model profile is not qualified for the billet force class."));
      }
      if ((READINESS_RANK[profile.readiness_rating] ?? -1) < (READINESS_RANK[billet.required_readiness] ?? 99)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_INSUFFICIENT_READINESS", `${pointer}.required_readiness`, "Model profile does not meet billet readiness requirement."));
      }
      if (!(profile.allowed_context_classes || []).includes(billet.context_scope)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_CONTEXT_INELIGIBLE", `${pointer}.context_scope`, "Model profile is not approved for the billet context class."));
      }
      for (const [fallbackIndex, fallbackId] of (billet.fallback_profile_ids || []).entries()) {
        const fallbackPointer = `${pointer}.fallback_profile_ids[${fallbackIndex}]`;
        const fallback = profileById.get(fallbackId);
        if (!fallback) {
          issues.push(issue("error", "MODEL_ASSIGNMENT_UNKNOWN_FALLBACK", `${pointer}.fallback_profile_ids[${fallbackIndex}]`, "Fallback references an unknown model profile."));
          continue;
        }
        if (fallbackId === billet.model_profile_id) {
          issues.push(issue("critical", "MODEL_ASSIGNMENT_SELF_FALLBACK", fallbackPointer, "A billet fallback must differ from its primary profile."));
        }
        if (fallback.availability === "unavailable") {
          issues.push(issue("critical", "MODEL_ASSIGNMENT_FALLBACK_UNAVAILABLE", fallbackPointer, "Unavailable profile cannot serve as a fallback."));
        }
        if (!(fallback.evaluated_tasks || []).includes(billet.task) || !(fallback.force_classes || []).includes(billet.force_class)) {
          issues.push(issue("critical", "MODEL_ASSIGNMENT_FALLBACK_NOT_QUALIFIED", fallbackPointer, "Fallback must be evaluated for the billet task and force class."));
        }
        if ((READINESS_RANK[fallback.readiness_rating] ?? -1) < READINESS_RANK.P) {
          issues.push(issue("critical", "MODEL_ASSIGNMENT_FALLBACK_UNREADY", fallbackPointer, "Fallback must have at least P readiness."));
        }
        if (!(fallback.allowed_context_classes || []).includes(billet.context_scope)) {
          issues.push(issue("critical", "MODEL_ASSIGNMENT_FALLBACK_CONTEXT_INELIGIBLE", fallbackPointer, "Fallback is not approved for the billet context class."));
        }
      }
      if (["command", "sof", "assurance"].includes(billet.force_class) && (billet.fallback_profile_ids || []).length < 2) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_CRITICAL_BILLET_WITHOUT_DEPTH", `${pointer}.fallback_profile_ids`, "Command, SOF, and assurance billets require alternate and contingency profiles."));
      }
    }

    const routerProfile = profileById.get(routing.router_profile_id);
    if (!routerProfile) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_UNKNOWN_ROUTER", "$.routing_policy.router_profile_id", "Routing policy references an unknown model profile."));
    }
    if (!["T", "P"].includes(routing.router_readiness) || (routerProfile && !["T", "P"].includes(routerProfile.readiness_rating))) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_ROUTER_UNREADY", "$.routing_policy.router_readiness", "Router must be T or P before it assigns mission work."));
    }
    if (!hasSubstantiveItems(routing.held_out_evaluation)) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_ROUTER_WITHOUT_HELD_OUT_EVAL", "$.routing_policy.held_out_evaluation", "Router requires held-out, task-relevant evaluation evidence."));
    }
    const acceptanceEvidence = (routing.acceptance_evidence || []).map(item => String(item).trim());
    if (!hasSubstantiveItems(acceptanceEvidence) || acceptanceEvidence.every(item => /confidence|self[- ]?report/i.test(item))) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_CONFIDENCE_ONLY", "$.routing_policy.acceptance_evidence", "Model verbal confidence cannot be the only acceptance evidence."));
    }

    const assuranceRequired = ["high", "critical"].includes(mission.risk_level)
      || mission.roe_class === "Red"
      || ["final_output", "external_release"].includes(mission.release_target)
      || mission.tool_impact === "irreversible_mutation";
    if (assuranceRequired && assurance.required !== true) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_REQUIRES_ASSURANCE", "$.assurance.required", "Mission risk, release, or tool impact requires independent assurance."));
    }
    if (assurance.required === true) {
      const assuranceProfile = profileById.get(assurance.independent_profile_id);
      if (!assuranceProfile || !(assuranceProfile.force_classes || []).includes("assurance")) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_INVALID_ASSURANCE_PROFILE", "$.assurance.independent_profile_id", "Independent assurance requires an assurance-qualified model profile."));
      }
      if (!billets.some(billet => billet.force_class === "assurance" && billet.model_profile_id === assurance.independent_profile_id)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_ASSURANCE_PROFILE_NOT_BILLETED", "$.assurance.independent_profile_id", "Independent assurance profile must fill the assurance billet."));
      }
      const primaryProfile = profileById.get(pace.primary_profile_id);
      if (assurance.different_model_family_required === true && assuranceProfile && primaryProfile && assuranceProfile.model_family === primaryProfile.model_family) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_CORRELATED_ASSURANCE", "$.assurance.independent_profile_id", "Independent assurance must use a different model family from the primary profile."));
      }
      if (!hasSubstantiveItems(assurance.deterministic_checks)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_WITHOUT_DETERMINISTIC_CHECKS", "$.assurance.deterministic_checks", "Independent assurance requires deterministic checks."));
      }
    }

    const paceIds = [pace.primary_profile_id, pace.alternate_profile_id, pace.contingency_profile_id];
    for (const [index, profileId] of paceIds.entries()) {
      if (!profileById.has(profileId)) {
        issues.push(issue("critical", "MODEL_ASSIGNMENT_UNKNOWN_PACE_PROFILE", `$.pace.${["primary_profile_id", "alternate_profile_id", "contingency_profile_id"][index]}`, "PACE references an unknown model profile."));
      }
    }
    if (new Set(paceIds).size !== paceIds.length) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_PACE_NOT_DISTINCT", "$.pace", "Primary, alternate, and contingency profiles must be distinct."));
    }
    const paceProfiles = paceIds.map(profileId => profileById.get(profileId)).filter(Boolean);
    const pacePrimaryTasks = new Set((paceProfiles[0] && paceProfiles[0].evaluated_tasks) || []);
    if (paceProfiles.some(profile => (READINESS_RANK[profile.readiness_rating] ?? -1) < READINESS_RANK.P
      || !(profile.allowed_context_classes || []).includes(mission.classification))
      || paceProfiles.slice(1).some(profile => !(profile.evaluated_tasks || []).some(task => pacePrimaryTasks.has(task)))) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_PACE_NOT_TASK_READY", "$.pace", "Every PACE profile must be P/T ready, context eligible, and share evaluated mission coverage."));
    }

    if (authority.inherited_from_model !== false) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_AUTHORITY_FROM_MODEL", "$.authority.inherited_from_model", "Model capability must never create or expand authority."));
    }
    if (authority.human_final_decision_authority !== true || !hasSubstantiveItems(authority.commander_retained_decisions)) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_HUMAN_AUTHORITY_MISSING", "$.authority", "The human Commander must retain final decisions and explicit retained authorities."));
    }
    if (mission.roe_class === "Black") {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_BLACK_PROHIBITED", "$.mission_profile.roe_class", "Black actions cannot receive an executable model assignment."));
    }
    if (assuranceRequired && !billets.some(billet => billet.force_class === "command" || billet.force_class === "sof")) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_MISSING_COMMAND", "$.billets", "High-impact missions require command or SOF integration capacity."));
    }
    if (routing.default_strategy === "sof_composition" && new Set(billets.map(billet => billet.model_profile_id)).size < 3) {
      issues.push(issue("critical", "MODEL_ASSIGNMENT_FORCE_MONOCULTURE", "$.billets", "SOF composition requires distinct command, execution, and assurance capacity."));
    }
  }

  if (type === "information-report") {
    const ccir = payload.related_ccir || [];
    if ((payload.operational_relevance === "order_change" || payload.operational_relevance === "report_up") && isEmptyArray(ccir)) {
      issues.push(issue("critical", "INFORMATION_RELEVANT_WITHOUT_CCIR", "$.related_ccir", "Information that changes orders or must be reported up requires CCIR classification."));
    }
    if (payload.operational_relevance === "order_change" && payload.recommended_handling !== "frago_review" && payload.recommended_handling !== "decision_packet") {
      issues.push(issue("critical", "ORDER_CHANGE_NOT_ROUTED_TO_DECISION", "$.recommended_handling", "Order-changing information must route to FRAGO review or decision packet."));
    }
    if (payload.eefi_risk === true && !ccir.includes("EEFI")) {
      issues.push(issue("critical", "EEFI_INFORMATION_WITHOUT_EEFI_CCIR", "$.related_ccir", "Information with EEFI risk must be classified as EEFI."));
    }
    if (payload.eefi_risk === true && payload.recommended_handling !== "suppress_raw") {
      issues.push(issue("critical", "EEFI_INFORMATION_WITHOUT_SUPPRESSION", "$.recommended_handling", "EEFI-risk information must suppress raw propagation."));
    }
    if ((payload.source_reliability === "unverified" || payload.source_reliability === "unknown") && payload.operational_relevance === "order_change") {
      issues.push(issue("error", "UNVERIFIED_INFORMATION_CANNOT_CHANGE_ORDER", "$.source_reliability", "Unverified information cannot directly drive order change."));
    }
  }

  if (type === "intelligence-assessment") {
    const outputs = payload.recommended_outputs || [];
    if (outputs.includes("FRAGO_SCOPE_CHANGE") && payload.operational_impact !== "frago_scope_change") {
      issues.push(issue("error", "FRAGO_OUTPUT_WITHOUT_FRAGO_IMPACT", "$.operational_impact", "FRAGO output requires frago_scope_change operational impact."));
    }
    if (outputs.includes("FRAGO_SCOPE_CHANGE") && payload.confidence !== "high") {
      issues.push(issue("critical", "LOW_CONFIDENCE_FRAGO", "$.confidence", "Low or medium confidence assessment cannot directly recommend FRAGO scope change."));
    }
    if ((payload.operational_impact === "frago_scope_change" || payload.operational_impact === "decision_packet") && payload.commander_decision_required !== true) {
      issues.push(issue("critical", "OPERATIONAL_CHANGE_WITHOUT_COMMANDER_DECISION", "$.commander_decision_required", "Operational change or decision packet impact requires commander decision."));
    }
    if ((payload.operational_impact === "frago_scope_change" || payload.operational_impact === "decision_packet") && !hasSubstantiveItems(payload.ccir_classification)) {
      issues.push(issue("critical", "ASSESSMENT_CHANGE_WITHOUT_CCIR", "$.ccir_classification", "Operationally relevant assessment must include CCIR classification."));
    }
    if (payload.confidence === "low" && !hasSubstantiveItems(payload.information_gaps)) {
      issues.push(issue("warning", "LOW_CONFIDENCE_WITHOUT_GAPS", "$.information_gaps", "Low confidence assessment should state information gaps."));
    }
    if (payload.operational_impact === "release_block" && !payload.ccir_classification.includes("EEFI")) {
      issues.push(issue("critical", "RELEASE_BLOCK_WITHOUT_EEFI", "$.ccir_classification", "Release block impact should include EEFI classification."));
    }
  }

  if (type === "sitrep") {
    if (payload.blocked && payload.blocked.length > 0 && (!payload.ccir || payload.ccir.length === 0)) {
      issues.push(issue("error", "BLOCKED_WITHOUT_ESCALATION", "$.ccir", "Blocked SITREP should include CCIR or decision request."));
    }
  }

  return issues;
}

function maxSeverity(issues) {
  const order = ["info", "warning", "error", "critical"];
  return issues.reduce((max, item) => order.indexOf(item.severity) > order.indexOf(max) ? item.severity : max, "info");
}

function validationResult(issues, type, payload) {
  const severity = maxSeverity(issues);
  return {
    valid: !issues.some(item => item.severity === "error" || item.severity === "critical"),
    can_execute: !Object.hasOwn(require("../native-training-producer").SCHEMAS, type) && !Object.hasOwn(require("../native-training-transfer-contract").SCHEMAS, type) && !Object.hasOwn(require("../native-training-product-contract").SCHEMAS, type) && !Object.hasOwn(require("../training-session-contract").SCHEMAS, type) && !DRAFT_TYPES.has(type) && !ADOPTION_TYPES.has(type) && !REVISION_TYPES.has(type) && !INTENT_TYPES.has(type) && !METHOD_TYPES.has(type) && !METHOD_CONTROL_TYPES.has(type) && !ISSUANCE_TYPES.has(type) &&
      !COP_TYPES.has(type) && !require("../force-registry-contract").TYPES.has(type) && !Object.hasOwn(require("../task-training-contract").SCHEMAS, type) && !["frago", "frago-scope-change", "workload-control-input", "workload-policy-assessment", "workload-control-receipt", "github-release-independent-verification", "codex-model-selection"].includes(type) &&
      !(type === "mission-wave-plan" && payload?.schema_version === "0.2") &&
      type !== "readiness-event" && type !== "readiness-drop-reconciliation" && type !== "agent-context-pack" && type !== "agent-dispatch-lease" && type !== "operator-consent-record" && !RECONCILIATION_TYPES.has(type) && !MODEL_RECONCILIATION_TYPES.has(type) && !ANALYSIS_RECONCILIATION_TYPES.has(type) && !MODEL_EVALUATION_TYPES.has(type) && !ANALYSIS_EVALUATION_TYPES.has(type) && type !== "order-analysis-response" && !REQUIREMENT_INVENTORY_TYPES.has(type) && !PLANNING_TYPES.has(type) &&
      !issues.some(item => item.severity === "error" || item.severity === "critical"),
    max_severity: severity,
    issue_count: issues.length,
    issues
  };
}

let activeSchemaSnapshot = null;

function validateSchemaPayload(payload, type) {
  if (!Object.hasOwn(TYPE_TO_SCHEMA, type)) throw new Error(`Unknown payload type: ${type}`);
  const schemas = activeSchemaSnapshot || loadSchemas();
  const schema = schemas[TYPE_TO_SCHEMA[type]];
  return validationResult(
    validateSchema(payload, schema, schemas)
      .map(item => ({ ...item, layer: "schema" })), type, payload
  );
}

function validatePayload(payload, type, options = {}) {
  const previous = activeSchemaSnapshot;
  activeSchemaSnapshot = previous || loadSchemas();
  try { return validatePayloadInSnapshot(payload, type, options); }
  finally { activeSchemaSnapshot = previous; }
}

function validatePayloadInSnapshot(payload, type, options) {
  const schemaResult = validateSchemaPayload(payload, type);
  const workloadChecks = { "workload-control-input": "inputIssues", "workload-policy-assessment": "assessmentIssues", "workload-control-receipt": "receiptIssues" };
  const issues = [
    ...schemaResult.issues,
    ...(schemaResult.valid ? require("../force-registry-contract").issues(payload, type).map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid ? require("../task-training-contract").issues(payload, type).map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid ? require("../training-session-contract").issues(payload, type).map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid ? require("../native-training-product-contract").issues(payload, type).map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid ? require("../native-training-transfer-contract").issues(payload, type).map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid ? require("../native-training-producer").issues(payload, type).map(item => ({ ...item, layer: "semantic" })) : []),
    ...semanticRules(payload, type, options)
      .map(item => ({ ...item, layer: "semantic" })),
    ...(schemaResult.valid && workloadChecks[type] ? require("../workload-control-contract")[workloadChecks[type]](payload)
      .map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid && type === "readiness-drop-reconciliation" ?
      require("../readiness-drop-revocation-runner").reconciliationIssues(payload).map(item => ({ ...item, layer: "semantic" })) : []),
    ...(schemaResult.valid ? [...selectionIssues(payload, type), ...intakeIssues(payload, type), ...adoptionIssues(payload, type), ...revisionIssues(payload, type), ...intentIssues(payload, type), ...methodIssues(payload, type), ...methodControlIssues(payload, type), ...issuanceIssues(payload, type), ...copIssues(payload, type), ...consentIssues(payload, type), ...reconciliationIssues(payload, type), ...modelReconciliationIssues(payload, type), ...analysisReconciliationIssues(payload, type), ...evaluationIssues(payload, type), ...analysisEvaluationIssues(payload, type), ...requirementInventoryIssues(payload, type), ...planningIssues(payload, type)]
      .map(item => ({ ...item, layer: "semantic" })) : [])
  ];
  const nested = {
    "operator-consent-record": ["request", "order-adoption-decision-request"],
    "order-revision-request": ["successor_plan", "mission-wave-plan"],
    "order-revision-proposal": ["request", "order-revision-request"],
    "order-adoption-proposal-request": ["plan", "mission-wave-plan"],
    "order-adoption-proposal": ["request", "order-adoption-proposal-request"],
    "order-backbrief": ["backbrief", "backbrief"],
    "order-rehearsal": ["rehearsal", "rehearsal"],
    "order-adoption-record": ["request", "order-adoption-decision-request"]
  }[type];
  if (schemaResult.valid && nested) {
    const [field, nestedType] = nested;
    issues.push(...validatePayload(payload[field], nestedType, options).issues
      .map(item => ({ ...item, path: `$.${field}${item.path.slice(1)}` })));
  }
  if (schemaResult.valid && type === "workload-control-input") {
    issues.push(...validatePayload(payload.report, "mission-wave-report", options).issues.map(item => ({ ...item, path: `$.report${item.path.slice(1)}` })));
  }
  const forceNested = {
    "force-registry-request": [["entity", "force-registry-entity"]],
    "force-registry-proposal": [["request", "force-registry-request"]],
    "force-registry-event": [["entity", "force-registry-entity"]],
    "force-registry-authorization": [["review.proposal", "force-registry-proposal"], ["review.previous_entity", "force-registry-entity"]]
  }[type];
  if (schemaResult.valid && forceNested) for (const [location, nestedType] of forceNested) {
    const value = location.split(".").reduce((current, key) => current[key], payload);
    if (value !== null) issues.push(...validatePayload(value, nestedType, options).issues.map(item => ({ ...item, path: `$.${location}${item.path.slice(1)}` })));
  }
  if (schemaResult.valid && type === "operator-reconciliation-authorization") {
    issues.push(...validatePayload(payload.subject.request, "order-adoption-decision-request", options).issues
      .map(item => ({ ...item, path: `$.subject.request${item.path.slice(1)}` })));
  }
  if (schemaResult.valid && type === "operator-reconciliation-record") {
    for (const field of ["authorization", ...(payload.prior_authorization ? ["prior_authorization"] : [])]) {
      issues.push(...validatePayload(payload[field], "operator-reconciliation-authorization", options).issues
        .map(item => ({ ...item, path: `$.${field}${item.path.slice(1)}` })));
    }
  }
  if (schemaResult.valid && type === "bounded-planning-proposal" && payload.plan) {
    issues.push(...validatePayload(payload.plan, "mission-wave-plan", options).issues.map(item => ({ ...item, path: `$.plan${item.path.slice(1)}` })));
  }
  return validationResult(issues, type, payload);
}

function main() {
  const [, , payloadArg, typeArg, ...optionArgs] = process.argv;
  if (!payloadArg || !typeArg || !Object.hasOwn(TYPE_TO_SCHEMA, typeArg)) {
    console.error(`Usage: node validator-cli-prototype/validate.js <payload.json> <${Object.keys(TYPE_TO_SCHEMA).join("|")}> [--evaluated-at <timestamp>]`);
    process.exit(2);
  }

  try {
    const options = {};
    for (let index = 0; index < optionArgs.length; index += 1) {
      const token = optionArgs[index];
      if (token !== "--evaluated-at" || !optionArgs[index + 1] ||
          optionArgs[index + 1].startsWith("--")) {
        throw new Error(
          "Only --evaluated-at <timestamp> is supported after the payload type."
        );
      }
      options.evaluatedAt = optionArgs[index + 1];
      index += 1;
    }
    const payloadPath = path.resolve(process.cwd(), payloadArg);
    const payload = readJson(payloadPath);
    const result = validatePayload(payload, typeArg, options);
    console.log(JSON.stringify(result, null, 2));
    process.exit(result.valid ? 0 : 1);
  } catch (error) {
    console.error(error.message);
    process.exit(2);
  }
}

module.exports = {
  controlExecutionDescriptor,
  controlExecutionReceiptId,
  validatePayload,
  validateSchemaPayload
};

if (require.main === module) main();
