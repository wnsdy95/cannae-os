# Validator CLI Prototype

Intent continuity validates complete plan/task/delegation bindings and context
v0.4 assignments through the shared contract. Commander intent, delegation,
projection and all context versions are non-authorizing metadata. The actual
lifecycle and dispatch consumers additionally replay exact retained scope; see
[intent continuity](../docs/intent-continuity-runtime.md).

This is a dependency-free Node.js prototype for validating the military-style LLM runtime payloads.

It performs two layers of checks:

1. A small JSON Schema subset used by this repository's `schema-files/*.schema.json`.
2. Semantic military-control rules such as missing intent, Red tool request without approval, Black action blocking, MOP-only assessment, and authority matrix safety.

The prototype is intentionally small. It is not a complete JSON Schema implementation.

Current and historical independent release-verification evidence is monitoring-only:
both validation APIs return `can_execute: false` even when it is valid. Historical
replay, schema validity and cryptographic success are not tool or release permission.

Fixture CLI cases must explicitly declare `requiredCodes`, including `[]` when
no issue code is expected. The runner checks all definitions before spawning
children and separately exercises malformed expectation definitions. Missing
expectations are harness failures, not successful payload validation. After adding
cases, run this CLI fixture ladder before the more expensive runtime suites;
contract-specific runner passes do not prove the CLI harness can execute them.

## Usage

```bash
node validator-cli-prototype/validate.js sample-payloads/valid-mission.json mission
node validator-cli-prototype/validate.js sample-payloads/invalid-mission-missing-intent.json mission
node validator-cli-prototype/validate.js sample-payloads/invalid-tool-request-red-without-approval.json tool-request
node validator-cli-prototype/validate.js sample-payloads/valid-authority-matrix.json authority-matrix
node validator-cli-prototype/validate.js sample-payloads/valid-decision-packet.json decision-packet
node validator-cli-prototype/validate.js sample-payloads/valid-context-item.json context-item
node validator-cli-prototype/validate.js sample-payloads/valid-release-gate-decision-event.json release-gate-decision-event
node validator-cli-prototype/validate.js sample-payloads/valid-github-release-authorization.json github-release-authorization
node validator-cli-prototype/validate.js sample-payloads/valid-github-release-receipt.json github-release-receipt
node validator-cli-prototype/validate.js sample-payloads/valid-github-release-immutability-authorization.json github-release-immutability-authorization
node validator-cli-prototype/validate.js sample-payloads/valid-github-release-immutability-receipt.json github-release-immutability-receipt
node validator-cli-prototype/validate.js github-release-independent-verification-fixtures/github-trusted-root.json github-release-trusted-root --evaluated-at <current-UTC-timestamp>
node validator-cli-prototype/validate.js .github/tuf/github-release-trust-checkpoint.json github-release-trust-checkpoint --evaluated-at <current-UTC-timestamp>
node validator-cli-prototype/validate.js sample-payloads/valid-maintenance-readiness.json maintenance-readiness
node validator-cli-prototype/validate.js sample-payloads/valid-backbrief.json backbrief
node validator-cli-prototype/validate.js sample-payloads/valid-rehearsal.json rehearsal
node validator-cli-prototype/validate.js sample-payloads/valid-approval-scope.json approval-scope
node validator-cli-prototype/validate.js sample-payloads/valid-approval-consumption-event.json approval-consumption-event
node validator-cli-prototype/validate.js sample-payloads/valid-approval-revocation-event.json approval-revocation-event
node validator-cli-prototype/validate.js sample-payloads/valid-approval-renewal-event.json approval-renewal-event
node validator-cli-prototype/validate.js sample-payloads/valid-approval-delegation-event.json approval-delegation-event
node validator-cli-prototype/validate.js sample-payloads/valid-approval-delegation-revocation-event.json approval-delegation-revocation-event
node validator-cli-prototype/validate.js sample-payloads/valid-risk-acceptance.json risk-acceptance
node validator-cli-prototype/validate.js sample-payloads/valid-force-structure-change-order.json force-structure-change-order
node validator-cli-prototype/validate.js sample-payloads/valid-model-force-assignment-plan.json model-force-assignment-plan
node validator-cli-prototype/validate.js sample-payloads/valid-model-registry.json model-registry
node validator-cli-prototype/validate.js sample-payloads/valid-model-assignment-request.json model-assignment-request
node validator-cli-prototype/validate.js sample-payloads/valid-integrated-mission-preflight.json integrated-mission-preflight
node validator-cli-prototype/validate.js sample-payloads/valid-model-usage-event.json model-usage-event
node validator-cli-prototype/validate.js sample-payloads/valid-repository-artifact-manifest.json repository-artifact-manifest
node validator-cli-prototype/validate.js sample-payloads/valid-self-improvement-campaign.json self-improvement-campaign
node validator-cli-prototype/validate.js sample-payloads/valid-self-improvement-checkpoint.json self-improvement-checkpoint
node validator-cli-prototype/validate.js sample-payloads/valid-self-improvement-decision.json self-improvement-decision
node validator-cli-prototype/validate.js sample-payloads/valid-verification-plan.json verification-plan
node validator-cli-prototype/validate.js sample-payloads/valid-verification-receipt.json verification-receipt
node validator-cli-prototype/validate.js sample-payloads/valid-verifier-trust-policy.json verifier-trust-policy
node validator-cli-prototype/validate.js sample-payloads/valid-verification-attestation.json verification-attestation
node validator-cli-prototype/validate.js sample-payloads/valid-comparative-evaluation-attestation.json comparative-evaluation-attestation
node validator-cli-prototype/validate.js sample-payloads/valid-document-access-manifest.json document-access-manifest
node validator-cli-prototype/validate.js sample-payloads/valid-routing-receipt-agent-s3.json routing-receipt
node validator-cli-prototype/validate.js sample-payloads/valid-tool-gateway-request.json tool-gateway-request
node validator-cli-prototype/validate.js sample-payloads/valid-tool-execution-receipt.json tool-execution-receipt
```

`github-release-trusted-root` and `github-release-trust-checkpoint`
validation require `--evaluated-at`. Omitting it fails closed; the validator
never treats an artifact's own retrieval or record time as the current clock.

## Exit Codes

- `0`: no `error` or `critical` issues.
- `1`: at least one `error` or `critical` issue.
- `2`: CLI usage or file loading failure.

## Supported Document Types

- `mission`
- `agent`
- `opord`
- `task-order`
- `tool-request`
- `dispatch-tool-policy`
- `agent-dispatch-lease`
- `tool-admission-event`
- `agent-execution-checkpoint`
- `tool-gateway-request`
- `tool-gateway-decision`
- `tool-execution-receipt`
- `tool-gateway-transaction-event`
- `approval-request`
- `sitrep`
- `frago`
- `evidence`
- `aar`
- `readiness-ledger`
- `authority-matrix`
- `decision-packet`
- `working-group`
- `sof-tf-charter`
- `department-collaboration-charter`
- `force-structure-change-order`
- `model-force-assignment-plan`
- `model-registry`
- `model-assignment-request`
- `integrated-mission-preflight`
- `model-usage-event`
- `repository-artifact-manifest`
- `self-improvement-campaign`
- `self-improvement-checkpoint`
- `self-improvement-decision`
- `verification-plan`
- `verification-receipt`
- `verifier-trust-policy`
- `verification-attestation`
- `comparative-evaluation-attestation`
- `document-access-manifest`
- `ccir-alert`
- `handoff-packet`
- `continuity-plan`
- `context-item`
- `release-review`
- `release-gate-decision-event`
- `github-release-authorization`
- `github-release-receipt`
- `github-release-immutability-authorization`
- `github-release-immutability-receipt`
- `github-release-integrity-policy`
- `github-release-integrity-observation`
- `github-release-trusted-root`
- `github-release-trust-checkpoint`
- `github-release-independent-verification`
- `maintenance-readiness`
- `backbrief`
- `rehearsal`
- `approval-scope`
- `approval-consumption-event`
- `approval-revocation-event`
- `approval-renewal-event`
- `approval-delegation-event`
- `approval-delegation-revocation-event`
- `risk-acceptance`
- `routing-receipt`

## Current Limits

- Supports the repository-used structural subset: local/file `$ref`,
  `type`, `const`, `enum`, numeric/string bounds, patterns,
  `required`, `properties`, `additionalProperties`, property counts,
  item counts, uniqueness, `items`, `prefixItems`, `contains`,
  `allOf`, `anyOf`, `oneOf`, `not`, and `if`/`then`/`else`.
- Structural violations, including nested additional fields and lightweight
  HTTP(S) URI or parseable date-time format failures, are blocking errors.
- Declared fields, required values, and registered type names use own-property
  membership. Undeclared `__proto__`, `constructor`, and `toString` JSON keys
  are additional fields, not schema entries; inherited API values cannot
  satisfy `required`. Unknown prototype-named types fail CLI usage and API
  lookup instead of selecting an absent schema.
- The exported `validateSchemaPayload` path performs structural-only
  preflight where time-based semantic errors need separate policy codes.
- Each synchronous `validatePayload` invocation uses one schema snapshot for
  its nested checks. The snapshot is discarded on return or exception; the next
  invocation reads current schema files again.
- This remains a repository-specific subset, not a complete JSON Schema
  draft 2020-12 implementation.
- Does not yet resolve recursive or remote refs.
- Semantic rules are intentionally conservative.
