#!/usr/bin/env node

const { spawnSync } = require("child_process");
const assert = require("assert/strict");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { validatePayload, validateSchemaPayload } = require("./validate");

const ROOT = path.resolve(__dirname, "..");
const VALIDATOR = path.join(ROOT, "validator-cli-prototype", "validate.js");

const fixtures = [
  ...["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing native producer inspection`,
    file: `sample-payloads/${prefix}-native-training-producer-inspection.json`, type: "native-training-producer-inspection", exitCode: prefix === "valid" ? 0 : 1,
    expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["NATIVE_TRAINING_PRODUCER_SUBSTITUTED"] })),
  { name: "producer inspection cannot grant hold discharge", file: "sample-payloads/valid-native-training-producer-inspection.json", type: "native-training-producer-inspection", exitCode: 1,
    expectedCanExecute: false, requiredCodes: ["CONST_MISMATCH"], mutate(value) { value.hold_discharge_authorized = true; } },
  ...["native-training-transfer-review-request", "native-training-transfer-authorization", "operator-native-training-product"].flatMap(type => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-authorizing native owner transfer ${type}`, file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1,
    expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["CONST_MISMATCH"]
  }))),
  ...["native-training-product-request", "native-training-product-response", "native-training-product-appraisal"].flatMap(type => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-executable ${type}`, file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1,
    expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [type.endsWith("response") ? "ADDITIONAL_PROPERTY" : "CONST_MISMATCH"]
  }))),
  ...["valid", "invalid"].map(prefix => ({ name: `${prefix} native task standard`, file: `sample-payloads/${prefix}-task-training-standard-native.json`,
    type: "task-training-standard", exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["TRAINING_STANDARD_CASE_COVERAGE_INVALID"] })),
  { name: "native request rejects substituted case without rekeying", file: "sample-payloads/valid-native-training-product-request.json", type: "native-training-product-request",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["NATIVE_TRAINING_REQUEST_ID_INVALID"], mutate(value) { value.case_id = "CASE-foreign"; } },
  ...["training-session-proposal", "training-session-authorization", "task-training-session-binding-current"].flatMap(type => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} distinct training session consent ${type}`, file: `sample-payloads/${prefix}-${type}.json`, type: type.replace("-current", ""),
    exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [type.endsWith("-current") ? "ANY_OF_MISMATCH" : "CONST_MISMATCH"]
  }))),
  ...["standard", "trial-request", "session-binding", "completion-input", "trial-appraisal"].flatMap(suffix => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-authorizing task training ${suffix}`, file: `sample-payloads/${prefix}-task-training-${suffix}.json`, type: `task-training-${suffix}`,
    exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [["standard", "session-binding", "trial-appraisal"].includes(suffix) ? "ANY_OF_MISMATCH" : "CONST_MISMATCH"]
  }))),
  { name: "training critical step cannot be waived as N/A", file: "sample-payloads/valid-task-training-standard.json", type: "task-training-standard",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["TRAINING_STANDARD_CRITICAL_OR_PRODUCT_MISSING"], mutate(value) { value.steps[0].not_applicable_permitted = true; } },
  { name: "training standard needs stage-specific distinct cases", file: "sample-payloads/valid-task-training-standard.json", type: "task-training-standard",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["TRAINING_STANDARD_CASE_COVERAGE_INVALID"], mutate(value) { value.cases = value.cases.filter(item => item.stage === "crawl"); } },
  { name: "training session rejects duplicate case IDs", file: "sample-payloads/valid-task-training-session-binding.json", type: "task-training-session-binding",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["TRAINING_SESSION_CASE_DUPLICATE"], mutate(value) { value.case_ids.push(value.case_ids[0]); } },
  { name: "training request rejects a changed digest-derived ID", file: "sample-payloads/valid-task-training-trial-request.json", type: "task-training-trial-request",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["TRAINING_INPUT_ID_BINDING_INVALID"], mutate(value) { value.case_id = "CASE-crawl-1"; } },
  { name: "training appraisal rejects mismatched request/output commitments", file: "sample-payloads/valid-task-training-trial-appraisal.json", type: "task-training-trial-appraisal",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["TRAINING_APPRAISAL_SUBJECT_INVALID"], mutate(value) { value.observed_output_sha256 = "0".repeat(64); } },
  { name: "valid non-authorizing CLI model selection", file: "sample-payloads/valid-codex-model-selection.json", type: "codex-model-selection",
    exitCode: 0, expectedCanExecute: false, requiredCodes: [] },
  { name: "changed CLI model selection digest", file: "sample-payloads/invalid-codex-model-selection.json", type: "codex-model-selection",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["SEMANTIC_MODEL_SELECTION_SUBSTITUTED"] },
  ...["entity", "request", "proposal", "authorization", "event"].flatMap(suffix => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-authorizing force registry ${suffix}`, file: `sample-payloads/${prefix}-force-registry-${suffix}.json`,
    type: `force-registry-${suffix}`, exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false,
    requiredCodes: prefix === "valid" ? [] : ["CONST_MISMATCH"]
  }))),
  { name: "force authorization rejects missing displayed subject commitment", file: "sample-payloads/valid-force-registry-authorization.json",
    type: "force-registry-authorization", exitCode: 1, expectedCanExecute: false, requiredCodes: ["MISSING_REQUIRED"],
    mutate(value) { delete value.displayed_review_sha256; } },
  { name: "force proposal rejects a null nested entity before semantic access", file: "sample-payloads/valid-force-registry-proposal.json",
    type: "force-registry-proposal", exitCode: 1, expectedCanExecute: false, requiredCodes: ["TYPE_MISMATCH"],
    mutate(value) { value.request.entity = null; } },
  ...["workload-control-input", "workload-policy-assessment", "workload-control-receipt"].flatMap(type => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-authorizing ${type}`, file: `sample-payloads/${prefix}-${type}.json`, type,
    exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["CONST_MISMATCH"]
  }))),
  ...["missing", "null-item"].map(kind => ({ name: `workload input rejects malformed ${kind} before semantic validation`,
    file: "sample-payloads/valid-workload-control-input.json", type: "workload-control-input", exitCode: 1,
    expectedCanExecute: false, requiredCodes: [kind === "missing" ? "MISSING_REQUIRED" : "TYPE_MISMATCH"],
    mutate(payload) { if (kind === "missing") delete payload.evidence; else payload.evidence[0] = null; } })),
  ...["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing readiness drop reconciliation`,
    file: `sample-payloads/${prefix}-readiness-drop-reconciliation.json`, type: "readiness-drop-reconciliation",
    exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["CONST_MISMATCH"] })),
  ...["missing", "null-item"].map(kind => ({ name: `readiness report handles malformed ${kind} before semantic replay`,
    file: "sample-payloads/valid-readiness-drop-reconciliation.json", type: "readiness-drop-reconciliation", exitCode: 1,
    expectedCanExecute: false, requiredCodes: [kind === "missing" ? "MISSING_REQUIRED" : "TYPE_MISMATCH"],
    mutate(payload) { if (kind === "missing") delete payload.results; else payload.results[0] = null; } })),
  ...["authorization", "record"].flatMap(suffix => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-authorizing analysis reconciliation ${suffix}`, file: `sample-payloads/${prefix}-operator-analysis-reconciliation-${suffix}.json`,
    type: `operator-analysis-reconciliation-${suffix}`, exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false,
    requiredCodes: prefix === "valid" ? [] : [suffix === "authorization" ? "CONST_MISMATCH" : "ANALYSIS_RECONCILIATION_PUBLICATION_INVALID"]
  }))),
  { name: "validator fixture expectations are explicit before any child runs", check() {
    for (const requiredCodes of [undefined, null, "CONST_MISMATCH", [7]]) {
      assert.throws(() => assertFixtureDefinitions([{ name: "malformed definition", requiredCodes }]),
        /must explicitly declare requiredCodes as a string array/);
    }
    assert.doesNotThrow(() => assertFixtureDefinitions([{ requiredCodes: [] }, { requiredCodes: ["CONST_MISMATCH"] }, { check() {} }]));
  } },
  { name: "evaluated proposed analysis remains non-authorizing", file: "sample-payloads/valid-operator-order-analysis-evaluated.json",
    type: "operator-order-analysis", exitCode: 0, expectedCanExecute: false, requiredCodes: [] },
  ...[["order-analysis-response", "CONST_MISMATCH"], ["operator-order-analysis", "ORDER_ANALYSIS_RESULT_STATE_INVALID"]]
    .flatMap(([type, code]) => ["valid", "invalid"].map(prefix => ({ name: `${prefix} proposed ${type}`,
      file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1,
      expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [code] }))),
  ...[["bounded-planning-request", "PLANNING_DUPLICATE_AGENT"], ["bounded-planning-proposal", "PLANNING_PROPOSAL_BINDING_INVALID"]]
    .flatMap(([type, code]) => ["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing ${type}`,
      file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1,
      expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [code] }))),
  ...[["requirement-inventory", "REQUIREMENT_INVENTORY_PARTITION_INVALID"],
    ["semantic-coverage-proposal", "SEMANTIC_REVIEW_ID_BINDING_INVALID"], ["semantic-review-assignment", "CONST_MISMATCH"]]
    .flatMap(([type, code]) => ["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing ${type}`,
      file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1,
      expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [code] }))),
  ...[["valid-operator-semantic-evaluation", 0, []], ["valid-operator-semantic-evaluation-legacy", 0, []],
    ["invalid-operator-semantic-evaluation", 1, ["MODEL_EVALUATION_VERDICT_BINDING_INVALID"]]].map(([name, exitCode, requiredCodes]) => ({
    name, file: `sample-payloads/${name}.json`, type: "operator-semantic-evaluation", exitCode, requiredCodes, expectedCanExecute: false
  })),
  ...["termination", "response", "time"].map(kind => ({ name: `signed model evaluation rejects ${kind}`,
    file: "sample-payloads/valid-operator-semantic-evaluation.json", type: "operator-semantic-evaluation", exitCode: 1, expectedCanExecute: false,
    requiredCodes: [kind === "time" ? "MODEL_EVALUATION_TIME_INVALID" : "MODEL_EVALUATION_STATE_BINDING_INVALID"],
    mutate(value) { if (kind === "termination") value.collection.process_group_absent = false;
      if (kind === "response") value.response_payload_sha256 = "0".repeat(64);
      if (kind === "time") value.started_at = "2026-10-23T00:00:02Z"; }
  })),
  ...["authorization", "record"].flatMap(suffix => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} non-authorizing model reconciliation ${suffix}`, file: `sample-payloads/${prefix}-operator-model-reconciliation-${suffix}.json`,
    type: `operator-model-reconciliation-${suffix}`, exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false,
    requiredCodes: prefix === "valid" ? [] : [suffix === "authorization" ? "CONST_MISMATCH" : "MODEL_RECONCILIATION_RECORD_BINDING_INVALID"]
  }))),
  ...["time", "action", "observation", "extra"].map(kind => ({ name: `model reconciliation rejects ${kind}`,
    file: "sample-payloads/valid-operator-model-reconciliation-authorization.json", type: "operator-model-reconciliation-authorization",
    exitCode: 1, expectedCanExecute: false, requiredCodes: [kind === "extra" ? "ADDITIONAL_PROPERTY" : "MODEL_RECONCILIATION_AUTHORIZATION_BINDING_INVALID"],
    mutate(value) { if (kind === "time") value.expires_at = value.created_at;
      if (kind === "action") value.action_id = value.reconciliation_id;
      if (kind === "observation") value.subject.observed_at = value.expires_at;
      if (kind === "extra") value.tool_execution_authorized = true; }
  })),
  { name: "model receipt cannot expand nested authority", file: "sample-payloads/valid-operator-model-reconciliation-record.json",
    type: "operator-model-reconciliation-record", exitCode: 1, expectedCanExecute: false,
    mutate(value) { value.authorization.release_authorized = true; }, requiredCodes: ["CONST_MISMATCH"] },
  ...["valid", "invalid"].map(prefix => ({ name: `${prefix} read-only operational COP`, file: `sample-payloads/${prefix}-operational-cop.json`,
    type: "operational-cop", exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["CONST_MISMATCH"] })),
  { name: "COP snapshot cannot invert display validity", file: "sample-payloads/valid-operational-cop.json", type: "operational-cop",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.snapshot_valid_until = value.as_of; }, requiredCodes: ["COP_SNAPSHOT_VALIDITY_INVALID"] },
  { name: "COP snapshot counts cannot silently omit rows", file: "sample-payloads/valid-operational-cop.json", type: "operational-cop",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.matching_wave_count = 1; }, requiredCodes: ["COP_SNAPSHOT_COUNTS_INVALID"] },
  ...[["method-control-channel-policy", "MISSING_REQUIRED"], ["method-control-launch-slot", "MISSING_REQUIRED"],
    ["method-control-session-observation", "ENUM_MISMATCH"]].flatMap(([type, code]) => ["valid", "invalid"].map(prefix => ({
      name: `${prefix} non-authorizing continuation ${type}`, file: `sample-payloads/${prefix}-${type}-continuation.json`, type,
      exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [code]
    }))),
  { name: "initial-only policy cannot carry a continuation capability", file: "sample-payloads/valid-method-control-channel-policy-continuation.json",
    type: "method-control-channel-policy", exitCode: 1, expectedCanExecute: false,
    mutate(value) { value.schema_version = "0.1"; }, requiredCodes: ["NOT_SCHEMA_MATCH"] },
  ...["method-control-channel-policy", "method-control-launch-slot", "method-control-session-observation", "method-control-enrollment",
    "method-control-request", "method-control-receipt", "method-control-delivery", "method-control-response"]
    .flatMap(type => ["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing ${type}`,
      file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false,
      requiredCodes: prefix === "valid" ? [] : [type === "method-control-channel-policy" ? "ADDITIONAL_PROPERTY" : "CONST_MISMATCH"] }))),
  ...["valid", "invalid"].map(prefix => ({ name: `${prefix} method-governed full mission plan`,
    file: `sample-payloads/${prefix}-mission-wave-plan-methods.json`, type: "mission-wave-plan", exitCode: prefix === "valid" ? 0 : 1,
    expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["METHOD_AGENT_COVERAGE"] })),
  ...["valid", "invalid"].map(prefix => ({ name: `${prefix} receiver-scoped method context`,
    file: `sample-payloads/${prefix}-agent-context-pack-methods.json`, type: "agent-context-pack", exitCode: prefix === "valid" ? 0 : 1,
    expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : ["METHOD_CONTEXT_BINDING_INVALID"] })),
  ...[["method-control-baseline", "METHOD_DUPLICATE_STEP"], ["method-deviation-event", "METHOD_DEVIATION_VALIDITY_INVALID"],
    ["initiative-deviation-report", "METHOD_REPORT_PHASE_BINDING_INVALID"], ["degeneration-incident-event", "CONST_MISMATCH"]]
    .flatMap(([type, code]) => ["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing ${type}`,
      file: `sample-payloads/${prefix}-${type}.json`, type, exitCode: prefix === "valid" ? 0 : 1,
      expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [code] }))),
  ...[["authorization", "CONST_MISMATCH"], ["record", "OPERATOR_RECONCILIATION_RECORD_SCOPE_INVALID"]]
    .flatMap(([suffix, code]) => ["valid", "invalid"].map(prefix => ({ name: `${prefix} non-authorizing operator reconciliation ${suffix}`,
      file: `sample-payloads/${prefix}-operator-reconciliation-${suffix}.json`, type: `operator-reconciliation-${suffix}`,
      exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: false, requiredCodes: prefix === "valid" ? [] : [code] }))),
  { name: "terminal consent cannot invert its own validity", file: "sample-payloads/valid-operator-reconciliation-authorization.json", type: "operator-reconciliation-authorization",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.expires_at = value.created_at; }, requiredCodes: ["OPERATOR_RECONCILIATION_VALIDITY_INVALID"] },
  { name: "terminal consent cannot substitute its original action", file: "sample-payloads/valid-operator-reconciliation-authorization.json", type: "operator-reconciliation-authorization",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.action_id = "0".repeat(8) + "-0000-0000-0000-000000000000"; }, requiredCodes: ["OPERATOR_RECONCILIATION_SCOPE_INVALID"] },
  { name: "terminal cancellation cannot omit its exact decision", file: "sample-payloads/valid-operator-reconciliation-record.json", type: "operator-reconciliation-record",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.authorization.cancellation_decision = null; }, requiredCodes: ["OPERATOR_RECONCILIATION_CANCELLATION_INVALID"] },
  { name: "nested terminal authorization cannot expand release authority", file: "sample-payloads/valid-operator-reconciliation-record.json", type: "operator-reconciliation-record",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.authorization.release_authorized = true; }, requiredCodes: ["CONST_MISMATCH"] },
  { name: "terminal outcome cannot claim adoption with no record", file: "sample-payloads/valid-operator-reconciliation-authorization.json", type: "operator-reconciliation-authorization",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.subject.recorded_outcome = "applied"; }, requiredCodes: ["OPERATOR_RECONCILIATION_OUTCOME_INVALID"] },
  { name: "prior cancellation acknowledgement requires its signed predecessor", file: "sample-payloads/valid-operator-reconciliation-record.json", type: "operator-reconciliation-record",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.authorization.resolution = "acknowledge_prior_cancellation"; }, requiredCodes: ["OPERATOR_RECONCILIATION_PRIOR_CANCELLATION_INVALID"] },
  { name: "terminal receipt cannot be recorded after fresh consent expires", file: "sample-payloads/valid-operator-reconciliation-record.json", type: "operator-reconciliation-record",
    exitCode: 1, expectedCanExecute: false, mutate(value) { value.recorded_at = value.authorization.expires_at; }, requiredCodes: ["OPERATOR_RECONCILIATION_RECORD_TIME_INVALID"] },
  { name: "operator consent metadata cannot authorize execution", file: "sample-payloads/valid-operator-consent-record.json", type: "operator-consent-record", exitCode: 0, requiredCodes: [] },
  { name: "operator consent execution expansion is rejected", file: "sample-payloads/invalid-operator-consent-record.json", type: "operator-consent-record", exitCode: 1, requiredCodes: ["CONST_MISMATCH"] },
  { name: "operator consent cannot substitute its mission", file: "sample-payloads/valid-operator-consent-record.json", type: "operator-consent-record", exitCode: 1,
    mutate(value) { value.mission_id = "MIS-OTHER"; }, requiredCodes: ["OPERATOR_CONSENT_SCOPE_BINDING_INVALID"] },
  { name: "operator consent cannot invert its validity", file: "sample-payloads/valid-operator-consent-record.json", type: "operator-consent-record", exitCode: 1,
    mutate(value) { value.expires_at = value.created_at; }, requiredCodes: ["OPERATOR_CONSENT_VALIDITY_INVALID"] },
  ...[
    ["commander-intent", "commander-intent", "INTENT_LOCAL_IDENTITY_INVALID"],
    ["intent-delegation-event", "intent-delegation-event", "INTENT_DELEGATION_BINDING_INVALID"],
    ["mission-wave-plan-intent", "mission-wave-plan", "INTENT_INHERITANCE_LOST"],
    ["agent-context-pack-intent", "agent-context-pack", "MISSING_REQUIRED"],
    ["intent-continuity-projection", "intent-continuity-projection", "CONST_MISMATCH"]
  ].flatMap(([name, type, invalidCode]) => ["valid", "invalid"].map(prefix => ({
    name: `${prefix} ${name}`, file: `sample-payloads/${prefix}-${name}.json`, type,
    exitCode: prefix === "valid" ? 0 : 1, expectedCanExecute: prefix === "valid" && type === "mission-wave-plan",
    requiredCodes: prefix === "valid" ? [] : [invalidCode]
  }))),
  { name: "legacy context metadata is not execution authority", file: "sample-payloads/valid-agent-context-pack.json", type: "agent-context-pack",
    exitCode: 0, expectedCanExecute: false, requiredCodes: [] },
  ...["missing-intent", "missing-edge", "partial-edge", "changed-task", "changed-parent", "null-object", "extra-boundary", "contradictory-projection"].map(mutation => ({
    name: `intent rejects ${mutation}`, file: mutation === "contradictory-projection"
      ? "sample-payloads/valid-intent-continuity-projection.json" : "sample-payloads/valid-agent-context-pack-intent.json",
    type: mutation === "contradictory-projection" ? "intent-continuity-projection" : "agent-context-pack",
    exitCode: 1, expectedCanExecute: false,
    requiredCodes: [{ "missing-intent": "MISSING_REQUIRED", "missing-edge": "MIN_ITEMS", "partial-edge": "INTENT_CONTEXT_INHERITANCE_INVALID", "changed-task": "INTENT_CONTEXT_LINEAGE_INVALID",
      "changed-parent": "INTENT_CONTEXT_INHERITANCE_INVALID", "null-object": "ONE_OF_MISMATCH", "extra-boundary": "ADDITIONAL_PROPERTY",
      "contradictory-projection": "INTENT_PROJECTION_STATUS_INVALID" }[mutation]],
    mutate(value) {
      if (mutation === "contradictory-projection") { value.status = "blocked"; return; }
      if (mutation === "partial-edge") {
        const support = require("../intent-continuity-fixtures/support");
        const plan = support.nested(support.fixturePlan());
        Object.assign(value, support.context(plan, plan.agents.at(-1)));
        value.intent_assignment.delegations.pop();
        return;
      }
      const assignment = value.intent_assignment;
      if (mutation === "missing-intent") delete value.intent_assignment;
      if (mutation === "missing-edge") assignment.delegations = [];
      if (mutation === "changed-task") value.task = "Substituted task";
      if (mutation === "changed-parent") assignment.lineage.at(-1).parent_intent_id = "INT-OTHER";
      if (mutation === "null-object") assignment.lineage[0].parent_intent_id = {};
      if (mutation === "extra-boundary") assignment.lineage[0].authority_boundary.user_approved = true;
    }
  })),
  { name: "descriptive FRAGO is not execution authority", file: "runtime-demo-payloads/frago.json", type: "frago",
    exitCode: 0, expectedCanExecute: false, requiredCodes: [] },
  { name: "scope-change metadata cannot replace reviewed revision", file: "sample-payloads/valid-frago-scope-change.json", type: "frago-scope-change",
    exitCode: 0, expectedCanExecute: false, requiredCodes: [] },
  ...[
    ["valid-order-revision-request", "order-revision-request", 0, []],
    ["valid-order-revision-proposal", "order-revision-proposal", 0, []],
    ["valid-mission-wave-plan-revision", "mission-wave-plan", 0, []],
    ["invalid-order-revision-request-scope", "order-revision-request", 1, ["ORDER_REVISION_PLAN_SCOPE_INVALID"]],
    ["invalid-order-revision-proposal-binding", "order-revision-proposal", 1, ["ORDER_REVISION_BINDING_INVALID"]],
    ["invalid-mission-wave-plan-revision-extra", "mission-wave-plan", 1, ["ADDITIONAL_PROPERTY"]]
  ].map(([name, type, exitCode, requiredCodes]) => ({ name, file: `sample-payloads/${name}.json`, type, exitCode, requiredCodes, expectedCanExecute: false })),
  ...["extra", "removed-after", "added-without-after", "retained-without-before", "expiry", "authority", "classification", "prototype-ref"].map(mutation => ({
    name: `revision rejects ${mutation}`, file: "sample-payloads/valid-order-revision-proposal.json", type: "order-revision-proposal",
    exitCode: 1, expectedCanExecute: false,
    requiredCodes: [{ extra: "ADDITIONAL_PROPERTY", "removed-after": "NOT_SCHEMA_MATCH", "added-without-after": "MISSING_REQUIRED",
      "retained-without-before": "MISSING_REQUIRED", expiry: "ORDER_REVISION_VALIDITY_INVALID", authority: "MISSION_WAVE_RETAINED_ACTION_DELEGATED",
      classification: "ORDER_REVISION_CLASSIFICATION_INVALID", "prototype-ref": "ADDITIONAL_PROPERTY" }[mutation]],
    mutate(payload) {
      const row = payload.changes[0];
      if (mutation === "extra") row.approved = true;
      if (mutation === "removed-after") row.change = "removed";
      if (mutation === "added-without-after") { row.change = "added"; delete row.after; }
      if (mutation === "retained-without-before") { row.change = "retained"; delete row.before; }
      if (mutation === "expiry") payload.expires_at = payload.recorded_at;
      if (mutation === "authority") payload.request.successor_plan.agents[0].allowed_actions = ["Push to production"];
      if (mutation === "classification") payload.classification = "public";
      if (mutation === "prototype-ref") Object.defineProperty(payload.request.parent_plan_ref, "__proto__", { value: { approved: true }, enumerable: true });
    }
  })),
  { name: "nested validation reads one schema snapshot", file: "sample-payloads/valid-order-adoption-proposal.json",
    check() {
      const payload = JSON.parse(fs.readFileSync(path.join(ROOT, this.file), "utf8"));
      const original = fs.readFileSync, reads = new Map(), schemaRoot = path.join(ROOT, "schema-files") + path.sep;
      try {
        fs.readFileSync = function(file, ...args) {
          if (typeof file === "string" && file.startsWith(schemaRoot) && file.endsWith(".json")) reads.set(file, (reads.get(file) || 0) + 1);
          return original.call(this, file, ...args);
        };
        assert.equal(validatePayload(payload, "order-adoption-proposal").valid, true);
        assert(reads.size > 0); assert([...reads.values()].every(count => count === 1));
      } finally { fs.readFileSync = original; }
    } },
  { name: "schema snapshot refreshes after return and exceptional validation", file: "sample-payloads/valid-mission.json",
    check() {
      const payload = JSON.parse(fs.readFileSync(path.join(ROOT, this.file), "utf8"));
      assert.equal(validatePayload(payload, "mission").valid, true);
      assert.throws(() => validatePayload(payload, "__proto__"), /Unknown payload type/);
      const original = fs.readFileSync, target = path.join(ROOT, "schema-files/mission.schema.json");
      try {
        fs.readFileSync = function(file, ...args) {
          const value = original.call(this, file, ...args);
          if (file !== target) return value;
          const schema = JSON.parse(value); schema.required.push("fresh_snapshot_marker");
          return JSON.stringify(schema);
        };
        for (const validate of [validatePayload, validateSchemaPayload]) {
          const result = validate(payload, "mission");
          assert.equal(result.valid, false); assert(result.issues.some(item => item.code === "MISSING_REQUIRED" && item.path === "$.fresh_snapshot_marker"));
        }
      } finally { fs.readFileSync = original; }
      assert.equal(validatePayload(payload, "mission").valid, true);
    } },
  ...["mission", "mission-wave-plan", "order-adoption-proposal-request"].flatMap(type =>
    ["root", "nested"].flatMap(location => ["__proto__", "constructor", "toString"].map(key => ({
      name: `${type} rejects undeclared ${location} ${key} in parsed JSON`,
      file: `sample-payloads/valid-${type}.json`, type, exitCode: 1,
      expectedCanExecute: false, requiredCodes: ["ADDITIONAL_PROPERTY"],
      mutate(payload) {
        const target = location === "root" ? payload : type === "mission" ? payload.intent :
          type === "mission-wave-plan" ? payload.agents[0] : payload.plan.order_binding.draft_ref;
        Object.defineProperty(target, key, { value: { execution_authorized: true }, enumerable: true });
      }
    })))),
  ...[
    ["mission", "id", value => value],
    ["mission", "purpose", value => value.intent],
    ["mission-wave-plan", "agent_id", value => value.agents[0]],
    ["order-adoption-proposal-request", "artifact_id", value => value.plan.order_binding.draft_ref]
  ].map(([type, key, select]) => ({
    name: `${type} cannot inherit required ${key}`, file: `sample-payloads/valid-${type}.json`,
    check() {
      const payload = JSON.parse(fs.readFileSync(path.join(ROOT, this.file), "utf8"));
      const target = select(payload);
      const inherited = { [key]: target[key] };
      delete target[key];
      Object.setPrototypeOf(target, inherited);
      for (const validate of [validateSchemaPayload, validatePayload]) {
        const result = validate(payload, type);
        assert.equal(result.valid, false);
        assert.equal(result.can_execute, false);
        assert(result.issues.some(item => item.code === "MISSING_REQUIRED" && item.path.endsWith(`.${key}`)));
      }
    }
  })),
  ...["__proto__", "constructor", "toString"].map(type => ({
    name: `prototype name ${type} is not a registered payload type`, file: "sample-payloads/valid-mission.json",
    check() {
      const payload = JSON.parse(fs.readFileSync(path.join(ROOT, this.file), "utf8"));
      for (const validate of [validateSchemaPayload, validatePayload]) {
        assert.throws(() => validate(payload, type), /Unknown payload type/);
      }
      const result = spawnSync(process.execPath, [VALIDATOR, this.file, type], { cwd: ROOT, encoding: "utf8" });
      assert.equal(result.status, 2);
      assert.equal(result.stdout, "");
      assert.match(result.stderr, /Usage:/);
    }
  })),
  ...["mission", "mission-wave-plan", "order-adoption-proposal-request"].map(type => ({
    name: `${type} accepts own properties without a prototype`, file: `sample-payloads/valid-${type}.json`,
    check() {
      const payload = JSON.parse(fs.readFileSync(path.join(ROOT, this.file), "utf8"));
      Object.setPrototypeOf(payload, null);
      for (const validate of [validateSchemaPayload, validatePayload]) assert.equal(validate(payload, type).valid, true);
    }
  })),
  ...["order-adoption-proposal-request", "order-adoption-proposal", "order-backbrief", "order-rehearsal",
    "order-adoption-decision-request", "order-adoption-record", "mission-wave-plan-adopted", "agent-context-pack-adopted"].map(name => ({
    name: `valid non-executable ${name}`, file: `sample-payloads/valid-${name}.json`, type: name.replace(/-adopted$/, ""),
    exitCode: 0, expectedCanExecute: false, requiredCodes: []
  })),
  ...[
    ["order-adoption-proposal-request", "MISSION_WAVE_RETAINED_ACTION_DELEGATED"],
    ["order-adoption-proposal", "ORDER_PROPOSAL_BINDING_MISMATCH"], ["order-backbrief", "BACKBRIEF_WITHOUT_RISK_CONTROLS"],
    ["order-rehearsal", "EXECUTE_WITH_UNRESOLVED_CHANGES"], ["order-adoption-decision-request", "ORDER_ADOPTION_REHEARSAL_REQUIRED"],
    ["order-adoption-record", "CONST_MISMATCH"], ["mission-wave-plan-adopted", "MISSING_REQUIRED"],
    ["agent-context-pack-adopted", "ORDER_CONTEXT_TASK_MISMATCH"]
  ].map(([name, code]) => ({ name: `invalid ${name}`, file: `sample-payloads/invalid-${name}.json`,
    type: name.replace(/-adopted$/, ""), exitCode: 1, expectedCanExecute: false, requiredCodes: [code] })),
  ...["missing-binding", "legacy-binding", "duplicate-agent", "extra-field"].map(mutation => ({
    name: `adopted plan rejects ${mutation}`, file: "sample-payloads/valid-mission-wave-plan-adopted.json", type: "mission-wave-plan",
    exitCode: 1, expectedCanExecute: false, requiredCodes: [{ "missing-binding": "MISSING_REQUIRED", "legacy-binding": "NOT_SCHEMA_MATCH",
      "duplicate-agent": "ORDER_PLAN_ASSIGNMENT_MISMATCH", "extra-field": "ADDITIONAL_PROPERTY" }[mutation]],
    mutate: value => {
      if (mutation === "missing-binding") delete value.order_binding;
      if (mutation === "legacy-binding") value.schema_version = "0.1";
      if (mutation === "duplicate-agent") value.order_binding.task_assignments[0].agent_id = value.order_binding.task_assignments[1].agent_id;
      if (mutation === "extra-field") value.order_binding.task_assignments[0].approved = true;
    }
  })),
  ...["missing-assignment", "legacy-assignment", "extra-field"].map(mutation => ({
    name: `adopted context rejects ${mutation}`, file: "sample-payloads/valid-agent-context-pack-adopted.json", type: "agent-context-pack",
    exitCode: 1, expectedCanExecute: false, requiredCodes: [{ "missing-assignment": "MISSING_REQUIRED",
      "legacy-assignment": "NOT_SCHEMA_MATCH", "extra-field": "ADDITIONAL_PROPERTY" }[mutation]],
    mutate: value => {
      if (mutation === "missing-assignment") delete value.order_assignment;
      if (mutation === "legacy-assignment") value.schema_version = "0.2";
      if (mutation === "extra-field") value.order_assignment.adoption_ref.approved = true;
    }
  })),
  { name: "adoption record requires concrete USER reference", file: "sample-payloads/valid-order-adoption-record.json", type: "order-adoption-record",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["ORDER_ADOPTION_BINDING_MISMATCH"],
    mutate: value => { value.request.decision_ref = { artifact_id: "none", relative_path: "none", sha256: "none" }; } },
  { name: "adoption rejects partial none", file: "sample-payloads/valid-order-adoption-decision-request.json", type: "order-adoption-decision-request",
    exitCode: 1, expectedCanExecute: false, requiredCodes: ["ONE_OF_MISMATCH"], mutate: value => { value.decision_ref.sha256 = "none"; } },
  ...["mission-request", "mission-order-analysis", "order-draft"].map(type => ({
    name: `valid non-executable ${type}`, file: `sample-payloads/valid-${type}.json`, type,
    exitCode: 0, expectedCanExecute: false, requiredCodes: []
  })),
  ...[
    ["mission-request-text", "mission-request", "ORDER_REQUEST_TEXT_BINDING_INVALID"],
    ["mission-order-analysis-fact", "mission-order-analysis", "ORDER_ANALYSIS_UNSUPPORTED_FACT"],
    ["order-draft-constraints", "order-draft", "ORDER_DRAFT_BINDING_INVALID"]
  ].map(([file, type, code]) => ({ name: `reject ${file}`, file: `sample-payloads/invalid-${file}.json`, type,
    exitCode: 1, expectedCanExecute: false, requiredCodes: [code] })),
  ...["extra-field", "duplicate-quote", "missing-reference", "invalid-span"].map(mutation => ({
    name: `analysis rejects ${mutation}`, file: "sample-payloads/valid-mission-order-analysis.json", type: "mission-order-analysis",
    exitCode: 1, expectedCanExecute: false,
    requiredCodes: [{ "extra-field": "ONE_OF_MISMATCH", "duplicate-quote": "ORDER_ANALYSIS_DUPLICATE_ID",
      "missing-reference": "ORDER_ANALYSIS_REFERENCE_MISSING", "invalid-span": "ORDER_ANALYSIS_SPAN_INVALID" }[mutation]],
    mutate: value => {
      if (mutation === "extra-field") value.statements[0].source.approved = true;
      if (mutation === "duplicate-quote") value.statements.push(JSON.parse(JSON.stringify(value.statements[0])));
      if (mutation === "missing-reference") value.sections["mission.statement"] = ["ST-ABSENT"];
      if (mutation === "invalid-span") {
        value.statements[0].source.start_byte = 1;
        value.statements[0].source.end_byte = 1;
      }
    }
  })),
  ...["authority", "expiry", "nested-task-extra"].map(mutation => ({
    name: `draft rejects ${mutation}`, file: "sample-payloads/valid-order-draft.json", type: "order-draft",
    exitCode: 1, expectedCanExecute: false,
    requiredCodes: [{ authority: "CONST_MISMATCH", expiry: "ORDER_DRAFT_VALIDITY_INVALID", "nested-task-extra": "ADDITIONAL_PROPERTY" }[mutation]],
    mutate: value => {
      if (mutation === "authority") value.execution_authorized = true;
      if (mutation === "expiry") value.expires_at = value.compiled_at;
      if (mutation === "nested-task-extra") value.opord.execution.tasks[0].approved = true;
    }
  })),
  ...["proposal-request", "proposal", "activation-request", "admission"].map(kind => ({
    name: `valid campaign successor ${kind}`, file: `sample-payloads/valid-campaign-successor-${kind}.json`,
    type: `campaign-successor-${kind}`, exitCode: 0, requiredCodes: []
  })),
  ...[
    ["proposal-request-scope", "proposal-request", "CAMPAIGN_SUCCESSOR_CANDIDATE_INVALID"],
    ["proposal-expiry", "proposal", "CAMPAIGN_SUCCESSOR_VALIDITY_INVALID"],
    ["activation-request-decision", "activation-request", "CAMPAIGN_SUCCESSOR_REFERENCE_INVALID"],
    ["admission-authority", "admission", "CONST_MISMATCH"]
  ].map(([file, type, code]) => ({ name: `invalid successor ${file}`,
    file: `sample-payloads/invalid-campaign-successor-${file}.json`, type: `campaign-successor-${type}`, exitCode: 1, requiredCodes: [code] })),
  ...["proposal", "admission"].flatMap(kind => ["id", "mission", "request"].map(mutation => ({
    name: `successor ${kind} binds ${mutation}`, file: `sample-payloads/valid-campaign-successor-${kind}.json`,
    type: `campaign-successor-${kind}`, exitCode: 1, requiredCodes: ["CAMPAIGN_SUCCESSOR_BINDING_INVALID"],
    mutate: payload => {
      if (mutation === "id") payload.id = `${kind === "proposal" ? "CSP" : "CSA"}-${"e".repeat(32)}`;
      else if (mutation === "mission") payload.mission_id = "MIS-Other";
      else payload.request.mission_id = "MIS-Other";
    }
  }))),
  { name: "successor option draft may omit consent", file: "sample-payloads/valid-campaign-successor-activation-request.json",
    type: "campaign-successor-activation-request", exitCode: 0, requiredCodes: [],
    mutate: payload => { payload.decision_ref = { artifact_id: "none", relative_path: "none", sha256: "none" }; } },
  { name: "successor admission requires concrete consent", file: "sample-payloads/valid-campaign-successor-admission.json",
    type: "campaign-successor-admission", exitCode: 1, requiredCodes: ["CAMPAIGN_SUCCESSOR_REFERENCE_INVALID"],
    mutate: payload => { payload.request.decision_ref = { artifact_id: "none", relative_path: "none", sha256: "none" }; } },
  { name: "successor embeds campaign semantic gates", file: "sample-payloads/valid-campaign-successor-proposal-request.json",
    type: "campaign-successor-proposal-request", exitCode: 1, requiredCodes: ["CAMPAIGN_SUCCESSOR_CANDIDATE_INVALID"],
    mutate: payload => { payload.successor_campaign.quality_model.dimensions[0].weight = 0; } },
  ...["request", "record"].map(kind => ({
    name: `valid campaign terminal ${kind}`, file: `sample-payloads/valid-campaign-terminal-${kind}.json`,
    type: `campaign-terminal-${kind}`, exitCode: 0, requiredCodes: []
  })),
  { name: "campaign terminal requires an exact stop", file: "sample-payloads/invalid-campaign-terminal-request-stop.json",
    type: "campaign-terminal-request", exitCode: 1, requiredCodes: ["CAMPAIGN_TERMINAL_REFERENCE_INVALID"] },
  { name: "campaign terminal never grants continuation", file: "sample-payloads/invalid-campaign-terminal-record-authority.json",
    type: "campaign-terminal-record", exitCode: 1, requiredCodes: ["CONST_MISMATCH"] },
  ...["request", "inventory", "identity", "missing-reference"].map(mutation => ({
    name: `campaign terminal binds ${mutation}`, file: "sample-payloads/valid-campaign-terminal-record.json",
    type: "campaign-terminal-record", exitCode: 1, requiredCodes: ["CAMPAIGN_TERMINAL_RECORD_BINDING_INVALID"],
    mutate: payload => {
      if (mutation === "request") payload.request.campaign_ref.sha256 = "f".repeat(64);
      else if (mutation === "inventory") payload.inventory_sha256 = "f".repeat(64);
      else if (mutation === "identity") payload.mission_id = "MIS-Substituted";
      else payload.inventory.retained_artifact_refs.pop();
    }
  })),
  ...["request", "record"].map(kind => ({
    name: `valid campaign stop ${kind}`, file: `sample-payloads/valid-campaign-stop-${kind}.json`,
    type: `campaign-stop-${kind}`, exitCode: 0, requiredCodes: []
  })),
  { name: "campaign stop rejects partial none", file: "sample-payloads/invalid-campaign-stop-request-reference.json",
    type: "campaign-stop-request", exitCode: 1, requiredCodes: ["CAMPAIGN_STOP_REFERENCE_INVALID"] },
  { name: "campaign stop never claims settlement", file: "sample-payloads/invalid-campaign-stop-record-settled.json",
    type: "campaign-stop-record", exitCode: 1, requiredCodes: ["CONST_MISMATCH"] },
  { name: "campaign stop preserves exact request digest", file: "sample-payloads/valid-campaign-stop-record.json",
    type: "campaign-stop-record", exitCode: 1, requiredCodes: ["CAMPAIGN_STOP_RECORD_BINDING_INVALID"],
    mutate: payload => { payload.request.reason = "Substituted reason"; } },
  { name: "campaign stop records require a concrete USER decision", file: "sample-payloads/valid-campaign-stop-record.json",
    type: "campaign-stop-record", exitCode: 1, requiredCodes: ["CAMPAIGN_STOP_REFERENCE_INVALID"],
    mutate: payload => { payload.request.decision_ref = { artifact_id: "none", relative_path: "none", sha256: "none" }; } },
  ...["request", "record"].map(kind => ({
    name: `valid gateway settlement ${kind}`,
    file: `sample-payloads/valid-gateway-effect-settlement${kind === "request" ? "-request" : ""}.json`,
    type: `gateway-effect-settlement${kind === "request" ? "-request" : ""}`, exitCode: 0, requiredCodes: []
  })),
  {
    name: "gateway settlement rejects partial none references",
    file: "sample-payloads/invalid-gateway-effect-settlement-request-none.json",
    type: "gateway-effect-settlement-request", exitCode: 1, requiredCodes: ["GATEWAY_SETTLEMENT_CONTAINMENT_INVALID"]
  },
  {
    name: "gateway settlement requires verified containment when execution started",
    file: "sample-payloads/invalid-gateway-effect-settlement-containment.json",
    type: "gateway-effect-settlement", exitCode: 1, requiredCodes: ["GATEWAY_SETTLEMENT_CONTAINMENT_INVALID"]
  },
  {
    name: "gateway settlement cannot authorize execution",
    file: "sample-payloads/valid-gateway-effect-settlement.json",
    type: "gateway-effect-settlement", exitCode: 1,
    mutate(payload) { payload.tool_execution_authorized = true; }, requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "gateway settlement identity binds the canonical request",
    file: "sample-payloads/valid-gateway-effect-settlement.json",
    type: "gateway-effect-settlement", exitCode: 1,
    mutate(payload) { payload.request.id = "GESR-OTHER"; }, requiredCodes: ["TOOL_EFFECT_SETTLEMENT_REQUEST_BINDING_MISMATCH"]
  },
  {
    name: "gateway settlement cannot outlive its proof admission",
    file: "sample-payloads/valid-gateway-effect-settlement.json",
    type: "gateway-effect-settlement", exitCode: 1,
    mutate(payload) { payload.admission_valid_until = payload.settled_at; }, requiredCodes: ["TOOL_EFFECT_SETTLEMENT_TIME_INVALID"]
  },
  {
    name: "external schema fragments resolve local none refs from their owning document",
    file: "sample-payloads/valid-gateway-effect-subject.json",
    type: "gateway-effect-subject", exitCode: 1,
    mutate(payload) { payload.references.production_sandbox_admission_ref.relative_path = "not-none"; },
    requiredCodes: ["ONE_OF_MISMATCH"]
  },
  ...["subject", "scope", "review"].map(kind => ({
    name: `valid non-authorizing gateway effect ${kind}`,
    file: `sample-payloads/valid-gateway-effect-${kind}.json`,
    type: `gateway-effect-${kind}`, exitCode: 0, requiredCodes: []
  })),
  {
    name: "gateway subject digest cannot be reused for a different transaction",
    file: "sample-payloads/invalid-gateway-effect-subject-digest.json",
    type: "gateway-effect-subject", exitCode: 1, requiredCodes: ["GATEWAY_EFFECT_SUBJECT_DIGEST_MISMATCH"]
  },
  {
    name: "gateway scope cannot substitute its subject agent",
    file: "sample-payloads/invalid-gateway-effect-scope-subject.json",
    type: "gateway-effect-scope", exitCode: 1, requiredCodes: ["GATEWAY_EFFECT_SCOPE_SUBJECT_MISMATCH"]
  },
  {
    name: "gateway review cannot settle effects",
    file: "sample-payloads/invalid-gateway-effect-review-authority.json",
    type: "gateway-effect-review", exitCode: 1, requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "nested gateway subject digest is checked semantically",
    file: "sample-payloads/valid-gateway-effect-scope.json",
    type: "gateway-effect-scope", exitCode: 1,
    mutate(payload) { payload.subject.transaction_id = "GTX-SUBSTITUTED"; },
    requiredCodes: ["GATEWAY_EFFECT_SUBJECT_DIGEST_MISMATCH"]
  },
  {
    name: "gateway scope cannot reverse expiry",
    file: "sample-payloads/valid-gateway-effect-scope.json",
    type: "gateway-effect-scope", exitCode: 1,
    mutate(payload) { payload.expires_at = payload.created_at; },
    requiredCodes: ["TOOL_EFFECT_SCOPE_TIME_INVALID"]
  },
  {
    name: "gateway evidence-bound review cannot conceal blockers",
    file: "sample-payloads/valid-gateway-effect-review.json",
    type: "gateway-effect-review", exitCode: 1,
    mutate(payload) { payload.reason_codes = ["GATEWAY_EFFECT_SUBJECT_CHANGED"]; },
    requiredCodes: ["TOOL_EFFECT_REVIEW_STATUS_INVALID"]
  },
  {
    name: "valid exact tool effect settlement request",
    file: "sample-payloads/valid-tool-effect-settlement-request.json",
    type: "tool-effect-settlement-request", exitCode: 0, requiredCodes: []
  },
  {
    name: "effect scope requires explicit USER judgement",
    file: "sample-payloads/invalid-tool-effect-settlement-request-unaccepted.json",
    type: "tool-effect-settlement-request", exitCode: 1, requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "valid non-executing effect settlement",
    file: "sample-payloads/valid-tool-effect-settlement.json",
    type: "tool-effect-settlement", exitCode: 0, requiredCodes: []
  },
  {
    name: "effect settlement cannot authorize tools",
    file: "sample-payloads/invalid-tool-effect-settlement-authority.json",
    type: "tool-effect-settlement", exitCode: 1, requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "effect settlement identity binds the canonical request",
    file: "sample-payloads/valid-tool-effect-settlement.json",
    type: "tool-effect-settlement", exitCode: 1,
    mutate(payload) { payload.request.id = "TESR-OTHER"; },
    requiredCodes: ["TOOL_EFFECT_SETTLEMENT_REQUEST_BINDING_MISMATCH"]
  },
  {
    name: "effect settlement cannot be admitted at proof expiry",
    file: "sample-payloads/valid-tool-effect-settlement.json",
    type: "tool-effect-settlement", exitCode: 1,
    mutate(payload) { payload.settled_at = payload.admission_valid_until; },
    requiredCodes: ["TOOL_EFFECT_SETTLEMENT_TIME_INVALID"]
  },
  {
    name: "valid tool effect scope",
    file: "sample-payloads/valid-tool-effect-scope.json",
    type: "tool-effect-scope", exitCode: 0, requiredCodes: []
  },
  {
    name: "effect scope expiry cannot be reversed",
    file: "sample-payloads/valid-tool-effect-scope.json",
    type: "tool-effect-scope", exitCode: 1,
    mutate(payload) { payload.expires_at = payload.created_at; },
    requiredCodes: ["TOOL_EFFECT_SCOPE_TIME_INVALID"]
  },
  {
    name: "effect scope resource identity cannot repeat",
    file: "sample-payloads/valid-tool-effect-scope.json",
    type: "tool-effect-scope", exitCode: 1,
    mutate(payload) { payload.resources.push(JSON.parse(JSON.stringify(payload.resources[0]))); },
    requiredCodes: ["TOOL_EFFECT_SCOPE_DUPLICATE_RESOURCE"]
  },
  {
    name: "valid non-authorizing tool effect review",
    file: "sample-payloads/valid-tool-effect-review.json",
    type: "tool-effect-review", exitCode: 0, requiredCodes: []
  },
  {
    name: "an effect review cannot settle unknown outcomes",
    file: "sample-payloads/invalid-tool-effect-review-settled.json",
    type: "tool-effect-review", exitCode: 1, requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "effect review evidence-bound status cannot conceal blockers",
    file: "sample-payloads/valid-tool-effect-review.json",
    type: "tool-effect-review", exitCode: 1,
    mutate(payload) { payload.reason_codes = ["TOOL_EFFECT_RESOURCE_UNRESOLVED"]; },
    requiredCodes: ["TOOL_EFFECT_REVIEW_STATUS_INVALID"]
  },
  {
    name: "current independent release evidence v0.2",
    file: "sample-payloads/valid-github-release-independent-verification-v0.2.json",
    type: "github-release-independent-verification",
    exitCode: 0, expectedCanExecute: false,
    requiredCodes: []
  },
  {
    name: "prior v0.2 producer evidence remains structurally readable",
    file: "sample-payloads/valid-github-release-independent-verification-prior-v0.2.json",
    type: "github-release-independent-verification",
    exitCode: 0, expectedCanExecute: false,
    requiredCodes: []
  },
  {
    name: "frozen pre-zone producer remains non-authorizing and structurally readable",
    file: "sample-payloads/valid-github-release-independent-verification-pre-zone-v0.2.json",
    type: "github-release-independent-verification", exitCode: 0, expectedCanExecute: false, requiredCodes: []
  },
  {
    name: "pre-console v0.2 producer evidence remains structurally readable",
    file: "sample-payloads/valid-github-release-independent-verification-pre-console-v0.2.json",
    type: "github-release-independent-verification",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "legacy independent evidence remains structurally readable",
    file: "sample-payloads/valid-github-release-independent-verification-legacy.json",
    type: "github-release-independent-verification",
    exitCode: 0, expectedCanExecute: false,
    requiredCodes: []
  },
  { name: "both validator APIs keep current and historical independent evidence non-executable", check() {
    for (const name of ["v0.2", "pre-zone-v0.2", "legacy"]) {
      const payload = JSON.parse(fs.readFileSync(path.join(ROOT, `sample-payloads/valid-github-release-independent-verification-${name}.json`)));
      for (const api of [validateSchemaPayload, validatePayload]) {
        const result = api(payload, "github-release-independent-verification"); assert.equal(result.valid, true); assert.equal(result.can_execute, false);
      }
    }
  } },
  {
    name: "evidence version cannot substitute another verifier generation",
    file: "sample-payloads/invalid-github-release-independent-verification-version-pair.json",
    type: "github-release-independent-verification",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "valid implementation candidate registry",
    file: "sample-payloads/valid-implementation-candidate-registry.json",
    type: "implementation-candidate-registry",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "candidate completion without checks and with unfinished work",
    file: "sample-payloads/invalid-implementation-candidate-registry-unproven.json",
    type: "implementation-candidate-registry",
    exitCode: 1,
    requiredCodes: ["CANDIDATE_COMPLETION_UNPROVEN"]
  },
  {
    name: "valid mission",
    file: "sample-payloads/valid-mission.json",
    type: "mission",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "missing intent mission",
    file: "sample-payloads/invalid-mission-missing-intent.json",
    type: "mission",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED", "MISSING_INTENT"]
  },
  {
    name: "mission with additional policy override field",
    file: "sample-payloads/invalid-mission-extra-field.json",
    type: "mission",
    exitCode: 1,
    requiredCodes: ["ADDITIONAL_PROPERTY"]
  },
  {
    name: "valid WARNO",
    file: "sample-payloads/valid-warno.json",
    type: "warno",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "WARNO execution before issue",
    file: "sample-payloads/invalid-warno-execution-before-issue.json",
    type: "warno",
    exitCode: 1,
    requiredCodes: ["WARNO_WITHOUT_PREPARATION_TASKS", "WARNO_EXECUTION_BEFORE_ISSUE"]
  },
  {
    name: "valid board decision",
    file: "sample-payloads/valid-board-decision.json",
    type: "board-decision",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "board decision without rationale",
    file: "sample-payloads/invalid-board-decision-no-rationale.json",
    type: "board-decision",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "approving board decision without selected option",
    file: "sample-payloads/valid-board-decision.json",
    type: "board-decision",
    exitCode: 1,
    mutate(payload) {
      payload.decision = "approve";
      delete payload.selected_option;
    },
    requiredCodes: ["BOARD_DECISION_OPTION_REQUIRED"]
  },
  {
    name: "valid battle rhythm event",
    file: "sample-payloads/valid-battle-rhythm-event.json",
    type: "battle-rhythm-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "battle rhythm event with unknown class",
    file: "sample-payloads/invalid-battle-rhythm-event-unknown-class.json",
    type: "battle-rhythm-event",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH"]
  },
  {
    name: "battle rhythm event with impossible cron and quorum",
    file: "sample-payloads/valid-battle-rhythm-event.json",
    type: "battle-rhythm-event",
    exitCode: 1,
    mutate(payload) {
      payload.cadence.kind = "cron";
      payload.quorum.minimum_participants = 99;
    },
    requiredCodes: ["BATTLE_RHYTHM_CRON_CADENCE_INVALID", "BATTLE_RHYTHM_QUORUM_IMPOSSIBLE"]
  },
  {
    name: "valid battle rhythm scheduler proposal",
    file: "sample-payloads/valid-battle-rhythm-scheduler.json",
    type: "battle-rhythm-scheduler",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "battle rhythm scheduler occurrence must be timestamp or null",
    file: "sample-payloads/invalid-battle-rhythm-scheduler-object-occurrence.json",
    type: "battle-rhythm-scheduler",
    exitCode: 1,
    requiredCodes: ["ANY_OF_MISMATCH"]
  },
  {
    name: "battle rhythm scheduler claiming auto-execution",
    file: "sample-payloads/invalid-battle-rhythm-scheduler-auto-executed.json",
    type: "battle-rhythm-scheduler",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH", "ENUM_MISMATCH"]
  },
  {
    name: "battle rhythm scheduler cannot propose with missing inputs",
    file: "sample-payloads/valid-battle-rhythm-scheduler.json",
    type: "battle-rhythm-scheduler",
    exitCode: 1,
    mutate(payload) {
      payload.proposals[0].inputs_missing = ["SITREP-MISSING-001"];
    },
    requiredCodes: ["SCHEDULER_PROPOSAL_STATE_INCONSISTENT"]
  },
  {
    name: "valid agent METL",
    file: "sample-payloads/valid-agent-metl.json",
    type: "agent-metl",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "agent METL task without standards",
    file: "sample-payloads/invalid-agent-metl-missing-standards.json",
    type: "agent-metl",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "agent METL cannot duplicate task ids",
    file: "sample-payloads/valid-agent-metl.json",
    type: "agent-metl",
    exitCode: 1,
    mutate(payload) {
      payload.essential_tasks[1].task_id = payload.essential_tasks[0].task_id;
    },
    requiredCodes: ["AGENT_METL_DUPLICATE_TASK"]
  },
  {
    name: "valid readiness event",
    file: "sample-payloads/valid-readiness-event.json",
    type: "readiness-event",
    exitCode: 0,
    expectedCanExecute: false,
    requiredCodes: []
  },
  {
    name: "readiness event with self-certified extra field",
    file: "sample-payloads/invalid-readiness-event-extra-field.json",
    type: "readiness-event",
    exitCode: 1,
    requiredCodes: ["ADDITIONAL_PROPERTY"]
  },
  {
    name: "readiness event cannot self-promote or expand authority",
    file: "sample-payloads/invalid-readiness-event-self-promotion.json",
    type: "readiness-event",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH", "READINESS_UNAUTHORIZED_ACTOR", "READINESS_PROMOTION_STAGE_JUMP", "READINESS_PROMOTION_EVIDENCE_INSUFFICIENT", "READINESS_AUTHORITY_ESCALATION"]
  },
  {
    name: "valid source plan annex",
    file: "sample-payloads/valid-source-plan.json",
    type: "source-plan",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "source plan with unusable source tier",
    file: "sample-payloads/invalid-source-plan-unusable-tier.json",
    type: "source-plan",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH"]
  },
  {
    name: "source plan sequence cannot reference an unplanned source",
    file: "sample-payloads/valid-source-plan.json",
    type: "source-plan",
    exitCode: 1,
    mutate(payload) {
      payload.collection_sequence[1].source_id = "SRC-GHOST-999";
    },
    requiredCodes: ["SOURCE_PLAN_UNKNOWN_SOURCE", "SOURCE_PLAN_UNSCHEDULED_SOURCE"]
  },
  {
    name: "valid context release",
    file: "sample-payloads/valid-context-release.json",
    type: "context-release",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "external raw context release without expiry",
    file: "sample-payloads/invalid-context-release-external-raw-no-expiry.json",
    type: "context-release",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "external raw context release by executor with invalid revocation",
    file: "sample-payloads/invalid-context-release-external-raw-executor.json",
    type: "context-release",
    exitCode: 1,
    evaluatedAt: "2026-08-11T01:00:00Z",
    requiredCodes: [
      "ENUM_MISMATCH",
      "CONTEXT_RELEASE_INVALID_VALIDITY",
      "CONTEXT_RELEASE_EXTERNAL_AUTHORITY_REQUIRED",
      "CONTEXT_RELEASE_EXTERNAL_RAW_PROHIBITED",
      "CONTEXT_RELEASE_REVIEW_BINDINGS_MISSING",
      "CONTEXT_RELEASE_REVOCATION_INCOMPLETE",
      "CONTEXT_RELEASE_REVOKED"
    ]
  },
  {
    name: "valid resource status",
    file: "sample-payloads/valid-resource-status.json",
    type: "resource-status",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "resource status rejects non-positive capacity",
    file: "sample-payloads/invalid-resource-status-negative-capacity.json",
    type: "resource-status",
    exitCode: 1,
    requiredCodes: ["EXCLUSIVE_MINIMUM"]
  },
  {
    name: "resource status without thresholds",
    file: "sample-payloads/invalid-resource-status-missing-thresholds.json",
    type: "resource-status",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "resource status rejects inconsistent level and threshold order",
    file: "sample-payloads/valid-resource-status.json",
    type: "resource-status",
    exitCode: 1,
    mutate(payload) {
      payload.current_level = payload.capacity + 1;
      payload.threshold_bands.green.min_remaining_ratio = 0.1;
    },
    requiredCodes: ["RESOURCE_LEVEL_EXCEEDS_CAPACITY", "RESOURCE_THRESHOLD_ORDER_INVALID"]
  },
  {
    name: "valid decision log entry",
    file: "sample-payloads/valid-decision-log.json",
    type: "decision-log",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "decision log entry without authority basis",
    file: "sample-payloads/invalid-decision-log-no-authority-basis.json",
    type: "decision-log",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "decision log chosen option must have been considered",
    file: "sample-payloads/valid-decision-log.json",
    type: "decision-log",
    exitCode: 1,
    mutate(payload) {
      payload.chosen_option = "OPT-GHOST-999";
    },
    requiredCodes: ["DECISION_CHOICE_NOT_CONSIDERED"]
  },
  {
    name: "valid source record",
    file: "sample-payloads/valid-source-record.json",
    type: "source-record",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "source record with unusable tier",
    file: "sample-payloads/invalid-source-record-bad-tier.json",
    type: "source-record",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH"]
  },
  {
    name: "source record requires a linked document",
    file: "sample-payloads/valid-source-record.json",
    type: "source-record",
    exitCode: 1,
    mutate(payload) {
      payload.linked_documents = [];
    },
    requiredCodes: ["SOURCE_RECORD_WITHOUT_DOCUMENT"]
  },
  {
    name: "valid classification label",
    file: "sample-payloads/valid-classification-label.json",
    type: "classification-label",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "classification label with unknown EEFI class",
    file: "sample-payloads/invalid-classification-label-unknown-eefi-class.json",
    type: "classification-label",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH"]
  },
  {
    name: "valid releasability review",
    file: "sample-payloads/valid-releasability-review.json",
    type: "releasability-review",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "releasability review with unknown decision",
    file: "sample-payloads/invalid-releasability-review-unknown-decision.json",
    type: "releasability-review",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH"]
  },
  {
    name: "releasability review cannot release forbidden content",
    file: "sample-payloads/invalid-releasability-review-forbidden-release.json",
    type: "releasability-review",
    exitCode: 1,
    evaluatedAt: "2026-08-11T01:00:00Z",
    requiredCodes: [
      "ENUM_MISMATCH",
      "RELEASABILITY_REVIEW_EXPIRED",
      "RELEASABILITY_REVIEW_EXTERNAL_AUTHORITY_REQUIRED",
      "RELEASABILITY_REVIEW_BLOCKING_FINDINGS",
      "RELEASABILITY_REVIEW_OUTPUT_FORBIDDEN",
      "RELEASABILITY_REVIEW_RESTRICTED_EXTERNAL_RELEASE",
      "RELEASABILITY_REVIEW_NON_PUBLIC_RAW_RELEASE"
    ]
  },
  {
    name: "valid EEFI alert",
    file: "sample-payloads/valid-eefi-alert.json",
    type: "eefi-alert",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "EEFI alert carrying a raw excerpt",
    file: "sample-payloads/invalid-eefi-alert-raw-excerpt.json",
    type: "eefi-alert",
    exitCode: 1,
    requiredCodes: ["PATTERN_MISMATCH"]
  },
  {
    name: "valid green tool request",
    file: "sample-payloads/valid-tool-request-green.json",
    type: "tool-request",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "red without approval",
    file: "sample-payloads/invalid-tool-request-red-without-approval.json",
    type: "tool-request",
    exitCode: 1,
    requiredCodes: ["RED_WITHOUT_APPROVAL"]
  },
  {
    name: "valid dispatch tool policy",
    file: "sample-payloads/valid-dispatch-tool-policy.json",
    type: "dispatch-tool-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unsafe dispatch tool policy",
    file: "sample-payloads/invalid-dispatch-tool-policy-unsafe.json",
    type: "dispatch-tool-policy",
    exitCode: 1,
    requiredCodes: [
      "DISPATCH_POLICY_INVALID_VALIDITY",
      "DISPATCH_POLICY_DUPLICATE_RULE_ID",
      "DISPATCH_POLICY_UNSAFE_PATH_PREFIX"
    ]
  },
  {
    name: "self-minted dispatch tool policy",
    file: "sample-payloads/invalid-dispatch-tool-policy-untrusted-issuer.json",
    type: "dispatch-tool-policy",
    exitCode: 1,
    requiredCodes: ["DISPATCH_POLICY_UNTRUSTED_ISSUER"]
  },
  {
    name: "valid agent dispatch lease",
    file: "sample-payloads/valid-agent-dispatch-lease.json",
    type: "agent-dispatch-lease",
    exitCode: 0,
    expectedCanExecute: false,
    requiredCodes: []
  },
  {
    name: "frozen non-authorizing issuance request",
    file: "sample-payloads/valid-dispatch-lease-issuance-request.json",
    type: "dispatch-lease-issuance-request", exitCode: 0, expectedCanExecute: false, requiredCodes: []
  },
  {
    name: "issuance request nonce substitution",
    file: "sample-payloads/invalid-dispatch-lease-issuance-request.json",
    type: "dispatch-lease-issuance-request", exitCode: 1, requiredCodes: ["DISPATCH_ISSUANCE_ID_MISMATCH"]
  },
  {
    name: "non-authorizing issuance resolution",
    file: "sample-payloads/valid-dispatch-lease-issuance-resolution.json",
    type: "dispatch-lease-issuance-resolution", exitCode: 0, expectedCanExecute: false, requiredCodes: []
  },
  {
    name: "issuance commit without its actual baseline",
    file: "sample-payloads/invalid-dispatch-lease-issuance-resolution.json",
    type: "dispatch-lease-issuance-resolution", exitCode: 1, requiredCodes: ["DISPATCH_ISSUANCE_RESOLUTION_INVALID"]
  },
  {
    name: "journal-linked lease remains non-authorizing as standalone JSON",
    file: "sample-payloads/valid-agent-dispatch-lease-issuance.json",
    type: "agent-dispatch-lease", exitCode: 0, expectedCanExecute: false, requiredCodes: []
  },
  {
    name: "new lease without an issuance reference",
    file: "sample-payloads/invalid-agent-dispatch-lease-issuance.json",
    type: "agent-dispatch-lease", exitCode: 1, requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "unsafe agent dispatch lease",
    file: "sample-payloads/invalid-agent-dispatch-lease-unsafe.json",
    type: "agent-dispatch-lease",
    exitCode: 1,
    requiredCodes: [
      "DISPATCH_LEASE_INVALID_VALIDITY",
      "DISPATCH_LEASE_AUTHORITY_DRIFT",
      "DISPATCH_LEASE_REASON_REF_MISMATCH",
      "DISPATCH_LEASE_DIRTY_CLEAN_START"
    ]
  },
  {
    name: "valid tool admission event",
    file: "sample-payloads/valid-tool-admission-event.json",
    type: "tool-admission-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "tool admission allow without rule",
    file: "sample-payloads/invalid-tool-admission-event-allow-without-rule.json",
    type: "tool-admission-event",
    exitCode: 1,
    requiredCodes: ["TOOL_ADMISSION_ALLOW_WITHOUT_RULE"]
  },
  {
    name: "tool admission deny without reason",
    file: "sample-payloads/invalid-tool-admission-event-deny-without-reason.json",
    type: "tool-admission-event",
    exitCode: 1,
    requiredCodes: ["TOOL_ADMISSION_DENY_WITHOUT_REASON"]
  },
  {
    name: "valid agent execution checkpoint",
    file: "sample-payloads/valid-agent-execution-checkpoint.json",
    type: "agent-execution-checkpoint",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "invalid post-tool checkpoint chain",
    file: "sample-payloads/invalid-agent-execution-checkpoint-post-tool.json",
    type: "agent-execution-checkpoint",
    exitCode: 1,
    requiredCodes: [
      "EXECUTION_CHECKPOINT_CHAIN_INVALID",
      "EXECUTION_CHECKPOINT_POST_TOOL_INVALID"
    ]
  },
  {
    name: "execution checkpoint authority expansion",
    file: "sample-payloads/invalid-agent-execution-checkpoint-authority.json",
    type: "agent-execution-checkpoint",
    exitCode: 1,
    requiredCodes: ["EXECUTION_CHECKPOINT_AUTHORITY_EXPANSION"]
  },
  {
    name: "unresolved tool effect cannot remain active",
    file: "sample-payloads/invalid-agent-execution-checkpoint-unresolved-active.json",
    type: "agent-execution-checkpoint",
    exitCode: 1,
    requiredCodes: ["EXECUTION_CHECKPOINT_UNRESOLVED_EFFECT_ACTIVE"]
  },
  {
    name: "valid tool gateway request",
    file: "sample-payloads/valid-tool-gateway-request.json",
    type: "tool-gateway-request",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unsafe tool gateway request",
    file: "sample-payloads/invalid-tool-gateway-request-unsafe.json",
    type: "tool-gateway-request",
    exitCode: 1,
    requiredCodes: [
      "GATEWAY_REQUEST_INVALID_VALIDITY",
      "GATEWAY_REQUEST_AUDIENCE_MISMATCH",
      "GATEWAY_REQUEST_ASSURANCE_MISMATCH",
      "GATEWAY_REQUEST_FIXTURE_IDENTITY_FOR_MANAGED",
      "GATEWAY_REQUEST_RAW_INPUT_RETAINED",
      "GATEWAY_REQUEST_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid gateway identity policy",
    file: "sample-payloads/valid-gateway-identity-policy.json",
    type: "gateway-identity-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "gateway identity policy overclaims authority",
    file: "sample-payloads/invalid-gateway-identity-policy-overclaim.json",
    type: "gateway-identity-policy",
    exitCode: 1,
    requiredCodes: [
      "GATEWAY_IDENTITY_POLICY_VALIDITY_INVALID",
      "GATEWAY_IDENTITY_POLICY_SIGNING_KEY_INVALID",
      "GATEWAY_IDENTITY_POLICY_AUTHORITY_OVERCLAIM"
    ]
  },
  {
    name: "valid gateway identity challenge",
    file: "sample-payloads/valid-gateway-identity-challenge.json",
    type: "gateway-identity-challenge",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "stale gateway identity challenge",
    file: "sample-payloads/invalid-gateway-identity-challenge-stale.json",
    type: "gateway-identity-challenge",
    exitCode: 1,
    requiredCodes: [
      "GATEWAY_IDENTITY_CHALLENGE_VALIDITY_INVALID",
      "GATEWAY_IDENTITY_CHALLENGE_DIGEST_MISMATCH"
    ]
  },
  {
    name: "valid gateway principal evidence",
    file: "sample-payloads/valid-gateway-principal-evidence.json",
    type: "gateway-principal-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound gateway principal evidence",
    file: "sample-payloads/invalid-gateway-principal-evidence-unbound.json",
    type: "gateway-principal-evidence",
    exitCode: 1,
    requiredCodes: [
      "GATEWAY_IDENTITY_EVIDENCE_VALIDITY_INVALID",
      "GATEWAY_IDENTITY_EVIDENCE_DIGEST_MISMATCH",
      "GATEWAY_IDENTITY_EVIDENCE_LEAF_INVALID",
      "GATEWAY_IDENTITY_EVIDENCE_LEAF_DIGEST_MISMATCH"
    ]
  },
  {
    name: "valid production sandbox policy",
    file: "sample-payloads/valid-production-sandbox-policy.json",
    type: "production-sandbox-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "production sandbox policy overclaims authority",
    file: "sample-payloads/invalid-production-sandbox-policy-overclaim.json",
    type: "production-sandbox-policy",
    exitCode: 1,
    requiredCodes: [
      "PRODUCTION_SANDBOX_POLICY_APPRAISER_INVALID",
      "PRODUCTION_SANDBOX_POLICY_AUTHORITY_INVALID",
      "PRODUCTION_SANDBOX_POLICY_NOT_ACTIVE",
      "PRODUCTION_SANDBOX_POLICY_REQUIRED_CONTROL_MISSING"
    ]
  },
  {
    name: "production sandbox policy reorders required failure-domain dimensions",
    file: "sample-payloads/valid-production-sandbox-policy.json",
    type: "production-sandbox-policy",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH"],
    mutate(payload) {
      [
        payload.quorum.required_dimensions[0],
        payload.quorum.required_dimensions[1]
      ] = [
        payload.quorum.required_dimensions[1],
        payload.quorum.required_dimensions[0]
      ];
    }
  },
  {
    name: "valid production sandbox evidence",
    file: "sample-payloads/valid-production-sandbox-evidence.json",
    type: "production-sandbox-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "production sandbox evidence overclaims authority",
    file: "sample-payloads/invalid-production-sandbox-evidence-overclaim.json",
    type: "production-sandbox-evidence",
    exitCode: 1,
    requiredCodes: [
      "PRODUCTION_SANDBOX_EVIDENCE_ATTESTATION_RESULT_INVALID",
      "PRODUCTION_SANDBOX_EVIDENCE_NOT_ACTIVE",
      "PRODUCTION_SANDBOX_EVIDENCE_AUTHORITY_INVALID"
    ]
  },
  {
    name: "valid production sandbox admission",
    file: "sample-payloads/valid-production-sandbox-admission.json",
    type: "production-sandbox-admission",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "production sandbox admission overclaims authority",
    file: "sample-payloads/invalid-production-sandbox-admission-overclaim.json",
    type: "production-sandbox-admission",
    exitCode: 1,
    requiredCodes: [
      "PRODUCTION_SANDBOX_ADMISSION_PROJECTION_MISMATCH",
      "PRODUCTION_SANDBOX_ADMISSION_NOT_ACTIVE",
      "PRODUCTION_SANDBOX_ADMISSION_AUTHORITY_INVALID"
    ]
  },
  {
    name: "valid tool gateway decision",
    file: "sample-payloads/valid-tool-gateway-decision.json",
    type: "tool-gateway-decision",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound tool gateway allow decision",
    file: "sample-payloads/invalid-tool-gateway-decision-unbound.json",
    type: "tool-gateway-decision",
    exitCode: 1,
    requiredCodes: [
      "GATEWAY_DECISION_ALLOW_UNBOUND",
      "GATEWAY_DECISION_REASON_MISSING",
      "GATEWAY_DECISION_INVALID_VALIDITY"
    ]
  },
  {
    name: "valid tool execution receipt",
    file: "sample-payloads/valid-tool-execution-receipt.json",
    type: "tool-execution-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "incomplete committed tool execution receipt",
    file: "sample-payloads/invalid-tool-execution-receipt-incomplete.json",
    type: "tool-execution-receipt",
    exitCode: 1,
    requiredCodes: [
      "TOOL_EXECUTION_RECEIPT_COMMIT_INCOMPLETE",
      "TOOL_EXECUTION_RECEIPT_REF_UNBOUND",
      "TOOL_EXECUTION_RECEIPT_EXECUTOR_REF_MISMATCH",
      "TOOL_EXECUTION_RECEIPT_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid protected executor policy",
    file: "sample-payloads/valid-protected-executor-policy.json",
    type: "protected-executor-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound protected executor policy",
    file: "sample-payloads/invalid-protected-executor-policy-unbound.json",
    type: "protected-executor-policy",
    exitCode: 1,
    requiredCodes: [
      "PROTECTED_EXECUTOR_POLICY_INVALID_VALIDITY",
      "PROTECTED_EXECUTOR_POLICY_SIGNING_KEY_INVALID",
      "PROTECTED_EXECUTOR_POLICY_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid protected process tool input",
    file: "sample-payloads/valid-protected-process-tool-input.json",
    type: "protected-process-tool-input",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound protected process tool input",
    file: "sample-payloads/invalid-protected-process-tool-input-unbound.json",
    type: "protected-process-tool-input",
    exitCode: 1,
    requiredCodes: ["PROTECTED_PROCESS_POLICY_REF_UNBOUND"]
  },
  {
    name: "valid protected execution envelope",
    file: "sample-payloads/valid-protected-execution-envelope.json",
    type: "protected-execution-envelope",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound protected execution envelope",
    file: "sample-payloads/invalid-protected-execution-envelope-unbound.json",
    type: "protected-execution-envelope",
    exitCode: 1,
    requiredCodes: [
      "PROTECTED_EXECUTION_ENVELOPE_REF_UNBOUND",
      "PROTECTED_EXECUTION_ENVELOPE_SIGNATURE_MALFORMED",
      "PROTECTED_EXECUTION_ENVELOPE_DIGEST_MISMATCH"
    ]
  },
  {
    name: "valid protected execution observation",
    file: "sample-payloads/valid-protected-execution-observation.json",
    type: "protected-execution-observation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "inconsistent protected execution observation",
    file: "sample-payloads/invalid-protected-execution-observation-inconsistent.json",
    type: "protected-execution-observation",
    exitCode: 1,
    requiredCodes: [
      "PROTECTED_EXECUTION_OUTPUT_ACCOUNTING_INVALID",
      "PROTECTED_EXECUTION_PROCESS_STATE_INVALID",
      "PROTECTED_EXECUTION_OBSERVATION_DIGEST_MISMATCH"
    ]
  },
  {
    name: "valid OCI Linux sandbox policy",
    file: "sample-payloads/valid-oci-linux-sandbox-policy.json",
    type: "oci-linux-sandbox-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "overclaiming OCI Linux sandbox policy",
    file: "sample-payloads/invalid-oci-linux-sandbox-policy-overclaim.json",
    type: "oci-linux-sandbox-policy",
    exitCode: 1,
    requiredCodes: ["OCI_SANDBOX_POLICY_AUTHORITY_DRIFT"]
  },
  {
    name: "valid OCI sandbox tool input",
    file: "sample-payloads/valid-oci-sandbox-tool-input.json",
    type: "oci-sandbox-tool-input",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound OCI sandbox tool input",
    file: "sample-payloads/invalid-oci-sandbox-tool-input-unbound.json",
    type: "oci-sandbox-tool-input",
    exitCode: 1,
    requiredCodes: ["OCI_SANDBOX_POLICY_REF_UNBOUND"]
  },
  {
    name: "valid OCI sandbox execution envelope",
    file: "sample-payloads/valid-oci-sandbox-execution-envelope.json",
    type: "oci-sandbox-execution-envelope",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound OCI sandbox execution envelope",
    file: "sample-payloads/invalid-oci-sandbox-execution-envelope-unbound.json",
    type: "oci-sandbox-execution-envelope",
    exitCode: 1,
    requiredCodes: [
      "OCI_SANDBOX_ENVELOPE_REF_UNBOUND",
      "OCI_SANDBOX_ENVELOPE_DIGEST_MISMATCH"
    ]
  },
  {
    name: "daemon-bound OCI envelope",
    file: "sample-payloads/valid-oci-sandbox-execution-envelope-v0.2.json",
    type: "oci-sandbox-execution-envelope",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "v0.2 OCI envelope requires its daemon binding",
    file: "sample-payloads/invalid-oci-sandbox-execution-envelope-v0.2-daemon.json",
    type: "oci-sandbox-execution-envelope",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "valid OCI containment observation",
    file: "sample-payloads/valid-oci-sandbox-containment-observation.json",
    type: "oci-sandbox-containment-observation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "OCI gateway subject binds all containment reference history",
    file: "sample-payloads/valid-gateway-effect-subject-v0.2.json",
    type: "gateway-effect-subject",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "v0.2 gateway subject cannot omit containment history",
    file: "sample-payloads/invalid-gateway-effect-subject-v0.2-history.json",
    type: "gateway-effect-subject",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"]
  },
  {
    name: "OCI containment observation has bounded freshness",
    file: "sample-payloads/invalid-oci-sandbox-containment-observation-expiry.json",
    type: "oci-sandbox-containment-observation",
    exitCode: 1,
    requiredCodes: ["OCI_CONTAINMENT_TIME_INVALID"]
  },
  {
    name: "valid OCI sandbox probe observation",
    file: "sample-payloads/valid-oci-sandbox-probe-observation.json",
    type: "oci-sandbox-probe-observation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "privileged OCI sandbox probe observation",
    file: "sample-payloads/invalid-oci-sandbox-probe-observation-privileged.json",
    type: "oci-sandbox-probe-observation",
    exitCode: 1,
    requiredCodes: ["OCI_SANDBOX_PROBE_PRIVILEGE_INVALID"]
  },
  {
    name: "valid OCI sandbox execution observation",
    file: "sample-payloads/valid-oci-sandbox-execution-observation.json",
    type: "oci-sandbox-execution-observation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unclean OCI sandbox execution observation",
    file: "sample-payloads/invalid-oci-sandbox-execution-observation-unclean.json",
    type: "oci-sandbox-execution-observation",
    exitCode: 1,
    requiredCodes: [
      "OCI_SANDBOX_OBSERVATION_STATE_INVALID",
      "OCI_SANDBOX_OBSERVATION_DIGEST_MISMATCH"
    ]
  },
  {
    name: "valid tool gateway transaction event",
    file: "sample-payloads/valid-tool-gateway-transaction-event.json",
    type: "tool-gateway-transaction-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "invalid tool gateway transaction transition",
    file: "sample-payloads/invalid-tool-gateway-transaction-event-transition.json",
    type: "tool-gateway-transaction-event",
    exitCode: 1,
    requiredCodes: [
      "GATEWAY_TRANSACTION_CHAIN_INVALID",
      "GATEWAY_TRANSACTION_TERMINAL_INVALID",
      "GATEWAY_TRANSACTION_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid approval request",
    file: "sample-payloads/valid-approval-request.json",
    type: "approval-request",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid SITREP",
    file: "sample-payloads/valid-sitrep.json",
    type: "sitrep",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid evidence",
    file: "sample-payloads/valid-evidence.json",
    type: "evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid AAR",
    file: "sample-payloads/valid-aar.json",
    type: "aar",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid authority matrix",
    file: "sample-payloads/valid-authority-matrix.json",
    type: "authority-matrix",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "red authority without approver",
    file: "sample-payloads/invalid-authority-matrix-red-without-approver.json",
    type: "authority-matrix",
    exitCode: 1,
    requiredCodes: ["DEFAULT_ALLOW_TOO_BROAD", "RED_NOT_APPROVAL_REQUIRED", "RED_WITHOUT_APPROVAL_AUTHORITY", "HIGH_RISK_ALLOW"]
  },
  {
    name: "valid decision packet",
    file: "sample-payloads/valid-decision-packet.json",
    type: "decision-packet",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "decision packet without options",
    file: "sample-payloads/invalid-decision-packet-no-options.json",
    type: "decision-packet",
    exitCode: 1,
    requiredCodes: ["DECISION_PACKET_WITHOUT_OPTIONS", "RECOMMENDATION_NOT_IN_OPTIONS", "AUTHORITY_REQUIRED_EMPTY", "DECISION_WITHOUT_EVIDENCE"]
  },
  {
    name: "valid working group",
    file: "sample-payloads/valid-working-group.json",
    type: "working-group",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid SOF TF charter",
    file: "sample-payloads/valid-sof-tf-charter.json",
    type: "sof-tf-charter",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbounded SOF TF charter",
    file: "sample-payloads/invalid-sof-tf-charter-unbounded.json",
    type: "sof-tf-charter",
    exitCode: 1,
    requiredCodes: [
      "SOF_TF_WITHOUT_TRIGGER",
      "SOF_TF_WITHOUT_RED_RETAINED_AUTHORITY",
      "SOF_TF_DIRECT_ACTION_WITHOUT_APPROVAL",
      "SOF_TF_RED_TEAM_NOT_INDEPENDENT",
      "SOF_TF_RELEASE_REVIEW_NOT_INDEPENDENT",
      "SOF_TF_WITHOUT_RECORDER",
      "SOF_TF_SOURCE_MAP_NOT_REQUIRED",
      "SOF_TF_RELEASE_REVIEW_NOT_REQUIRED",
      "SOF_TF_WITHOUT_FALLBACK_PLAN",
      "SOF_TF_WITHOUT_ABORT_CRITERIA"
    ]
  },
  {
    name: "valid department collaboration charter",
    file: "sample-payloads/valid-department-collaboration-charter.json",
    type: "department-collaboration-charter",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "siloed department collaboration charter",
    file: "sample-payloads/invalid-department-collaboration-charter-siloed.json",
    type: "department-collaboration-charter",
    exitCode: 1,
    requiredCodes: [
      "COLLABORATION_TOO_FEW_DEPARTMENTS",
      "COLLABORATION_WITHOUT_COMMAND",
      "COLLABORATION_WITHOUT_RECORDER",
      "DEPARTMENT_WITHOUT_SOURCE_OF_TRUTH",
      "RELATIONSHIP_UNKNOWN_SUPPORTING_DEPARTMENT",
      "RELATIONSHIP_WITHOUT_REQUIRED_OUTPUTS",
      "RELATIONSHIP_WITHOUT_HANDOFF_INTERFACE",
      "RELATIONSHIP_WITHOUT_LIAISON",
      "LIAISON_NOT_PAIRWISE",
      "COLLABORATION_CONFLICT_AUTHORITY_TOO_LOW",
      "COLLABORATION_WITHOUT_DECISION_PACKET_ROUTE",
      "COLLABORATION_WITHOUT_SOURCE_MAP",
      "COLLABORATION_WITHOUT_EEFI_CONTROLS"
    ]
  },
  {
    name: "valid force structure change order",
    file: "sample-payloads/valid-force-structure-change-order.json",
    type: "force-structure-change-order",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid COS wave routing receipt",
    file: "sample-payloads/valid-routing-receipt-wave-cos.json",
    type: "routing-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid S3 agent routing receipt",
    file: "sample-payloads/valid-routing-receipt-agent-s3.json",
    type: "routing-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "capability-gap routing omits force-structure controls",
    file: "sample-payloads/invalid-routing-receipt-capability-gap-bypass.json",
    type: "routing-receipt",
    exitCode: 1,
    requiredCodes: ["CAPABILITY_GAP_WITHOUT_FORCE_STRUCTURE_CONTROL"]
  },
  {
    name: "manual routing receipt without router proof",
    file: "sample-payloads/invalid-routing-receipt-manual.json",
    type: "routing-receipt",
    exitCode: 1,
    requiredCodes: [
      "ROUTING_RECEIPT_WITHOUT_MATCHED_ROUTES",
      "ROUTING_RECEIPT_WITHOUT_SOURCE_MAP",
      "ROUTING_RECEIPT_UNROUTED_ARTIFACTS",
      "ROUTING_RECEIPT_NOT_FROM_CONTROLS_ROUTER",
      "ROUTING_RECEIPT_NOT_AI_ACTOR"
    ]
  },
  {
    name: "agent routing receipt with wrong role",
    file: "sample-payloads/invalid-routing-receipt-agent-wrong-role.json",
    type: "routing-receipt",
    exitCode: 1,
    requiredCodes: [
      "AGENT_ROUTING_NOT_S3",
      "AGENT_ROUTING_WRONG_DEPARTMENT",
      "AGENT_ROUTING_WRONG_AUTHORITY"
    ]
  },
  {
    name: "valid operational mission wave plan",
    file: "sample-payloads/valid-mission-wave-plan.json",
    type: "mission-wave-plan",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "mission wave plan assigns AI final authority",
    file: "sample-payloads/invalid-mission-wave-plan-ai-final-authority.json",
    type: "mission-wave-plan",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH", "MISSION_WAVE_AI_COMMAND_AUTHORITY", "MISSION_WAVE_RETAINED_ACTION_DELEGATED"]
  },
  {
    name: "valid operational agent context pack",
    file: "sample-payloads/valid-agent-context-pack.json",
    type: "agent-context-pack",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "agent context pack claims release authority",
    file: "sample-payloads/invalid-agent-context-pack-release-authorized.json",
    type: "agent-context-pack",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "valid mandatory control execution receipt",
    file: "sample-payloads/valid-control-execution-receipt.json",
    type: "control-execution-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "mandatory control receipt falsely claims pass",
    file: "sample-payloads/invalid-control-execution-receipt-false-pass.json",
    type: "control-execution-receipt",
    exitCode: 1,
    requiredCodes: ["CONTROL_RECEIPT_STATUS_MISMATCH"]
  },
  {
    name: "mandatory control receipt cannot substitute report input",
    file: "sample-payloads/valid-control-execution-receipt.json",
    type: "control-execution-receipt",
    exitCode: 1,
    mutate(payload) {
      payload.report_input_sha256 = "cd".repeat(32);
    },
    requiredCodes: ["CONTROL_RECEIPT_ID_BINDING_MISMATCH"]
  },
  {
    name: "mandatory control receipt cannot substitute its command descriptor",
    file: "sample-payloads/valid-control-execution-receipt.json",
    type: "control-execution-receipt",
    exitCode: 1,
    mutate(payload) {
      payload.control.script_path = "source-map-linter.js";
    },
    requiredCodes: ["CONTROL_RECEIPT_DESCRIPTOR_MISMATCH"]
  },
  {
    name: "mandatory control receipt cannot lie about unchanged state",
    file: "sample-payloads/valid-control-execution-receipt.json",
    type: "control-execution-receipt",
    exitCode: 1,
    mutate(payload) {
      payload.repository_state_before_sha256 = "12".repeat(32);
    },
    requiredCodes: ["CONTROL_RECEIPT_STATE_BINDING_MISMATCH"]
  },
  {
    name: "valid operational mission wave report",
    file: "sample-payloads/valid-mission-wave-report.json",
    type: "mission-wave-report",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "mission wave report requests self-release",
    file: "sample-payloads/invalid-mission-wave-report-self-release.json",
    type: "mission-wave-report",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "valid operational mission wave closeout",
    file: "sample-payloads/valid-mission-wave-closeout.json",
    type: "mission-wave-closeout",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid mission wave expiration request",
    file: "sample-payloads/valid-mission-wave-termination-request.json",
    type: "mission-wave-termination-request",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid mission wave expiration record",
    file: "sample-payloads/valid-mission-wave-termination.json",
    type: "mission-wave-termination",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "aborting a mission requires a retained decision",
    file: "sample-payloads/invalid-mission-wave-termination-request-unapproved.json",
    type: "mission-wave-termination-request",
    exitCode: 1,
    requiredCodes: ["MISSION_TERMINATION_DECISION_REQUIRED"]
  },
  {
    name: "mission expiration cannot be backdated",
    file: "sample-payloads/invalid-mission-wave-termination-premature.json",
    type: "mission-wave-termination",
    exitCode: 1,
    requiredCodes: ["MISSION_TERMINATION_INVALID_TIME"]
  },
  {
    name: "mission wave closeout claims self-release",
    file: "sample-payloads/invalid-mission-wave-closeout-self-release.json",
    type: "mission-wave-closeout",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH"]
  },
  {
    name: "unjustified force structure expansion",
    file: "sample-payloads/invalid-force-structure-change-order-unjustified.json",
    type: "force-structure-change-order",
    exitCode: 1,
    requiredCodes: [
      "FORCE_CHANGE_WITHOUT_EVIDENCE",
      "FORCE_CHANGE_WITHOUT_ALTERNATIVES",
      "FORCE_CHANGE_WITHOUT_NON_ORG_ALTERNATIVE",
      "FORCE_CHANGE_INCOMPLETE_DOTMLPF",
      "FORCE_CHANGE_REQUIRES_COMMANDER",
      "FORCE_CHANGE_WITHOUT_APPROVAL_EVIDENCE",
      "FORCE_CHANGE_WITHOUT_MAINTAINER",
      "FORCE_CHANGE_LOW_READINESS_TARGET",
      "FORCE_CHANGE_WITHOUT_VALIDATION_FIXTURE",
      "FORCE_CHANGE_WITHOUT_HANDOFF",
      "FORCE_CHANGE_WITHOUT_SUNSET",
      "FORCE_CHANGE_WITHOUT_DOC_UPDATE",
      "FORCE_CHANGE_WITHOUT_MOE",
      "FORCE_CHANGE_WITHOUT_SUNSET_CONDITION"
    ]
  },
  {
    name: "valid model force assignment plan",
    file: "sample-payloads/valid-model-force-assignment-plan.json",
    type: "model-force-assignment-plan",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unready model force monoculture",
    file: "sample-payloads/invalid-model-force-assignment-plan-monoculture.json",
    type: "model-force-assignment-plan",
    exitCode: 1,
    requiredCodes: [
      "MODEL_ASSIGNMENT_FLOATING_VERSION",
      "MODEL_ASSIGNMENT_WITHOUT_EVIDENCE",
      "MODEL_ASSIGNMENT_TASK_NOT_EVALUATED",
      "MODEL_ASSIGNMENT_INSUFFICIENT_READINESS",
      "MODEL_ASSIGNMENT_CONTEXT_INELIGIBLE",
      "MODEL_ASSIGNMENT_SELF_FALLBACK",
      "MODEL_ASSIGNMENT_FALLBACK_NOT_QUALIFIED",
      "MODEL_ASSIGNMENT_FALLBACK_UNREADY",
      "MODEL_ASSIGNMENT_FALLBACK_CONTEXT_INELIGIBLE",
      "MODEL_ASSIGNMENT_CRITICAL_BILLET_WITHOUT_DEPTH",
      "MODEL_ASSIGNMENT_ROUTER_UNREADY",
      "MODEL_ASSIGNMENT_ROUTER_WITHOUT_HELD_OUT_EVAL",
      "MODEL_ASSIGNMENT_CONFIDENCE_ONLY",
      "MODEL_ASSIGNMENT_ASSURANCE_PROFILE_NOT_BILLETED",
      "MODEL_ASSIGNMENT_CORRELATED_ASSURANCE",
      "MODEL_ASSIGNMENT_WITHOUT_DETERMINISTIC_CHECKS",
      "MODEL_ASSIGNMENT_PACE_NOT_DISTINCT",
      "MODEL_ASSIGNMENT_PACE_NOT_TASK_READY",
      "MODEL_ASSIGNMENT_AUTHORITY_FROM_MODEL",
      "MODEL_ASSIGNMENT_HUMAN_AUTHORITY_MISSING",
      "MODEL_ASSIGNMENT_FORCE_MONOCULTURE"
    ]
  },
  {
    name: "valid model registry",
    file: "sample-payloads/valid-model-registry.json",
    type: "model-registry",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unready model registry",
    file: "sample-payloads/invalid-model-registry-unready.json",
    type: "model-registry",
    exitCode: 1,
    requiredCodes: [
      "MODEL_REGISTRY_FLOATING_IDENTITY",
      "MODEL_REGISTRY_FLOATING_VERSION",
      "MODEL_REGISTRY_SECRET_IN_ENDPOINT_REF",
      "MODEL_REGISTRY_DUPLICATE_TASK_READINESS",
      "MODEL_REGISTRY_READY_WITHOUT_EVIDENCE",
      "MODEL_REGISTRY_EXPIRED_READINESS",
      "MODEL_REGISTRY_INVALID_OWNER",
      "MODEL_REGISTRY_HUMAN_AUTHORITY_MISSING"
    ]
  },
  {
    name: "valid model assignment request",
    file: "sample-payloads/valid-model-assignment-request.json",
    type: "model-assignment-request",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unsafe model assignment request",
    file: "sample-payloads/invalid-model-assignment-request-unsafe.json",
    type: "model-assignment-request",
    exitCode: 1,
    requiredCodes: [
      "MODEL_REQUEST_WEIGHTS_NOT_100",
      "MODEL_REQUEST_REGISTRY_VERSION_FLOATING",
      "MODEL_REQUEST_CLASSIFICATION_MISMATCH",
      "MODEL_REQUEST_BLACK_PROHIBITED",
      "MODEL_REQUEST_WITHOUT_DEPLOYMENT_BOUNDARY",
      "MODEL_REQUEST_WITHOUT_READY_ROUTER",
      "MODEL_REQUEST_MISSING_COMMAND",
      "MODEL_REQUEST_REQUIRES_ASSURANCE",
      "MODEL_REQUEST_AUTHORITY_FROM_MODEL",
      "MODEL_REQUEST_HUMAN_AUTHORITY_MISSING"
    ]
  },
  {
    name: "valid integrated mission preflight",
    file: "sample-payloads/valid-integrated-mission-preflight.json",
    type: "integrated-mission-preflight",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unbound integrated mission preflight",
    file: "sample-payloads/invalid-integrated-mission-preflight-unbound.json",
    type: "integrated-mission-preflight",
    exitCode: 1,
    requiredCodes: [
      "INTEGRATED_PREFLIGHT_PATH_TRAVERSAL",
      "INTEGRATED_PREFLIGHT_HUMAN_AUTHORITY_MISSING"
    ]
  },
  {
    name: "valid model usage event",
    file: "sample-payloads/valid-model-usage-event.json",
    type: "model-usage-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "self-authorized model usage event",
    file: "sample-payloads/invalid-model-usage-event-self-authorized.json",
    type: "model-usage-event",
    exitCode: 1,
    requiredCodes: [
      "MODEL_USAGE_FLOATING_VERSION",
      "MODEL_USAGE_WITHOUT_AUTHORITY_SNAPSHOT",
      "MODEL_USAGE_WITHOUT_EXTERNAL_EVIDENCE"
    ]
  },
  {
    name: "valid repository artifact manifest",
    file: "sample-payloads/valid-repository-artifact-manifest.json",
    type: "repository-artifact-manifest",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "cross-repository artifact manifest",
    file: "sample-payloads/invalid-repository-artifact-manifest-cross-repo.json",
    type: "repository-artifact-manifest",
    exitCode: 1,
    requiredCodes: [
      "REPOSITORY_ARTIFACT_NAMESPACE_MISMATCH",
      "REPOSITORY_ARTIFACT_COUNT_MISMATCH",
      "REPOSITORY_ARTIFACT_PATH_TRAVERSAL",
      "REPOSITORY_ARTIFACT_CROSS_REPOSITORY_PATH",
      "REPOSITORY_ARTIFACT_ID_PATH_MISMATCH"
    ]
  },
  {
    name: "valid document access manifest",
    file: "sample-payloads/valid-document-access-manifest.json",
    type: "document-access-manifest",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "overbroad document access manifest",
    file: "sample-payloads/invalid-document-access-manifest-overbroad.json",
    type: "document-access-manifest",
    exitCode: 1,
    requiredCodes: [
      "DOCUMENT_ACCESS_WITHOUT_NEED_TO_KNOW",
      "DOCUMENT_ACCESS_ALLOWS_BULK_READ",
      "DOCUMENT_ACCESS_WITHOUT_AUDIT",
      "DOCUMENT_ACCESS_EXCEPTION_WITHOUT_APPROVAL",
      "DOCUMENT_ACCESS_WILDCARD_PATH",
      "DOCUMENT_ACCESS_WITHOUT_ALLOWED_ROLES",
      "DOCUMENT_ACCESS_WITHOUT_DUTIES",
      "DOCUMENT_ACCESS_SENSITIVE_RAW_TOO_BROAD",
      "DOCUMENT_ACCESS_RESTRICTED_RAW",
      "DOCUMENT_ACCESS_REQUIRED_DOC_NOT_DECLARED",
      "DOCUMENT_ACCESS_REQUIRED_DOC_NOT_READABLE",
      "DOCUMENT_ACCESS_DENIED_DOC_REQUIRED",
      "DOCUMENT_ACCESS_ESCALATION_SELF"
    ]
  },
  {
    name: "valid doctrine consistency review",
    file: "sample-payloads/valid-doctrine-consistency-review.json",
    type: "doctrine-consistency-review",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "US-only doctrine consistency review",
    file: "sample-payloads/invalid-doctrine-consistency-review-us-only.json",
    type: "doctrine-consistency-review",
    exitCode: 1,
    requiredCodes: [
      "DOCTRINE_REVIEW_TOO_FEW_SOURCE_FAMILIES",
      "DOCTRINE_REVIEW_TOO_FEW_NON_US_FAMILIES",
      "DOCTRINE_REVIEW_US_ONLY_DISPOSITION",
      "DOCTRINE_REVIEW_CONTROL_DISABLED",
      "DOCTRINE_REVIEW_UNVERIFIED_FINDING",
      "DOCTRINE_REVIEW_PLACEHOLDER_DOC_UPDATE",
      "DOCTRINE_REVIEW_ROLE_ALIAS_MISSING",
      "DOCTRINE_REVIEW_JURISDICTION_GATE_MISSING"
    ]
  },
  {
    name: "working group without disband condition",
    file: "sample-payloads/invalid-working-group-no-disband.json",
    type: "working-group",
    exitCode: 1,
    requiredCodes: ["CHAIR_NOT_IN_PARTICIPANTS", "WORKING_GROUP_WITHOUT_DELIVERABLE", "NO_DISBAND_CONDITION"]
  },
  {
    name: "valid CCIR alert",
    file: "sample-payloads/valid-ccir-alert.json",
    type: "ccir-alert",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "red CCIR alert without decision",
    file: "sample-payloads/invalid-ccir-alert-red-without-decision.json",
    type: "ccir-alert",
    exitCode: 1,
    requiredCodes: ["HIGH_SEVERITY_ALERT_NOT_BLOCKING", "HIGH_SEVERITY_WITHOUT_DECISION"]
  },
  {
    name: "valid handoff packet",
    file: "sample-payloads/valid-handoff-packet.json",
    type: "handoff-packet",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid continuity plan",
    file: "sample-payloads/valid-continuity-plan.json",
    type: "continuity-plan",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "continuity plan with single point of failure",
    file: "sample-payloads/invalid-continuity-plan-single-point-failure.json",
    type: "continuity-plan",
    exitCode: 1,
    requiredCodes: [
      "ESSENTIAL_FUNCTION_NOT_TWO_DEEP",
      "SUCCESSOR_CANNOT_BE_SELF",
      "ESSENTIAL_FUNCTION_WITHOUT_HANDOFF",
      "ESSENTIAL_FUNCTION_WITHOUT_VITAL_RECORDS",
      "SUCCESSION_RULE_NOT_TWO_DEEP",
      "SUCCESSION_RULE_SELF_SUCCESSOR",
      "SUCCESSION_WITHOUT_AUTHORITY_LIMITS",
      "ROTATION_WITHOUT_OVERLAP",
      "ROTATION_WITHOUT_BACKBRIEF",
      "ROTATION_WITHOUT_HANDOFF_PACKET",
      "CONTINUITY_WITHOUT_AUTHORITY_RECORD",
      "CONTINUITY_WITHOUT_HANDOFF_RECORD",
      "DEGRADED_MODE_WITHOUT_PAUSED_FUNCTIONS",
      "CONTINUITY_WITHOUT_COMMANDER_RETAINED_DECISIONS"
    ]
  },
  {
    name: "blocked handoff without decision",
    file: "sample-payloads/invalid-handoff-packet-blocked-without-decision.json",
    type: "handoff-packet",
    exitCode: 1,
    requiredCodes: ["HANDOFF_WITHOUT_SOURCE_OF_TRUTH", "BLOCKED_WITHOUT_PENDING_DECISION", "HANDOFF_WITHOUT_PROHIBITIONS"]
  },
  {
    name: "valid context item",
    file: "sample-payloads/valid-context-item.json",
    type: "context-item",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "EEFI context item released to final",
    file: "sample-payloads/invalid-context-item-eefi-final.json",
    type: "context-item",
    exitCode: 1,
    requiredCodes: ["EEFI_RELEASE_TO_FINAL", "RESTRICTED_RELEASE_TO_FINAL", "RAW_EEFI_PRESENT"]
  },
  {
    name: "valid release review",
    file: "sample-payloads/valid-release-review.json",
    type: "release-review",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "release review approves raw EEFI",
    file: "sample-payloads/invalid-release-review-eefi-approved.json",
    type: "release-review",
    exitCode: 1,
    requiredCodes: ["NO_RELEASE_CONSTRAINTS", "RESTRICTED_OR_EEFI_RAW_RELEASE", "NON_PUBLIC_RAW_FINAL_OUTPUT"]
  },
  {
    name: "valid release gate decision event",
    file: "sample-payloads/valid-release-gate-decision-event.json",
    type: "release-gate-decision-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "release gate allows missing release review",
    file: "sample-payloads/invalid-release-gate-decision-event-missing-review.json",
    type: "release-gate-decision-event",
    exitCode: 1,
    requiredCodes: ["RELEASE_GATE_RELEASE_BLOCK_NOT_FINAL", "RELEASE_GATE_ALLOW_WITH_FAILED_RELEASE_REVIEW", "RELEASE_GATE_WITHOUT_EVIDENCE"]
  },
  {
    name: "valid exact GitHub release authorization",
    file: "sample-payloads/valid-github-release-authorization.json",
    type: "github-release-authorization",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "GitHub release authorization accepts AI approval",
    file: "sample-payloads/invalid-github-release-authorization-ai-approval.json",
    type: "github-release-authorization",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH", "GITHUB_RELEASE_AUTHORITY_DRIFT"]
  },
  {
    name: "valid exact GitHub release receipt",
    file: "sample-payloads/valid-github-release-receipt.json",
    type: "github-release-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "GitHub release receipt resolves tag to a different commit",
    file: "sample-payloads/invalid-github-release-receipt-tag-drift.json",
    type: "github-release-receipt",
    exitCode: 1,
    requiredCodes: ["GITHUB_RELEASE_RECEIPT_TARGET_MISMATCH"]
  },
  {
    name: "valid GitHub release immutability authorization",
    file: "sample-payloads/valid-github-release-immutability-authorization.json",
    type: "github-release-immutability-authorization",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "GitHub release immutability authorization accepts AI approval",
    file: "sample-payloads/invalid-github-release-immutability-authorization-ai-approval.json",
    type: "github-release-immutability-authorization",
    exitCode: 1,
    requiredCodes: [
      "CONST_MISMATCH",
      "GITHUB_RELEASE_IMMUTABILITY_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid GitHub release immutability receipt",
    file: "sample-payloads/valid-github-release-immutability-receipt.json",
    type: "github-release-immutability-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "GitHub release immutability receipt claims release authority",
    file: "sample-payloads/invalid-github-release-immutability-receipt-release-authority.json",
    type: "github-release-immutability-receipt",
    exitCode: 1,
    requiredCodes: [
      "CONST_MISMATCH",
      "GITHUB_RELEASE_IMMUTABILITY_RECEIPT_NOT_TERMINAL",
      "GITHUB_RELEASE_IMMUTABILITY_RECEIPT_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid GitHub release integrity policy",
    file: "sample-payloads/valid-github-release-integrity-policy.json",
    type: "github-release-integrity-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "v0.3 release integrity policy omits conditional checkpoint policy",
    file: ".github/release-integrity-policy.json",
    type: "github-release-integrity-policy",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED"],
    mutate(payload) {
      delete payload.trust_checkpoint_policy;
    }
  },
  {
    name: "GitHub release integrity policy claims mutation and release authority",
    file: "sample-payloads/invalid-github-release-integrity-policy-authority.json",
    type: "github-release-integrity-policy",
    exitCode: 1,
    requiredCodes: [
      "CONST_MISMATCH",
      "GITHUB_RELEASE_INTEGRITY_POLICY_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid GitHub release integrity observation",
    file: "sample-payloads/valid-github-release-integrity-observation.json",
    type: "github-release-integrity-observation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "GitHub release integrity observation claims mutation and release authority",
    file: "sample-payloads/invalid-github-release-integrity-observation-authority.json",
    type: "github-release-integrity-observation",
    exitCode: 1,
    requiredCodes: [
      "CONST_MISMATCH",
      "GITHUB_RELEASE_INTEGRITY_OBSERVATION_AUTHORITY_DRIFT"
    ]
  },
  {
    name: "valid USER-authorized GitHub release bootstrap recovery",
    file:
      "sample-payloads/valid-github-release-bootstrap-recovery.json",
    type: "github-release-bootstrap-recovery",
    evaluatedAt: "2026-07-28T00:30:00.000Z",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "GitHub release bootstrap recovery accepts AI authority",
    file:
      "sample-payloads/invalid-github-release-bootstrap-recovery-authority.json",
    type: "github-release-bootstrap-recovery",
    evaluatedAt: "2026-07-28T00:30:00.000Z",
    exitCode: 1,
    requiredCodes: [
      "CONST_MISMATCH",
      "GITHUB_RELEASE_BOOTSTRAP_RECOVERY_AUTHORITY_INVALID"
    ]
  },
  {
    name: "valid maintenance readiness",
    file: "sample-payloads/valid-maintenance-readiness.json",
    type: "maintenance-readiness",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "unavailable maintenance asset without fallback",
    file: "sample-payloads/invalid-maintenance-readiness-unavailable-no-fallback.json",
    type: "maintenance-readiness",
    exitCode: 1,
    requiredCodes: ["MIN_LENGTH", "OVERALL_FULLY_WITH_BAD_ASSETS", "FAILED_ASSET_WITHOUT_FALLBACK", "UNAVAILABLE_WITHOUT_CCIR", "BAD_ASSETS_WITHOUT_COMMANDER_DECISION_FLAG"]
  },
  {
    name: "valid backbrief",
    file: "sample-payloads/valid-backbrief.json",
    type: "backbrief",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "backbrief without stop conditions",
    file: "sample-payloads/invalid-backbrief-no-stop-conditions.json",
    type: "backbrief",
    exitCode: 1,
    requiredCodes: ["BACKBRIEF_WITHOUT_ACTIONS", "BACKBRIEF_WITHOUT_STOP_CONDITIONS", "BACKBRIEF_WITHOUT_RISK_CONTROLS", "LOW_CONFIDENCE_WITHOUT_CLARIFICATION", "DECISION_NEEDED_WITHOUT_QUESTION"]
  },
  {
    name: "valid rehearsal",
    file: "sample-payloads/valid-rehearsal.json",
    type: "rehearsal",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "rehearsal execute with unresolved change",
    file: "sample-payloads/invalid-rehearsal-execute-with-unresolved-change.json",
    type: "rehearsal",
    exitCode: 1,
    requiredCodes: ["REHEARSAL_WITHOUT_BACKBRIEF", "REHEARSAL_WITHOUT_SEQUENCE", "EXECUTE_WITH_UNRESOLVED_CHANGES", "HIGH_FRICTION_WITHOUT_DECISION_POINT"]
  },
  {
    name: "valid annex",
    file: "sample-payloads/valid-annex.json",
    type: "annex",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "annex changes authority",
    file: "sample-payloads/invalid-annex-changes-authority.json",
    type: "annex",
    exitCode: 1,
    requiredCodes: ["ANNEX_CHANGES_INTENT", "ANNEX_CHANGES_AUTHORITY", "ANNEX_WITHOUT_VERIFICATION"]
  },
  {
    name: "valid FRAGO scope change",
    file: "sample-payloads/valid-frago-scope-change.json",
    type: "frago-scope-change",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "FRAGO scope change without backbrief",
    file: "sample-payloads/invalid-frago-scope-change-no-backbrief.json",
    type: "frago-scope-change",
    exitCode: 1,
    requiredCodes: ["FRAGO_SCOPE_WITHOUT_CHANGE_DETAILS", "AUTHORITY_CHANGE_WITHOUT_AUTHORITY_DETAILS", "FRAGO_SCOPE_WITHOUT_AFFECTED_ROLES", "FRAGO_SCOPE_WITHOUT_BACKBRIEF", "FRAGO_SCOPE_WITHOUT_REHEARSAL", "FRAGO_SCOPE_WITHOUT_ANNEX_BOUNDARY_REASON", "AUTHORITY_FRAGO_REQUIRES_COMMANDER"]
  },
  {
    name: "valid information report",
    file: "sample-payloads/valid-information-report.json",
    type: "information-report",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "order-changing information without CCIR",
    file: "sample-payloads/invalid-information-report-order-change-no-ccir.json",
    type: "information-report",
    exitCode: 1,
    requiredCodes: ["INFORMATION_RELEVANT_WITHOUT_CCIR", "ORDER_CHANGE_NOT_ROUTED_TO_DECISION"]
  },
  {
    name: "valid intelligence assessment",
    file: "sample-payloads/valid-intelligence-assessment.json",
    type: "intelligence-assessment",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "low confidence assessment recommends FRAGO",
    file: "sample-payloads/invalid-intelligence-assessment-low-confidence-frago.json",
    type: "intelligence-assessment",
    exitCode: 1,
    requiredCodes: ["LOW_CONFIDENCE_FRAGO", "OPERATIONAL_CHANGE_WITHOUT_COMMANDER_DECISION", "LOW_CONFIDENCE_WITHOUT_GAPS"]
  },
  {
    name: "valid approval scope",
    file: "sample-payloads/valid-approval-scope.json",
    type: "approval-scope",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "approval scope without expiry",
    file: "sample-payloads/invalid-approval-scope-no-expiry.json",
    type: "approval-scope",
    exitCode: 1,
    requiredCodes: ["APPROVAL_WITHOUT_EXPIRY", "APPROVE_ONCE_NOT_SINGLE_USE", "APPROVAL_WITHOUT_ROLLBACK", "APPROVAL_WITHOUT_EVIDENCE", "CONSUMED_APPROVAL_WITHOUT_CONSUMPTION_EVENT"]
  },
  {
    name: "valid risk acceptance",
    file: "sample-payloads/valid-risk-acceptance.json",
    type: "risk-acceptance",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "high risk accepted by S3",
    file: "sample-payloads/invalid-risk-acceptance-high-by-s3.json",
    type: "risk-acceptance",
    exitCode: 1,
    requiredCodes: ["RISK_ACCEPTANCE_REQUIRES_COMMANDER", "RISK_ACCEPTANCE_WITHOUT_EXPIRY", "RISK_ACCEPTANCE_WITHOUT_CONTROLS", "RISK_ACCEPTANCE_WITHOUT_SUPERVISION", "RISK_ACCEPTANCE_WITHOUT_EVIDENCE"]
  },
  {
    name: "valid approval consumption event",
    file: "sample-payloads/valid-approval-consumption-event.json",
    type: "approval-consumption-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "approval consumption event mismatch",
    file: "sample-payloads/invalid-approval-consumption-event-mismatch.json",
    type: "approval-consumption-event",
    exitCode: 1,
    requiredCodes: ["APPROVAL_ALREADY_CONSUMED_OR_INACTIVE", "APPROVAL_CONSUMPTION_TARGET_MISMATCH", "APPROVAL_CONSUMED_OUTSIDE_WINDOW", "APPROVE_ONCE_CONSUMPTION_COUNT_INVALID", "EXECUTED_APPROVAL_NOT_MARKED_CONSUMED", "APPROVAL_CONSUMPTION_WITHOUT_EVIDENCE"]
  },
  {
    name: "valid approval revocation event",
    file: "sample-payloads/valid-approval-revocation-event.json",
    type: "approval-revocation-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "approval revocation event after consumption",
    file: "sample-payloads/invalid-approval-revocation-event-consumed.json",
    type: "approval-revocation-event",
    exitCode: 1,
    requiredCodes: ["APPROVAL_REVOCATION_NOT_ACTIVE", "APPROVAL_REVOCATION_REQUIRES_COMMANDER", "APPROVAL_REVOCATION_AUTHORITY_MISMATCH", "APPROVAL_REVOKED_OUTSIDE_WINDOW", "APPROVAL_REVOCATION_NOT_MARKED_REVOKED", "APPROVAL_REVOCATION_WITHOUT_REASON", "APPROVAL_REVOCATION_WITHOUT_EVIDENCE", "APPROVAL_REVOCATION_WITHOUT_NOTIFICATION"]
  },
  {
    name: "valid approval renewal event",
    file: "sample-payloads/valid-approval-renewal-event.json",
    type: "approval-renewal-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "approval renewal event after expiry",
    file: "sample-payloads/invalid-approval-renewal-event-expired.json",
    type: "approval-renewal-event",
    exitCode: 1,
    requiredCodes: ["APPROVAL_RENEWAL_NOT_ACTIVE", "APPROVAL_RENEWAL_REQUIRES_COMMANDER", "APPROVAL_RENEWAL_AUTHORITY_MISMATCH", "APPROVAL_RENEWED_OUTSIDE_WINDOW", "APPROVAL_RENEWAL_NOT_EXTENSION", "APPROVAL_RENEWAL_EXPIRES_BEFORE_RENEWED_AT", "APPROVAL_RENEWAL_EXPANDS_EXECUTIONS", "APPROVE_ONCE_ALREADY_USED_BEFORE_RENEWAL", "APPROVAL_RENEWAL_NOT_MARKED_ACTIVE", "APPROVAL_RENEWAL_WITHOUT_REASON", "APPROVAL_RENEWAL_WITHOUT_EVIDENCE", "APPROVAL_RENEWAL_WITHOUT_NOTIFICATION"]
  },
  {
    name: "valid approval delegation event",
    file: "sample-payloads/valid-approval-delegation-event.json",
    type: "approval-delegation-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "approval delegation attempts retained authority",
    file: "sample-payloads/invalid-approval-delegation-event-retained.json",
    type: "approval-delegation-event",
    exitCode: 1,
    requiredCodes: ["DELEGATION_REQUIRES_COMMANDER", "DELEGATEE_CANNOT_APPROVE_SELF_ROLE", "DELEGATION_CANNOT_INCLUDE_COMMANDER_RETAINED_ROE", "DELEGATION_CANNOT_ACCEPT_HIGH_RISK", "DELEGATION_WITHOUT_TASK_SCOPE", "DELEGATION_EXPIRY_NOT_AFTER_START", "DELEGATION_WITHOUT_LIMITS", "DELEGATION_ALLOWS_SUBDELEGATION", "DELEGATION_WITHOUT_RETAINED_AUTHORITIES", "DELEGATION_WITHOUT_RESTRICTED_CONTEXT_GUARD", "DELEGATION_SENSITIVE_RELEASE_WITHOUT_REVIEW", "DELEGATION_WITHOUT_POST_ACTION_EVIDENCE", "DELEGATION_NOT_MARKED_ACTIVE", "DELEGATION_WITHOUT_NOTIFICATION", "DELEGATION_WITHOUT_REASON", "DELEGATION_WITHOUT_EVIDENCE"]
  },
  {
    name: "valid approval delegation revocation event",
    file: "sample-payloads/valid-approval-delegation-revocation-event.json",
    type: "approval-delegation-revocation-event",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "staff approval delegation revocation event",
    file: "sample-payloads/invalid-approval-delegation-revocation-event-staff.json",
    type: "approval-delegation-revocation-event",
    exitCode: 1,
    requiredCodes: ["DELEGATION_TERMINATION_NOT_ACTIVE", "DELEGATION_TERMINATION_STATUS_MISMATCH", "DELEGATION_TERMINATION_AUTHORITY_MISMATCH", "DELEGATION_REVOCATION_REQUIRES_COMMANDER", "DELEGATION_REVOKED_OUTSIDE_WINDOW", "DELEGATION_TERMINATION_WITHOUT_REASON", "DELEGATION_TERMINATION_WITHOUT_EVIDENCE", "DELEGATION_TERMINATION_WITHOUT_NOTIFICATION"]
  },
  {
    name: "valid AAR readiness update",
    file: "sample-payloads/valid-aar-readiness-update.json",
    type: "aar-readiness-update",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "AAR readiness downgrade without commander review",
    file: "sample-payloads/invalid-aar-readiness-update-no-review.json",
    type: "aar-readiness-update",
    exitCode: 1,
    requiredCodes: ["DOWNGRADE_WITHOUT_COMMANDER_REVIEW"]
  },
  {
    name: "valid bounded self-improvement campaign",
    file: "sample-payloads/valid-self-improvement-campaign.json",
    type: "self-improvement-campaign",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "self-improvement campaign claims AI final authority",
    file: "sample-payloads/invalid-self-improvement-campaign-ai-final-authority.json",
    type: "self-improvement-campaign",
    exitCode: 1,
    requiredCodes: [
      "CONST_MISMATCH",
      "SELF_IMPROVEMENT_HUMAN_AUTHORITY_MISSING",
      "SELF_IMPROVEMENT_EVALUATOR_NOT_INDEPENDENT",
      "SELF_IMPROVEMENT_WITHOUT_INVARIANTS",
      "SELF_IMPROVEMENT_ENVELOPE_TOO_BROAD",
      "SELF_IMPROVEMENT_QUALITY_WEIGHTS_INVALID",
      "SELF_IMPROVEMENT_CHECKPOINT_TRIGGER_MISSING"
    ]
  },
  {
    name: "valid self-improvement checkpoint",
    file: "sample-payloads/valid-self-improvement-checkpoint.json",
    type: "self-improvement-checkpoint",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "self-improvement checkpoint escapes repository",
    file: "sample-payloads/invalid-self-improvement-checkpoint-path-traversal.json",
    type: "self-improvement-checkpoint",
    exitCode: 1,
    requiredCodes: ["SELF_IMPROVEMENT_PATH_TRAVERSAL", "SELF_IMPROVEMENT_PROHIBITED_EXTERNALITY"]
  },
  {
    name: "runtime-control checkpoint lacks comparative evidence",
    file: "sample-payloads/invalid-self-improvement-checkpoint-control-plane-no-comparison.json",
    type: "self-improvement-checkpoint",
    exitCode: 1,
    requiredCodes: ["SELF_IMPROVEMENT_COMPARATIVE_EVALUATION_MISSING"]
  },
  {
    name: "valid self-improvement decision",
    file: "sample-payloads/valid-self-improvement-decision.json",
    type: "self-improvement-decision",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "self-improvement decision claims self-release",
    file: "sample-payloads/invalid-self-improvement-decision-self-release.json",
    type: "self-improvement-decision",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH", "SELF_IMPROVEMENT_SELF_RELEASE", "SELF_IMPROVEMENT_DECISION_EXECUTION_MISMATCH"]
  },
  {
    name: "valid self-improvement cycle order",
    file: "sample-payloads/valid-self-improvement-cycle-order.json",
    type: "self-improvement-cycle-order",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid challenged self-improvement cycle order",
    file: "sample-payloads/valid-self-improvement-cycle-order-v0.5.json",
    type: "self-improvement-cycle-order",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid failure-domain-assured self-improvement cycle order",
    file: "sample-payloads/valid-self-improvement-cycle-order-v0.6.json",
    type: "self-improvement-cycle-order",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid continuously transparent self-improvement cycle order",
    file: "sample-payloads/valid-self-improvement-cycle-order-v0.7.json",
    type: "self-improvement-cycle-order",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "self-improvement cycle order falsely claims transparency",
    file: "sample-payloads/invalid-self-improvement-cycle-order-v0.7-false-transparency.json",
    type: "self-improvement-cycle-order",
    exitCode: 1,
    requiredCodes: ["CYCLE_ORDER_TRANSPARENCY_FALSE_SATISFACTION"]
  },
  {
    name: "blocked self-improvement cycle order authorizes execution",
    file: "sample-payloads/invalid-self-improvement-cycle-order-blocked-execution.json",
    type: "self-improvement-cycle-order",
    exitCode: 1,
    requiredCodes: ["CYCLE_ORDER_EXECUTION_STATUS_MISMATCH", "CYCLE_ORDER_NONREADY_TRANSITION"]
  },
  {
    name: "valid comparative evaluation set",
    file: "sample-payloads/valid-comparative-evaluation-set.json",
    type: "comparative-evaluation-set",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "comparative evaluation set duplicates a fixture",
    file: "sample-payloads/invalid-comparative-evaluation-set-duplicate-fixture.json",
    type: "comparative-evaluation-set",
    exitCode: 1,
    requiredCodes: ["COMPARATIVE_EVALUATION_DUPLICATE_FIXTURE"]
  },
  {
    name: "valid comparative evaluation plan",
    file: "sample-payloads/valid-comparative-evaluation-plan.json",
    type: "comparative-evaluation-plan",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid comparative evaluation report",
    file: "sample-payloads/valid-comparative-evaluation-report.json",
    type: "comparative-evaluation-report",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid verification plan",
    file: "sample-payloads/valid-verification-plan.json",
    type: "verification-plan",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "verification plan invokes a shell",
    file: "sample-payloads/invalid-verification-plan-shell.json",
    type: "verification-plan",
    exitCode: 1,
    requiredCodes: ["VERIFICATION_PLAN_SHELL_PROHIBITED"]
  },
  {
    name: "valid verification receipt",
    file: "sample-payloads/valid-verification-receipt.json",
    type: "verification-receipt",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "self-reported verification receipt",
    file: "sample-payloads/invalid-verification-receipt-self-reported.json",
    type: "verification-receipt",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH", "MIN_ITEMS", "VERIFICATION_RECEIPT_SHELL_USED"]
  },
  {
    name: "valid verifier trust policy",
    file: "sample-payloads/valid-verifier-trust-policy.json",
    type: "verifier-trust-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "verifier trust policy has a mismatched key id",
    file: "sample-payloads/invalid-verifier-trust-policy-key-id.json",
    type: "verifier-trust-policy",
    exitCode: 1,
    requiredCodes: ["VERIFIER_POLICY_KEY_ID_MISMATCH"]
  },
  {
    name: "valid Sigstore verifier trust policy",
    file: "sample-payloads/valid-verifier-trust-policy-v0.3.json",
    type: "verifier-trust-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "Sigstore verifier trust policy disables Rekor verification",
    file: "sample-payloads/invalid-verifier-trust-policy-v0.3-threshold.json",
    type: "verifier-trust-policy",
    exitCode: 1,
    requiredCodes: ["MINIMUM"]
  },
  {
    name: "valid execution-assured verifier trust policy",
    file: "sample-payloads/valid-verifier-trust-policy-v0.4.json",
    type: "verifier-trust-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid pre-dispatch-challenged verifier trust policy",
    file: "sample-payloads/valid-verifier-trust-policy-v0.5.json",
    type: "verifier-trust-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid failure-domain-assured verifier trust policy",
    file: "sample-payloads/valid-verifier-trust-policy-v0.6.json",
    type: "verifier-trust-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid continuously transparent verifier trust policy",
    file: "sample-payloads/valid-verifier-trust-policy-v0.7.json",
    type: "verifier-trust-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "v0.7 verifier trust policy omits transparency assurance",
    file: "sample-payloads/invalid-verifier-trust-policy-v0.7-missing-transparency.json",
    type: "verifier-trust-policy",
    exitCode: 1,
    requiredCodes: ["VERIFIER_POLICY_TRANSPARENCY_ASSURANCE_INVALID"]
  },
  {
    name: "valid transparency policy",
    file: "sample-payloads/valid-transparency-policy.json",
    type: "transparency-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid transparency observation",
    file: "sample-payloads/valid-transparency-observation.json",
    type: "transparency-observation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid trust-root rotation",
    file: "sample-payloads/valid-trust-root-rotation.json",
    type: "trust-root-rotation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "trust-root rotation skips a TUF root version",
    file: "sample-payloads/invalid-trust-root-rotation-version-skip.json",
    type: "trust-root-rotation",
    exitCode: 1,
    requiredCodes: ["TRUST_ROOT_ROTATION_VERSION_INVALID"]
  },
  {
    name: "valid transparency incident",
    file: "sample-payloads/valid-transparency-incident.json",
    type: "transparency-incident",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "transparency incident omits a required contained action",
    file: "sample-payloads/valid-transparency-incident.json",
    type: "transparency-incident",
    exitCode: 1,
    requiredCodes: ["CONTAINS_MISMATCH"],
    mutate(payload) {
      payload.containment_actions =
        payload.containment_actions.filter(action =>
          action !== "preserve_evidence");
      if (payload.containment_actions.length < 2) {
        payload.containment_actions.push("notify_operator");
      }
    }
  },
  {
    name: "valid transparency state",
    file: "sample-payloads/valid-transparency-state.json",
    type: "transparency-state",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "transparency state falsely claims readiness",
    file: "sample-payloads/invalid-transparency-state-false-ready.json",
    type: "transparency-state",
    exitCode: 1,
    requiredCodes: ["TRANSPARENCY_STATE_FALSE_STATUS"]
  },
  {
    name: "valid verifier challenge set",
    file: "sample-payloads/valid-verifier-challenge-set.json",
    type: "verifier-challenge-set",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "verifier challenge set claims release authority",
    file: "sample-payloads/invalid-verifier-challenge-set-authority.json",
    type: "verifier-challenge-set",
    exitCode: 1,
    requiredCodes: ["CONST_MISMATCH", "CHALLENGE_SET_AUTHORITY_INVALID"]
  },
  {
    name: "valid pinned Sigstore trusted root",
    file: "sample-payloads/valid-sigstore-trusted-root.json",
    type: "sigstore-trusted-root",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "Sigstore trusted root contains an override field",
    file: "sample-payloads/invalid-sigstore-trusted-root-extra-field.json",
    type: "sigstore-trusted-root",
    exitCode: 1,
    requiredCodes: ["ADDITIONAL_PROPERTY", "SIGSTORE_TRUSTED_ROOT_DIGEST_MISMATCH"]
  },
  {
    name: "valid GitHub Actions OIDC trust bundle",
    file: "sample-payloads/valid-github-actions-oidc-trust-bundle.json",
    type: "github-actions-oidc-trust-bundle",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid GitHub Actions OIDC evidence projection",
    file: "sample-payloads/valid-github-actions-oidc-evidence.json",
    type: "github-actions-oidc-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid GitLab CI OIDC trust bundle",
    file: "sample-payloads/valid-gitlab-ci-oidc-trust-bundle.json",
    type: "gitlab-ci-oidc-trust-bundle",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid GitLab CI OIDC evidence projection",
    file: "sample-payloads/valid-gitlab-ci-oidc-evidence.json",
    type: "gitlab-ci-oidc-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid verifier workload identity evidence",
    file: "sample-payloads/valid-verifier-identity-evidence.json",
    type: "verifier-identity-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "verifier identity evidence contains an authority override",
    file: "sample-payloads/invalid-verifier-identity-evidence.json",
    type: "verifier-identity-evidence",
    exitCode: 1,
    requiredCodes: ["ADDITIONAL_PROPERTY"]
  },
  {
    name: "Black EEFI alert cannot leave release open",
    file: "sample-payloads/valid-eefi-alert.json",
    type: "eefi-alert",
    exitCode: 1,
    mutate(payload) {
      payload.blocks_release = false;
      payload.status = "complete";
    },
    requiredCodes: ["EEFI_SEVERE_ALERT_MUST_BLOCK_RELEASE"]
  },
  {
    name: "valid Sigstore verifier workload identity evidence",
    file: "sample-payloads/valid-sigstore-verifier-identity-evidence.json",
    type: "sigstore-verifier-identity-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "Sigstore identity evidence claims a different bundle media type",
    file: "sample-payloads/invalid-sigstore-verifier-identity-evidence-media.json",
    type: "sigstore-verifier-identity-evidence",
    exitCode: 1,
    requiredCodes: ["ENUM_MISMATCH", "SIGSTORE_IDENTITY_EVIDENCE_BUNDLE_BINDING_INVALID"]
  },
  {
    name: "valid verifier runtime policy",
    file: "sample-payloads/valid-verifier-runtime-policy.json",
    type: "verifier-runtime-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid failure-domain verifier runtime policy",
    file: "sample-payloads/valid-verifier-runtime-policy-v0.2.json",
    type: "verifier-runtime-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid native GitHub Actions verifier runtime policy",
    file: "sample-payloads/valid-verifier-runtime-policy-v0.3.json",
    type: "verifier-runtime-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "native GitHub Actions runtime policy permits a self-hosted runner",
    file: "sample-payloads/invalid-verifier-runtime-policy-v0.3-self-hosted.json",
    type: "verifier-runtime-policy",
    exitCode: 1,
    requiredCodes: ["VERIFIER_RUNTIME_INDEPENDENCE_CLAIMS_INVALID", "VERIFIER_RUNTIME_NATIVE_CLAIMS_INVALID"]
  },
  {
    name: "valid native GitLab CI verifier runtime policy",
    file: "sample-payloads/valid-verifier-runtime-policy-v0.3-gitlab.json",
    type: "verifier-runtime-policy",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "native GitLab CI runtime policy permits an unprotected ref",
    file: "sample-payloads/invalid-verifier-runtime-policy-v0.3-gitlab-unprotected.json",
    type: "verifier-runtime-policy",
    exitCode: 1,
    requiredCodes: ["VERIFIER_RUNTIME_NATIVE_CLAIMS_INVALID"]
  },
  {
    name: "failure-domain runtime policy omits a zone identity",
    file: "sample-payloads/invalid-verifier-runtime-policy-v0.2-missing-domain.json",
    type: "verifier-runtime-policy",
    exitCode: 1,
    requiredCodes: ["MISSING_REQUIRED", "VERIFIER_RUNTIME_INDEPENDENCE_CLAIMS_INVALID"]
  },
  {
    name: "verifier runtime policy claims release authority",
    file: "sample-payloads/invalid-verifier-runtime-policy-authority.json",
    type: "verifier-runtime-policy",
    exitCode: 1,
    requiredCodes: ["ADDITIONAL_PROPERTY"]
  },
  {
    name: "valid verifier execution evidence contract",
    file: "sample-payloads/valid-verifier-execution-evidence.json",
    type: "verifier-execution-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "valid failure-domain-bound verifier execution evidence",
    file: "sample-payloads/valid-verifier-execution-evidence-v0.2.json",
    type: "verifier-execution-evidence",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "execution evidence substitutes an unsigned failure-domain identity",
    file: "sample-payloads/invalid-verifier-execution-evidence-v0.2-domain-substitution.json",
    type: "verifier-execution-evidence",
    exitCode: 1,
    requiredCodes: ["EXECUTION_EVIDENCE_STATEMENT_BINDING_INVALID"]
  },
  {
    name: "verifier execution evidence claims release authority",
    file: "sample-payloads/invalid-verifier-execution-evidence-authority.json",
    type: "verifier-execution-evidence",
    exitCode: 1,
    requiredCodes: ["ADDITIONAL_PROPERTY", "EXECUTION_EVIDENCE_SIGNER_CORRELATION"]
  },
  {
    name: "valid signed verification attestation",
    file: "sample-payloads/valid-verification-attestation.json",
    type: "verification-attestation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "verification attestation has an invalid signed statement",
    file: "sample-payloads/invalid-verification-attestation-statement.json",
    type: "verification-attestation",
    exitCode: 1,
    requiredCodes: ["ATTESTATION_STATEMENT_INVALID"]
  },
  {
    name: "valid signed comparative evaluation attestation",
    file: "sample-payloads/valid-comparative-evaluation-attestation.json",
    type: "comparative-evaluation-attestation",
    exitCode: 0,
    requiredCodes: []
  },
  {
    name: "comparative evaluation attestation has an invalid signed statement",
    file: "sample-payloads/invalid-comparative-evaluation-attestation-statement.json",
    type: "comparative-evaluation-attestation",
    exitCode: 1,
    requiredCodes: ["COMPARATIVE_ATTESTATION_STATEMENT_INVALID"]
  }
];

function assertFixtureDefinitions(entries) {
  for (const [index, fixture] of entries.entries()) {
    if (typeof fixture.check === "function") continue;
    assert(Array.isArray(fixture.requiredCodes) && fixture.requiredCodes.every(code => typeof code === "string"),
      `Validator fixture ${index} (${fixture.name}) must explicitly declare requiredCodes as a string array.`);
  }
}

function runFixture(fixture) {
  if (fixture.check) {
    try {
      fixture.check();
      return { ok: true, fixture };
    } catch (error) {
      return { ok: false, fixture, reason: error.message };
    }
  }
  let temporaryDirectory = null;
  let fixturePath = fixture.file;
  if (fixture.mutate) {
    const payload = JSON.parse(fs.readFileSync(
      path.resolve(ROOT, fixture.file),
      "utf8"
    ));
    fixture.mutate(payload);
    temporaryDirectory = fs.mkdtempSync(
      path.join(os.tmpdir(), "controls-validator-fixture-")
    );
    fixturePath = path.join(temporaryDirectory, "payload.json");
    fs.writeFileSync(
      fixturePath,
      `${JSON.stringify(payload, null, 2)}\n`
    );
  }
  const validatorArgs = [
    VALIDATOR,
    fixturePath,
    fixture.type,
    ...(fixture.evaluatedAt
      ? ["--evaluated-at", fixture.evaluatedAt]
      : [])
  ];
  const result = spawnSync(
    "node",
    validatorArgs,
    {
      cwd: ROOT,
      encoding: "utf8"
    }
  );
  if (temporaryDirectory) {
    fs.rmSync(temporaryDirectory, {
      recursive: true,
      force: true
    });
  }

  let parsed;
  try {
    parsed = JSON.parse(result.stdout);
  } catch (error) {
    return {
      ok: false,
      fixture,
      reason: `Validator did not return JSON: ${error.message}`,
      stdout: result.stdout,
      stderr: result.stderr
    };
  }

  const issueCodes = new Set((parsed.issues || []).map(issue => issue.code));
  const missingCodes = fixture.requiredCodes.filter(code => !issueCodes.has(code));
  const executionMatches = fixture.expectedCanExecute === undefined || parsed.can_execute === fixture.expectedCanExecute;
  const ok = result.status === fixture.exitCode && missingCodes.length === 0 && executionMatches;

  return {
    ok,
    fixture,
    exitCode: result.status,
    expectedExitCode: fixture.exitCode,
    executionMatches,
    missingCodes,
    maxSeverity: parsed.max_severity,
    issueCount: parsed.issue_count
  };
}

assertFixtureDefinitions(fixtures);
const results = fixtures.map(runFixture);
const failed = results.filter(result => !result.ok);

for (const result of results) {
  const status = result.ok ? "PASS" : "FAIL";
  console.log(`${status} ${result.fixture.name} (${result.fixture.file})`);
  if (!result.ok) {
    console.log(`  expected exit: ${result.expectedExitCode}, actual: ${result.exitCode}`);
    if (result.executionMatches === false) console.log("  can_execute does not match the contract");
    if (result.missingCodes && result.missingCodes.length) {
      console.log(`  missing issue codes: ${result.missingCodes.join(", ")}`);
    }
    if (result.reason) {
      console.log(`  reason: ${result.reason}`);
    }
  }
}

console.log(JSON.stringify({
  total: results.length,
  passed: results.length - failed.length,
  failed: failed.length
}, null, 2));

process.exit(failed.length === 0 ? 0 : 1);
