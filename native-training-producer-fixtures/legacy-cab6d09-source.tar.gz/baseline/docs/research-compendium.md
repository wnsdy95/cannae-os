# Research Compendium

## Consent, Data Handling And Collection Are Separate (2026-10-25)

The [native owner-transfer candidate](native-training-owner-consent.md) binds
the exact original prompt and source labels to authenticated human consent.
An explicit external-tool review cannot be replaced by an internal handoff.
The runtime can reject existing adverse labels and literal mission matches;
it cannot prove a human inventory semantically complete. Signed bytes are not
a grade, and a canonical publication is not independently attested finality.
Retain unknown/partial outcomes and inspect deterministic artifacts rather than
rerunning the task to manufacture an apparently complete history.

## Collection Identity Is Not Native Identity (2026-10-25)

The [native task-product candidate](native-training-products.md) separates a
reviewed pre-start collection UUID from the later observed provider thread.
The official [Codex JSONL documentation](https://learn.chatgpt.com/docs/non-interactive-mode#make-output-machine-readable)
describes streamed thread/turn events and final-message output; it does not claim
that upstream inference waits for an external enrollment ceremony. Original
private events, exact returned bytes and measured profile commitments improve
local evidence, not account/weight attestation, authenticated grading or grants.
The separate owner purpose, complete failure inventory and all full outcomes
remain required. Local byte-count minima and distinct-case thresholds are
engineering policy, not measured accuracy or a numerical military requirement.

## A Session Mapping Needs Its Own Original Consent (2026-10-25)

The [owner-session ceremony candidate](training-session-consent.md) separates
definition enrollment from a pre-call, exact standard/case/lease review. Its
current binding references the original purpose-bound signed authorization;
historical mappings cannot acquire that assurance through a later label. Actual
task-result appraisal still proves no model quality, qualification or new grant.
Uncertain publication remains held rather than replaying consent. Deployment,
whole-trial evaluation, qualification and actual grant reconciliation stay open.

The first development run passed its positive real-ceremony/dispatch group,
then stopped because the worker queue discarded the new `TRAINING_*` denial code.
Its unexecuted suffix was not a pass. A separately retained controlled transport
probe reproduced that loss; the correction permits the bounded code namespace
at both boundaries while still filtering private details. This is an engineering
lesson, not broader completion evidence.

## Training Observations Precede Qualification (2026-10-25)

The [in-progress intake](task-training-evidence.md) binds actual admitted-call
results and retained bytes to pre-existing enrolled definitions and a separately
signed session mapping. Stable performer identity is not an ephemeral session ID.
Evidence intake cannot turn a model/configuration declaration into attestation
or a step observation into a qualification/grant. The initial routing rejection
correctly exposed unregistered new source; inventory must be registered, not
waived. Owner-session verification/rollout, step assessment, positive qualification and
actual new-grant/freshness/regression consumers remain required under goal 5.

## Green Does Not Remove Explicit Approval (2026-10-25)

A further schema-valid reference probe on `c91cae6` declared approval required
for a Green request without an approval scope. The integrator still returned
allowed because it considered only computed ROE and the matrix decision. The
[corrective path](readiness-authority-intersection.md) now intersects the actual
request's flag too, including release composition. This is engineering synthesis,
not proof of authenticated approval consumption or complete qualification.

## Approval Cannot Replace Readiness (2026-10-24)

Actual reference consumers on `26660c3` allowed a below-minimum performer with
approval and weakened a schema-valid Green prohibition into an approvable
decision. Separate direct probes admitted a suffixed tool and did not prohibit
unmatched Black. The [local correction](readiness-authority-intersection.md)
intersects exact matching restrictions, checks expiry and binds the matrix and
approval to the actual request. Failed prerequisites survive release composition.
This is engineering synthesis, not new military doctrine, real-owner execution
or positive training evidence. Declared ratings/signers, P supervision, durable
approval consumption, qualification, active-grant reconciliation and controlled
rollout remain separate; all eight full outcomes stay open.

## A Default Preference Is Not Transfer Consent (2026-10-24)

The human selected the current Codex CLI default, not an invented military model
alias. The [local bridge](codex-default-model-binding.md) resolves a configured
model or one unambiguous catalog recommendation during trusted host preparation,
then freezes the literal, time and digest for subsequent exact-packet review.
There is no automatic upgrade after a default change or transfer from a browser
model override. Raw configuration/account responses are not retained.

The actual installed CLI emitted an inactive remote-control notification omitted
by the first fake. The original native probes failed closed. A generated schema
review and new disabled/connecting/connected regressions distinguish harmless
metadata from active or unknown behavior. A later empty-HOME, network-denied probe
completed without a model turn; it does not resolve the real account's default or
prove access. Synthetic owner APIs exercise frozen omission and analysis/compiler
paths separately. None supplies calibrated semantics, planning quality, protected
execution or real owner consent; all eight full outcomes remain open.

A separate synthetic owner/API probe displayed a separately altered model while
the original no-display-commitment request still collected the original model.
It was not a deployed browser or real-owner exploit. The new commit contract
requires the digest of the complete displayed invocation; the browser computes
it rather than copying a supplied digest, and the server compares the private
original before reservation. Re-keying altered response bytes cannot authorize
that original. The old failed/counterexample artifacts stay immutable; no human
presence, compromised-host protection or semantic-quality guarantee is inferred.

## Definition Enrollment Is Not Qualification (2026-10-24)

The existing force-change projection uses approval strings and does not create
an authenticated persistent registry. Literal task/readiness matching also
cannot provide stable organization, capability or performer identity. The
[local enrollment candidate](force-registry-enrollment.md) adds permanent IDs,
versioned owner/configuration declarations, explicit alias history and separate
exact password-reauthenticated owner consent with full signed nested subjects.
It deliberately keeps definitions unassessed and preserves partial publication
holds. This is local engineering synthesis, not new military doctrine, training
evidence, native configuration attestation or positive execution authority.
Full training, mandatory grant consumers, all organization lifecycle operations,
recovery, CoS/COP integration and controlled rollout remain open under goal 5.

## Code Regression Is Not Workload Inspection (2026-10-24)

A retained actual-function probe on `1f2b261` passed the same routed fixture
command for both clean and credential-bearing report inputs. The command received
no report/evidence bytes; a digest-bound receipt alone did not close that gap.
It did not exercise full report admission or demonstrate external disclosure.
The [local corrective candidate](subject-bound-workload-controls.md) adds actual
same-mission/wave work-byte inspection, a bounded fixed worker and separately
bound policy receipts to report admission. Publication rechecks the full subject.
This is engineering synthesis, not new military doctrine or model calibration.
Core credential/marking checks remain narrower than custom EEFI, CCIR, KM,
resource, semantic-truth or releasability assessment. Regression caching and
protected execution remain open; all eight program outcomes remain open.

## Readiness Must Reach Actual Grants (2026-10-24)

A synthetic probe on `c475726` retained a schema-valid T-to-X event for the
same role and exact task after a completed call; actual next-call admission
still allowed it. The [local restriction candidate](readiness-drop-reconciliation.md)
now reads that history at issuance, dispatch/gateway admission, publication and
completion. Old grants cannot revive merely because a later event claims T.
Pending results and gateway obligations still need their original settlement;
blocked does not mean revoked, and a reconciliation report is not task work.

Current manifests are path-sorted. Valid transitions must replay their retained
introduction revisions and parsed timestamps, not lexical event IDs or offsets.
Payload rejection and actual consumer/race tests remain distinct evidence classes.
This is local engineering synthesis, not a new military-source or model-quality
claim. Literal role/task matching, trusted local EVALUATOR labels and a deny-only
fence do not finish stable capability ownership, authenticated training,
positive qualification, fresh restoration or goal 5. All eight outcomes remain open.

## Bounded Derived Order Publication (2026-10-24)

A retained synthetic probe passed an 80,932-byte authored response through the
actual materializer/compiler and published a 21,200,694-byte draft that the
8,388,608-byte reader then rejected. It did not invoke the native collector or
a real model; execution and release remained false. Input/schema limits alone
do not bound output when global text is inherited by many tasks.

The local correction counts the complete store encoding, including two-space
formatting, final newline, escaping and UTF-8, with early termination and cached
string costs rather than allocating an amplified serialized output. Actual
assessment/compiler paths reject before publication; the reader limit is not
widened. Under-limit work keeps every task/constraint/decision. Both skills route
the exact denial and require a separately reviewed decomposition instead of
automatic truncation, transfer replay or historical artifact rewriting.
Synthetic collector regressions are not real provider/owner acceptance or
semantic calibration. Existing oversized history needs separate recovery.
The first frozen correction ladder rejected the original counterexample, then
failed its new semantic-validator assertion because a deliberately oversized
analysis field hit schema `MAX_LENGTH` first. That failure is retained, not a
whole-suite pass. The revised regression proves structural validity before
requiring the whole-draft size denial; neither limit is weakened.

## Purpose-Specific Analysis Recovery (2026-10-24)

A failed request analysis can already have published a non-executable draft when
later delivery fails. A null draft field in the signed failure therefore does not
prove publication absence. The separate [owner ceremony](order-analysis-reconciliation.md)
binds original collector/response bytes and derives the expected draft for actual
read-only compiler inspection. It never recompiles or adopts that draft. An exact
verified-manifest absence observation is not a universal no-effect claim; later
independently approved deterministic publication must not rewrite that historical
observation or permanently deadlock future work. A previously observed published
reference and original response/journal/consent must remain exact.

Analysis v0.1 already has a journal commitment; accepting it does not retrofit
unbound omission v0.1 history. Separate typed purposes and endpoints prevent
borrowing another acknowledgment while sharing verification mechanics. This is
local engineering synthesis. Synthetic crash/browser checks and current signatures
do not prove real human presence, protected keys, provider cancellation, billing,
unknown-process recovery or independent semantic calibration. All eight outcomes
and operational acceptance remain separate.

The first frozen browser ladder also exposed stale Evidence rows remaining
clickable during a full refresh after publication changed the manifest. The
server correctly rejected the old snapshot. Clearing old actions/counts before
awaiting a fresh list repairs that workflow without weakening the server guard
or silently renewing consent. Preserve the original failed ladder/screenshot;
the delayed-list regression tests the changed UI boundary, not a security bypass.

The next frozen HTTP ladder retained a different failure: nine invalid commit
attempts in one fixture caused the real eight-per-minute throttle to run before
the intended rationale check. An unrelated rejection cannot prove that later
rule. Separate synthetic environments now test the exact independent denials,
and a dedicated case tests the actual ninth-attempt throttle with unchanged hold
and no signature. The production limit is not relaxed or mocked away.

## Historical Model Scope Integrity (2026-10-23)

An actual synthetic controller probe on the first native-analysis candidate
changed the stored preview's projected mission without changing its claimed
invocation digest. Valid original consent/result signatures then accompanied an
incorrectly verified history scope; fresh collection correctly rejected the
modified body before launch. Those are separate paths and evidence classes.
The shared consent verifier now recomputes the complete invocation and nested
preview commitments before static historical validation, preserving original
timing and signatures. Rehashing new content cannot repair old consent. Both
skills and actual analysis/omission history regressions retain this operational
lesson. This does not establish independent model quality or protected operation.

## Purpose-Bound Native Request Analysis (2026-10-23)

The [analysis candidate](native-order-analysis.md) addresses the still-manual
request-to-analysis step before structural planning. A closed purpose adapter
shares finite collection/process controls without sharing omission consent,
prompt/schema or task authority. Model statements become actual compiler inputs;
the host binds request/scope and retains proposed/unknown status rather than
treating generated statements as verified facts. Existing owner review remains
mandatory. The official [CLI reference](https://learn.chatgpt.com/docs/developer-commands#codex-exec)
supports the transport choices, not semantic correctness or protected execution.
Synthetic response labels are authored tests, not independent held-out truth.
The later analysis acknowledgment entry supports verifiable failures and observed
publication only; unknown/integrity recovery, calibration and complete orchestration
remain open.

## Bounded Structural Planning (2026-10-23)

The compiler-to-execution gap previously required a whole manually authored
mission plan even after retaining actual OPORD tasks. The
[structural generator](bounded-plan-synthesis.md) now constructs those plans and
policy drafts from finite roster/control bounds, preserving actual task text,
every task assignment, parent restrictions and exact source provenance. Failed
allocation or exhausted search never presents a shortened or partial plan.
Replanning subtracts actual prior allow admissions from parent policy/rule caps
and rechecks remaining budget at consumption; a new wave must not silently reset
spent allowance. Actual revision, fresh human coverage and USER adoption remain
separate. This is structural synthesis with zero model calls, not automatic
understanding, invented strategy, verified readiness or independent calibration.
A separate actual report-consumer probe found an untyped planner CLI envelope
could complete a data-only wave despite its inner proposal being non-work.
Positive structural/browser/schema checks did not cover that composition.
Typed operation returns and recursive semantic/planning packet detection now
guard this boundary, with reference-only work as an explicit positive control.

## Source-Accounted Human Coverage Review (2026-10-23)

An advisory evaluator can enumerate only part of a request and still derive
`complete` for its own subset. An unused analysis quotation likewise does not
preserve a prohibition in an actual receiver task. The separate
[human inventory admission candidate](requirement-inventory-admission.md) requires
every source byte to be classified and every declared requirement to be reviewed
against the actual order and receiving task/agent projection. New captured-request
adoption binds that review and the whole plan; active consumers cannot downgrade
it while historical records remain readable.

This is an explicit human-review class, not a promotion of an uncalibrated model
result. A wrong context classification or applicability judgement can still omit
meaning. Exact pointers, fresh authentication and passing synthetic fixtures do
not prove complete extraction or semantic equivalence. Independent held-out
calibration and bounded automatic planning/replanning remain unfinished.
The local owner preview now exposes exact source classifications, requirement
instructions and actual receiving task/agent quotes side by side, while retaining
the full plan and raw subject. Pagination/filter counts preserve the full matrix
denominator and do not redefine consent. A clearer display helps inspection but
cannot establish semantic equivalence or that the human read every requirement.

## Failed Model Transfer Acknowledgment (2026-10-23)

The [separate owner ceremony](model-transfer-reconciliation.md) resolves a verified
failed local invocation without changing it to success or replaying its transfer.
Bind fresh consent to exact signed failure, journal, source/repository/manifest,
key and consumed-attempt inventory; independently observe both PID and process
group absence. `EPERM` and PID reuse deny, rather than becoming absence evidence.
An atomic saved receipt, not a private terminal label, acknowledges the local hold.

The PID must already be committed by the original signed observation. A reproduced
candidate counterexample changed only a private journal PID before review and
obtained acknowledgment of that unrelated value despite a valid original result
signature. Signed evaluation v0.2 now commits exact collector-returned journal
bytes before review; historical v0.1 results remain readable but cannot acquire
that missing provenance retroactively. Passing the earlier selected ladder did
not cover or refute this counterexample.

The original failure and prior attempts remain immutable. Fresh acknowledgment
does not verify or cancel remote provider billing, clear another ownership class
or authorize the next evaluation. Missing signatures, journals and termination
proof stay held. Protected infrastructure and unknown-process recovery remain open.

## Exact Model Transfer Consent (2026-10-23)

The [local ceremony](model-transfer-consent.md) now connects an owner-reviewed
packet to the existing collector. Cached user identity alone cannot revoke an
already running collector after logout: check the actual stored session and
retain the one-use reservation while terminating its child. Killing a read
worker is not evidence that a separately spawned CLI stopped.

Authenticated preparation is not transmission, HTTP 202 is not completion and
process-group absence is not provider billing cancellation. Signed historical
results remain advisory control metadata; their expiry does not become renewed
permission. Missing/changed results are unverifiable and fence another local
transfer. The later verified-failure acknowledgment above supplies only its own
local hold ceremony; unknown/integrity recovery, held-out calibration, mandatory
adoption consumers, automatic replanning and protected operation remain unfinished.

## Existing-CLI Semantic Collector Foundation (2026-10-23)

Literal source fidelity does not prove that compiled orders preserve prohibitions,
approval conditions or bounds. The [collector foundation](semantic-omission-evaluation.md)
therefore excludes unused analysis from its candidate and checks actual order and
receiver projections. Exact UTF-8 spans and candidate pointers establish quoted
provenance, not the truth of a model's coverage judgement.

The existing local CLI login avoids new credential provisioning; it does not
authorize private request transmission. A distinct pinned-key purpose binds one
exact preview/profile and a durable reservation prevents automatic replay.
At the foundation checkpoint, no owner-transfer ceremony existed; the separate
authenticated transfer service described above now supplies that local path. Fake processes test
failure behavior, never model quality; actual native probes must remain separately
identified. Model snapshots, full native context/tool inventory, billing cancellation,
held-out calibration and mandatory planning/adoption consumers remain unproven.

## Browser Response Scope (2026-10-23)

A real local browser counterexample retained an owner-authorized Evidence list,
logged out, authenticated the same browser as a mission-scoped viewer, then
delivered the old response. The server correctly bounded current viewer reads,
but the old unguarded renderer restored an owner-only row in that workspace.
Authentication at request time is therefore not sufficient render context.

The shared console now checks session epoch, principal, view and per-surface
request sequence, clears hidden data on identity changes and ignores stale
errors and mutation responses. Its browser suite delays actual authenticated
HTTP bodies; it does not infer correctness from mocked business decisions or
API-only tests. The unchanged throttle can legitimately delay repeated fixture
logins; tests validate the 429 and wait for `Retry-After`, never disable it.
Both skills require fresh principal-bound reads and exact outcome inspection
instead of replaying writes after a discarded response. This is a local display
boundary, not erasure of previously copied data or protected deployment.

## Operational Read Product (2026-10-23)

The [local operational COP](operational-cop.md) derives an authenticated,
restricted read product from actual manifest-backed wave/control history,
not supplied demo events. Replaying terminal dependencies is necessary:
a plausible closeout JSON is not proof that its report, controls, evidence,
AAR/readiness derivation and dispatch settlement were admitted.

Lease discovery is also not complete call admission. Owner-side projection
separately compares the latest settled checkpoint with current repository
state; it never calls admission or writes a denial to render the board.
Pending tools remain pending while their actual result may change the tree.
Staff display filters cannot suppress critical alerts elsewhere in permitted
scope, and viewer scope cannot disclose foreign missions. Snapshot validity,
record freshness and worker liveness are distinct. Both skills teach refreshing
the manifest and never converting a current-looking view into execution consent.

The fixed 300-second activity threshold is a local conservative display rule,
not the planned configurable CCIR/reporting policy. Readiness/risk/resource
blocks, CoS decision consumption and complete goal 4 remain unfinished.

## Local Issuance Transactions (2026-10-23)

Full consumer integration distinguishes historical replay from current grants:
reconciled-failure markers and required revocation retain their specific denial
before generic legacy-lease/source eligibility. Existing active/interrupted and
resumed-descendant settlement cases must retain their exact assertions; moving
a generic migration guard earlier cannot silently replace recovery diagnostics.
Mandatory new-context rules must not prevent neutral settlement of an already
admitted legacy result. Resume/publication retain specific terminal, stop and
reconciled-failure holds before generic conflicts. Reappraisal of
repository-wide gateway/effect obligations also applies at actual publication,
including a different wave's obligation arriving after initial appraisal.
The existing publication-race regression retains its specific denial assertion;
an exact case filter diagnoses it without silently accepting an empty selection.
Stronger early rejection of
unobserved startup or unknown effects is tested for no partial publications,
not relaxed to reproduce an obsolete unsafe sequence. These checks supplement,
not replace, full exact-source CI and the wider unfinished program.
For a retained stop arriving at commit publication, the issuance fixture now
requires the exact campaign-blocked code and stop reason, plus denied new-session
admission. The runtime is unchanged by this test/documentation alignment; its
earlier generic-conflict expectation would contradict specific stop precedence.

A reproduced core resume failure could retain predecessor supersession without
its successor. Work stayed denied, but the original input was not retained for
exact recovery. The [issuance protocol](dispatch-issuance-recovery.md) now freezes
that input before any transition and requires the actual request, lease,
baseline and terminal resolution. Recovery reuses identity, nonce and expiry;
cancellation never restores the predecessor or replays a task. Pending issuance
is a visible obligation even when no usable successor exists.

Generic store-journal recovery can restore a final committed resolution. That
historical fact is not current execution eligibility: actual new-call admission
and final allow publication also compare the retained runtime source entry with
current bytes. Copied-runtime cases distinguish valid unchanged recovery from
source drift, preserve already-admitted results and explicit revocation, and
ensure restored source bytes cannot clear an actual revoked checkpoint.

This local design uses the repository's existing verified introduction history
and guarded publication. It does not reconstruct unknown legacy inputs, attest
native clients, authenticate a human from a role string or provide production
infrastructure. Broader semantic planning, staff/readiness/sustainment workflows,
authenticated approvals and externally protected operation remain open.

## Local Method Metadata Transport (2026-10-23)

The subsequent reviewed channel policy v0.2 permits finite same-wave handoffs
without rebinding an old private file. A new slot binds the exact interruption,
predecessor enrollment and immutable root deadline; startup observation must
precede an actual resumed lease. Root request IDs/budgets and task-policy/rule
counters survive the session change. Missing actual reports or delivery and
unknown effects block preparation, while schema-valid branching or extended
deadlines block work. This is local engineering synthesis over the existing
contracts, not new military authority or native startup attestation. Partial
dispatch-resume transaction recovery remains a separate gap.

The [local method channel](method-control-channel.md) uses the official pinned
MCP SDK rather than treating a tool prefix or discovery message as authority.
Official [protocol-era guidance](https://ts.sdk.modelcontextprotocol.io/v2/migration/support-2026-07-28)
explains disposable stdio probes; our design inference is to keep discovery
read-only and separate it from enrollment and request budgets.
[Codex startup sources](https://learn.chatgpt.com/docs/hooks#sessionstart) and
[Claude MCP provenance](https://code.claude.com/docs/en/hooks#pretooluse-input)
inform exact session observation and source checks, not independent identity
attestation. The native configuration and same-UID operator remain trusted.

A reviewed baseline v0.2 and every receiver's backbrief bind exact operations,
source-entry/lock digest and finite limits. A prepared server stays dormant
until startup observation precedes the exact lease and enrollment. Requests,
real result receipts and delivery acknowledgments remain control metadata;
missing delivery holds actual work/completion without blocking admitted-result
callbacks. Neutral reconciliation cannot renew task or release authority.

Actual SDK pipes plus synthetic provider hook payloads test this local design;
they do not prove an actual native agent client, semantic mission completion,
protected hosts/keys or non-bypassable deployment. Full DI/CoS/recovery and all
eight required outcomes remain open, and deployment selection remains deferred.

## Exact Reviewed Method Execution (2026-10-22)

The [method runtime](method-deviation-runtime.md) connects a complete USER-reviewed
baseline and individual backbrief acknowledgments to actual local tool admission.
Every finite alternative already belongs to the exact Green policy; neither a
deviation nor a before acknowledgment broadens that policy. Derived SITREPs bind
actual admission/result references. Missing after reports and safeguards block
completion, while observed drift persists a denial before actual revocation.
An interrupted response cannot erase that mission hold; admitted callbacks and
unknown-effect settlement remain available.

Early integration exposed an inventory-order mistake: artifact arrays are sorted,
not append-order logs. Causal replay now uses verified introduction history and
per-snapshot caches. It also rejects retrospective report repair, forged result
metadata and whole-JSON MIME-disguised control records as work evidence. Both
skills now require result-bound reports before the next covered call and verify
the actual response checkpoint instead of trusting an incident label.

A subsequent probe found that an untyped derived SITREP, reformatted as a text
deliverable, crossed the metadata filter and reached a later completion denial.
It did not demonstrate acceptance of the whole report. The filter now compares
complete canonical JSON against all retained control kinds, uses snapshot-local
caches and reappraises bindings immediately before publication. Dedicated actual
report tests preserve ordinary JSON work and verify fresh-ID retry executes new
controls after a publication race. This is whole-record identity, not a semantic
classifier for arbitrary claimed work.

This is a partial local reference, not completion of goal 2. The full DI ruleset,
novel method equivalence, insertion/reordering, semantic drift, all degeneration
patterns, reviewed recovery/readiness, universal baseline rollout and protected
production operation remain required. It does not change the other seven goals
or select the deployment environment deferred by the USER.

## Authenticated Local Owner Decisions (2026-10-22)

[Local terminal reconciliation](operator-terminal-reconciliation.md) adds fresh
owner consent over exact original/terminal history, a signed private outbox,
scope cancellation when adoption did not occur, then a signed receipt before
private hold discharge. Retained cancellations are acknowledged rather than
repeated after interruption; original failure and expiry are preserved. This is
a local engineering contract, not new military-source authority or independently
protected production identity/execution evidence. Same-key signatures do not
form an independent quorum. Broader tool approvals, COP and production operation
remain required.

[Exact local owner consent](operator-consent-and-adoption.md) now reaches real
plan adoption, rejection and revision through the existing controller. The
finite one-use browser-session challenge, password reauthentication and guarded
source/repository/manifest comparison preserve the selected subject. Native
Ed25519 evidence is non-authorizing metadata; canonical signature encoding and
separately pinned issuer keys are required for offline verification.

Publication interruption preserves a durable hold, never automatic approval on
restart. Login and viewer access do not grant decision authority. Legacy CLI
USER logs remain unauthenticated; broader tool approvals,
operational COP and protected production infrastructure remain open.

## Mandatory Intent Continuity (2026-10-22)

The [intent runtime](intent-continuity-runtime.md) binds every newly generated
context to an exact plan and complete task commitments without copying sibling
task text. Default flat scopes and explicitly nested rostered scopes share one
root-reachability, inheritance and narrowing-only boundary appraiser. Lifecycle,
policy/lease, covered-tool, resume and report consumers reject substituted or
legacy contexts while old admitted results remain retainable.

Both skill routers now recommend the intent doctrine directly instead of leaving
it in supporting artifacts or returning a false capability gap. Both wrappers
offer non-authorizing diagnostics, and both skills require a newly reviewed wave
rather than relabeling old context history. This is local engineering synthesis
of existing doctrine, not new military research or a claim of semantic completeness,
authenticated USER consent, approval-bearing delegation, disciplined method
deviation or completion of the full eight-part program.

## Linked Order Revision And Supersession (2026-10-21)

The [revision contract](order-revision-and-supersession.md) links an opened adopted
plan to an exact change request and full successor scope. Deterministic comparison
retains changed and unchanged fields; the existing USER adoption ceremony reviews
the complete returned plan. Successor context preparation precedes supersession,
while policy/lease/tool admission waits for the exact prior termination and settled
effects. Selecting the successor also holds new predecessor tool calls without
blocking already-admitted result retention.

Both skills now use the dedicated revision wrapper, distinguish preparation from
tool eligibility and require fresh scope review after expiry during cleanup. This
is local runtime integration, not authenticated consent, semantic-completeness
evaluation, automatic replanning, cross-mission equivalence detection or the full
disciplined-initiative workflow. The wider roadmap remains partial.

## Exact Order Adoption And Downstream Binding (2026-09-30)

The [adoption contract](order-adoption-and-plan-binding.md) addresses the remaining
handoff between review-only drafts and executable mission plans: adoption freezes
the entire plan, unique task-to-agent assignments, per-agent backbriefs, rehearsal
and one exact USER scope decision. Historical manifest replay and publication
guards reject substitution, stale inputs and consumed decisions. Lifecycle and
dispatch consumers require current adoption; admitted-result retention remains
separate from permission to start another tool call.

Both skills now require complete-plan review before opening a captured-intake
wave and prohibit stripping bindings or renaming scope to bypass review. This is
local implementation synthesis, not proof of authenticated human identity,
complete semantic interpretation or protected execution. Phase 2 remains partial:
approved changes to an opened wave now use the linked revision/new-wave path,
and a renamed mission cannot be recognized semantically by exact identifiers.

## General Request Intake And Draft Provenance (2026-09-29)

The [request intake implementation](request-order-intake.md) closes a concrete
input gap: the previous order contracts did not retain a general request and its
typed interpretation. Captured UTF-8 bytes, exact source spans, repository/mission
scope and complete analysis digests now bind non-executable OPORD/task drafts.
Constraints and retained USER decisions propagate to every proposed task.

Inspection also found that `orders-dissemination-runner.js` ignored CLI paths and
always read its demo. It now validates caller input, rejects drafts and fails on
unsupported argument counts. Fixtures cover source substitution, unsupported
facts, unknowns, expiry, scope crossing and both provider wrappers. Both skills
use the new procedure.

This is engineering evidence, not proof of truth, complete interpretation,
authenticated USER decisions. The later adoption contract above supplies exact
review consumption and draft-to-plan binding; Phase 2 remains partial for broader
approved-edit integration and semantic completeness. Distinct types block accidental unchanged extraction, not hostile
rewriting of local contracts or code.

## Dependency Security And Retained Proof (2026-09-29)

The 2026-10-24 IPv6-zone follow-up pins transitive `ip-address` 10.7.4 after a
local 10.7.2 reproduction: both constructor and `isValid()` entered parsing but
exceeded the same 2.5-second child deadline; normal controls completed. Identical
patched inputs then completed without rejecting long valid zones. The
[upstream fix](https://github.com/beaugunderson/ip-address/commit/ec80fcd) keeps
the deprecated exported regex but removes library use. Neither a successful
rejection nor the patch version alone proves bounded behavior for every caller.

Accepted main `22c61c3` and its unchanged sample are separately frozen before
installation; old and current producer tuples remain distinct. The current
sample comes from actual pinned-engine verification. Unknown/hybrid identities
and changed signed claims remain rejected. Both skills route package/advisory
queries directly to this procedure and require valid long-input controls, not a
blanket cap. This local candidate does not clear the separate HTTP-cache alert,
repair monitor credentials or close any of the eight full program outcomes.

A separate local classification check found that both generic validator APIs
returned `can_execute: true` for valid monitoring-only independent evidence,
including historical records. This was not an actual publisher/tool bypass.
The corrected type classification keeps validity true and execution false;
both APIs and the real CLI are regressed independently of cryptographic replay.

The 2026-10-22 follow-up updates only transitive `brace-expansion` 5.0.9 to
5.0.12. The [maintainer's changes](https://github.com/juliangruber/brace-expansion/compare/v5.0.9...v5.0.12)
address comma parsing, nested-set stack exhaustion and quadratic rescanning.
Actual installed-package regressions run hostile inputs in finite child
processes and check normal expansion/minimatch behavior. This does not establish
that arbitrary hostile patterns are safe or reachable in this application.

Accepted producer `1b51ef6` and its byte-identical pre-brace sample are retained
separately from the regenerated current sample. All original evidence still
passes current cryptographic verification, and every recognized old module
paired with today's lock remains an unknown producer. Both skills now require
bounded hostile-input probes, ordinary-input controls and explicit disputed
advisory handling before claiming a migration complete.

The [HTTP-cache issue and maintainer response](https://github.com/kornelski/http-cache-semantics/issues/56)
disagree about the reported cross-user max-stale behavior. The provider alert
remains a separate unresolved operational item: a newer 4.3.0 package fixes Vary
matching, not this specific report. Neither an advisory nor the dispute alone
proves application reachability or absence of risk. No alert dismissal, risk
acceptance, credential repair, checkpoint reset or release is performed here.

The upstream [ip-address advisory](https://github.com/beaugunderson/ip-address/security/advisories/GHSA-2vr4-cq9g-pvrc)
identified missing private classification for the NAT64 local-use range in the
retained 10.4.0 dependency. Updating to 10.7.2 also changes producer lock identity.
An actual installed-dependency replay reproduced rejection of unchanged v0.2
evidence even though the Sigstore package version stayed 4.1.2.

The [producer compatibility procedure](github-release-independent-verification.md#producer-compatibility)
now preserves the source-audited `4bad6dd` tuple and its byte-identical sample.
Fresh results must match a separate current sample; historical records must
pass current cryptographic verification before retaining original metadata.
Unknown or mixed module/lock identities are not admitted. Both CLI skills now
route dependency/lockfile requests here and require the two-sample migration
check. Dependency classification tests do not prove application-wide SSRF
protection, authenticated historical execution or repaired monitor continuity.

## Exact Successor Admission (2026-09-29)

Local integration review found a digest cycle in naive restart designs: the
proposal and USER decision themselves change the terminal inventory they cite.
The [successor contract](campaign-successor-admission.md) instead freezes one
terminal publication prefix and accepts only the exact proposal, exact decision
and byte-identical partial candidate added during that ceremony. Generic artifact
kind exclusions would permit unreviewed history and are not used.

Publication is candidate first, admission second. Only the separately appraised
admission satisfies the original mission fence for the selected successor;
ordinary supervisor/trust/routing/dispatch remain independent. A later stop wins,
one stop set cannot activate competing successors, and subsequent admission must
follow the latest admitted predecessor. Historical replay stays inside decreasing
manifest prefixes so retained settlement proof cannot import future authority.
Both skills now distinguish held candidates, immutable historical admission and
current stop-fence status, and require fresh consent after drift or expiry.
This is local engineering synthesis, not authentication, trusted time, hard
process cancellation or complete production operation.

## Campaign Terminal Reconciliation (2026-09-29)

Local inspection found that live-only settlement reloads could not appraise an
older terminal snapshot: later evidence and old dispatch history must not mix.
The [terminal contract](campaign-terminal-reconciliation.md) uses an exact,
verified read-only manifest prefix while live authority paths still reject
stale views. It replays wave disposition, report-bound controls, all dispatch
lineages, supported effect settlement and explicit failed-agent revocation.
Orphans, partial waves and concurrent history growth cannot become an empty
success projection. A terminal record keeps failed work failed and the stop
in force. Both skills now use the dedicated wrapper and recheck current inventory
after history changes. This completes local known-obligation terminal recording,
not successor activation itself, authenticated USER identity or production containment.
The separate successor follow-up above now supplies exact local admission.

## Explicit Campaign Stop Intake (2026-09-29)

Local inspection found that retained evaluator escalation stopped execution,
but a user stop had no standalone immutable intake. The new
[stop contract](bounded-self-improvement-operations.md#210-explicit-user-stop-intake)
binds the exact campaign, reason and retained USER scope decision without
inventing evaluation results. Publication records a verified historical manifest;
path-sorted artifact arrays are not chronological event logs. Later decisions
cannot silently erase a stop, and same-mission campaign renaming or disabled
adaptation cannot bypass it. Already-admitted results and explicit revocation
remain available. Synthetic USER fixtures do not authenticate a real person.
This closes stop intake only; the terminal follow-up above is a separate contract.
The separate successor follow-up above now supplies exact local admission;
managed process cancellation and trusted time remain open. No new external
military-source assertion is introduced.

## Supervisor Publication-Time Admission (2026-09-28)

Source inspection found challenge writes inside the supervisor and cycle-order
writes in its CLI outside the existing publication guard. A current projection
could become stale before storage. Both publications now share the supervisor's
guarded path: reappraise history, clock and trust admission under the namespace
lease, including exact order reuse. Signed challenges additionally require the
unchanged observed manifest, live bootstrap eligibility and their exact deadline.

The local campaign/challenge fixtures cover concurrent stops, expiry, rollback,
competing issuance, a direct CLI race and all four journal interruption stages.
A challenge and its blocked order remain separate writes; operators must inspect
partial issuance and recover retained evidence before retrying. This is local
engineering synthesis. It does not authenticate USER decisions, replace external
containment, implement campaign restart, or create an atomic multi-artifact stop.

## Exact Gateway Reconciliation (2026-09-28)

The [gateway settlement controller](gateway-effect-settlement.md) joins the
previously separate subject/review, execution-bound verifier proof, fresh exact
USER judgement and signed OCI containment. It supports orphan admissions and
OCI reference outcomes. Discharge is an append-only projection, never a forged
success checkpoint or receipt. Raw history stays separate from settlement-aware
queries so historical appraisal cannot recursively rely on its own conclusion.
Decisions and orders are consumed once across both hook and gateway families;
the failed agent still requires post-settlement revocation and cannot resume or
report success. The reusable skill lesson is to distinguish effect resolution,
original outcome and future authority explicitly at handoff.

This is local engineering synthesis. External/process containment, managed
coordination/fencing, legacy-envelope migration and campaign restart are still
open; fixture identity/isolation declarations are not deployed infrastructure.

## Retained Containment Before Gateway Settlement (2026-09-28)

Local source inspection found that recovery returned cleanup success without
retaining a signed cleanup artifact, and its envelope did not bind the original
daemon ID. A later reviewer therefore could not distinguish a checked target
from a claim about a different daemon. The [OCI provider](oci-linux-sandbox-provider.md)
now records that binding in envelope v0.2 and produces a separate signed
`OciSandboxContainmentObservation`, with exact transaction/event/envelope refs,
CLI/daemon checks before and after cleanup, finite freshness and manifest-bound
publication. Gateway intake includes these records, invalidating older frozen
subjects when new observations arrive. They do not replace failed execution
records, complete-effect inspection or USER judgement.

This is an engineering result, not external doctrine or proof of an honest
host. A reported daemon ID is not attestation. Legacy envelopes without the
binding and managed deployments without retained external fencing evidence
cannot use this reference path. At this prerequisite stage, the gateway
settlement controller, production coordination and full campaign restart were
unfinished; the later reconciliation entry above records the supported subset.

## Reconciled Failure And Authority (2026-09-28)

Local regression finding: after valid hook settlement, a schema-valid legacy
success checkpoint could make `complete` accept the original failed lease.
Effect resolution and mission success must therefore be projected separately.
The [settlement runtime](tool-effect-settlement.md) now retains an independently
verified failed-agent marker across lease status and same-agent resume lineage.
Explicit revocation must follow settlement in manifest order and timestamp;
completion, resume and success reporting remain prohibited afterward. New
authority, wave publication and termination fail closed until revocation, with
publication-time checks for concurrent reconciliation. The fixtures execute
real checkers and signatures against synthetic USER/provider inputs. This is
engineering synthesis, not a new military-source or production-isolation claim.
Gateway effect settlement was unfinished at this prerequisite stage; the later
reconciliation entry above records its supported subset. Complete campaign
restart remains open.

## 2026-09-28: Gateway Intake Before Settlement

Local gateway histories differ from hook failures: recovery may leave a pending
allow admission, or deny an orphan with no execution event or receipt. Reusing
hook settlement would either fabricate missing history or leave an unresolved
admission after clearing the hold. [Gateway Effect Review](gateway-effect-review.md)
therefore reconstructs a typed subject first, freezes exact minimum inspection
boundaries, and binds observations plus verification plan/receipt to that subject.
Any new checkpoint or retained execution record invalidates the frozen scope.

This is local engineering synthesis, not an external doctrine claim. Fixtures
use real gateway transitions and an executed local checker, with explicitly
synthetic observations. Evidence consistency does not authenticate the verifier
or prove containment, scope completeness, production coordination, or USER
consent. Review does not clear holds or revoke/renew authority. The separate
gateway settlement contract above covers orphan/OCI reference subjects;
unsupported adapters and campaign restart remain in [the backlog](completion-backlog.md).

## 2026-09-28: Gateway Ownership And Retained Obligations

Local reproduction at `f61529c` showed that a direct successful provider callback
after gateway unknown-outcome recovery consumed the admission. Lease revocation
and a new wave could then issue fresh authority, while the gateway still said
`recovery_required`. Direct cancellation after begin similarly enabled another
tool. These are temporary-repository synthetic callbacks, not executed external
effects, and are distinct from the earlier hook-failure reproduction below.

The repair restricts gateway-owned dispatch writes to the gateway's validated
operation, reconstructs unsettled transactions independently of callback/lease
history, and repeats publication checks for new authority and wave terminal
records. Commit retry must match exact result/status/time/repository evidence.
Adversarial fixtures cover legacy terminal histories, callback/cancellation
attempts, caller flags, publication races, interrupted receipt publication and
both provider wrappers. No new external doctrine claim is made.

This is a cooperating-process guard, not hostile-writer isolation. It does not
authorize compensation, gateway effect settlement, production deployment,
campaign restart, or release. OCI cleanup and hook settlement remain separate.
See [gateway contract](protected-tool-gateway-contract.md),
[dispatch history](enforced-dispatch-and-resume.md#52-gateway-owned-obligations),
and the [completion backlog](completion-backlog.md).

## 2026-09-28: Exact Hook Effect Settlement

[Tool Effect Settlement](tool-effect-settlement.md) now joins the non-authorizing
review to actual receipt attestations, execution evidence, historical pre-dispatch
readiness, current policy admission and an exact retained USER scope decision.
The checkpoint, decision and cycle order are single-use. Manifest publication
reappraises expiry, repository state and proof; replay uses the original manifest
and time so later edits do not rewrite the original failure or erase settlement.

Tests execute a real local checker and ephemeral signatures, while USER decisions,
provider/isolation claims and v0.4 independence groups remain synthetic. Passing
fixtures do not prove complete external scope or production infrastructure.
USER identity is not cryptographically authenticated by a local decision log.
Gateway requests and decisions are explicitly excluded from the hook controller
and use the separate gateway contract above. Failed leases require explicit revocation after
settlement; campaign restart and release remain independently controlled.
This is local engineering synthesis from the existing contracts.

## 2026-09-28: Effect Evidence Is Not Effect Settlement

The unknown-effect reproduction requires two separate gates: binding the
inspection evidence and authorizing terminal settlement. The first executable
slice is [Tool Effect Review](tool-effect-review.md). It binds exact retained
lease/admission/checkpoint identity, finite resource scope, source observations,
verification plan, actual receipt claims, and unchanged repository state.
Cross-scope substitution, incomplete checks, stale proof, and publication-time
drift block the review. It neither executes inspection nor clears the hold.

A receipt self-digest and explicit checker arguments establish consistency,
not verifier identity, complete inspection, absence of arbitrary external
effects, or USER consent. These distinctions remain explicit false fields even
for an `evidence_bound` review. Stronger verifier policies must not be reduced
to static signature verification when terminal settlement is implemented.
This is local engineering synthesis, not a new external doctrine claim.

## Unknown Effects Versus Completed Callbacks (2026-09-28)

**Reproduction:** at both main `e502101` and publication-fence head `fbfb495`,
a matching synthetic `PostToolUseFailure` left a blocked checkpoint with unknown
external effects, but consumed the pending callback. Revocation then produced
`revoked` and wave expiry returned a terminal record. The different gateway
executing/unknown-recovery path without a matching completion was already blocked
by its pending admission; do not conflate that path with the reproduced gap.

**Repair:** project unknown-effect checkpoint references independently from
pending callbacks and latest lease status. Recheck full retained history before
new repository lease/tool authority, resume, completed-agent reporting, and wave
termination. Revocation is still recorded but cannot settle the unknown outcome.
Legacy terminal rows do not clear it; evidence remains immutable.

**Limit:** a conservative hold is not an effect-reconciliation workflow. A future
exact USER decision and independently retained effect evidence must define how
it can be cleared. Generic scope approval, clean files, a replacement wave, or
manually supplied success claims cannot perform that operation. The fixture
uses temporary repositories and hook events, not actual external side effects.

## Campaign Publication Appraisal (2026-09-28)

**Local finding:** entry-time readiness checks left a gap before durable wave,
dispatch, and gateway authority publication. Separate per-wave, per-agent, and
per-lease locks do not serialize an independently persisted campaign decision.

**Application:** a synchronous store predicate repeats the relevant readiness
checks under the existing repository namespace lease, after verified recovery
and before journal preparation. Earlier written candidates recover before a
later stop commits; unwritten prepared candidates roll back. Exact reuse still
requires appraisal. Frozen snapshots, explicit boolean success, expired-lease
rejection, no recursive write/recovery, and actual competing-process tests make
this a storage-boundary check rather than another early observation.

**Scope:** wave plans/campaign creation/context/report/closeout, dispatch
policy/lease/tool allow, and gateway allow/authorized/executing events. Denial,
already-admitted checkpoint recording, cancellation, and recovery remain available.
The fixtures inject an escalation or expiry between earlier checks and the
actual publication, and verify the forbidden artifact is absent.

**Limits:** cooperating local writers, not a hostile-writer or distributed
security boundary; no multi-artifact transaction, hard process kill, USER
stop/restart contract, or complete terminal reconciliation. Supervisor
order/challenge publication still needs integration. No external military-source
claim is added. See `docs/completion-backlog.md` for remaining lifecycle work.

## Sigstore Dependency Replay Migration (2026-09-28)

**Primary evidence:** upstream [e66d99f](https://github.com/sigstore/sigstore-js/commit/e66d99f0d79ddc28266ef71c8dfbcb9863c682e8)
hardens checkpoint parsing, and [adbe253](https://github.com/sigstore/sigstore-js/commit/adbe2535c5702364e9c958ae3d67fbdefe068edd)
prevents repeated log entries from inflating a threshold count.

**Local finding:** independent release records bind the verifier module and
dependency lockfile, not only its package version. Comparing their entire
replayed object to a new producer broke historical evidence after upgrades.
Source history identifies three supported v0.1 tuples at `786c38a`, `9635f8d`,
and `d08420a`; their module digest is identical, while lockfile digests differ.

**Application:** fresh evidence is v0.2 from exactly verifier 4.1.2, with
protobuf-specs 0.5.2. Historical recognition checks every producer field against
an exact source profile; the latest engine still verifies all cryptographic
claims. Comparison preserves original provenance only after that verification,
and does not mutate the retained bytes. Tests cover all three old profiles,
unknown producer fields, claim substitution, version pairs, and old-runtime
denial. Monitor and checkpoint admission still validate provider lineage.

**Rejected alternatives:** loading the old package to reproduce history,
ignoring module/lockfile fields, broadly allowing any patch version, altering
signed claims, rewriting the committed policy, or resetting checkpoints.

**Limit:** the migration recognizes producer source identity, not protected
historical execution. Synthetic migration wrappers around the retained public
GitHub bundle are test cases, not production-run evidence. Later producer
changes require explicit compatibility review. Credential repair, fresh live
monitor acceptance, and independently operated storage remain separate work.

## Campaign Stop Admission Gap (2026-09-28)

Local reproduction showed that a retained `escalate` decision stopped supervisor
cycle orders but did not stop `openWave` from reusing the immutable campaign's
original `active` field. A regression test failed with a missing expected
exception before the repair. The wave and dispatch runtimes now call the actual
read-only supervisor before admission instead of duplicating its state rules.
Tests cover terminal decisions, stale leases, result settlement, revocation,
resume denial, pauses, incomplete history, and cross-mission campaign reuse.

This is an admission repair, not a completed campaign cancellation/restart
contract. Already admitted processes need reconciliation; atomic stop fencing and
explicit USER-authorized successor lineage remain in `docs/completion-backlog.md`.

## Campaign Elapsed-Time Admission Gap (2026-09-28)

A new boundary regression reproduced `ready` at the exact deadline for a campaign
without checkpoints. The supervisor previously consulted only reported progress,
so idle time and an understated counter could leave admission open indefinitely.

The repair compares the evaluation instant against immutable campaign creation
plus the finite time budget, independently of the cumulative reported counter.
It checks before reusing retained orders and rejects evaluation before known
creation/history. Offset-aware boundary, low-counter, retained-ready, live CLI,
and wave/lease settlement tests exercise the behavior. Existing reported budget
snapshots and evidence bytes are preserved, not rewritten into stopwatch data.

This implements an admission deadline, not trusted time or an OS timeout.
Replay/test clock overrides are not live execution evidence. No pause discount,
automatic reset, process termination, campaign-wide cancellation, or USER restart
authority is inferred. These limits remain in the completion backlog.

## Implementation Traceability Audit (2026-09-28)

**Reason:** filename-only searches and broad changelog closure language obscured
unfinished requirements. A heading/list-aware scan found 125 requirements in
21 candidate sections, including narrative UI items and directory proposals.
Earlier counts from a narrower 16-document filename scan were not a full census.

**Application:** `docs/implementation-candidate-registry.md` defines exact source
IDs/digests, reviewed equivalent-path mappings, residual work, and separate
audit versus executed-verification results. The initial registry declares 37
implemented, 18 partial, and 70 planned requirements. Its fixtures reject
omissions, source drift, unsupported completion, unsafe check paths, execution
failure, and source mutation. `docs/completion-backlog.md` retains the broader
request compiler, intent, COP, force lifecycle, actual UI/API, campaign control,
dependency compatibility, and externally operated trust requirements.

**Limit:** these are engineering interpretations grounded in local code, not
additional military research. A mapped check cannot automatically establish
semantic adequacy for a prose requirement. Reviewers must inspect the claimed
mapping; implemented refers only to that candidate, not its whole doctrine.
The registry's current-source audit does not execute tests, and passing a
selected verification never grants authority or closes the overall program.

## 0. Purpose

This document brings together, in one place, the military command-and-control, order-issuance, authority-delegation, reporting, verification, and after-action materials researched so far, along with their interpretation.

The goal is not a simple bibliography. It records how each military concept can be converted into LLM usage patterns, single-agent operation, multi-agent orchestration, and hallucination-prevention prompting systems.

Scope:

- Focuses on public/unclassified documents.
- Includes US military, NATO, and some Korean military-related public research.
- Includes doctrine documents, research papers, handbooks, focus papers, and LLM hallucination/multi-agent research.
- Does not directly reproduce full source text; leaves summaries and applied opinions instead.

## 1. Overall Conclusion

The military's strength is not "chain of command obedience" itself. The real strength is the structure below.

```text
Preserve higher intent
-> Standard document format
-> Role-based staff analysis
-> Explicit authority and reporting standards
-> Rewriting by subordinate units
-> Confirmation brief / backbrief / rehearsal
-> FRAGO during execution
-> Post-action AAR
```

The core of an LLM framework is the same.

```text
Preserve user intent
-> OPORD-style prompt
-> Differentiation of agent roles
-> Definition of approval authority / reporting authority / autonomy
-> Rewriting of the execution plan by subordinate agents
-> Confirmation of understanding and verification before execution
-> Change orders during execution
-> Post-action retrospective and prompt improvement
```

Core design statement:

```text
When issuing instructions to an LLM, you must distinguish which information must never be altered
and which information subordinate agents are free to rewrite.
```

## 2. Lessons from the Military Document System

### 2.1 Order Issuance Is Intent-Preserving Rewriting, Not Copying

A higher unit's order is not copied verbatim by the subordinate unit. The subordinate unit creates a new OPORD suited to its own terrain, personnel, time, resources, and risk. However, the mission, commander's intent, and concept of operations of the one to two echelons above are preserved.

LLM Application:

- The higher-level user's intent must not be altered.
- Subordinate agents may rewrite the execution method.
- Even if the execution method changes, success conditions and prohibition lines are maintained.
- Each subordinate agent first reports its own understanding via a backbrief.

### 2.2 The OPORD Structure Converts Directly into a Prompt Structure

The five paragraphs of an OPORD:

1. Situation: background, environment, adversary, constraints, information gaps.
2. Mission: who, what, when, where, why.
3. Execution: commander's intent, concept of operations, phases, tasks, coordinating instructions.
4. Sustainment: resources, tools, cost, support.
5. Command and Signal: reporting lines, approval authority, communications, method of change.

LLM Application:

- Write the prompt as an "operation order," not a "request statement."
- Specify together what the model should do, should not do, must report, and must halt on.
- Separate detailed material out like an annex.

### 2.3 Annexes, Appendices, Tabs, and Exhibits Are Context-Separation Devices

Military documents do not put all information in the body. The body maintains the core intent and concept of operations, and detailed areas are separated into annexes.

LLM Application:

- The main prompt holds only the purpose, intent, success conditions, and approval criteria.
- Data, policy, style guides, glossaries, and test criteria are kept as separate annexes.
- In a RAG or multi-agent system, each annex is managed as a separate context pack.

### 2.4 WARNO, OPORD, and FRAGO Form a Time-Based Order-Update System

- WARNO: issued in advance so preparation can begin even before the full order is complete.
- OPORD: the main execution order.
- FRAGO: a partial change to an existing order in response to a change in the situation.

LLM Application:

- Before a long task, send a "preparatory prompt" first.
- Execute the main task as an OPORD.
- Record interim changes clearly as a FRAGO rather than rewriting the entire prompt.

## 3. Lessons from the Authority System

The military does not decide approval authority by rank alone. Duty position, command relationships, mission, delegated scope, ROE, SOP, and CCIR together determine authority.

LLM Application Principle:

```text
Authority is determined not by rank but by mission, risk, reversibility, information certainty, and alignment with higher intent.
```

### 3.1 Conditions for Autonomous Execution

Conditions under which an agent may execute without approval:

1. It aligns with higher intent.
2. It is within the scope of the order.
3. It is reversible.
4. Cost, security, and legal risk are low.
5. It does not trigger a CCIR reporting condition.
6. The evidentiary basis is sufficient.
7. Even if it fails, it does not significantly undermine the overall purpose.

### 3.2 Approval Levels

| Level | Name | Description |
|---|---|---|
| L0 | Observation | Reading, summarizing, research, drafting |
| L1 | Reversible work | Local temporary changes, testing |
| L2 | Restricted execution | In-scope file modification, document creation |
| L3 | External impact | Network, cost, external system changes |
| L4 | Irreversible work | Deletion, deployment, payment, public publication |
| L5 | High-risk judgment | Major legal, medical, financial, security, or personnel decisions |

### 3.3 Reporting Does Not Mean Escalating All Information

The military's CCIR is the core information a commander needs for a decision. Not all information is subject to reporting.

LLM Application:

- The model does not report every intermediate thought.
- Only information requiring the user's judgment is reported immediately.
- Everything else is compiled into a SITREP, Completion Report, or AAR.

## 4. Lessons from the Reporting and Verification System

### 4.1 Confirmation Brief

Immediately after receiving an order, the subordinate restates it: "This is the mission as I understand it."

LLM Application:

```text
The goal as I understand it:
Conditions that must not be altered:
What I may decide autonomously:
What requires approval:
Conditions for immediate reporting:
```

### 4.2 Backbrief

After completing their own plan, the subordinate explains it to the superior.

LLM Application:

- Report the plan before execution.
- Present phased deliverables, failure conditions, and verification methods.
- Let the user catch important directional errors early.

### 4.3 Rehearsal

Finds errors that arise in the process of converting a document into actual execution.

LLM Application:

- Dry run before execution.
- Red team review.
- Confirm inputs, outputs, failure conditions, and approval conditions.
- Halt high-risk work before actual execution.

### 4.4 AAR

The after-action retrospective is a learning system, not "blame."

LLM Application:

1. What was the original intent?
2. What was the actual result?
3. Why did the discrepancy occur?
4. Which procedures should be kept?
5. Which procedures should be improved?
6. What should be reflected in the next prompt/SOP?

## 5. Interpreting the Multi-Agent Structure

| Military Staff | LLM Agent | Role |
|---|---|---|
| Commander | User / Final Approver | Purpose, intent, prohibition lines, final approval |
| Chief of Staff | Orchestrator | Task decomposition, role assignment, conflict coordination |
| S2 | Research / Intelligence | Data collection, source verification, information gaps |
| S3 | Operations | Execution plan, phases, priorities |
| S4 | Sustainment | Resources, tools, cost, feasibility |
| S6 | Signal | Reporting, logs, document links, status sharing |
| Red Team | Critic / Validator | Review of errors, hallucinations, counterexamples, risk |
| Executor | Worker | Code, document, analysis execution |
| Recorder | Knowledge Manager | Decision log, change history, AAR |

Core Views:

- The purpose of multi-agent systems is not "running a lot of AI."
- It is to separate roles in order to reduce hallucination, overconfidence, authority overreach, and unclear responsibility.
- In particular, S2 and Red Team must be kept separate. If the person who did the research also verifies their own conclusion, errors are easily missed.

## 6. Interpreting Hallucination Prevention

The military system's hallucination-prevention devices are analogous to the following.

| Military Device | LLM Hallucination-Prevention Function |
|---|---|
| Standard terminology | Reduces ambiguous wording |
| OPORD | Clarifies purpose, constraints, reporting standards |
| CCIR | Immediately reports uncertain key information |
| IPB/JIPOE | Systematic analysis of environment and adversary |
| Red Team | Attacks assumptions and conclusions |
| Rehearsal | Finds errors before execution |
| AAR | Fixes recurring errors |
| FRAGO | Explicitly reflects changes |

Hallucination-Prevention Prompting Principles:

1. Have the model separate facts, inferences, and assumptions.
2. Any claim requiring a source must have one attached.
3. If evidence is insufficient, mark it "unknown" or "verification needed."
4. Core claims undergo independent verification.
5. When having the model re-verify its own answer, first have it generate independent questions.
6. Use search or RAG for up-to-date information that requires external material.

## 7. Core Views So Far

### 7.1 The Central Axis of Military-Style LLM Operation

The most important thing in LLM operation is not prompt writing skill. What matters is the command system.

A good LLM system must answer the following questions.

- Who sets the final intent?
- Which information must not be altered?
- Which information may subordinate agents reinterpret?
- Which actions may be executed autonomously?
- Which actions require approval?
- Which situations must be reported immediately?
- How will learning occur after execution?

### 7.2 The Military Increases Accuracy by Reducing the Volume of Information

Military documents do not put vast amounts of information all in the body. The body is centered on the order and intent, and details are separated into annexes.

Rather than stuffing everything into a long context in an LLM as well, it is more stable to separate it into:

- base order
- evidence annex
- policy annex
- data annex
- reporting annex
- verification annex

### 7.3 Higher Intent and Subordinate Autonomy Are Both Needed Simultaneously

If the higher level controls every detail, it is slow and fragile. Conversely, if the subordinate level is completely free, intent breaks down.

What is needed, therefore, is:

```text
Purpose is centralized
Method is decentralized
Reporting standards are explicit
Risk criteria are predefined
```

### 7.4 The AI Agent Is Staff, Not the Commander

An LLM agent can gather information, generate alternatives, build plans, and review risk. However, final purpose, value judgment, risk acceptance, and public execution must be approved by the Commander.

## 8. List of Key Sources

### 8.1 Mission Command / Command and Control

1. ADP 6-0, Mission Command: Command and Control of Army Forces  
   https://armypubs.army.mil/epubs/DR_pubs/DR_a/ARN34403-ADP_6-0-000-WEB-3.pdf

   Key Content:
   - Commander's intent.
   - Mission-type orders.
   - Mutual trust.
   - Shared understanding.
   - Disciplined initiative.
   - Subordinates exercise judgment within intent under uncertain conditions.

   LLM Application:
   - Define the user's intent as the commander's intent.
   - Leave the method to the agent, but clearly specify boundaries and success conditions.

2. FM 6-0, Commander and Staff Organization and Operations  
   https://armypubs.army.mil/epubs/DR_pubs/DR_a/ARN35404-FM_6-0-000-WEB-1.pdf

   Key Content:
   - Command post organization.
   - Staff roles.
   - Knowledge management and information management.
   - Meeting bodies and battle rhythm.
   - C2 system operations.

   LLM Application:
   - Basis for orchestrator and role-based agent design.
   - Meeting bodies can be converted into synchronization loops between agents.

3. NATO AJP-3, Allied Joint Doctrine for the Conduct of Operations  
   https://assets.publishing.service.gov.uk/media/6964e72799fbdc498faecce2/AJP_3_Ed_D_V1-O.pdf

   Key Content:
   - NATO mission command philosophy.
   - The principle of leaving decisions to whoever is best positioned to judge.
   - Emphasis on initiative and opportunity exploitation.

   LLM Application:
   - Let the relevant specialist agent judge specific subordinate problems.
   - The center controls only purpose and risk.

4. MCDP 6, Command and Control  
   https://www.marines.mil/Portals/1/Publications/MCDP%206.pdf

   Key Content:
   - OODA loop.
   - Decision-making speed.
   - Philosophy of command and control.

   LLM Application:
   - Design the agent loop as observe, orient, decide, act.

### 8.2 Operations Process / The Operations Process

1. ADP 5-0, The Operations Process  
   https://armypubs.army.mil/epubs/DR_pubs/DR_a/ARN18126-ADP_5-0-000-WEB-3.pdf

   Key Content:
   - planning, preparing, executing, assessing.
   - The commander performs understanding, visualizing, describing, directing, leading, and assessing.
   - Situational understanding and assessment repeat continuously.

   LLM Application:
   - Work in a plan, prepare, execute, assess loop rather than a single-shot answer.
   - Insert reporting and verification at each stage of long tasks.

2. FM 5-0, Planning and Orders Production  
   https://armypubs.army.mil/epubs/DR_pubs/DR_a/ARN44590-FM_5-0-001-WEB-3.pdf

   Key Content:
   - Comprehensive manual for planning and order production.
   - Problem solving, MDMP, TLP, assessment planning, plans and orders format.
   - The 2024 edition consolidates planning and orders production.

   LLM Application:
   - Basis for the standard format of prompts and work documents.
   - Agent work is also divided into planning documents and execution documents.

### 8.3 Planning Process / MDMP, JPP, MCPP, TLP

1. Military Decision-Making Process Handbook  
   https://api.army.mil/e2/c/downloads/2023/11/17/f7177a3c/23-07-594-military-decision-making-process-nov-23-public.pdf

   Key Content:
   - Receipt of mission.
   - Mission analysis.
   - COA development.
   - COA analysis/wargaming.
   - COA comparison.
   - Approval.
   - Order production.

   LLM Application:
   - For complex questions, do not answer directly; generate alternatives using the COA approach.
   - Compare each alternative against the Red Team.

2. JP 5-0, Joint Planning  
   https://www.esd.whs.mil/Portals/54/Documents/FOID/Reading%20Room/Joint_Staff/18-F-1152_JP_5-0_Joint_Planning_2020.pdf

   Key Content:
   - Joint planning.
   - Objectives, ways, means, risks.
   - Commander's intent and operational approach.

   LLM Application:
   - Decompose the user's goal into ways, means, and risks.

3. MCWP 5-10, Marine Corps Planning Process  
   https://www.usmcu.edu/Portals/218/CDET/content/other/MCWP%205-10.pdf

   Key Content:
   - Marine Corps Planning Process.
   - Problem framing, COA development, wargaming, transition.
   - Distinction between BAMCIS and MCPP.

   LLM Application:
   - Handle small tasks quickly, like TLP/BAMCIS.
   - Handle large tasks systematically, like MCPP/MDMP.

4. Troop Leading Procedures card  
   https://safety.army.mil/Portals/0/Documents/MEDIA/SMALLUNITLEADERCARDS/Standard/Troop-Leading-Procedures.pdf

   Key Content:
   - The procedure by which a small-unit leader receives a mission and quickly plans, prepares, and executes.

   LLM Application:
   - Use as the basic procedure when a single agent performs a small task.

### 8.4 Orders / Document Format

1. STANAG 2014, Formats for Orders  
   https://www.trngcmd.marines.mil/Portals/207/Docs/TBS/STANAG%202014%20Edition%2009-%20FORMATS%20FOR%20ORDERS%20%28OPORD%29.pdf

   Key Content:
   - Warning Order format.
   - Operations Order format.
   - Standardization of timings, locations, boundaries.
   - Annex format.

   LLM Application:
   - Design the prompt format like an internationally standardized order format.
   - Clarify changes, locations, timing, and boundary conditions.

2. Marine Corps Five Paragraph Order training material  
   https://www.trngcmd.marines.mil/Portals/207/Docs/FMTBE/Student%20Materials/FMST/209.pdf

   Key Content:
   - Mission includes who, what, when, where, why.
   - Execution covers how.

   LLM Application:
   - Force the 5W into the prompt's mission section.
   - Separate the "how" into the execution section.

3. Air Force Five-Paragraph Order Training Tool Guide  
   https://www.doctrine.af.mil/Portals/61/documents/NonDoctrine/Five-Paragraph%20Order%20Training%20Tool%20Guide.pdf

   Key Content:
   - A basic five-paragraph order training tool.
   - Does not replace the formal planning process; assists in drafting the final product.

   LLM Application:
   - The OPORD-style prompt is a tool that standardizes the resulting instruction document, not a replacement for the thinking process.

### 8.5 Commander's Intent / Higher Intent

1. Commanders Intent and Concept of Operations  
   https://www.armyupress.army.mil/Portals/7/military-review/Archives/English/MilitaryReview_20131231_art011.pdf

   Key Content:
   - The difference between commander's intent and concept of operations.
   - Producing effective mission orders.

   LLM Application:
   - Intent and the execution plan must be separated.
   - If purpose and method are mixed together, subordinate agents will misinterpret them.

2. Evolution of Commander's Intent in the United States Military  
   https://www.files.ethz.ch/isn/30757/Intent_USMilitary_v4.pdf

   Key Content:
   - Combat orders include the intent of the two echelons above.
   - Intent is a knowledge layer in combat orders that is relatively resistant to distortion.

   LLM Application:
   - Include both the higher-level goal and the immediate goal in each subordinate agent's prompt.
   - State explicitly "how this task contributes to the overall goal."

3. Mission Command Focus Paper  
   https://www.jcs.mil/Portals/36/Documents/Doctrine/fp/missioncommand_fp_2nd_ed.pdf

   Key Content:
   - Mission command enables rapid problem-solving through commander's intent, mission-type orders, and decentralized execution.

   LLM Application:
   - The central orchestrator does not control every detail.
   - Instead, it clarifies intent, boundaries, and reporting conditions.

### 8.6 Command Relationships / Command Relationships and Approval Authority

1. JCS Authorities Focus Paper  
   https://www.jcs.mil/Portals/36/Documents/Doctrine/fp/authorities_fp.pdf

   Key Content:
   - Authority relationships such as COCOM, OPCON, TACON, support.
   - TACON is more restrictive than OPCON.
   - OPCON is the authority to organize, employ, and task-organize forces needed to accomplish the mission.

   LLM Application:
   - Agent authority should also be divided into "full control," "tactical execution," and "support."

2. JTF and Command and Control Focus Paper  
   https://www.jcs.mil/Portals/36/Documents/Doctrine/fp/jtf_and_c2_fp.pdf

   Key Content:
   - JTF task organization.
   - Command relationships.
   - Need to clarify support relationships and authority.

   LLM Application:
   - When forming a multi-agent team, clarify who commands whom and who supports whom.

3. Command Relationships article  
   https://ndupress.ndu.edu/Portals/68/Documents/jfq/jfq-63/jfq-63_153-155_Katsos.pdf

   Key Content:
   - Command, unity of command, unity of effort.
   - Understanding authority relationships is essential in joint operations.

   LLM Application:
   - There must be a single final approver for a given task.
   - Even with multiple agents, unity of effort must be maintained.

### 8.7 CCIR / Reporting Standards

1. JCS CCIR Focus Paper  
   https://www.jcs.mil/Portals/36/Documents/Doctrine/fp/ccir_fp4th_ed.pdf

   Key Content:
   - CCIR is information critical to the commander's timely decision making.
   - CCIR also changes as mission, priorities, and the operating environment change.
   - Too much tactical detail flowing up can blur the commander's focus.

   LLM Application:
   - Do not report every detail to the user.
   - Report immediately only information that requires a decision.
   - Define CCIR before starting the task.

2. NDU CCIR article  
   https://ndupress.ndu.edu/Media/News/News-Article-View/Article/3843920/commanders-critical-information-requirements-crucial-for-decisionmaking-and-joi/

   Key Content:
   - CCIR must be linked to a decision point.
   - "What decision does this information support" matters more than a simple list.

   LLM Application:
   - Link "information to be reported" to "the decision the user must make."

3. Staff Facilitation of Commander Decision-Making in LSCO  
   https://api.army.mil/e2/c/downloads/2023/04/19/c0bb3dd8/23-758-staff-facilitation-of-commander-decision-making-in-lsco-apr-23-public.pdf

   Key Content:
   - There can be a gap between CCIR development and actual execution.
   - Staff must better support commander decision-making.

   LLM Application:
   - Reporting standards must not exist only on paper; they must operate within the actual agent loop.

### 8.8 Intelligence / Intelligence Analysis

1. ATP 2-01.3, Intelligence Preparation of the Battlefield  
   https://home.army.mil/wood/application/files/8915/5751/8365/ATP_2-01.3_Intelligence_Preparation_of_the_Battlefield.pdf

   Key Content:
   - Defining the operational environment.
   - Analyzing environmental effects.
   - Evaluating the adversary.
   - Determining adversary COAs.
   - IPB is central to MDMP and decision support.

   LLM Application:
   - Define the problem environment before answering.
   - State information gaps and assumptions explicitly.
   - Build possible adversary/situation scenarios.

2. JP 2-01.3, Joint Intelligence Preparation of the Operational Environment  
   https://www.bits.de/NRANEU/others/jp-doctrine/jp2_01_3%2809%29.pdf

   Key Content:
   - Analyze the operational environment with a holistic view.
   - Evaluate adversary COAs and centers of gravity.
   - Support wargaming and decision making.

   LLM Application:
   - Rather than simply summarizing search results, analysis of environment, actors, constraints, intent, and alternatives is needed.

### 8.9 Rehearsal / Rehearsal

1. Commander and Staff Guide to Rehearsals  
   https://api.army.mil/e2/c/downloads/2023/01/19/48e6a637/19-18-commander-and-staff-guide-to-rehearsals-a-no-fail-approach-handbook-jul-19-public.pdf

   Key Content:
   - Confirmation brief.
   - Backbrief.
   - Confirming understanding and feasibility of execution through rehearsal.

   LLM Application:
   - Make a backbrief mandatory before long tasks.
   - Confirm errors and omissions through a dry run before execution.

### 8.10 AAR / After-Action Learning

1. FM 7-0 Appendix K, After Action Reviews  
   https://www.first.army.mil/Portals/102/FM%207-0%20Appendix%20K.pdf

   Key Content:
   - The AAR is a guided analysis that examines performance to improve future performance.
   - Conducted at every echelon.

   LLM Application:
   - Write an AAR after every significant agent task.

2. Leader's Guide to After-Action Reviews  
   https://pinnacle-leaders.com/wp-content/uploads/2018/02/Leaders_Guide_to_AAR.pdf

   Key Content:
   - The AAR is a professional discussion, not a critique.
   - It lets participants discover what happened and why for themselves.

   LLM Application:
   - Do not treat failure as a simple error; connect it to SOP improvement.

3. Center for Army Lessons Learned  
   https://www.army.mil/CALL

   Key Content:
   - CALL collects, analyzes, disseminates, integrates, and archives lessons learned at the tactical-to-strategic level.

   LLM Application:
   - AAR results accumulate as organizational knowledge, not just individual task logs.

### 8.11 Red Team / Critical Thinking

1. U.S. Army Red Team Handbook  
   https://home.army.mil/wood/6115/8222/0759/RedTeamHB.pdf

   Key Content:
   - Critical thinking.
   - Alternative analysis.
   - Mitigating decision-making bias.

   LLM Application:
   - Place the Red Team agent in an independent role.
   - Separate the plan author from the validator.

2. UK Guide to Red Teaming  
   https://cmapspublic3.ihmc.us/rid%3D1M8NDWNQ5-9HYH9B-1D7R/A%20Guide%20to%20Red%20Teaming%20-%20DCDC%20Guidance%20Note.pdf

   Key Content:
   - Identify vulnerabilities, threats, alternatives, and branches/sequels in campaign planning and mission rehearsal.

   LLM Application:
   - Bring in the red team from the planning stage, not just right before the final answer.

### 8.12 C2 Agility / Network-Based Command and Control

1. Understanding Command and Control  
   https://www.dodccrp.org/files/Alberts_UC2.pdf

   Key Content:
   - Conceptual foundations of C2.
   - Resource allocation, shared awareness, decision-making.

   LLM Application:
   - Evaluate the quality of an agent system not just on answer quality, but on the quality of resource allocation and coordination.

2. Power to the Edge  
   https://www.dodccrp.org/files/Alberts_Power.pdf

   Key Content:
   - Information age command and control.
   - Edge organization, empowerment, shared awareness.

   LLM Application:
   - Subordinate agents must be given sufficient context and authority to operate quickly.

3. NATO SAS-085 Final Report on C2 Agility  
   https://dodccrp.org/sas-085/sas-085_report_final.pdf

   Key Content:
   - C2 agility is the ability to successfully respond to and exploit change.
   - Responsiveness, versatility, flexibility, resilience, adaptability, innovativeness.

   LLM Application:
   - A structure that supports FRAGO and authority adjustment as the situation changes is needed, rather than a fixed prompt.

### 8.13 OODA / Maneuver Warfare

1. John Boyd, Patterns of Conflict  
   https://www.projectwhitehorse.com/pdfs/boyd/patterns%20of%20conflict.pdf

   Key Content:
   - Observe, Orient, Decide, Act.
   - The concept of running the decision loop faster and less predictably than the adversary.

   LLM Application:
   - Rapidly repeat the observe-orient-decide-act loop rather than giving a single answer.

2. MCDP 1, Warfighting  
   https://www.marines.mil/portals/1/publications/mcdp%201%20warfighting.pdf

   Key Content:
   - The uncertainty, friction, and fluidity of war.
   - Commander's intent, main effort, critical vulnerability.

   LLM Application:
   - Translate "friction" into tool failure, information shortage, ambiguous requests, and hallucination.
   - Use main effort as the task priority.

### 8.14 Critiques of and Cautions About Mission Command

1. The Trouble with Mission Command  
   https://ndupress.ndu.edu/Portals/68/Documents/jfq/jfq-86/jfq-86_94-100_Hill-Niemi.pdf

   Key Content:
   - Mission command presupposes decentralization, but tools for judging when and where control should reside can be lacking.

   LLM Application:
   - Giving autonomy to every agent is risky.
   - Adjust central control versus decentralization according to risk, reversibility, and information certainty.

2. Beyond Auftragstaktik  
   https://ndupress.ndu.edu/Portals/68/Documents/jfq/jfq-96/JFQ-96_29-36_Lythgoe.pdf

   Key Content:
   - The dangers of excessive decentralization.

   LLM Application:
   - Maintain human approval for high-risk tasks.
   - An autonomy boundary is essential.

3. History, Mission Command, and the Auftragstaktik Infatuation  
   https://www.armyupress.army.mil/Journals/Military-Review/English-Edition-Archives/July-August-2022/Herrera/

   Key Content:
   - Critiques the narrative that worships Auftragstaktik as a simplistic archetype.
   - History and cultural context matter.

   LLM Application:
   - Military concepts should not be imported as simple metaphors.
   - Their actual operating principles and limitations must be brought over together.

### 8.15 Staff Organization / Staff System

1. The General Staff System: Basic Structure  
   https://arsof-history.org/articles/v7n2_general_staff_system_page_1.html

   Key Content:
   - S1/G1 Personnel.
   - S2/G2 Intelligence.
   - S3/G3 Operations.
   - S4/G4 Logistics.
   - S5/G5 Civil-military/plans.
   - S6/G6 Signal.

   LLM Application:
   - The basic framework for differentiating agent roles.

2. FM 101-5, Staff Organization and Operations  
   https://www.aiai.ed.ac.uk/~arpi/SUO/DOC/fm101-5.pdf

   Key Content:
   - Staff roles, relationships, responsibilities.

   LLM Application:
   - Designing the relationship between the orchestrator and specialist agents.

3. JP 3-33, Joint Task Force Headquarters  
   https://www.dodig.mil/Portals/48/JP%203-33%20Joint%20Task%20Force%20Headquarters.pdf

   Key Content:
   - Forming and operating a JTF HQ.
   - Planning, preparing, executing, assessing.

   LLM Application:
   - Organize a large multi-agent team like a temporary task force.

### 8.16 PACE / Communications Contingency Planning

1. CISA, Leveraging PACE Plan into Emergency Communications Ecosystems  
   https://www.cisa.gov/sites/default/files/2024-10/2024_NCSWICPTE_Leveraging_PACE_Plan_Emergency_Comms_Ecosystems.pdf

   Key Content:
   - Primary, Alternate, Contingency, Emergency.
   - Preparing for communications failure.

   LLM Application:
   - A backup model when the primary model fails.
   - Alternate material when search fails.
   - A manual procedure when automated execution fails.
   - Human approval when uncertainty is high.

### 8.17 Korean Military-Related Sources

1. A Study on Developing a Scale to Measure Mission Command
   https://www.kci.go.kr/kciportal/landing/article.kci?arti_id=ART002861979

   Key Content:
   - The Republic of Korea (ROK) Army adopted mission command as its command philosophy in 2018.
   - Measurement constructs: shared tactical understanding, delegation of authority, mutual trust, communication, capability building.

   LLM Application:
   - The maturity of an agent system can also be assessed using these five factors.
   - Shared doctrine, delegation, trust, communication, capability building.

2. Case Study on Applying Mission Command: The Russia-Ukraine War and KCTC Training
   https://m.riss.kr/search/detail/DetailView.do?control_no=1b5922e48fc3e9997f7a54760bb41745&p_mat_type=1a0202e37d52c72d

   Key Content:
   - Compares the Russian military's control-oriented command with the Ukrainian military's mission command.
   - Includes KCTC (Korea Combat Training Center) training case studies.

   LLM Application:
   - A comparative study of centrally controlled AI operation versus mission-command-style AI operation is possible.

3. Background Analysis of Improvements to US Air Force Command and Control Principles
   https://www.kci.go.kr/kciportal/ci/sereArticleSearch/ciSereArtiView.kci?sereArticleSearchBean.artiId=ART003133605

   Key Content:
   - Relates JADO, ACE, Lead Wing, MCA, AFFORGEN, and others to mission command.

   LLM Application:
   - Can be connected to distributed execution and multi-function agent concepts.

### 8.18 LLM Hallucination and Multi-Agent Research

1. Chain-of-Verification Reduces Hallucination in Large Language Models  
   https://arxiv.org/abs/2309.11495

   Key Content:
   - Generate a draft.
   - Generate verification questions.
   - Answer the questions independently.
   - Revise the final answer.

   LLM Application:
   - Directly connects to backbrief/rehearsal/red-team.

2. SelfCheckGPT  
   https://arxiv.org/abs/2303.08896

   Key Content:
   - Generate multiple samples for the same prompt to check consistency.
   - Possibility of black-box hallucination detection without an external database.

   LLM Application:
   - Verify core facts with multiple samples or an independent agent.

3. Hallucination Mitigation for Retrieval-Augmented Large Language Models  
   https://www.mdpi.com/2227-7390/13/5/856

   Key Content:
   - Hallucination can still occur in RAG at the retrieval and generation stages.
   - Detection, correction, and mitigation are needed.

   LLM Application:
   - RAG is a device that reduces hallucination, not one that eliminates it.
   - Manage source conflicts and retrieval quality separately.

4. Multi-Agent Collaboration Mechanisms: A Survey of LLMs  
   https://arxiv.org/abs/2501.06322

   Key Content:
   - Actor, collaboration type, structure, strategy, coordination protocol.

   LLM Application:
   - Connects military staff systems with multi-agent coordination research.

5. LLM-based Agents Suffer from Hallucinations: A Survey  
   https://arxiv.org/html/2509.18970v1

   Key Content:
   - Types and causes of hallucination at each stage of the agent workflow.
   - Mitigation and detection taxonomy.

   LLM Application:
   - Agent hallucination occurs not only in answer generation but also in planning, tool use, memory, and collaboration.

### 8.19 SOP / Standardization of Repeated Execution

1. ATP 3-90.90, Army Tactical Standard Operating Procedures  
   https://www.scribd.com/document/78673750/ATP-3-90-90

   Key Content:
   - Material to facilitate the development of tactical SOPs.
   - SOPs standardize repeated procedures to raise efficiency and adaptability.
   - SOP cases are shared and improved through a collaborative portal.

   LLM Application:
   - Repeated tasks are handled with SOP templates rather than being redesigned each time.
   - Research, summarization, code changes, verification, reporting, and AAR each need an SOP.
   - An SOP is not a device that blocks agent autonomy, but one that stabilizes baseline execution and lets attention focus on exception judgment.

2. Building a Unit Planning Standard Operating Procedure  
   https://www.army.mil/article/277041/building_a_unit_planning_standard_operating_procedure_psop

   Key Content:
   - An effective PSOP supports staff planning clearly and concisely.
   - It reduces unproductive time between warfighting functions and creates an efficient planning procedure.

   LLM Application:
   - Quality suffers if multi-agent systems plan differently each time.
   - A Planning SOP should be created to fix the input/output/reporting cycle for each agent.

### 8.20 Battle Rhythm / Meetings and the Decision Cycle

1. Executing Knowledge Management in Support of Mission Command  
   https://api.army.mil/e2/c/downloads/2023/01/19/919a5372/18-02-executing-knowledge-management-in-support-of-mission-command-a-primer-for-senior-leaders-nov-17-public.pdf

   Key Content:
   - Battle rhythm is the activity that synchronizes current and future operations.
   - Inefficiency arises if the battle rhythm is not linked to the critical path for commander decisions.

   LLM Application:
   - Agent status reports must be inputs for the next decision, not simple progress reports.
   - Align cycles so that each agent's output becomes the next agent's input.

2. Improving the Battle Rhythm to Operate at the Speed of Relevance  
   https://ndupress.ndu.edu/Media/News/News-Article-View/Article/2679728/improving-the-battle-rhythm-to-operate-at-the-speed-of-relevance/

   Key Content:
   - Battle rhythm is the deliberate cycle of command, staff, and unit activities.
   - Meetings, working groups, boards, briefings, and so on are synchronized by time and purpose.
   - Each headquarters' battle rhythm must be nested with the others.

   LLM Application:
   - In long-running tasks, set a rhythm of regular SITREPs, Red Team reviews, and Commander approval gates.
   - If reporting cycles are misaligned, information arrives late and produces bad decisions.

3. Staff Processes in Large-scale Combat Operations, Rhythm of the Battle  
   https://api.army.mil/e2/c/downloads/2024/06/07/b62f30eb/24-852-staff-processes-in-large-scale-combat-operations-part-1-rhythm-of-the-battle.pdf

   Key Content:
   - A rigid battle rhythm is useful in a static environment, but in LSCO it must be adjusted as the situation changes.
   - The battle rhythm changes as the operation progresses.

   LLM Application:
   - A framework must not rely on a fixed workflow alone.
   - Different rhythms should be set for urgent/simple/complex/high-risk tasks.

### 8.21 Knowledge Management / Information Flow Management

1. FM 6-01.1, Knowledge Management Operations  
   https://www.bits.de/NRANEU/others/amd-us-archive/fm6-01-1%2812%29.pdf

   Key Content:
   - Knowledge management is the activity that ensures information reaches the people who need it, at the time and in the format they need.
   - Working groups and boards are part of the battle rhythm.
   - It breaks down information silos and supports staff integration.

   LLM Application:
   - Putting all information into a single context is a bad approach.
   - Information flow should be separated into a Source Map, Evidence Map, Decision Log, Change Log, and AAR Library.

2. USFKI 5780.01 Knowledge Management Program  
   https://www.usfk.mil/Portals/105/Documents/Publications/Instructions/USFKI_5780-01_Knowledge-Management-Program.pdf

   Key Content:
   - Battle rhythm is the overall activity by which people, processes, and tools are synchronized to support the leader's decision cycle.
   - It supports shared understanding and timely commander decision making.

   LLM Application:
   - To build shared understanding between agents, documents, logs, and reporting formats must use the same structure.

### 8.22 Liaison / Horizontal Connection

1. FM 6-0 Appendix E, Liaison  
   https://www.globalsecurity.org/military/library/policy/army/fm/6-0/appe.htm

   Key Content:
   - Liaison facilitates communication between organizations and maintains freedom of action and flexibility.
   - It provides senior commanders with relevant information and answers to operational questions.

   LLM Application:
   - In a multi-agent system, liaison is the "interface between agents."
   - Track whether S2's evidence made it into S3's plan, and whether Red Team findings led to Executor fixes.

### 8.23 Risk Management / Risk Management

1. ATP 5-19, Risk Management  
   https://www.first.army.mil/Portals/102/Users/231/99/999/Risk%20Management%20ATP%205-19.pdf

   Key Content:
   - Doctrinal guidance on risk management during operations.
   - Risk must be identified, assessed, controlled, decided upon, executed, and supervised/evaluated.

   LLM Application:
   - Agent authority must vary with risk level.
   - Low-risk/reversible tasks get autonomy; high-risk/irreversible tasks require approval.
   - A risk register must be maintained.

2. Risk Management Quick Reference Booklet  
   https://asktop.net/wp/download/GTA/GTAx21-08-001xv2014.pdf

   Key Content:
   - A quick reference based on ATP 5-19.
   - Used to quickly check the risk management procedure.

   LLM Application:
   - Rather than applying the entire lengthy risk doctrine every time, insert a simple risk gate into the prompt.

### 8.24 Operation Assessment / Performance Evaluation

1. Operation Assessment MTTP  
   https://www.alssa.mil/mttps/assessment/

   Key Content:
   - A commander and staff guide for integrating assessment into planning and the operations process.
   - How-to techniques and procedures that supplement joint/service doctrine.

   LLM Application:
   - Evaluate separately whether a deliverable was produced and whether the purpose was achieved.
   - Document MOP, MOE, and indicators.

2. ATP 5-0.3 / Operation Assessment PDF  
   https://www.bits.de/NRANEU/others/amd-us-archive/ATP5-0x3%2815%29.pdf

   Key Content:
   - Integrates assessment into the planning and operations process.
   - Uses indicators and assessment products.

   LLM Application:
   - Passing a test is closer to an MOP; actually achieving the user's goal is closer to an MOE.
   - For a documentation project, "the next worker can execute it as-is" is the MOE, not just "the document exists."

3. JP 5-0, Joint Planning  
   https://www.esd.whs.mil/Portals/54/Documents/FOID/Reading%20Room/Joint_Staff/18-F-1152_JP_5-0_Joint_Planning_2020.pdf

   Key Content:
   - Operation assessment measures observable key indicators to increase the effectiveness of planning and execution.

   LLM Application:
   - A framework can only be improved if it also has measurable indicators.

### 8.25 Training / Readiness / METL

1. ADP 7-0, Training  
   https://armypubs.army.mil/ProductMaps/PubForm/Details.aspx?PUB_ID=1032716

   Key Content:
   - Training is a core commander responsibility for building readiness.
   - Units select and evaluate training tasks matched to the missions they must actually perform.
   - Training is not a one-time event but a repetition of plan, prepare, execute, assess.

   LLM Application:
   - Agents, too, should be evaluated not on "being good" but on which mission-essential tasks they can perform.
   - Manage prompt writing, source verification, code changes, Red Team review, and AAR incorporation as an AI METL.
   - Place more checklists and approval gates on agents with lower readiness.

2. FM 7-0, Training  
   https://armypubs.army.mil/ProductMaps/PubForm/Details.aspx?PUB_ID=1022335

   Key Content:
   - Training management connects unit missions with training resources.
   - The commander sets training priorities and evaluation methods.
   - Collective tasks and individual tasks must be linked.

   LLM Application:
   - Evaluate single-agent capability and multi-agent collective capability separately.
   - Example: if S2 is good at source verification but S3 integration is weak, overall operational readiness is low.
   - Keeping a record of success/failure per task, like a training record, allows agent authority to be expanded gradually.

3. Crawl-Walk-Run Approach

   Key Content:
   - A complex mission is not performed with full autonomy right away; proficiency is built up in stages.
   - It progresses from simple procedures at first, to complex procedures under supervision, and finally to mission-type performance.

   LLM Application:
   - Crawl: the agent follows the SOP checklist exactly.
   - Walk: the agent makes some judgment calls but receives a backbrief and approval.
   - Run: the agent receives only the commander's intent and CCIR and executes autonomously.

### 8.26 Sustainment / Logistics

1. ADP 4-0, Sustainment  
   https://armypubs.army.mil/ProductMaps/PubForm/Details.aspx?PUB_ID=1028796

   Key Content:
   - Operations cannot be sustained without sustainment support.
   - Sustainment covers the ability to continue combat operations, including supply, maintenance, transportation, personnel, and medical support.
   - The commander must consider the operation plan and the sustainment plan together.

   LLM Application:
   - The sustainment of LLM work consists of tokens, context, tools, APIs, file access, time, and the test environment.
   - Long-running research or multi-agent work needs an S4 role.
   - Look not only at "can it be done" but at "can it be sustained through completion."

2. JP 4-0, Joint Logistics  
   https://www.jcs.mil/Doctrine/Joint-Doctrine-Pubs/4-0-Logistics-Series/

   Key Content:
   - Joint logistics integrates multiple organizations and functions to support operations.
   - Priority, allocation, and coordination are the core.

   LLM Application:
   - When multiple agents work simultaneously, they compete for the same context, the same sources, and the same tools.
   - A Chief of Staff or S4 agent must manage resource allocation and bottlenecks.
   - Long tasks must guard against context loss through checkpoints and documentation.

3. Sustainment principles

   Key Content:
   - Principles such as anticipation, responsiveness, simplicity, economy, survivability, continuity, and improvisation are repeatedly emphasized.

   LLM Application:
   - Anticipation: anticipate the sources and tools needed before starting work.
   - Responsiveness: issue a FRAGO quickly in response to user change requests or failures.
   - Simplicity: keep document structure and prompt chains simple.
   - Economy: use expensive models and tools only where needed.
   - Survivability: leave documents and summaries in place to guard against context loss.
   - Continuity: keep saving intermediate deliverables.
   - Improvisation: have a fallback procedure ready for tool failure.

### 8.27 Targeting / Effects

1. JP 3-60, Joint Targeting  
   https://www.jcs.mil/Doctrine/Joint-Doctrine-Pubs/3-0-Operations-Series/

   Key Content:
   - Targeting is not simply about designating a target; it is a process that links the desired effect, means, and assessment.
   - The joint targeting cycle is a system that links decision, execution, and assessment.

   LLM Application:
   - LLM work, too, must first decide "what effect to produce" rather than "what to do."
   - Example: "writing a document" is an activity; "enabling the next agent to trace the evidence" is the effect.
   - Attach a target, desired effect, and assessment method to every change.

2. FM 3-60, Army Targeting  
   https://armypubs.army.mil/ProductMaps/PubForm/Details.aspx?PUB_ID=1030750

   Key Content:
   - Army targeting is described by the decide, detect, deliver, assess (D3A) flow.
   - After confirming where a decided target actually is and what state it is in, means are applied and effects are assessed.

   LLM Application:
   - Decide: decide which documents, code, claims, or risks to change.
   - Detect: check the current state of files and sources.
   - Deliver: perform the edit, creation, or tool call.
   - Assess: check tests, reviews, the source map, and whether the user's goal was achieved.

3. Effects-based thinking

   Key Content:
   - In operations, the effect an action produces matters more than the action itself.

   LLM Application:
   - The effect is not "fixed the code" but "reproduced the user's problem and prevented it with a test."
   - The effect is not "attached a source" but "the core claim and the official source are traceable."

### 8.28 Rules of Engagement / Legal and Ethical Control

1. CJCSI 3121.01B, Standing Rules of Engagement / Standing Rules for the Use of Force  
   A public reference exists, but the latest official release must be confirmed before use as an actual operating standard.

   Key Content:
   - ROE predefine which actions are permitted and which are restricted in a given situation.
   - The commander weighs mission accomplishment and legal/policy restrictions simultaneously.

   LLM Application:
   - ROE for agents are divided into allowed, approval required, and prohibited.
   - Reading and summarizing files is allowed; external distribution and incurring cost is approval required; exposing secret keys and fabricating sources is prohibited.
   - ROE must be an actual tool-use authority table, not just model safety boilerplate.

2. JP 3-84, Legal Support  
   https://www.jcs.mil/Doctrine/Joint-Doctrine-Pubs/3-0-Operations-Series/

   Key Content:
   - Legal support and restriction review are combined in operational command.
   - Legal judgment is included in planning and execution, not treated as a separate after-the-fact stage from the operation plan.

   LLM Application:
   - High-risk domains such as law, medicine, finance, and security are not areas where an agent should form its own independent conclusion.
   - The agent must identify the risk and escalate it via an approval/expert review path.

3. Combining Risk Decision Authority with ROE

   Key Content:
   - The authority to accept risk differs by echelon.

   LLM Application:
   - The agent is a risk reporter, not a risk acceptor.
   - High-risk judgments must be classified as "approval required," not "I handled it."

### 8.29 Warfighting Functions / Integration by Function

1. FM 3-0, Operations  
   https://armypubs.army.mil/ProductMaps/PubForm/Details.aspx?PUB_ID=1026282

   Key Content:
   - Combat power arises from the integration of multiple warfighting functions.
   - Command and control, intelligence, movement, fires, sustainment, and protection must operate together rather than separately.

   LLM Application:
   - An LLM framework, too, cannot rely on prompts alone.
   - Command and control, intelligence, execution, sustainment, protection, information, and assessment must all be present.
   - This perspective becomes the basic structure of `functional-domains.md`.

2. ADP 3-0, Operations  
   https://armypubs.army.mil/ProductMaps/PubForm/Details.aspx?PUB_ID=1032715

   Key Content:
   - Modern operations are conducted in an environment where multiple domains and functions affect each other simultaneously.

   LLM Application:
   - Multi-agent work also involves research, code, documentation, testing, and user communication interacting simultaneously.
   - Success in one function does not guarantee overall success.

3. Translation of LLM Functional Domains

   Key Mapping:
   - Command and Control -> user intent, approval, reporting, authority.
   - Intelligence -> sources, facts, uncertainty, hallucination prevention.
   - Movement and Maneuver -> task sequencing, file navigation, execution path.
   - Fires -> changes and effects on a specific target.
   - Sustainment -> tokens, time, tools, context, dependencies.
   - Protection -> security, sensitive information, rollback, approval gates.
   - Information -> documentation, knowledge management, SITREP, AAR.

### 8.30 Korean Public Military Sources / Public ROK Military Sources

1. Ministry of National Defense (MND) Public Materials and Defense White Paper
   https://www.mnd.go.kr/

   Key Content:
   - Provides insight into Korean defense policy, force structure, defense innovation, and the direction of the shift to a technology-based force.
   - More useful for understanding strategic, organizational, and policy context than detailed operational doctrine.

   LLM Application:
   - Used as background material for a Korean-style LLM military framework.
   - Connects AI not merely as a productivity tool but to command and control, informatization, education and training, and logistics transformation.
   - States the limitations of the public material explicitly and fills structural gaps using published US military doctrine.

2. Korean Law Information Center (National Law Information Center)
   https://www.law.go.kr/

   Key Content:
   - Provides access to the Act on the Status and Service of Military Personnel, MND directives, and unit management regulations.
   - Provides the legal/institutional basis for command, service, command responsibility, security, and management systems.

   LLM Application:
   - Used as an analogical basis for agent authority and ROE.
   - Distinguishes "the user gave an order" from "it can be executed within legitimate authority."
   - Translates honest reporting, risk reporting, and protection of sensitive information into hallucination prevention and tool-use control.

3. Korea Institute for Defense Analyses (KIDA)
   https://www.kida.re.kr/

   Key Content:
   - Provides public research materials on defense policy, defense AI, command and control, logistics, informatization, and organizational operations.
   - Useful for understanding the institutional context of the Korean military and Korean defense policy.

   LLM Application:
   - Used to calibrate mission command for Korean organizational culture.
   - Connects defense AI and informatization research as a basis for the implementation guide.
   - KIDA material is treated as research-grade, distinct from official law/doctrine.

4. Public Korean Military Terminology Sources

   Key Content:
   - Unifying military terminology is a key device for reducing distortion in command and reporting.
   - Korean military terms and English doctrinal terms may not correspond exactly one-to-one.

   LLM Application:
   - Manage Korean/English terms together in `glossary.md`.
   - Stabilize the field names of the prompt DSL.
   - Prevent the model from translating or coining military terms arbitrarily.

5. Limits of Using Korean Sources

   Key Content:
   - Detailed operational doctrine, order formats, and actual command-and-control procedures have low public accessibility.
   - Public materials are centered on law, policy, research, and terminology sources.

   LLM Application:
   - Use Korean military sources to establish Korean context, and supplement procedural structure with published US military doctrine.
   - Where public material is absent, leave it marked as "assumption" or "further research needed."

### 8.31 Implementation / Runtime Translation

1. Converting a Military-Style System into a Runtime Structure

   Key Content:
   - Military-style operation does not function on concepts alone.
   - An actual system needs mission state, an authority gate, a tool log, an evidence store, and an AAR store.

   LLM Application:
   - Store the user request as a mission object.
   - The OPORD is compiled into a task order.
   - Tool calls are ruled on by ROE at the tool gateway.
   - Source-based claims are linked to the evidence store.
   - After completion, the AAR is reflected in the SOP and readiness rating.

2. Prompt DSL

   Key Content:
   - Express OPORD, WARNO, FRAGO, SITREP, and AAR as a schema that is human-readable and machine-verifiable.
   - Keep mission, intent, authority, CCIR, and assessment as required fields.

   LLM Application:
   - Structure the prompt instead of leaving it as a blob of natural language.
   - Detect missing intent, authority, or MOP/MOE with validation rules.
   - A prompt compiler can convert the DSL into system/developer/user prompts.

3. Tool-Use ROE

   Key Content:
   - Translate military ROE into an LLM tool-use authority system.
   - Divide actions into Green, Amber, Red, and Black, each with its own execute/approve/deny rules.

   LLM Application:
   - Reading files and generating documents can be Green.
   - API writes, package changes, and external form submission are Amber or higher.
   - Data deletion, production DB changes, and deployment are Red.
   - Printing secret keys, fabricating sources, and bypassing access to restricted material are Black.

4. Agent Org Chart

   Key Content:
   - For multi-agent systems, the command relationship matters more than the number of roles.
   - Separate the responsibilities and reporting lines of Commander, Chief of Staff, S2, S3, S4, S6, Red Team, and Evaluator.

   LLM Application:
   - If every agent becomes a commander, deliverables become scattered.
   - Red Team is an independent reviewer, not the final author.
   - S2 produces sources and uncertainty, S3 produces the execution plan, and the CoS integrates them.

### 8.32 Reference Architecture / Productization

1. Calibrating for Korean Organizational Culture

   Key Content:
   - In Korean organizations, hierarchical obedience, approval chains, over-optimistic reporting, and suppression of dissent affect how the framework operates.
   - When introducing a military-style system, the emphasis should be on strengthening backbriefs, risk reporting, Red Team independence, and authority delegation, rather than automating superior-issued orders.

   LLM Application:
   - Even a "just handle it" request does not bypass the ROE.
   - Ambiguous orders are calibrated using a backbrief and an assumption list.
   - Red Team findings are treated as material for command judgment, not as criticism.

2. Reference Architecture

   Key Content:
   - An actual system divides into an Orchestrator, OPORD compiler, Agent registry, Policy/ROE engine, Tool gateway, Evidence store, State store, and Audit store.
   - The Tool gateway must be the single gateway for all external actions.

   LLM Application:
   - Agents do not execute tools directly; they pass through the policy engine.
   - Separate mission state from the evidence store to trace intent and evidence.
   - Record approvals, denials, and execution results through the audit store.

3. Sample Runtime State

   Key Content:
   - Defined sample states for mission, OPORD, task order, agent registry, tool request, approval request, SITREP, FRAGO, evidence, and AAR.

   LLM Application:
   - Reduce context loss on long tasks through state storage.
   - Record the AAR in a learning store and link it to readiness and SOP updates.

4. Prompt DSL Validator

   Key Content:
   - For the validator, detecting risk before execution matters more than grammar checking.
   - Catches missing mission, intent, authority, CCIR, or assessment as an error or critical.

   LLM Application:
   - Set rules such as MISSING_AUTHORITY, HIGH_RISK_NO_APPROVAL, MOP_ONLY.
   - Have ambiguous mission and authority fixed before execution.

5. Approval UI Patterns

   Key Content:
   - Approval should not be a "continue?" prompt; it must show action, tool, target, risk, rollback, and alternatives.
   - For Red actions, the default should be dry-run, not approve.

   LLM Application:
   - The approval request must become a decision memo.
   - Action-level, time-bound approval is safer than blanket approval.

### 8.33 Runtime Contracts / Schema and Operations

1. JSON Schema contracts

   Key Content:
   - Separated schemas for mission, agent, OPORD, task order, tool request, approval request, SITREP, FRAGO, evidence, AAR, and readiness ledger.
   - The schema serves as the runtime's "order format."

   LLM Application:
   - The agent produces verifiable state objects rather than free text that merely looks like a document.
   - The OPORD and tool request are linked by the same mission id, making them auditable.

2. Validator prototype

   Key Content:
   - Separated JSON Schema validation from semantic military-control validation.
   - Blocks missing intent, authority, CCIR, MOP/MOE, or high-risk tool actions before execution.

   LLM Application:
   - Blocks a "prompt that is formally correct but has no command and control."
   - Halts tasking and tool execution when a critical issue exists.

3. Agent runtime playbook

   Key Content:
   - Defined the procedures for startup, mission intake, OPORD approval, tasking, execution, SITREP, FRAGO, approval, evidence, verification, incident, AAR, and shutdown.

   LLM Application:
   - The runtime operator manages active missions, pending decisions, failed tool requests, and unresolved AARs, not just model output.

4. Military AI risk register

   Key Content:
   - Built a register of recurring risks such as intent distortion, hallucination, unauthorized action, secret exposure, gateway bypass, and MOP-only evaluation.

   LLM Application:
   - Links each risk to a CCIR and a control, for use as reporting and approval criteria.

5. Agent readiness ledger

   Key Content:
   - Records per-agent task readiness as T/P/U/X.
   - Readiness is an evidence-based evaluation of a specific mission-essential task, not a general evaluation of the model.

   LLM Application:
   - High-readiness tasks are performed autonomously; low-readiness tasks require a backbrief and supervision.

### 8.34 Runtime Fixtures / Policy / Dashboard

1. Sample payloads

   Key Content:
   - Created valid/invalid JSON examples for mission, tool request, approval, SITREP, evidence, and AAR.
   - The invalid examples represent failures the validator must catch, such as missing intent and Red without approval.

   LLM Application:
   - The framework becomes a testable runtime contract rather than staying on paper.

2. Policy engine rules

   Key Content:
   - ROE rulings follow the priority Black > Red > Amber > Green.
   - Considers actor, tool, action, target, data sensitivity, mission constraint, and approval scope together.

   LLM Application:
   - An agent's tool request must pass through the policy engine, and even with approval, mission/tool/action/target/time must match.

3. Command post dashboard

   Key Content:
   - The dashboard must prioritize decision required, CCIR, approval queue, risk, and evidence over completion percentage.

   LLM Application:
   - Rather than showing the user every log, surface only the information needed for command judgment.

4. Runtime automation roadmap

   Key Content:
   - A document-based framework is productized in the order: validator CLI, prompt compiler, tool gateway, approval UI, evidence store, command post dashboard, learning runtime.

   LLM Application:
   - Implement gate by gate rather than building full automation all at once.

5. Evaluation fixtures

   Key Content:
   - Defined schema, semantic, policy, evidence, and runtime fixtures.
   - Downgrading a critical rule, allowing Red without approval, or allowing a Black action are regression failures.

   LLM Application:
   - The validator and policy engine must be managed with fixture-based regression tests, not just documentation descriptions.

### 8.35 Executable Prototype / Data Model / Demo

1. Validator CLI prototype

   Key Content:
   - Built a draft CLI running a JSON Schema subset and semantic rules in Node.js with no external dependencies.
   - Passed smoke tests for a valid mission, invalid missing intent, valid Green tool request, and invalid Red without approval.

   LLM Application:
   - The first executable deliverable in converting a military-style document system into an actual runtime gate.

2. Dashboard wireframes

   Key Content:
   - Divided the command post dashboard into mission board, approval queue, CCIR alerts, evidence viewer, risk board, and readiness board.

   LLM Application:
   - The user sees the information requiring a decision, risks, approval requests, and evidence first, not the full log.

3. SQL data model

   Key Content:
   - Designed tables for missions, orders, task_orders, tool_requests, approvals, audit_events, evidence, sitreps, fragos, aars, risks, and readiness_ledger.

   LLM Application:
   - Tracks command, evidence, audit, and learning centered on the mission id.

4. Runtime demo scenario

   Key Content:
   - Wrote an example of a user's implementation request flowing through intake, OPORD, task order, tool request, SITREP, FRAGO, verification, and AAR.

   LLM Application:
   - Shows that the framework has a flow of time and events like an actual operation.

5. Source reliability rubric

   Key Content:
   - Rates sources A/B/C/D/X, looking at authority, directness, currency, scope, and interpretive risk.

   LLM Application:
   - Separates the source claim from the LLM's interpretation so that "what the source said" and "the interpretation we applied" are not confused.

### 8.36 Runtime Prototype / Event Model

1. Validator fixture runner

   Key Content:
   - `run-fixtures.js` runs valid/invalid payloads and checks the expected issue code.
   - Missing intent and Red without approval must fail as critical.

   LLM Application:
   - The validator rule becomes a regression test, not just a documented promise.

2. Policy engine prototype

   Key Content:
   - Rules on Black, Red, Amber, or Green based on the tool request text and the declared ROE class.
   - Black cannot be bypassed even with approval.

   LLM Application:
   - Produces the first implementation unit of the tool gateway.

3. Runtime demo payloads

   Key Content:
   - Wrote payloads for mission, task order, Green tool request, Red tool request, approval request, SITREP, evidence, and AAR.

   LLM Application:
   - Makes it possible to verify how a single mission flows through the runtime state objects.

4. Dashboard UI prototype

   Key Content:
   - Built a command post dashboard as static HTML.
   - Placed mission intent, CCIR, approval queue, risks, active tasks, evidence, readiness, and SITREP on a single screen.

   LLM Application:
   - Validates a UI direction that shows the user "what must be decided" first.

5. Event sourcing model

   Key Content:
   - Defined events such as MissionCreated, OPORDCreated, ToolRequestCreated, PolicyDecisionMade, ApprovalRequested, ToolBlocked, SITREPIssued, AARIssued, and ReadinessUpdated.

   LLM Application:
   - In long-running operations, the history of command judgment matters as much as the current state.

### 8.37 Automation Runners / Dashboard State / Event Replay

1. Policy fixture runner

   Key Content:
   - Automatically tests the expected decision for a Green local action, Red without approval, demo Green, and demo Red deploy.

   LLM Application:
   - Immediately catches a regression where the policy engine allows a Red action.

2. Runtime demo runner

   Key Content:
   - Validates the entire demo mission payload with the validator, and checks Green/Red tool requests with the policy engine.

   LLM Application:
   - Confirms that a single mission flow passes both the schema and policy gates.

3. Dashboard state

   Key Content:
   - Separated the dashboard prototype's data into `dashboard-state.json`.
   - The HTML renders the state if the JSON fetch succeeds, and uses a fallback state if it fails.

   LLM Application:
   - Event replay projections can later be converted into dashboard state.

4. Event fixtures and replay prototype

   Key Content:
   - Built a demo event log; the replay script computes mission, tasks, tool requests, approvals, SITREP, evidence, AAR, and readiness projections.

   LLM Application:
   - Separates the history of command judgment from the current state, supporting both audit and dashboard projection at once.

### 8.38 Projection Automation / OPORD Payload / Commander Handbook

1. Dashboard state renderer

   Key Content:
   - Added `dashboard-ui-prototype/render-state.js`.
   - Converts the event replay projection into the JSON state format read by the dashboard prototype.
   - Folds blocked Red requests, pending approval, evidence count, latest SITREP, and readiness into a commander-facing screen state.

   LLM Application:
   - The command post screen is built from the event log projection, not from conversational memory.
   - Creates a link between "current state" and "auditable history."

2. Event replay fixture runner

   Key Content:
   - Added `event-replay-prototype/run-event-fixtures.js`.
   - Automatically verifies mission complete, OPORD retention, task projection, Green executed, Red blocked, pending approval, SITREP, evidence/AAR count, readiness, and the dashboard approval queue.

   LLM Application:
   - Fails immediately if the event replay logic loses a Red action block or the approval queue.
   - Makes the audit architecture a regression gate, not just a documented idea.

3. Runtime demo OPORD

   Key Content:
   - Added `runtime-demo-payloads/opord.json`.
   - Put the mission -> OPORD -> task order chain under actual schema validation.
   - Authority, CCIR, sustainment, and assessment are included inside the OPORD payload.

   LLM Application:
   - A user request is not executed directly; it is structured into an order document and then passed through the validator.
   - Approval authority and prohibition lines are made into a payload contract, not just prompt text.

4. Military operating deep research queue

   Key Content:
   - Added `military-operating-deep-research-queue.md`.
   - Organized missing areas such as B2C2WG, staff integration, OPSEC/classification, knowledge management, training/METL, sustainment, and liaison into a research backlog.

   LLM Application:
   - Framework expansion is managed as a backlog by military operating domain, not as arbitrary topics.
   - Manages source rating, research question, and output artifact together.

5. Commander handbook

   Key Content:
   - Added `commander-handbook.md`.
   - Organized, as practical procedure, how a human operates intent, priority, risk, authority, CCIR, approval, and AAR as an AI commander.

   LLM Application:
   - In both single-agent and multi-agent settings, the commander can clearly state "what to execute autonomously and where to stop."
   - Approval requests, backbriefs, SITREPs, and hallucination control prompts became immediately usable.

### 8.39 B2C2WG / CCIR Alerting / OPSEC / KM / METL / Authority Matrix

1. B2C2WG operating model

   Key Content:
   - Added `b2c2wg-operating-model.md`.
   - Converted boards, bureaus, centers, cells, and working groups into an LLM runtime's board, bureau, center, cell, and working group.
   - The working group produces a decision packet, and the board decides approval, priority, risk acceptance, and FRAGO.

   LLM Application:
   - Controls the structure where multiple agents each report verbosely, via CoS integration and decision packet flow.
   - Connected to event sourcing, defining candidate events such as `WorkingGroupOpened`, `DecisionPacketPrepared`, and `BoardDecisionMade`.

2. CCIR alerting model

   Key Content:
   - Added `ccir-alerting-model.md`.
   - Converted PIR, FFIR, EEFI, and Decision Point into an alert severity and routing matrix.
   - Branches a Red action to an approval request, a scope change to a FRAGO, and source uncertainty to an evidence review.

   LLM Application:
   - The dashboard shows only information that affects commander decisions, not the entire log.
   - Separates "what to report" from "what to merely record."

3. OPSEC classification model

   Key Content:
   - Added `opsec-classification-model.md`.
   - Defined public/internal/sensitive/restricted classification along with an EEFI and context releasability matrix.
   - Organized tool-use OPSEC, evidence store OPSEC, downgrade review, and the dashboard OPSEC panel.

   LLM Application:
   - Context sharing and final output carry need-to-know and releasability criteria.
   - Restricted information such as secrets/tokens/private keys is treated as something to be blocked across output, query, log, and tool target alike.

4. Knowledge management SOP

   Key Content:
   - Added `knowledge-management-sop.md`.
   - Organized README, source-map, compendium, evidence, decision log, event log, runtime payload, and AAR/readiness ledger into a source-of-truth hierarchy.
   - Defined the handoff packet and decision log format.

   LLM Application:
   - Long-running work is carried forward through stored documents and event projections, not chat history.
   - The S6 Knowledge role becomes an operator of the knowledge flow, not just a document writer.

5. Agent METL

   Key Content:
   - Added `agent-metl.md`.
   - Defined mission-essential tasks and evaluation criteria for Commander, CoS, S2, S3, S4, S6, Red Team, and Evaluator.
   - Linked the T/P/U/X readiness rating to Green/Amber/Red/Black authority.

   LLM Application:
   - Agent autonomy is determined by the combination of role/task/tool/target/risk/readiness, not model performance.
   - AAR results can lead to a readiness increase/decrease and to training tasks.

6. Authority matrix schema and fixtures

   Key Content:
   - Added `schema-files/authority-matrix.schema.json`.
   - Added `sample-payloads/valid-authority-matrix.json` and `sample-payloads/invalid-authority-matrix-red-without-approver.json`.
   - Connected the `authority-matrix` type and semantic rule to the validator.

   LLM Application:
   - A Red rule must always have `approval_required` and `approval_authority`.
   - A Black rule must always be `prohibit` and cannot be bypassed by approval.
   - A default allow fails as a broad authority risk.

### 8.40 Decision Packet / Working Group / CCIR Alert / Handoff / Alert Router / Readiness Gate

1. Decision packet schema

   Key Content:
   - Added `schema-files/decision-packet.schema.json`.
   - Fixed as schema the option, recommended option, risk, authority, evidence, deadline, and fallback that go up to the commander board.
   - Connected valid/invalid fixtures and semantic rules.

   LLM Application:
   - The agent produces a decidable packet instead of just saying "please approve" to the user.
   - A decision packet with no options or no evidence fails in the validator.

2. Working group schema

   Key Content:
   - Added `schema-files/working-group.schema.json`.
   - Specifies chair, participants, inputs, deliverables, decision board, trigger, and disband condition.

   LLM Application:
   - Prevents multi-agent discussion from continuing endlessly, and enforces a deliverable and a disbandment condition.

3. CCIR alert and alert router

   Key Content:
   - Added `schema-files/ccir-alert.schema.json`.
   - Added `alert-router-prototype/` to generate Red decision point, Amber FFIR, and Amber PIR alerts from the event log.

   LLM Application:
   - The event log is converted into commander dashboard alerts.
   - A Red/Black alert must carry a required decision and an execution block.

4. Handoff packet schema

   Key Content:
   - Added `schema-files/handoff-packet.schema.json`.
   - Made mandatory the current order, commander intent, completed/in-progress/blocked status, pending decisions, active risks, source-of-truth files, verification status, next actions, and do-not-do.

   LLM Application:
   - Produces a minimum packet that lets the work be picked up during a context transition even without chat history.
   - Fails in the validator if there is a blocked item but no pending decision.

5. Readiness gate prototype

   Key Content:
   - Added `readiness-gate-prototype/`.
   - Combines the authority matrix with role/task readiness to determine allow, report_required, approval_required, or prohibit.

   LLM Application:
   - For the same S3, local validation is allowed at readiness P, while a production deploy requires commander approval.
   - If readiness is insufficient, even an action that is normally Green is escalated to approval_required.

6. Context releasability policy

   Key Content:
   - Added `context-releasability-policy.md`.
   - Defined the raw/summary/redacted/reference_only/denied delivery mode per role.

   LLM Application:
   - Restricts multi-agent context sharing by need-to-know and EEFI criteria.
   - Final output must include only information for which release_to_final is permitted.
   - Later, `role-document-access-policy.md` and `document-access-runner.js` restrict access to the document files themselves, a stage earlier than the context item.

### 8.41 Context Filter / Release Review / Handoff Generator / Maintenance Readiness

1. Context item and release review schema

   Key Content:
   - Added `schema-files/context-item.schema.json` and `schema-files/release-review.schema.json`.
   - A context item has classification, EEFI, allowed roles, release_to_final, and retention.
   - The release review records the delivery mode and redaction per item at final output/external release.

   LLM Application:
   - The validator fails if restricted/EEFI context goes directly into final output.
   - The final answer, too, is subject to a release review from an operational standpoint.

2. Context filter prototype

   Key Content:
   - Added `context-filter-prototype/`.
   - Computes the raw, summary, redacted, reference_only, or denied delivery mode based on role or `FINAL_OUTPUT`.

   LLM Application:
   - S3 may receive internal blocked-deployment context as raw, but EEFI credential context is denied.
   - Red Team receives sensitive architecture only as a summary.

3. Handoff generator

   Key Content:
   - Added `handoff-generator.js`.
   - Combines the event replay projection and alert projection to produce a schema-valid handoff packet.

   LLM Application:
   - At a context transition, current order, commander intent, blocked items, pending decisions, active risks, and source-of-truth files are assembled automatically.

4. Decision packet linter

   Key Content:
   - Added `decision-packet-linter.js` and `run-decision-packet-linter-fixtures.js`.
   - In addition to the validator's schema/semantic check, checks the number of options, the benefit/risk/tradeoff per option, and the default action.

   LLM Application:
   - Confirms, via a separate gate, that a packet going up to the commander has the minimum quality needed to be decidable.

5. Working group event fixtures

   Key Content:
   - Added `event-fixtures/working-group-event-fixtures.json` and `event-replay-prototype/run-working-group-fixtures.js`.
   - Verifies the lifecycle: WG opened -> decision packet prepared -> board decision made -> WG closed.

   LLM Application:
   - B2C2WG moves beyond a documented concept into an event-sourced workflow.

6. Maintenance readiness model

   Key Content:
   - Added `maintenance-readiness-model.md`.
   - Converted sustainment/maintenance into tool readiness, resource readiness, context freshness, verification, and fallback.

   LLM Application:
   - Even if an agent is capable, its execution authority is limited if tool/resource/context/fallback is insufficient.
   - S4/S6 is responsible for runtime sustainment and the maintenance report.

### 8.42 Maintenance Runner / Release Runner / Approval Scope / Risk Acceptance / Source Coverage

1. Maintenance readiness schema and runner

   Key Content:
   - Added `schema-files/maintenance-readiness.schema.json`.
   - `maintenance-readiness-runner.js` runs the validator, policy, runtime, event replay, alert router, and context filter runners to produce a readiness report.

   LLM Application:
   - Tool/resource/context/fallback readiness has been raised as a pre-execution gate.
   - A critical runner failure is an S4/S6 maintenance issue and a candidate FFIR/CCIR.

2. Release review runner

   Key Content:
   - Added `release-review-runner.js` and `run-release-review-fixtures.js`.
   - Compares the context filter output with the release review document and fails if the review is more permissive than the filter.

   LLM Application:
   - Final output, too, must pass the release gate.
   - EEFI/restricted context is blocked at both the filter and the review.

3. Working group dashboard projection

   Key Content:
   - Added `dashboard-ui-prototype/working-group-projection-dashboard-state.json`.
   - Verified that the working group event fixture projection matches the dashboard state.

   LLM Application:
   - The B2C2WG lifecycle can be converted into command post UI state.

4. Approval scope and risk acceptance documents

   Key Content:
   - Added `approval-scope-policy.md` and `risk-acceptance-authority.md`.
   - Organized approval once, expiry, rollback, evidence, release review separation, residual risk, and commander-retained authority.

   LLM Application:
   - Separated "approval" from "risk acceptance."
   - Red action approval is a scoped release, not blanket permission.

5. Approval scope and risk acceptance schemas

   Key Content:
   - Added `schema-files/approval-scope.schema.json`.
   - Added `schema-files/risk-acceptance.schema.json`.
   - Added valid/invalid fixtures and used validator semantic rules to verify expiry, rollback, evidence, and commander-retained authority.

   LLM Application:
   - A Red action is not unlocked by a mere "approval request."
   - The scoped approval must be active, single-use, and matched on target/action/tool/time.
   - High/critical/irreversible residual risk must be accepted by the Commander.

6. Policy authority integration prototype

   Key Content:
   - Added `policy-engine-authority-integration.js`.
   - Composes the policy engine, authority matrix/readiness, scoped approval, and risk acceptance.
   - `run-authority-integration-fixtures.js` verifies an approved Red deployment, reuse of a consumed approval, and missing risk acceptance.

   LLM Application:
   - A Red action is blocked under policy, but changes to `allow_scoped_execution` only when both the exact approval scope and risk acceptance are valid.
   - A consumed approval cannot be reused.
   - A high-risk action with approval but no risk acceptance remains blocked.

7. Approval consumption event

   Key Content:
   - Added `schema-files/approval-consumption-event.schema.json`.
   - Added `approval-consumption-runner.js` and `run-approval-consumption-fixtures.js`.
   - Separated approval granted from actual execution, and defined an audit event that converts the approval to consumed at the moment of execution.

   LLM Application:
   - It's not enough to check that the approval scope is active; the actual execution event must be verified against mission/action/tool/target/time/evidence.
   - A target mismatch is not recognized as approval consumption.
   - An already-consumed approval cannot be consumed by a second execution event.
   - Preventing approval reuse is part of the event-sourcing audit trail, not a single policy check.

8. Approval revocation event

   Key Content:
   - Added `schema-files/approval-revocation-event.schema.json`.
   - Added `approval-revocation-runner.js` and `run-approval-revocation-fixtures.js`.
   - Only an active approval can be revoked; a consumed approval cannot be handled as a post-hoc revocation.

   LLM Application:
   - Revoking approval, too, must match on action/tool/target/time/authority/evidence.
   - The revoking authority must match the authority that granted the approval.
   - A revocation requiring notification leaves a notified role to reduce distortion in the chain of transmission.
   - An already-executed action must be handled through rollback, FRAGO, and AAR, not revocation.

9. Approval renewal event

   Key Content:
   - Added `schema-files/approval-renewal-event.schema.json`.
   - Added `approval-renewal-runner.js` and `run-approval-renewal-fixtures.js`.
   - Only extends the validity period of an active approval; expanding target/action/tool/max execution requires a new approval.

   LLM Application:
   - Even a "just a little more time" request is recorded as an append-only event rather than directly modifying the existing approval object.
   - Renewal is only possible before the existing expiry.
   - An `approve_once` that has already expired or already been used requires a new approval or a FRAGO, not a renewal.
   - Renewal is not a means of broadening the scope of authority.

10. Approval delegation event

   Key Content:
   - Added `schema-files/approval-delegation-event.schema.json`.
   - Added `approval-delegation-runner.js` and `run-approval-delegation-fixtures.js`.
   - Made delegation of approval authority valid only within the existing approval-required rules of the authority matrix.

   LLM Application:
   - Rather than asking the user or Commander for every approval, Amber-level recurring sustainment approval can be delegated in a limited way to, e.g., the CoS.
   - Delegation cannot include Red/Black, high/critical residual risk, restricted release, or subdelegation.
   - Self-approval, where a delegatee approves their own role, is also prohibited.
   - Delegation, too, must leave reason, evidence, notification, backbrief, and post-action evidence.

11. Approval delegation revocation/expiry event

   Key Content:
   - Added `schema-files/approval-delegation-revocation-event.schema.json`.
   - Added `approval-delegation-revocation-runner.js` and `run-approval-delegation-revocation-fixtures.js`.
   - Delegated approval authority must be closed with a `revoked` or `expired` event, and the original delegation snapshot must be preserved.

   LLM Application:
   - A creation event alone is not enough for authority delegation. Without a termination event, a subordinate agent may mistake a past delegation for still-valid authority.
   - Commander revocation must be performed by the Commander within the active window.
   - The expiry projection can be recorded after expiry by the `RECORDER` or a termination authority.
   - The termination event checks task/action/tool/target/risk/time limit/retained authority/context guardrail against the original delegation.
   - Prevents a staff role from arbitrarily revoking delegated authority or marking it expired before its actual expiry.

12. Policy release integration

   Key Content:
   - Added `policy-engine-release-integration.js`.
   - Added `run-release-integration-fixtures.js` and `release-integration-fixtures/`.
   - Blocks final/external output if the release review is missing or fails, even when the authority gate allows execution.

   LLM Application:
   - "Approval to execute a tool" is not "approval to disclose information."
   - Red execution requires scoped approval and risk acceptance, and release-required output requires a separate release review.
   - A valid release review cannot bypass missing risk acceptance.
   - An invalid release review halts final output as `blocked_pending_release_review` even if approval already exists.

13. Authority delegation dashboard projection

   Key Content:
   - Added `authority-delegation-projection-runner.js`.
   - Added `run-authority-delegation-projection-fixtures.js` and `authority-delegation-projection-fixtures/`.
   - Stored the active/revoked/expired delegation projection in `dashboard-ui-prototype/authority-delegation-projection-state.json`.

   LLM Application:
   - Authority delegation must be surfaced as a dashboard projection, since an operator may miss it if it exists only in the event log.
   - Separates active, revoked, and expired states to prevent reuse of expired/revoked authority.
   - Leaves the termination actor and reason in the dashboard row to enable after-the-fact tracing and AAR.

14. Release gate decision event

   Key Content:
   - Added `schema-files/release-gate-decision-event.schema.json`.
   - Added `release-gate-decision-runner.js` and `run-release-gate-decision-fixtures.js`.
   - Verifies that the release integration result matches the final decision/snapshot/evidence recorded in the event log.

   LLM Application:
   - The gate computation result must not exist only in conversational memory; it must be recorded as an append-only event.
   - Blocks a case where the release review is missing or failed but the event claims `allow_scoped_execution_and_release`.
   - Even a valid release review cannot bypass missing risk acceptance.
   - Records the final decision, authority snapshot, release review snapshot, reasons, and evidence together.

15. Release gate dashboard projection

   Key Content:
   - Added `release-gate-dashboard-runner.js`.
   - Added `run-release-gate-dashboard-fixtures.js` and `release-gate-dashboard-fixtures/`.
   - Stored the released, release-review-blocked, and authority-blocked projections in `dashboard-ui-prototype/release-gate-dashboard-state.json`.

   LLM Application:
   - The final/external output gate must be surfaced on the operator dashboard, not just the event log.
   - Separates the state where authority allowed but there is no release review from the state where the release review passed but authority blocked it.
   - Shows "why it was blocked" together with reasons/evidence so the next decision-maker can act immediately.

16. Maintenance readiness dashboard projection

   Key Content:
   - Added `maintenance-dashboard-runner.js`.
   - Added `run-maintenance-dashboard-fixtures.js` and `maintenance-dashboard-fixtures/`.
   - Stored the ready/degraded/down sustainment projection in `dashboard-ui-prototype/maintenance-readiness-dashboard-state.json`.

   LLM Application:
   - Tool/resource/context readiness must be surfaced in a dashboard queue, since it may be missed by an executor if it exists only in a document or report.
   - Separates degraded assets from unavailable assets, handling restricted operation and blocked status differently.
   - Preserves the commander decision flag in the projection so that states such as resource Red, no fallback, or blocked execution connect immediately to a decision point.

17. Source-map linter

   Key Content:
   - Added `source-map-linter.js`.
   - Checks whether official source domains in the docs have coverage in the source-map.
   - Stored a per-host coverage snapshot in `source-map-url-coverage-report.json`.

   LLM Application:
   - Automatically monitors for the problem of a new official source entering the compendium while being missing from the source-map.
   - Source coverage is left as an artifact rather than existing only in an execution log, so the next worker can audit it.

18. AAR readiness update

   Key Content:
   - Added `aar-to-readiness-update.js`.
   - Added `schema-files/aar-readiness-update.schema.json`.
   - Added `run-aar-readiness-update-fixtures.js` and `aar-readiness-update-fixtures/`.
   - Converts an AAR's delta, cause, improve, and SOP update into a readiness recommendation, maintenance action, and CCIR trigger.

   LLM Application:
   - The AAR is an event input that changes future authority/training/maintenance status, not a retrospective document.
   - A critical source failure or hallucination signal is connected to a Red Team downgrade/hold and a commander review.
   - A sustain-only AAR becomes a candidate for increased autonomy, while an AAR with remaining improvements is left on hold/train.

19. OPORD annex and FRAGO scope-change schemas

   Key Content:
   - Added `schema-files/annex.schema.json`.
   - Added `schema-files/frago-scope-change.schema.json`.
   - Blocks, via semantic validation, an annex quietly changing OPORD intent or an authority boundary.
   - Expresses mission scope or authority boundary changes as a FRAGO scope-change including affected roles, backbrief, rehearsal, and the annex boundary reason.

   LLM Application:
   - Separating the details of a specialized plan from a change to commander intent is necessary to prevent distortion in the chain of transmission.
   - Prevents the phrase "I updated the annex" from changing mission purpose, task priority, or approval boundary.
   - A scope-changing FRAGO must be redelivered to the affected role and go through a backbrief and rehearsal before it is executable.

20. Rehearsal to CCIR router

   Key Content:
   - Added `rehearsal-to-ccir-router.js`.
   - Added `run-rehearsal-to-ccir-fixtures.js` and `rehearsal-to-ccir-fixtures/`.
   - Converts rehearsal friction points and decision points into CCIR alerts and decision packets.

   LLM Application:
   - Friction found in rehearsal must be surfaced to the commander-facing queue before execution.
   - Medium friction is tracked as an FFIR/Amber alert; high/critical friction is escalated into a blocked decision alert and a decision packet.
   - Credential/restricted-related friction is handled as an EEFI/Black alert, blocking execution and release.

21. AI special operations task force

   Key Content:
   - Added `ai-special-operations-tf.md`.
   - Added `schema-files/sof-tf-charter.schema.json`.
   - Added `sof-tf-activation-runner.js`, `run-sof-tf-fixtures.js`, and `sof-tf-fixtures/`.
   - Referenced JP 3-05, FM 3-05, USSOCOM SOF Truths, USSOCOM core activities, and the official USASOC page.
   - Converted the SOF Truths into AI operating principles: people/intent/approval matter more than the model, a small number of vetted agents is better than many agents, and a highly skilled workflow cannot be created ad hoc after an emergency begins.
   - Defined the AI SOF TF structure as Commander, TF Lead/CoS, S2 Recon, S3 Execution, S4/S6 Enabler, OPSEC/Release, Red Team, and Recorder/KM.
   - The charter validator verifies trigger, commander-retained authority, independent Red Team/release review, source-map, release review, fallback, backbrief, rehearsal, dry run, and abort/handoff criteria.

   LLM Application:
   - A high-risk/high-uncertainty mission needs a smaller team, stronger control, better enablers, and a faster decision loop, not more autonomy.
   - Converts not actual military operational tactics but agent selection, readiness, need-to-know context, OPORD/annex, rehearsal, CCIR, and AAR/readiness update.
   - SOF core activity names are used only as safe metaphors for AI operation, with deception/unauthorized access/harmful instruction kept as a Black prohibition line.
   - The activation runner projects the SOF TF charter into `go/no_go`, approval gates, context distribution, required support, preflight blocks, and a commander queue.

22. Information to operations cycle

   Key Content:
   - Added `information-to-operations-cycle.md`.
   - Connected JP 2-0, ADP 2-0, ATP 2-01.3, ADP 5-0, FM 5-0, and the JCS CCIR Focus Paper as the basis for information processing/operational change.
   - Separated raw information, information report, intelligence assessment, running estimate, CCIR, decision packet, SITREP, and FRAGO scope-change.
   - Added `schema-files/information-report.schema.json` and `schema-files/intelligence-assessment.schema.json`.
   - Added `information-to-operations-router.js` and `run-information-to-operations-fixtures.js`.

   LLM Application:
   - New information does not immediately change the prompt/order. It is first evaluated for source reliability, confidence, CCIR relevance, EEFI risk, and operational impact.
   - Order-changing information cannot become a FRAGO without a CCIR alert and a commander decision packet.
   - Low-confidence information is left as a PIR/running estimate or a source review, not a FRAGO scope-change.
   - EEFI or credential-like raw values are not repeated in output even after release-block routing.

23. Personnel continuity and succession

   Key Content:
   - Added `personnel-continuity-model.md`.
   - Connected FM 6-0, ADP 6-0, the Federal Continuity Directive planning framework, the KM primer, and ADP 7-0.
   - Organized the reasons the military withstands personnel loss and rotation into duty-position priority, 2-deep succession, bounded authority, vital records, battle handover, readiness gate, and degraded mode.
   - Added `schema-files/continuity-plan.schema.json`.
   - Added `continuity-drill-runner.js`, `run-continuity-drill-fixtures.js`, and `continuity-drill-fixtures/`.

   LLM Application:
   - An agent instance is expendable. The source of truth resides in role, order, authority, event log, handoff, and readiness ledger.
   - Even if a Commander or S6 disappears, the successor chain activates, but Red approval, risk acceptance, release target expansion, and FRAGO scope change do not automatically pass to the successor.
   - Role rotation requires overlap, a handoff packet, an incoming backbrief, and a focused rehearsal.
   - A continuity drill flags a single-point-of-failure successor, an essential function with no handoff, missing vital records, and the absence of a degraded mode as failures.

24. Interdepartment collaboration and branch integration

   Key Content:
   - Added `interdepartment-collaboration-policy.md`.
   - Connected ADP 3-0, FM 3-0, JP 3-0, FM 6-0, the JTF HQ organization focus paper, and the JTF command and control focus paper as the basis for branch/function integration.
   - Converted the military's combined arms, warfighting functions, joint functions, supported/supporting relationship, liaison, battle rhythm, and deconfliction into AI department collaboration policy.
   - Added `schema-files/department-collaboration-charter.schema.json`.
   - Added `department-collaboration-runner.js`, `run-department-collaboration-fixtures.js`, and `department-collaboration-fixtures/`.

   LLM Application:
   - Department collaboration is not parallel work. Each relationship must have a supported department, supporting department, required output, quality gate, handoff interface, and escalation trigger.
   - Every blocking dependency must have a liaison rule, and the liaison is not a decision-maker but is responsible for meaning translation and conflict routing.
   - When a cross-department conflict touches source validity, release target, authority boundary, high risk, or scope, a decision packet and a Commander/CoS route are needed.
   - The collaboration runner projects the charter into relationship edges, missing liaisons, unknown dependencies, a commander queue, and a preflight block.

25. Force structure change and force management

   Key Content:
   - Added `force-structure-change-policy.md`.
   - Connected AR 71-32, DA PAM 71-32, the Army Force Management School digital library, the How the Army Runs reference material, and Force Management Functional Area materials as the basis for creating, disestablishing, expanding, or reducing branches/units.
   - Organized the military's force management into capability requirement, DOTMLPF-P alternatives, force development, force documentation, affordability/supportability, readiness, and lifecycle review.
   - Added `schema-files/force-structure-change-order.schema.json`.
   - Added `force-structure-change-runner.js`, `run-force-structure-change-fixtures.js`, and `force-structure-change-fixtures/`.

   LLM Application:
   - A new agent, department, unit, TF, runner, or dashboard panel is not created out of naming convenience. Evidence is required that the capability gap cannot be resolved by adjusting an existing SOP/schema/training/tool.
   - A router-detected gap is never treated as permission to continue as unowned general work. The mission immediately receives one deterministic provisional capability cell for bounded analysis and drafting, while a paired standing-department candidate enters the force-structure review path.
   - The provisional cell inherits the requesting agent's existing authority and expires with the mission. It cannot activate a standing department or expand authority; those actions require a validated `ForceStructureChangeOrder` and the human USER's decision.
   - Creating or expanding an organization requires Commander approval, retained release/risk/scope authority, a maintainer, validation fixtures, readiness evidence, a source-of-truth, and a sunset condition.
   - Disestablishing or reducing an organization is not complete without function transfer, handoff, data migration, authority withdrawal, documentation update, and an AAR/readiness update.
   - The force structure runner projects an order into a preflight block, commander queue, transition task, documentation queue, readiness requirement, and sunset watch.

26. Role document access and reading discipline

   Key Content:
   - Added `role-document-access-policy.md`.
   - Defined a need-to-know matrix that restricts which documents each agent may read by role, duty, and authority level.
   - Added `schema-files/document-access-manifest.schema.json`.
   - Added `document-access-runner.js`, `run-document-access-fixtures.js`, and `document-access-fixtures/`.
   - The valid fixture verifies that S2, Executor, and S6 each receive only the documents needed for their own duty.
   - The invalid fixture blocks bulk read, wildcard path, missing allowed role/duty, restricted raw, required-but-denied, and self escalation.

   LLM Application:
   - Instead of giving every agent the entire repository context, a per-mission `DocumentAccessManifest` is generated first.
   - S2 reads source/evidence documents, Executor reads only implementation/tool/schema documents, and Commander-only risk documents remain as summary or denied.
   - The document access runner checks role/duty/authority against the manifest to project allowed documents, denied documents, required documents, and audit requirements.
   - This gate sits ahead of `context-filter-prototype`. An agent that cannot open a file also cannot create a context item from that file.

### 8.47 Orders Production / Backbrief / Rehearsal Gate

1. Orders production pipeline

   Key Content:
   - Rather than turning a user request directly into an execution prompt, it is converted in the order mission analysis, OPORD, task order, backbrief, rehearsal, execution, SITREP, FRAGO, AAR.
   - Distortion in the chain of transmission is not reduced merely by "writing the order in more detail." It is reduced when the subordinate executor restates the intent, task, stop condition, and approval boundary.
   - Execution sequence and friction points must be caught during rehearsal.

   LLM Application:
   - Long-running tasks follow the state machine in `orders-production-pipeline.md`.
   - The `ordered -> acknowledged -> rehearsed -> executing` transition is made into a runtime gate.
   - `orders-dissemination-runner.js` verifies the connectivity of the OPORD, task order, backbrief, and rehearsal.

2. OPORD annex model

   Key Content:
   - The OPORD body is the command contract, and the annex is the specialized detailed plan.
   - Putting all detailed plans such as source/tool/risk/verification/context/sustainment into the body blurs the intent.
   - An annex must have a parent order and an owner, and an intent change is handled via a FRAGO, not an annex.

   LLM Application:
   - Defined the Source Plan, Tool/ROE Plan, Sustainment Plan, OPSEC/Releasability, Risk/Red Team, Assessment, and Handoff/Audit annexes.
   - Connected to the context releasability policy so that not every agent receives every annex as raw.

3. Backbrief schema

   Key Content:
   - The task owner restates commander intent, assigned task, purpose, end state, constraints, planned actions, risk controls, stop conditions, and approval/prohibited actions.
   - A backbrief without a stop condition must not be allowed to proceed to execution.

   LLM Application:
   - Added `schema-files/backbrief.schema.json`.
   - Added `sample-payloads/valid-backbrief.json` and `sample-payloads/invalid-backbrief-no-stop-conditions.json`.
   - The validator semantic rule catches `BACKBRIEF_WITHOUT_ACTIONS`, `BACKBRIEF_WITHOUT_STOP_CONDITIONS`, and `LOW_CONFIDENCE_WITHOUT_CLARIFICATION`.

4. Rehearsal schema

   Key Content:
   - The rehearsal records the execution sequence, expected result, evidence, friction point, decision point, required changes, and disposition.
   - If a required change remains but an execute disposition is issued, distortion in the chain of transmission turns into an execution error.

   LLM Application:
   - Added `schema-files/rehearsal.schema.json`.
   - Added `sample-payloads/valid-rehearsal.json` and `sample-payloads/invalid-rehearsal-execute-with-unresolved-change.json`.
   - The validator semantic rule catches `REHEARSAL_WITHOUT_SEQUENCE`, `EXECUTE_WITH_UNRESOLVED_CHANGES`, and `HIGH_FRICTION_WITHOUT_DECISION_POINT`.

5. Runtime demo integration

   Key Content:
   - Task `T-DEMO-001` of the demo OPORD connects to `runtime-demo-payloads/backbrief.json` and `runtime-demo-payloads/rehearsal.json`.
   - The runtime demo now has the flow mission -> OPORD -> task order -> backbrief -> rehearsal -> tool/policy -> SITREP/evidence/AAR.

   LLM Application:
   - `runtime-demo-runner.js` includes backbrief and rehearsal validation.
   - `orders-dissemination-runner.js` verifies the intent/task/actor/approval boundary connections.

### 8.48 Mission-Based Model Force Assignment

1. Routing, cascades, and economy of force

   Sources:
   - RouteLLM: https://arxiv.org/abs/2406.18665
   - FrugalGPT: https://arxiv.org/abs/2305.05176
   - Language Model Cascades: https://proceedings.iclr.cc/paper_files/paper/2024/file/11f5520daf9132775e8604e89f53925a-Paper-Conference.pdf
   - RouterBench: https://arxiv.org/abs/2403.12031

   Key Content:
   - Strong/weak model routing and cascades can reduce inference cost while preserving task quality, but gains depend on task distribution, routing data, and evaluator accuracy.
   - Models occupy different quality, cost, latency, and task-specialization positions; a single model is not uniformly optimal.
   - RouterBench reports that cascade performance degrades quickly when the judge or router error becomes material. The router therefore cannot be treated as an invisible utility.

   LLM Application:
   - Use C1 line profiles for eligible routine, reversible, validated work; escalate to C2 specialists or C3 command integration only on explicit mission or verification triggers.
   - Do not apply start-low routing to Red, sensitive, novel, irreversible, or final-release work. Those missions receive the required mixed force at assignment time.
   - Give the router an immutable profile, T/P readiness, held-out evaluation evidence, retry ceiling, and acceptance evidence independent of verbal confidence.

2. Task-specific readiness and operational evaluation

   Sources:
   - HELM: https://crfm.stanford.edu/2022/11/17/helm.html
   - Berkeley Function-Calling Leaderboard: https://gorilla.cs.berkeley.edu/leaderboard
   - tau-bench: https://arxiv.org/abs/2406.12045
   - NIST AI RMF Core: https://airc.nist.gov/airmf-resources/airmf/5-sec-core/
   - NIST AI RMF Generative AI Profile: https://doi.org/10.6028/NIST.AI.600-1

   Key Content:
   - Broad language benchmarks do not establish readiness for a local mission, tool schema, policy environment, or context boundary.
   - HELM emphasizes broad scenario and metric coverage; BFCL isolates function-calling behavior; tau-bench evaluates tool-agent-policy interaction and repeated-run consistency.
   - NIST AI RMF calls for documented knowledge limits, predeployment and ongoing TEVV, representative conditions, risk-proportionate review, and independent assessment.

   LLM Application:
   - Record readiness as `model profile x task x tool set x context class x harness x environment`.
   - A model version, system prompt, tool schema, harness, or material environment change creates a new evaluation subject.
   - Specialist branches are selected by local METL evidence, not model size. A narrow C1 profile may outrank a C3 general profile for its evaluated task.
   - Evaluate task success, policy compliance, tool-call correctness, source fidelity, calibration, robustness, consistency, latency, throughput, cost, and data-boundary eligibility.

3. Assurance independence and uncertainty

   Sources:
   - Judging LLM-as-a-Judge: https://arxiv.org/abs/2306.05685
   - Confident or Seek Stronger: https://arxiv.org/abs/2502.04428

   Key Content:
   - LLM judges can exhibit position, verbosity, and self-enhancement biases; reference-guided evaluation can reduce but not remove these risks.
   - Verbal confidence does not reliably equal correctness. Confidence-based routing requires task-level calibration and still needs external evidence.

   LLM Application:
   - Independent assurance is a distinct force class. Use a different model family from the primary executor where feasible and label same-family review as correlated.
   - Assurance receives intent, output, evidence, tests, and policy constraints, but it cannot execute remediation or approve its own finding.
   - Deterministic schema, policy, test, source, and release checks remain primary evidence. A model's statement that it is confident is neither acceptance evidence nor an authority grant.

4. Military organizational synthesis and implemented contract

   Military anchors:
   - ADP 6-0 and FM 6-0 for mission command, staff integration, and retained authority.
   - ADP 7-0 for METL-based training and readiness.
   - AR 71-32 for capability-based force management and documentation.
   - USSOCOM SOF Truths for selected personnel, readiness, enablers, and sustainable special operations capacity.

   Implemented conclusion:
   - Separate model capability bands C0-C3 from force classes: utility, line, specialist, command, SOF, assurance, and reserve.
   - Capability never creates authority. Role authority remains in the mission and authority contracts, and the human user retains final decisions.
   - High-impact missions require command/SOF integration, independent assurance, and distinct primary/alternate/contingency profiles. Emergency action stops execution and hands preserved state to the human Commander.
   - Added `model-force-assignment-policy.md`, `schema-files/model-force-assignment-plan.schema.json`, `model-force-assignment-runner.js`, `run-model-force-assignment-fixtures.js`, and valid/invalid sample plans.
   - The invalid fixture blocks floating model aliases, missing evidence, unready routing, out-of-METL tasks, context-ineligible profiles, confidence-only acceptance, correlated assurance, model monoculture, collapsed PACE, and authority inherited from model capability.

### 8.49 Model Force v0.2 Operationalization

1. Registry and demand separation

   Implemented conclusion:
   - A static assignment plan is insufficient as the source of truth because it can embed model claims without proving where readiness, identity, and availability came from.
   - `ModelRegistry` now owns immutable model/harness/prompt/tool identity, deployment and context eligibility, per-task readiness evidence, expiry, cost, latency, and availability.
   - `ModelAssignmentRequest` owns the mission's billet demand, force class, task, tool impact, authority scope, fallback depth, assurance, and optimization weights.
   - Registry governance retains human final decision authority and prohibits floating versions and secret-bearing endpoint references.

2. Hard filtering before optimization

   Implemented conclusion:
   - Deployment, context, task, tool-impact, readiness, evidence, expiry, availability, load, and family-separation requirements are eligibility gates rather than score components.
   - Cost and latency are optimized only among eligible profiles. They cannot compensate for a policy, evidence, or readiness failure.
   - Deterministic tie-breaking makes identical registry/request inputs reproducible.
   - The compiler materializes the existing v0.1 `ModelForceAssignmentPlan`, preserving its stable projection and safety checks.

3. Integrated routing and dispatch gate

   Implemented conclusion:
   - Model selection alone does not authorize an agent to work. Every dispatched agent must be bound to one current-wave accepted routing receipt and one compiled dispatch-required billet.
   - `integrated-mission-preflight-runner.js` combines routing receipt validation, model compilation, v0.1 plan projection, identity verification, and one-to-one binding checks.
   - A blocked projection emits no dispatch rows. A ready projection contains endpoint references, immutable identity, role, authority/tool/context scope, fallbacks, and routed documents.
   - Model capability remains separate from agent identity, role authority, release approval, and human risk acceptance.

4. Operational evidence and reassessment

   Implemented conclusion:
   - `ModelUsageEvent` records the immutable model identity, authority snapshot, release target, outcome, cost, latency, evidence, fallback/escalation, failure code, and transition.
   - Telemetry does not self-promote readiness. AAR and controlled readiness updates remain the path for changing T/P/U/X status.
   - Material model, prompt, harness, tool schema, environment, or policy changes require reevaluation.
   - Added `model-force-v0.2-operations.md`, four v0.2 schemas, `model-assignment-compiler.js`, `integrated-mission-preflight-runner.js`, `run-model-force-v0.2-fixtures.js`, and valid/invalid samples.

### 8.50 Repository-Scoped Artifact Isolation

1. Repository identity as the custody boundary

   Implemented conclusion:
   - A mission ID or agent ID is not sufficient to separate outputs when one campaign operates on several repositories.
   - Durable artifacts require a target Git repository identity before they are written.
   - The implementation derives an opaque fingerprint from normalized origin metadata plus the real Git root. Separate clones/worktrees of the same origin remain separate; remote URLs, credentials, and absolute roots are not stored in manifests.

2. Repository, mission, wave, and kind hierarchy

   Implemented conclusion:
   - The storage hierarchy is `repository -> mission -> wave -> kind -> artifact`, so repeated mission/wave/artifact IDs in different repositories cannot collide.
   - A per-repository manifest records relative path, content type, byte size, hash, Git head, and timestamps.
   - Subdirectories remain in the parent Git repository namespace; nested Git roots receive independent identities.

3. Fail-closed persistence

   Implemented conclusion:
   - Path traversal, absolute artifact paths, symlink source files, cross-repository manifest paths, and identity mismatch are blocked.
   - Identical repeated writes are idempotent. Different content at an existing path fails unless overwrite is explicit.
   - Per-repository cross-process locking serializes artifact and manifest mutation. Lock acquisition is finite; only a dead same-host stale lock is recovered, while active and foreign-host locks fail closed.
   - Every committed manifest mutation advances a monotonic revision, preventing concurrent last-writer loss from remaining invisible.
   - Integrated mission preflight clears dispatch outputs and changes to blocked when requested artifact persistence fails.
   - Routing receipts redact local repository and artifact-root paths from recorded command evidence.

4. Implemented surface

   Implemented conclusion:
   - Added `repository-artifact-isolation-policy.md`, `repository-artifact-store.js`, `schema-files/repository-artifact-manifest.schema.json`, valid/invalid manifest samples, semantic validator rules, `run-repository-artifact-isolation-fixtures.js`, and `run-repository-artifact-concurrency-fixtures.js`.
   - The store handles structured JSON projections and general file deliverables such as Markdown, PDF, and images.
   - The isolation fixture creates two Git repositories and proves same mission/wave/artifact IDs produce separate namespaces and manifests.
   - The concurrency fixture launches 24 writers and verifies full retention, monotonic revisions, stale local recovery, and active/foreign lock refusal.

### 8.51 Bounded Self-Improvement Control Plane

1. Self-improvement as a finite campaign

   Implemented conclusion:
   - An agent must not interpret "improve yourself" as permission to choose new goals, expand authority, approve its own evidence, or continue indefinitely.
   - Adaptation is represented as a finite campaign bound to one mission, repository identity, objective, acceptance set, authority envelope, quality model, budget, and stop conditions.
   - The human user remains final decision authority. Every controller decision explicitly keeps release authorization false.

2. Improvement of work already in progress

   Implemented conclusion:
   - Active drafts and implementations can be improved without restarting the mission when each candidate is compared with an accepted baseline.
   - A candidate advances only when deterministic or independent evidence passes hard gates, the weighted normalized score meets the quality floor, and the score improves by the declared minimum.
   - Cycle 1 is pinned to the campaign baseline revision, and every follow-on checkpoint names the accepted parent decision so a rejected candidate cannot become a hidden baseline.
   - Insufficient gain routes to revision. Failed validation or hard gates route to rollback of the campaign's own uncommitted candidate. Repeated no-progress and exhausted budgets route to human review.

3. Control-plane self-modification

   Implemented conclusion:
   - Procedures, runtime controls, and skills may be changed as isolated candidates, but require independent evaluation before becoming a working state.
   - Policy and authority effects require USER approval scoped to the exact candidate.
   - Destructive and cross-repository self-modification terminate autonomous execution rather than creating an approval path.

4. Mandatory completion checkpoint

   Implemented conclusion:
   - A normal wave-end cannot declare the campaign complete.
   - Completion requires a distinct `before_completion` checkpoint with no open acceptance criteria, all hard gates passing, the weighted quality floor met, and repository-scoped evidence.
   - Completion freezes a working state for the human merge/release decision; it does not merge, push, or release.

5. Implemented surface

   Implemented conclusion:
   - Added `bounded-self-improvement-operations.md`, three schemas, valid/invalid samples, semantic validator rules, `self-improvement-campaign-init.js`, `autonomous-improvement-controller.js`, and `run-self-improvement-fixtures.js`.
   - The fixture suite covers accepted work improvement, insufficient gain, validation rollback, policy escalation, destructive termination, completion, repository drift, no-progress budgets, independent review, permission drift, and repository-scoped checkpoint/decision persistence.
   - This v0.1 conclusion was superseded by the proof-carrying v0.2 controls in section 8.52.

### 8.52 Proof-Carrying Self-Improvement v0.2

1. Execute evidence instead of trusting evidence claims

   Implemented conclusion:
   - A checkpoint must not decide that its own test claim is true. A separate runner executes an exact executable/argument array with `shell: false`, finite timeout, bounded output, and repository-relative working directory.
   - The verification plan is bound to campaign, mission, cycle, candidate, repository identity, Git head, and worktree fingerprint. A stale plan is rejected before execution.
   - The receipt records resolved executable hash, exact argv, exit code, signal, duration, stdout/stderr size and SHA-256, bounded excerpts, runtime environment hash, and repository state before/after.
   - Repository mutation during verification fails the receipt. Metrics and independent evaluations must cite verified receipt IDs rather than prose evidence.

2. Prove accepted lineage

   Implemented conclusion:
   - A follow-on checkpoint supplies a manifest-backed parent decision reference, not only an ID string.
   - The controller reloads and validates the parent, requires the immediately prior cycle and `accept_working_state`, and matches the parent's `accepted_revision` to the next baseline.
   - Missing, forged, rejected, or baseline-mismatched parents block continuation.

3. Consume retained approval exactly

   Implemented conclusion:
   - Policy, authority, scope, and release-affecting candidates cannot rely on `USER approved` text.
   - The checkpoint references a repository-stored `ApprovalScope` and `ApprovalConsumptionEvent`. The controller validates both schemas and checks mission, actor, action, tool, candidate target, validity window, execution count, executed result, consumed status, and checkpoint-specific execution ID.
   - A consumption event cannot be reused for another checkpoint. Working-state acceptance still does not authorize merge, push, or release.

4. Recover and verify artifact custody

   Implemented conclusion:
   - Repository manifests advanced to v0.3. Each mutation writes a journal before artifact bytes, then commits an immutable manifest-history entry, current manifest, and SHA-256 sidecar.
   - Recovery under the namespace lock reconciles `artifact_written` and `manifest_committed` interruptions idempotently. Unexpected bytes or divergent manifest heads fail closed.
   - The verifier checks pending journals, repository identity, canonical manifest digest, sidecar, contiguous retained history, previous-digest links, artifact path/type/size/hash, and orphan files.
   - SHA-256 history is tamper-evident local custody, not an external signature or trusted execution environment.

5. Implemented surface

   Implemented conclusion:
   - Added `verification-runner.js`, two proof schemas, valid/invalid samples, semantic rules, manifest-backed proof loading, consumed approval binding, exact parent verification, and decision proof summaries.
   - Added `repository-artifact-verify.js` and `run-repository-artifact-recovery-fixtures.js`; expanded self-improvement fixtures to execute real commands and reload proof artifacts.
   - Updated both AI CLI skills to make proof issuance, artifact verification, approval consumption, and parent lineage mandatory operating steps.

### 8.53 Signed Quorum and Fenced Persistence v0.3

Research question:

> How can an adaptive AI runtime distinguish independently executed proof from locally rewritten evidence, and how can several writers coordinate without allowing an expired writer to overwrite a newer state?

Primary references:

- RFC 8032 defines Ed25519 signing and verification.
- DSSE defines a pre-authentication encoding that signs both payload type and exact payload bytes.
- The in-toto Attestation Framework separates subject digest, statement, predicate, and authentication envelope.
- etcd's lease and transaction model demonstrates that ownership expiry and compare-and-swap revision control are separate requirements.

Engineering conclusions:

1. A receipt hash proves content consistency but not who vouched for it. v0.3 therefore keeps the executable receipt and adds an Ed25519 DSSE attestation from a verifier listed in a hash-bound trust policy.
2. One signature is not independence. Promotion requires distinct verifier IDs, distinct public-key IDs, and a minimum number of declared independence groups. Repeating one attestation or assigning one key to several names does not count.
3. The signed subject is the persisted receipt SHA-256, not an informal test label. The predicate repeats the campaign, mission, cycle, candidate revision, repository identity, verifier invocation, origin, nonce, and validity window so replay or cross-repository reuse fails.
4. `remote` is a signed origin claim, not proof of a trusted execution environment. Stronger assurance needs externally authenticated workload identity, protected keys, trusted time, and optionally transparency logging or hardware-backed execution.
5. Lock expiry alone creates a stale-writer hazard. Every lease acquisition therefore receives a monotonically increasing fencing token, and every manifest revision records that token. Several revisions may share a token only while one lease remains owner; a new lease ID must have a higher token. Immutable history creation and head compare-and-swap reject an older or concurrent revision.
6. The built-in shared-filesystem lease assumes atomic directory creation, atomic hard-link publication, coherent reads, and tolerable clock skew. It is suitable for cooperating writers on one strongly consistent filesystem, not for surviving network partitions. Distributed deployments need a linearizable external lease/transaction service.
7. Root-of-trust policy remains human-controlled. A campaign binds the exact policy artifact path and hash; key rotation, revocation, policy replacement, merge, push, and release do not become autonomous authority.

Implemented artifacts:

- `verification-attestation.js`
- `verification-attestation-runner.js`
- `schema-files/verifier-trust-policy.schema.json`
- `schema-files/verification-attestation.schema.json`
- `run-verification-attestation-fixtures.js`
- `run-signed-self-improvement-fixtures.js`
- `repository-lease.js`
- `repository-artifact-store.js` manifest v0.4

### 8.54 Deterministic Campaign Supervision v0.4

Research question:

> How does a bounded adaptive campaign resume without relying on conversational memory, skipping an approval boundary, or turning one controller decision into open-ended recursion?

Engineering conclusions:

1. A checkpoint controller answers whether one candidate can be accepted; it does not prove that a caller selected the correct next cycle, baseline, parent, or retry count. Campaign scheduling must therefore be a separate deterministic function over durable records.
2. The repository manifest is the campaign's custody boundary. The supervisor reloads one exact campaign and every matching checkpoint and decision only after manifest, history, sidecar, path, size, and artifact hashes pass verification.
3. Every checkpoint must pair with exactly one decision. Orphan checkpoints, orphan decisions, duplicate IDs, skipped cycle numbers, records after acceptance, and records after a terminal decision make the history non-executable.
4. A cycle advances only from `accept_working_state`. The next baseline is that decision's `accepted_revision`, and every follow-on checkpoint cites the decision's exact manifest path and SHA-256. Revision, rollback, and continue decisions increment an attempt in the same cycle rather than creating a parent they did not earn.
5. Finite budgets are dispatch gates, not advisory counters. The supervisor refuses to open a cycle beyond `max_cycles`, a retry beyond `max_retries_per_cycle`, or follow-on work after failure, no-progress, or elapsed limits are reached.
6. Completion, termination, escalation, invalid lineage, and incomplete persistence all become `hold` orders with `execution_authorized: false`. The cycle order also fixes `release_authorized: false`; it cannot widen the controller's authority.
7. Durable orders are idempotent. Re-running supervision against the same campaign state returns the existing order instead of appending another manifest revision. A conflicting order with the same deterministic identity is an integrity error.
8. The supervisor issues tasking but does not perform the task, generate evidence, decide a candidate, resolve human escalation, or release work. An active agent harness remains responsible for executing one ready order and returning a new proof-backed checkpoint.

Implemented artifacts:

- `campaign-supervisor.js`
- `schema-files/self-improvement-cycle-order.schema.json`
- `sample-payloads/valid-self-improvement-cycle-order.json`
- `sample-payloads/invalid-self-improvement-cycle-order-blocked-execution.json`
- `run-campaign-supervisor-fixtures.js`

### 8.55 Comparative Control-Plane Promotion v0.5

Research question:

> How can a self-improving campaign show that a skill or runtime-control candidate is better than its accepted baseline without trusting a model-authored before/after score?

Primary references:

- NIST AI RMF Generative AI Profile: https://doi.org/10.6028/NIST.AI.600-1
- Google SRE Workbook, Canarying Releases: https://sre.google/workbook/canarying-releases/
- OpenAI Working with evals: https://developers.openai.com/api/docs/guides/evals
- OpenAI Model guidance: https://developers.openai.com/api/docs/guides/latest-model

Engineering conclusions:

1. A single candidate receipt proves that a command ran against one state, but it does not establish comparative improvement. Baseline and candidate therefore need separate immutable repository-state bindings under one predeclared comparison plan.
2. A time-separated before/after claim is vulnerable to changed inputs, harnesses, and environments. The local gate fixes one ordered evaluation set, one artifact hash, one exact argv, and one harness hash for both worktrees. Any mismatch is `inconclusive`, not a soft warning.
3. Relative improvement alone can reward two bad states. Every quality dimension therefore combines a campaign-owned absolute target with a direction-aware maximum regression from the accepted baseline.
4. Test selection after seeing candidate output enables hindsight bias. The evaluation set and plan must be persisted before the paired execution. The set records whether fixtures are held out or open and requires expected outputs to be excluded from candidate context.
5. The harness emits structured observations rather than prose. The runner verifies subject, evaluator invocation, evaluation-set identity, exact fixture order, sample count, normalized metric dimensions, process result, and repository/fixture immutability.
6. A valid measured failure is `rollback`; invalid or uncomparable evidence is `inconclusive`; only a full pass is `promotable`. The comparison report never authorizes execution, merge, push, or release.
7. The controller reloads the report, plan, and set from the integrity-checked manifest and recomputes every threshold. Checkpoint before/after values must equal the report values, preventing a second model-authored metric layer from replacing runtime evidence.
8. The campaign supervisor binds any comparative report named by a decision back to its checkpoint and publishes the required target types in every cycle order.
9. Local hashes and process controls do not prove a trusted evaluator, isolated host, prior non-exposure, or statistical confidence. Signed report attestations, authenticated workload identity, host sandboxing, repeated stochastic trials, and post-deployment monitoring remain future controls.

Implemented artifacts:

- `comparative-evaluation-runner.js`
- `schema-files/comparative-evaluation-set.schema.json`
- `schema-files/comparative-evaluation-plan.schema.json`
- `schema-files/comparative-evaluation-report.schema.json`
- `sample-payloads/valid-comparative-evaluation-set.json`
- `sample-payloads/valid-comparative-evaluation-plan.json`
- `sample-payloads/valid-comparative-evaluation-report.json`
- `run-comparative-evaluation-fixtures.js`
- controller, supervisor, validator, roadmap, and skill integrations

### 8.56 Authenticated Comparative Evidence v0.6

Research question:

> How can the controller authenticate the party vouching for a comparative result without confusing a valid signature with proof that the evaluation itself was honest or isolated?

Primary references:

- DSSE protocol: https://github.com/secure-systems-lab/dsse/blob/master/protocol.md
- in-toto Statement v1: https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md
- SLSA Verification Summary Attestation v1: https://slsa.dev/spec/v1.2/verification_summary
- SLSA artifact verification: https://slsa.dev/spec/v1.2/verifying-artifacts
- Sigstore keyless signing overview: https://docs.sigstore.dev/cosign/signing/overview/

Engineering conclusions:

1. A report hash in a local manifest proves local byte consistency, not who vouched for the report. Schema v0.4 therefore adds an Ed25519 DSSE attestation whose in-toto subject is the exact persisted report artifact SHA-256.
2. Authentication must be purpose-bound. Receipt and comparative-report statements use different predicate types, preventing a valid signature from one evidence class from being interpreted as the other. Comparative signing additionally requires an explicit `comparative_evaluation_report` grant in the verifier's `allowed_attestation_types`; a receipt-only key is rejected before signing and during verification.
3. Subject digest alone is insufficient for policy. The signed comparative predicate repeats the report self-digest, plan and evaluation-set IDs, outcome, campaign, mission, cycle, target type, baseline and candidate identities/revisions, repository identity, evaluator ID/invocation, verifier identity, execution origin, nonce, and validity window.
4. Verification follows the SLSA pattern: validate the trusted key and envelope, match the subject digest, require the expected predicate, bind signer to verifier identity, then compare every relevant claim with preconfigured expectations. The controller derives those expectations from manifest-reloaded campaign, checkpoint, plan, set, and report artifacts.
5. One signer is not independent assurance. The same human-controlled trust policy sets minimum valid attestations, distinct keys, distinct verifier IDs, independence groups, allowed repositories/origins and attestation purposes, key windows, policy window, and maximum evidence age for both receipt and report quorums.
6. Outer fields are conveniences, not authority. They must equal the signed predicate and the controller's expectations. Changing an outer candidate revision and recomputing the local attestation digest still fails because the DSSE payload does not change.
7. A report attestation authenticates a trusted-key statement; it does not establish host isolation, honest harness execution, workload identity, provider independence, or trusted time. Sigstore-style OIDC identity, short-lived credentials, transparency inclusion, protected keys, and a sandboxed evaluator are future infrastructure controls.
8. `promotable` plus a valid report quorum remains only working-state evidence. The report, attestation, controller decision, and supervisor order all leave merge, push, policy, trust-root, authority, and release decisions outside autonomous scope.
9. Backward compatibility is explicit: v0.2 remains receipt-only, v0.3 retains signed-receipt semantics, and newly bootstrapped trusted campaigns use v0.4 with a separate signed comparative quorum for skill and runtime-control targets.

Implemented artifacts:

- `comparative-evaluation-attestation.js`
- `comparative-evaluation-attestation-runner.js`
- `schema-files/comparative-evaluation-attestation.schema.json`
- `sample-payloads/valid-comparative-evaluation-attestation.json`
- `sample-payloads/invalid-comparative-evaluation-attestation-statement.json`
- `run-comparative-evaluation-attestation-fixtures.js`
- v0.4 controller, supervisor, validator, roadmap, and skill integrations

### 8.57 Pre-Dispatch Verifier Readiness Admission v0.7

Research question:

> How can a campaign avoid starting work whose mandatory independent proof quorum is already impossible to obtain?

Primary references:

- SLSA artifact verification: https://slsa.dev/spec/v1.2/verifying-artifacts
- SLSA Verification Summary Attestation v1: https://slsa.dev/spec/v1.2/verification_summary
- RFC 8032: https://www.rfc-editor.org/rfc/rfc8032.html
- DSSE protocol: https://github.com/secure-systems-lab/dsse/blob/master/protocol.md

Engineering conclusions:

1. Requiring a signed quorum only after candidate execution wastes work and invites pressure to weaken the gate. The supervisor must verify that the bound trust policy can form every required evidence quorum before issuing execution authority.
2. Readiness cannot be an agent-authored status field. It is a deterministic projection from the exact policy artifact already identified by campaign ID, path, SHA-256, mission namespace, and repository identity in the verified manifest.
3. Receipt and comparative statements are separate purposes. A legacy v0.3 key with no purpose field may support receipts, but comparative readiness requires an explicit `comparative_evaluation_report` grant. Receipt capacity cannot silently become report capacity.
4. Eligible population is time- and repository-dependent. Only active entries with valid Ed25519 key identities, an allowed repository, and a validity interval containing the issuance instant count. Suspended, revoked, future, expired, wrong-repository, or malformed-key entries are excluded.
5. Headcount is not quorum. Readiness independently records distinct verifier IDs, public-key IDs, and independence groups. Repeating one key under several names or placing all verifiers in one group cannot satisfy the campaign threshold.
6. Campaign and trust policy may both state minimums. Admission uses the stricter value for each threshold and cannot turn off distinct-key enforcement required by either contract.
7. Readiness changes over time even when campaign history does not. Cycle-order v0.2 therefore records evaluation time and a conservative `valid_until`; admission state is included in deterministic order identity while the evaluation timestamp is excluded from idempotency comparison.
8. A validator recomputes satisfaction from the order's recorded lists and thresholds. A payload cannot claim `satisfied: true` with insufficient keys or groups, drift admission time from issuance, or attach v0.2 admission claims to a v0.1 order.
9. This is capacity admission, not availability proof. Public policy entries do not establish that private keys are online, uncompromised, independently operated, or able to answer. External workload identity, protected execution, online health, trusted time, and transparency remain separate controls.

Implemented artifacts:

- `verifier-trust-readiness.js`
- `campaign-supervisor.js` trust-policy loading and fail-closed admission
- `schema-files/self-improvement-cycle-order.schema.json` v0.2
- `sample-payloads/valid-self-improvement-cycle-order.json`
- `run-verifier-trust-readiness-fixtures.js`
- `run-cycle-order-admission-fixtures.js`
- expanded `run-campaign-supervisor-fixtures.js`

### 8.58 Authenticated Verifier Workload and Transparency Admission v0.8

Research question:

> How can pre-dispatch admission prove that a currently active workload, rather than only a public-key entry in policy, controls the verifier identity and has made that proof transparent?

Primary references:

- SPIFFE X.509-SVID specification: https://spiffe.io/docs/latest/spiffe-specs/x509-svid/
- SPIFFE Workload API specification: https://spiffe.io/docs/latest/spiffe-specs/spiffe_workload_api/
- Sigstore security model: https://docs.sigstore.dev/about/security/
- Sigstore bundle format: https://docs.sigstore.dev/about/bundle/
- Sigstore verification guide: https://docs.sigstore.dev/cosign/verifying/verify/
- Rekor transparency overview: https://docs.sigstore.dev/logging/overview/
- RFC 5280, Internet X.509 PKI certificate and CRL profile: https://www.rfc-editor.org/rfc/rfc5280.html
- RFC 9162, Certificate Transparency v2: https://datatracker.ietf.org/doc/html/rfc9162
- RFC 6962, Certificate Transparency v1: https://www.rfc-editor.org/rfc/rfc6962.html

Engineering conclusions:

1. Static policy eligibility and live workload authentication answer different questions. A registered Ed25519 key can establish who is allowed to sign, but it does not show that a current verifier process is online or bound to an externally issued workload identity. Trust-policy v0.2 therefore requires both layers before a verifier enters admission.
2. SPIFFE provides a provider-neutral workload identifier. The leaf certificate must expose exactly one URI SAN containing the expected SPIFFE ID, use a non-root path under the configured trust domain, be a non-CA certificate, and chain to the pinned root. Multiple URI SANs are rejected instead of selecting one favorable value.
3. The workload's SVID key must not replace the verifier's policy key. Both keys sign one canonical statement containing evidence ID, verifier and key, SPIFFE ID, root and log IDs, repository identity, allowed evidence purposes, nonce, issue time, and expiry. This demonstrates simultaneous participation and prevents either credential from silently widening the other.
4. Workload proof must be purpose-bound. Evidence can cover receipts, comparative reports, or both, but admission counts a verifier for a purpose only when policy and current identity evidence independently grant it.
5. Short-lived credentials reduce exposure but create a verification-time problem. Transparency material records the proof while the SVID is active. The verifier derives a canonical transparency entry from the statement, certificate and both signatures, applies domain-separated SHA-256 leaf/node hashes, and verifies an inclusion path to a checkpoint signed by the policy-pinned log key.
6. A signed checkpoint is not an append-only service by itself. Local inclusion verification proves membership in the stated tree root, not consistency with older roots or visibility to other observers. Production deployments still need log monitoring, consistency proofs, witness cosigning or gossip, and an incident path for equivocation.
7. Manifest custody remains mandatory. The supervisor considers only schema-valid identity evidence loaded from the campaign mission namespace of the verified repository artifact store, and cycle-order v0.3 records its exact manifest ID, path, and SHA-256. An otherwise valid object passed only in memory cannot authorize dispatch.
8. Admission validity must be conservative. The order expires at the earliest relevant policy, verifier, SVID, or evidence boundary. Stale evidence fails independently through `max_evidence_age_seconds`, even when its nominal expiry is later.
9. Provider-neutral does not mean standards-complete. The local verifier performs a bounded direct-chain check for signatures, CA roles, time, pinned root, exact SPIFFE SAN and Ed25519 keys. It does not implement general RFC 5280 path building, name/policy constraints, revocation, AIA retrieval, every critical extension, or the SPIFFE Workload API.
10. The local transparency envelope is not a Sigstore bundle and its checkpoint is not a Rekor wire object. Sigstore bundles, Fulcio OIDC claims, signed entry timestamps, trusted-root metadata and Rekor versions evolve as one ecosystem. Phase 11B should use official libraries and adapters instead of hand-rolling protocol compatibility.
11. Authentication still does not prove honest execution. A valid workload can run a defective or malicious verifier, and an independence-group label can misstate operational separation. Protected execution, service health, operator controls, reproducible verification and cross-provider evidence remain distinct assurances.
12. Human authority does not move. Agents cannot add roots, log keys, SPIFFE IDs, verifier keys, widen purposes, reduce quorum, extend validity, merge, push or release from identity evidence or a ready cycle order.

Implemented artifacts:

- `verifier-identity-evidence.js`
- `schema-files/verifier-identity-evidence.schema.json`
- `schema-files/verifier-trust-policy.schema.json` v0.2
- `schema-files/self-improvement-cycle-order.schema.json` v0.3
- `sample-payloads/valid-verifier-identity-evidence.json`
- `sample-payloads/invalid-verifier-identity-evidence.json`
- `run-verifier-identity-evidence-fixtures.js`
- `run-workload-identity-admission-fixtures.js`
- `verifier-trust-readiness.js` and `campaign-supervisor.js` identity admission integration

### 8.59 Native Sigstore Bundle and TrustedRoot Admission v0.9

Research question:

> How can Controls consume the evolving Fulcio, Rekor, CT-log and bundle ecosystem without reimplementing Sigstore, while still binding keyless identity to the framework's static verifier authority and current-workload requirement?

Primary references:

- Sigstore bundle protobuf: https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_bundle.proto
- Sigstore TrustedRoot protobuf: https://github.com/sigstore/protobuf-specs/blob/main/protos/sigstore_trustroot.proto
- Sigstore root-signing repository: https://github.com/sigstore/root-signing
- sigstore-js client: https://github.com/sigstore/sigstore-js/tree/main/packages/client
- sigstore-js verifier: https://github.com/sigstore/sigstore-js/tree/main/packages/verify
- Sigstore conformance suite: https://github.com/sigstore/sigstore-conformance
- Cosign `verify-blob` contract: https://github.com/sigstore/cosign/blob/main/doc/cosign_verify-blob.md
- Cosign Rekor-entry binding advisory GHSA-whqx-f9j3-ch6m: https://github.com/sigstore/cosign/security/advisories/GHSA-whqx-f9j3-ch6m
- Rekor transparency overview: https://docs.sigstore.dev/logging/overview/

Engineering conclusions:

1. Native Sigstore is a separate provider adapter, not a new interpretation of the Phase 11A local envelope. The trust policy selects `spiffe_x509` or `sigstore_bundle` per verifier so protocol and assurance boundaries remain visible.
2. A bundle is verification material, not policy. Policy independently fixes the exact certificate SAN, OIDC issuer, TrustedRoot artifact, bundle media type, CT/Rekor/timestamp thresholds, repository, verifier, purposes and validity limits.
3. Trusted material is an executable dependency. `SigstoreTrustedRoot` normalizes official protobuf JSON, records source and retrieval time, requires CA/Rekor/CT-log material, hashes the normalized root and enters the repository manifest by exact ID/path/SHA-256. Root replacement is a human-controlled trust change.
4. Keyless identity must not erase the long-lived Controls authority registry. The Fulcio certificate key and separately registered Ed25519 verifier key both sign one canonical binding statement containing identity, issuer, root digest, repository, purposes, nonce and validity. Neither proof can silently widen the other.
5. The official verifier performs coupled checks that are unsafe to reproduce piecemeal: trusted signing time, Fulcio path and SCT, Rekor inclusion/checkpoint, Rekor entry body binding, artifact signature and certificate identity policy. Controls invokes the low-level verifier with explicit trust material and nonzero thresholds.
6. Artifact binding is a first-class regression. The 2026 Cosign advisory demonstrates that an otherwise valid Rekor entry is not enough when it is unrelated to the supplied artifact/signature/key. Controls retains both wrong-artifact and unrelated-valid-entry tests and requires `TLOG_BODY_ERROR` on the latter class.
7. Policy accepts only the exact selected bundle media type. Current `sigstore` JavaScript message signing can emit bundle v0.2 even when v0.3 is available in the ecosystem, so the runtime supports explicit v0.2 or v0.3 selection instead of inferring or rewriting a version.
8. Artifact verification and current-workload admission use different time semantics. Sigstore can validate a historical signature after its short-lived Fulcio certificate expires when trusted signing time exists. Controls additionally requires the certificate to be active at dispatch and caps evidence expiry at certificate expiry.
9. Exact identity means literal policy data. The adapter escapes and anchors the SAN only because the library API accepts a regular-expression policy; operators cannot supply a broad regex. Issuer comparison is exact.
10. Conformance material is pinned, offline and adversarial. A live public-good Fulcio/Rekor sample proves end-to-end compatibility, while upstream conformance vectors test behavior without requiring network availability during every validation run.
11. One verified inclusion proof does not establish global log consistency, non-equivocation or universal visibility. Production deployments still need TUF/root-update operations, Rekor monitoring, consistency proofs, witnesses or gossip and incident response.
12. A valid bundle authenticates a signer and event, not honest verifier execution, protected key handling, operator independence or correct software. Those assurances require separate infrastructure and evidence. Merge, release, policy and trust-root authority remain with the human decision-maker.

Implemented artifacts:

- `sigstore-trusted-root.js` and `sigstore-trusted-root-runner.js`
- `sigstore-verifier-identity-evidence.js` and `sigstore-verifier-identity-runner.js`
- `schema-files/sigstore-trusted-root.schema.json`
- `schema-files/sigstore-verifier-identity-evidence.schema.json`
- `schema-files/verifier-trust-policy.schema.json` v0.3
- `schema-files/self-improvement-cycle-order.schema.json` v0.4
- `sigstore-fixtures/` pinned real and adversarial bundles
- `run-sigstore-verifier-identity-fixtures.js`
- supervisor, readiness, validator, roadmap and skill integrations

### 8.60 Verifier Execution Integrity v0.10

Research question:

> After workload identity and attestation signatures are valid, what evidence is required to decide that the exact approved verifier code ran under the expected isolation controls against the exact repository state and target?

Primary references:

- SLSA Build Provenance v1.2: https://slsa.dev/spec/v1.2/build-provenance
- SLSA artifact verification: https://slsa.dev/spec/v1.2/verifying-artifacts
- in-toto Statement v1: https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md
- OCI image descriptor: https://github.com/opencontainers/image-spec/blob/main/descriptor.md
- OCI image manifest: https://github.com/opencontainers/image-spec/blob/main/manifest.md
- OCI runtime configuration: https://github.com/opencontainers/runtime-spec/blob/main/config.md
- OCI Linux runtime configuration: https://github.com/opencontainers/runtime-spec/blob/main/config-linux.md
- GitHub Actions OIDC reference: https://docs.github.com/en/actions/reference/security/oidc
- GitHub artifact attestations: https://docs.github.com/en/actions/concepts/security/artifact-attestations
- GitLab ID token authentication: https://docs.gitlab.com/ci/secrets/id_token_authentication/
- GitLab runner configuration and provenance: https://docs.gitlab.com/ci/runners/configure_runners/
- IETF RFC 9334 RATS architecture: https://www.rfc-editor.org/rfc/rfc9334.html
- gVisor security model: https://gvisor.dev/docs/architecture_guide/security/
- gVisor platform guide: https://gvisor.dev/docs/architecture_guide/platforms/
- Confidential Containers attestation policies: https://confidentialcontainers.org/docs/attestation/policies/

Engineering conclusions:

1. Identity, output signature and execution integrity are separate proofs. Phase 11 authenticates the current workload; an attestation authenticates a statement; Phase 12A must additionally bind the statement to approved code and a policy-described execution environment.
2. Consumer expectations remain authoritative. Following SLSA verification, a valid signature is only the first check: verifier code, image, dependencies, harness, arguments, tools, network, sandbox, repository and subject must all equal values fixed outside the evidence being evaluated.
3. The exact persisted receipt or report belongs in the in-toto `subject`; the underlying verification target and execution details belong in a typed predicate. Cannae therefore uses its own execution predicate instead of mislabeling verifier execution as standard artifact build provenance.
4. Immutable OCI identity is the image-manifest digest, not a tag. Runtime policy records `name@sha256:<digest>`, expected media type and digest so registry tag movement cannot preserve equivalence.
5. Isolation is a profile, not a boolean. Read-only root, no-new-privileges, privilege mode, host network, host PID, host mounts, network endpoints, tool allowlist and sandbox-profile digest are independently compared.
6. One signer is insufficient. The registered verifier must bind itself to the record, while a distinct policy-pinned builder or provider attestor vouches for the environment and provider claims. Both sign identical DSSE payload bytes.
7. Repository state and verification target are first-class inputs. Evidence records whether the worktree is dirty and binds its exact Git head, full worktree fingerprint, target artifact ID/path/digest and Phase 11 identity-evidence reference. A content-bound uncommitted candidate is valid; an unrecorded or mismatched state is not.
8. Provider identity is adapter-specific. GitHub and GitLab expose different issuer, workflow/project, ref, commit, runner and configuration claims. A common schema can normalize them, but native JWT and provider-provenance verification must remain separate adapters.
9. RATS distinguishes evidence appraisal from the attestation result consumed by a relying party. TEE evidence therefore needs vendor-aware appraisal under an exact policy before its measurement and result can enter the common contract.
10. A builder assertion does not itself enforce isolation. The `generic_oci` adapter verifies a trusted builder's signed claim. Native GitHub Actions, GitLab CI, local sandbox and TEE adapters must independently verify provider tokens, host isolation or hardware evidence before projection.
11. Fresh execution evidence is not a liveness challenge. Phase 12B must issue a one-time supervisor nonce with a strict deadline and replay ledger, then remove stale, replayed, offline and late responders from current quorum.
12. Declared independence is not operational independence. Phase 12C must evaluate provider, operator, account, runner pool, cloud project, infrastructure and actual failure-domain identities before counting diversity.
13. A valid execution record does not grant release authority. Merge, push, deployment, trust-policy, runtime-policy, builder-root and provider-adapter changes remain human-controlled.

Implemented artifacts:

- `docs/verifier-execution-integrity.md`
- `schema-files/verifier-runtime-policy.schema.json`
- `schema-files/verifier-execution-evidence.schema.json`
- `schema-files/verifier-trust-policy.schema.json` v0.4
- `schema-files/verification-attestation.schema.json` v0.2
- `schema-files/comparative-evaluation-attestation.schema.json` v0.2
- `verifier-execution-evidence.js` and `verifier-execution-runner.js`
- `run-verifier-execution-evidence-fixtures.js`
- runtime-policy readiness, controller manifest reload, validator, sample, roadmap and skill integrations

### 8.61 Pre-Dispatch Verifier Challenge v0.11

Research question: How can a supervisor distinguish a registered verifier from a verifier that is currently online, controls its accepted workload identity and static key, and is responding to this exact dispatch rather than replaying prior evidence?

Primary sources:

- IETF RFC 9334 RATS freshness, especially nonce-based implicit timekeeping: https://www.rfc-editor.org/rfc/rfc9334.html#section-10.2
- IETF RFC 9449 DPoP nonce and proof-replay controls: https://www.rfc-editor.org/rfc/rfc9449.html#section-11.1
- W3C Web Authentication Level 3 cryptographic challenge requirements: https://www.w3.org/TR/webauthn-3/#sctn-cryptographic-challenges
- NIST SP 800-63B replay resistance: https://pages.nist.gov/800-63-4/sp800-63b.html#replay

Engineering conclusions:

1. Freshness needs an extra round trip. An appraising entity sends an unpredictable nonce and accepts only evidence that signs the exact returned value; a previously valid identity record is not proof of current response capability.
2. Nonce state belongs to the supervisor side. A challenge must be persisted with issue time, deadline and consumption identity so stale or repeated proofs can be rejected after process restart. A dedicated policy-pinned Ed25519 issuer key authenticates supervisor origin instead of trusting an `issued_by` string.
3. Entropy and equality are separate checks. WebAuthn recommends at least 16 bytes and exact comparison. Cannae uses a stricter local minimum of 32 cryptographically random bytes per verifier and checks exact hex equality.
4. A challenge must identify the operation, not only the verifier. Campaign, mission, repository, exact trust/runtime policy references, cycle, attempt, transition, baseline, parent lineage, task and proof-requirements digests are part of one dispatch binding.
5. One set contains unique per-verifier nonces. Reusing a nonce across verifier identities creates avoidable correlation and substitution risk, so duplicate nonce values fail validation.
6. Existing Phase 11 evidence is already the correct response envelope. Both the workload credential and registered verifier key sign the nonce-bearing statement; an additional unsigned response wrapper would add complexity without assurance.
7. Readiness is purpose-specific. Only challenged responders authorized for a receipt or comparative-report purpose may count in that purpose quorum. One responder cannot fill a missing verifier, key or independence-group position.
8. Deadline enforcement is half-open: response evidence is issued at or after challenge issuance and before challenge expiry; supervisor reevaluation also occurs before expiry. Admission cannot outlive the challenge.
9. Ambiguity fails closed. Two active challenge sets matching the same dispatch can result from an unsafe issuance race, so the supervisor does not choose one arbitrarily. Expired sets remain history but do not prevent a newly signed challenge from replacing their liveness window.
10. Single use is bound to the dispatch projection. Idempotent reevaluation of the same ready order is allowed, but consumption by a different projection is replay and cannot re-enter quorum.
11. Challenge success is bounded liveness, not continuous service health or honesty. A verifier may fail after responding, and compromised current credentials can answer. Phase 12A execution evidence and Phase 12C independence remain separate controls.
12. Challenge evidence never grants release. Merge, push, deployment, policy, trust-root, runtime-policy and authority decisions remain human controlled.

Implemented artifacts:

- `docs/verifier-pre-dispatch-challenge.md`
- `schema-files/verifier-challenge-set.schema.json`
- `schema-files/verifier-trust-policy.schema.json` v0.5
- `schema-files/self-improvement-cycle-order.schema.json` v0.5
- `verifier-challenge-set.js`
- challenge-aware `verifier-trust-readiness.js` and `campaign-supervisor.js`
- `run-verifier-challenge-fixtures.js`
- valid/invalid trust-policy, challenge-set and cycle-order samples
- validator, roadmap, bounded-operations, source-map and skill routing integrations

### 8.62 Verifier Failure-Domain Independence v0.12

Research question: How can a quorum distinguish genuinely independent verifier execution systems from several identities, jobs, or declared groups controlled by one provider account, operator, runner fleet, cloud project, infrastructure stack, region, or zone?

Primary sources:

- NIST SP 800-160 Vol. 2 Rev. 1 cyber-resiliency diversity: https://csrc.nist.gov/pubs/sp/800/160/v2/r1/final
- SLSA build-platform trust closure: https://slsa.dev/spec/v1.1/terminology
- SLSA provenance builder identity: https://slsa.dev/spec/v1.2/provenance
- GitHub Actions OIDC claims: https://docs.github.com/en/actions/reference/security/oidc
- GitLab ID-token claims: https://docs.gitlab.com/ci/secrets/id_token_authentication/
- Kubernetes topology spread and failure domains: https://kubernetes.io/docs/concepts/scheduling-eviction/topology-spread-constraints/
- AWS fault-isolation boundaries: https://docs.aws.amazon.com/whitepapers/latest/aws-fault-isolation-boundaries/abstract-and-introduction.html
- AWS multi-account organization: https://docs.aws.amazon.com/organizations/latest/userguide/orgs_best-practices.html
- Azure regions and availability zones: https://learn.microsoft.com/en-us/azure/well-architected/resiliency/regions-availability-zones
- Google Cloud resource hierarchy: https://docs.cloud.google.com/docs/get-started/organize-resources
- Google Cloud infrastructure reliability: https://docs.cloud.google.com/architecture/infra-reliability-guide

Engineering conclusions:

1. Independence is a property of failure correlation, not a label. NIST diversity aims to reduce common-mode failure through heterogeneity; two differently named verifier groups under one administrative or technical failure boundary remain correlated.
2. The trust boundary is transitive. SLSA defines a build platform through the software, hardware, people, and organizations trusted to execute faithfully, so provider and operator identities belong beside machine-placement identities.
3. One scalar group field cannot represent the relevant failure surfaces. The v0.6 contract requires provider, operator, control plane, account, project, runner pool, infrastructure, region, and zone separately.
4. Correlation is conservative: sharing any required component creates an edge. Connected components, not pairwise labels, are counted, so A sharing an account with B and B sharing a runner pool with C correlates all three.
5. Unknown cannot mean independent. Every field must be a stable URI-like identifier. Missing, extra, mutable-display-name, or invented values fail contract validation.
6. Provider-native identity stays behind adapters. GitHub and GitLab expose different stable claims; cloud accounts, Kubernetes topology, local hosts, and TEEs require different evidence. A common projection does not justify parsing every provider with one generic rule.
7. Geography and administration are different. Region/zone placement can reduce physical failure correlation while one account, control plane, operator, or project can still compromise every verifier.
8. Azure zone numbering is tenant-specific, and similar provider scoping problems exist elsewhere. Component identifiers must carry provider/account context rather than compare bare zone names.
9. Pre-dispatch and post-execution need the same algorithm. Runtime-policy v0.2 predicts available domains; execution-evidence v0.2 confirms the observed identities under builder and verifier signatures; attestation quorum then uses the computed `VID-*` domain.
10. Declared `independence_group` remains readable for old contracts but has no v0.6 quorum authority. This prevents a policy author from manufacturing diversity by renaming correlated verifiers.
11. Correlated attestations can be individually valid. The correct failure is group-diversity quorum failure, not necessarily signature invalidity.
12. Builder and provider honesty remain roots of trust. The generic adapter proves that configured keys signed matching claims; native OIDC, provider-attestation, host-attestation, or TEE appraisal is still required to establish claim truth.
13. Strict all-dimension separation can reduce availability and often implies cross-provider execution. A lower-assurance policy must be explicit in a future contract rather than silently reinterpret v0.6.
14. Independence does not grant release. Trust-policy, runtime-policy, provider roots, merge, push, deployment, and public-release decisions remain human controlled.

Implemented artifacts:

- `docs/verifier-independence-assurance.md`
- `verifier-independence.js`
- `VerifierTrustPolicy` v0.6 independence assurance
- `VerifierRuntimePolicy` v0.2 component identities
- `VerifierExecutionEvidence` v0.2 signed observations
- `SelfImprovementCycleOrder` v0.6 domain projection
- readiness, receipt-quorum, comparative-quorum, supervisor, controller, runner, schema, validator and sample integrations
- `run-verifier-independence-fixtures.js` covering label substitution, shared components, transitive correlation, dual-signed evidence, mutation and quorum failure

### 8.63 Transparency Operations v0.13

Research question: How can verifier trust remain valid over time when transparency logs grow, signing roots rotate, observers fail or collude, and compromise evidence requires revocation and recovery?

Primary sources:

- Rekor transparency overview: https://docs.sigstore.dev/logging/overview/
- Rekor monitor: https://github.com/sigstore/rekor-monitor
- transparency-dev checkpoint formats: https://github.com/transparency-dev/formats/tree/main/log
- transparency-dev witness: https://github.com/transparency-dev/witness
- Rekor v2 tiled logs: https://github.com/sigstore/rekor-tiles
- RFC 6962: https://www.rfc-editor.org/rfc/rfc6962.html
- The Update Framework specification: https://theupdateframework.github.io/specification/draft/
- Sigstore threat model: https://docs.sigstore.dev/about/threat-model/
- Sigstore root-signing repository: https://github.com/sigstore/root-signing

Engineering conclusions:

1. Inclusion is not consistency. A valid artifact entry and checkpoint prove one view; durable append-only assurance requires the prior checkpoint and a valid consistency proof to the next view.
2. Same-size checkpoints with different roots are direct equivocation evidence. A smaller tree is rollback. Both must block dispatch and enter incident handling.
3. Monitor state is durable control state, not a disposable CI log. A stateless job cannot prove which checkpoint it previously trusted.
4. Witness and monitor functions should not collapse into one operator set. Witnesses countersign a consistent transition; monitors independently audit and report. Distinct identity and operator thresholds reduce one-key and one-operator substitution.
5. Gossip is still necessary. A local verifier can reject conflicting checkpoints it receives, but it cannot detect a conflicting view that every local source withholds.
6. Witnesses countersign the exact checkpoint after consistency verification; monitors sign the complete transition, including the previous checkpoint. Observer timestamps must equal the monitor-signed observation time so unsigned metadata cannot alter registry eligibility.
7. TUF root update is dual authorization. Root N's threshold authorizes N+1, then N+1's own threshold confirms the new trust set. Exact sequential versions prevent skipped-state ambiguity, and the accepted root expiry must remain a state validity boundary.
8. A valid root rotation must not silently widen an already active verifier trust policy. The current transparency-state roots remain bounded by roots explicitly admitted in the trust policy.
9. Time-sharded logs make log identity and active/inactive shard distribution operational trust data. A changed URL or shard is a policy/root event, not harmless configuration drift.
10. Incident records are immutable. Resolution is a new USER-authorized record that exactly supersedes an earlier open/contained record; rewriting or dropping the original destroys auditability.
11. Revocation survives incident resolution. Recovery after a compromised active component requires replacement through an authorized policy or root transition, not a status flip.
12. Blocked states belong in history. A transparency sequence must preserve the failure and its recovery rather than restart from an apparently clean state, so the state runner must persist a valid blocked projection without treating it as dispatch authority.
13. Embedded evidence is insufficient. The supervisor must find each observation, root, rotation, incident and state as exact bytes in the verified repository manifest before admission.
14. Freshness has three bounds: the signed observation/checkpoint expiry, current TUF root expiry, and the maximum state age selected by both transparency and verifier trust policies. The earliest boundary must cap both admission and the issued cycle order.
15. Provider operation remains outside the generic core. Rekor polling, shard discovery, witness networking, TUF repository refresh, and cloud/TEE observation require provider adapters.
16. Transparency never grants authority. Policy changes, roots, revocation disposition, execution, merge, push and release remain separately controlled.

Implemented artifacts:

- `docs/transparency-operations.md`
- `transparency-operations.js` and `transparency-operations-runner.js`
- `TransparencyPolicy`, `TransparencyObservation`, `TrustRootRotation`, `TransparencyIncident`, and `TransparencyState` schemas
- `VerifierTrustPolicy` and `SelfImprovementCycleOrder` v0.7
- readiness, supervisor, attestation, controller, schema, validator and repository-manifest integrations
- `run-transparency-operations-fixtures.js` and `run-transparency-supervisor-fixtures.js`
- valid and adversarial policy, observation, rotation, incident, state, trust-policy and cycle-order samples

### 8.64 Deep-Research Queue Doctrine Synthesis

This tranche converted fifteen previously queued operating concepts into doctrine artifacts. Each artifact separates the military-source claim from the framework interpretation and names the runtime boundary it is intended to control. Their presence here, in `README.md`, and in `docs/source-map.md` is a mandatory knowledge-management closeout condition.

| Artifact | Research conclusion | LLM application | Current limit |
| --- | --- | --- | --- |
| `docs/mission-command-runtime-policy.md` | Commander's intent must preserve purpose, key tasks, end state, failure conditions, and authority boundaries through delegation. | Compile intent into constraints checked at context issuance, tool admission, reporting, and reassessment. | Semantic compliance still requires backbrief and evaluator judgment. |
| `docs/disciplined-initiative-rules.md` | Initiative is legitimate only inside intent, authority, risk, and reporting boundaries. | Classify drift and force continue, report, stop, or seek approval responses. | It does not make ambiguous intent mechanically decidable. |
| `docs/dry-run-approval-ui.md` | Rehearsal exists to expose decisions before effects occur. | Present evidence-bound approve, revise, rehearse again, and abort dispositions. | A UI cannot replace an authenticated approval and consumption record. |
| `docs/chief-of-staff-agent.md` | A chief of staff integrates staff work but is not a second commander. | Own routing, battle rhythm, packet quality, and unresolved-conflict escalation. | It never receives retained USER authority. |
| `docs/common-operational-picture-state.md` | Shared understanding should be projected from authoritative events, not conversational memory. | Derive role-filtered mission state with provenance and staleness indicators. | Projection quality is bounded by event completeness and timestamp integrity. |
| `docs/reporting-threshold-policy.md` | Reports should serve decisions and exceptions rather than narrate routine progress. | Route must-report, may-stay-silent, and prohibited disclosure classes by threshold. | Novel events may still need human classification. |
| `docs/handoff-packet-template.md` | Relief in place requires an accepted transfer of authority, state, evidence, and pending decisions. | Gate resume and successor activation on a complete, verified packet. | A packet proves recorded state, not the successor's understanding. |
| `docs/training-progression-model.md` | Proficiency is task-specific, progressive, evidenced, and perishable. | Use crawl-walk-run evidence and regression triggers per METL task. | Model and tool drift require locally chosen reassessment intervals. |
| `docs/readiness-to-authority-policy.md` | Readiness is necessary but never sufficient for authority. | Compute a ceiling combined with mission, matrix, approval, risk, and expiry gates. | Readiness can never unlock Red/Black or release authority. |
| `docs/sustainment-agent-sop.md` | Operational endurance depends on continuous visibility of consumable and repairable resources. | Monitor budget, quota, tool, time, and context thresholds and run bounded outage drills. | External provider recovery remains outside local enforcement. |
| `docs/resource-priority-policy.md` | Scarce resources follow declared priority of support, not request order. | Allocate to the main effort, define preemption, and prevent starvation. | Priority changes still require a valid FRAGO or commander decision. |
| `docs/sensitive-output-filter.md` | Disclosure controls must exist at both final-output and tool-transfer boundaries. | Detect EEFI, redact or block, and retain digest-only audit evidence. | Pattern detection cannot prove that every semantic secret was found. |
| `docs/liaison-agent-model.md` | Liaison preserves mutual understanding without assuming either organization's command authority. | Translate terminology, route requests, and maintain boundary records. | It cannot resolve policy or authority conflicts itself. |
| `docs/interop-release-packet.md` | Boundary crossing needs one reviewed, purpose-bound package rather than ad hoc context sharing. | Bind audience, subject, mission, labels, reviews, expiry, and released bytes. | Partner-side handling after release requires a separate agreement and control plane. |
| `docs/partner-command-relationship.md` | External relationships must declare what may be directed, coordinated, requested, or denied. | Enforce request classes and escalation without importing partner authority. | It does not establish legal authority between real organizations. |

## 9. Research Questions to Dig Into Further

1. How should the military document hierarchy be implemented as an LLM context hierarchy?
2. Can OPORD, Annex, and FRAGO be made into an actual prompt DSL?
3. How should per-agent authority levels be enforced in the system prompt?
4. How should a rule-based/model-based method for automatically detecting CCIR be designed?
5. What is the method for automatically reflecting AAR results into the next prompt and SOP?
6. What independence should the Red Team agent have?
7. How should unity of command and unity of effort be maintained in a multi-agent structure?
8. How should the boundary conditions requiring human approval be standardized?
9. How does military-style "mission command" differ across creative work, coding work, and research work?
10. What is a mission-command-style AI operating system suited to Korean organizational culture?
11. When implementing a prompt DSL validator as actual code, which missing fields should be caught first?
12. How should the tool gateway present approval required to the user as UX?
13. How can the mismatch between Korean and English military terminology be detected automatically?
14. Into what DB schema should mission state and the evidence store be separated?
15. Can an agent's readiness rating be updated automatically?
16. In a Korean organization, what UI would make Red Team findings accepted as decision-making material?
17. How densely must JSON Schema valid/invalid fixtures be built for the validator to be a meaningful gate?
18. What priority should be applied when Green/Amber/Red/Black conflict in the policy engine?
19. What should the command post dashboard hide, and what should it show first?
20. In what language should the validator CLI prototype be built, and which fixtures should be automated first?
21. What representative mission should the runtime demo scenario be based on?
22. Can the validator fixture runner automatically verify semantic issue codes as well?
23. What information density is appropriate when building the command post dashboard as static HTML?
24. Is it necessary to convert the SQL model to an event-sourcing approach?
25. Can the policy engine fixture runner also verify approval scope and expiry?
26. Can the dashboard prototype be rendered based on actual JSON state?
27. Can a mission_current_state projection be built by replaying the event log?
28. Can an event replay projection be automatically converted into dashboard-state.json?
29. Can adding a demo OPORD payload more strictly verify the mission -> OPORD -> task order flow?
30. Should the still-missing military operating domains be managed as a separate deep research queue?
31. How should B2C2WG be implemented as multi-agent scheduling and a decision packet workflow?
32. Can the authority matrix be schematized as a combination of role, task, tool, target, risk, readiness, and expiry?
33. Under what conditions should CCIR alerting branch into a dashboard notification, SITREP, or approval request?
34. How should OPSEC/classification and EEFI be turned into an LLM context sharing policy?
35. In what order should the knowledge management SOP update the decision log, evidence store, and handoff packet?
36. How are agent METL and readiness rating linked to automatic expansion/reduction of execution authority?
37. How should the decision packet schema enforce option/risk/evidence/authority/deadline?
38. When should a working group charter be opened, and when should it be disbanded?
39. By what rule should the CCIR alert router compute Red/Amber/Watch from the event log?
40. What information should the context releasability filter remove or summarize, per role?
41. How should the readiness gate combine the authority matrix and the agent readiness ledger?
42. What current state should the handoff packet schema require as mandatory during a context transition?
43. How should the context item schema standardize classification, EEFI, allowed_roles, and release_to_final?
44. How should the context filter prototype determine raw/summary/redacted/reference_only/denied delivery?
45. How should a release review determine what information can go out in the final answer?
46. How should the handoff generator combine the event replay projection with the README queue?
47. How should working group opened/prepared/closed events be entered into the replay projection?
48. How should maintenance readiness evaluate tool availability, quota, context budget, and fallback?
49. How should the maintenance-readiness schema standardize tool/resource/context/fallback state?
50. How should the release-review runner compare the context filter output with the final output constraints?
51. How should the working group projection be displayed in dashboard state?
52. How should the approval scope policy enforce approval once, constraints, expiry, and rollback?
53. How should risk acceptance authority divide retained authority by role/risk/severity/readiness?
54. How should the source-map linter fail when a new URL is not in the source-map?
55. How should the approval scope schema prevent reuse of a consumed approval?
56. How should the risk acceptance schema enforce residual risk and a supervision plan?
57. How should the maintenance readiness dashboard show unavailable/degraded tools as a commander-facing panel?
58. In what order should the policy engine compose the authority matrix, readiness gate, and release review?
59. Can an AAR finding be automatically converted into a readiness update recommendation?
60. How should the FRAGO scope-change schema change an OPORD authority boundary?
61. When building the annex schema, how should the OPORD body be distinguished from the FRAGO boundary?
62. How far can backbrief quality be evaluated with deterministic rules, without an LLM judge?
63. Can a rehearsal friction point be automatically converted into a CCIR alert and a decision packet?
64. Under what conditions should collected information branch into a running estimate, SITREP, decision packet, or FRAGO scope-change?
65. When a commander/staff member/agent is lost or replaced, what succession line, handoff, and authority pause are needed?
66. When converting a high-risk/high-uncertainty task into an SOF TF, what cell separation, enablers, rehearsal, and release gate should determine the activation go/no-go?
67. When different branches/departments collaborate, how should the supported/supporting relationship, liaison, handoff interface, and conflict decision route be enforced as a runtime contract?
68. When creating, expanding, reducing, or disestablishing a branch/duty position/unit/TF, how should capability gap, DOTMLPF-P, readiness, transition, and documentation gates be enforced as a runtime contract?
69. How should a document access manifest be enforced as a runtime gate so that each agent reads only the documents fixed for its role, duty, and authority?
70. How should local calibration thresholds and cost-quality budgets be updated from mission AAR evidence without allowing a router to self-certify readiness?

## 10. Relationship to the Current Document Set

- `military-llm-framework-v0.1.md`: overall conceptual doctrine.
- `military-operating-system.md`: models the way the military operates as an LLM operating system.
- `agent-roles-and-authority.md`: per-position approval, reporting, autonomous judgment, and after-action management.
- `decision-risk-assessment.md`: CCIR, risk, decision support, operation assessment.
- `information-to-operations-cycle.md`: the procedure by which information collection/evaluation converts into a running estimate, CCIR, SITREP, decision packet, and FRAGO.
- `personnel-continuity-model.md`: a continuity model in which duty positions and authority continue even through personnel loss/replacement/rotation.
- `interdepartment-collaboration-policy.md`: converts branch/function integration principles into inter-department supported/supporting, liaison, handoff, and conflict route policy.
- `force-structure-change-policy.md`: a policy that controls the creation, disestablishment, expansion, and reduction of branches/duty positions/units/TFs via capability gap, DOTMLPF-P, readiness, and transition order.
- `model-force-assignment-policy.md`: a mission-based policy for allocating deterministic, line, specialist, command, SOF, assurance, and reserve model profiles without inheriting authority from capability.
- `model-force-v0.2-operations.md`: the executable registry, compiler, receipt-binding, dispatch, telemetry, and reassessment procedure for heterogeneous model forces.
- `repository-artifact-isolation-policy.md`: target-repository custody, namespace, persistence, and manifest rules for multi-repository AI campaigns.
- `bounded-self-improvement-operations.md`: finite evidence-driven adaptation for active work and control-plane candidates without AI self-release or authority expansion.
- `prompt-templates.md`: OPORD, WARNO, FRAGO, SITREP, and AAR prompt templates.
- `orders-production-pipeline.md`: the order production pipeline running from request to AAR.
- `opord-annex-model.md`: the model separating responsibility between the OPORD body and annexes.
- `backbrief-and-rehearsal-sop.md`: the SOP for confirming understanding and dry-running before execution.
- `sop-library.md`: standard procedures for repeated tasks.
- `agent-battle-rhythm.md`: the cycle of reporting, meetings, decisions, and AAR.
- `functional-domains.md`: LLM mapping of warfighting functions, training, sustainment, targeting, and ROE.
- `source-map.md`: a map connecting military concepts per source to their LLM application points.
- `case-studies.md`: actual application case studies.
- `glossary.md`: the shared term dictionary.
- `evaluation-metrics.md`: the AI METL, MOP/MOE, and readiness rating evaluation system.
- `experiments.md`: experiment design for verifying the framework's effect.
- `korean-military-sources.md`: public Korean military sources and LLM application notes.
- `implementation-guide.md`: a guide for actually implementing the LLM app/agent runtime.
- `prompt-dsl.md`: a machine-readable schema for OPORD, WARNO, FRAGO, SITREP, and AAR.
- `tool-use-roe.md`: tool-use authority and approval gates.
- `llm-agent-org-chart.md`: the agent org chart, command relationships, RACI, and reporting lines.
- `korean-org-culture.md`: how to calibrate backbrief, reporting, Red Team, and approval chains for Korean organizational culture.
- `reference-architecture.md`: the reference structure for the Orchestrator, policy engine, tool gateway, and evidence store.
- `sample-runtime-state.md`: example states for mission, OPORD, task order, tool request, SITREP, and AAR.
- `prompt-dsl-validator.md`: validation rules for OPORD/WARNO/FRAGO/SITREP/AAR.
- `approval-ui-patterns.md`: user approval UI patterns before Amber/Red tool execution.
- `schema-files/`: the bundle of JSON Schemas for the prompt DSL and runtime state.
- `validator-prototype.md`: DSL validator pseudocode and test cases.
- `agent-runtime-playbook.md`: runtime operating procedures, SITREP/FRAGO/AAR, and incident response.
- `military-ai-risk-register.md`: a list of military-style AI operating risks and their controls.
- `agent-readiness-ledger.md`: per-agent readiness rating and training plan.
- `sample-payloads/`: valid/invalid JSON examples for testing schema and the validator.
- `policy-engine-rules.md`: Green/Amber/Red/Black ROE ruling rules.
- `command-post-dashboard.md`: design of the mission board, approval queue, CCIR, and evidence viewer.
- `runtime-automation-roadmap.md`: the implementation roadmap from a document framework to a tool-gated runtime.
- `evaluation-fixtures.md`: definitions of validator/policy/evidence/runtime regression test fixtures.
- `validator-cli-prototype/`: a draft Node CLI running a JSON Schema subset and semantic rules.
- `dashboard-wireframes.md`: screen wireframes for the command post dashboard.
- `data-model.sql.md`: the SQL storage model for mission/evidence/audit/readiness.
- `runtime-demo-scenario.md`: an end-to-end demo running from intake to AAR.
- `source-reliability-rubric.md`: criteria for evaluating source reliability and interpretive risk.
- `validator-cli-prototype/run-fixtures.js`: an automatic runner for validator fixture expectations.
- `policy-engine-prototype/`: a draft that separates ROE ruling functions into actual code.
- `runtime-demo-payloads/`: the actual JSON payload set for the demo mission.
- `dashboard-ui-prototype/`: the static command post dashboard HTML prototype.
- `event-sourcing-model.md`: the design of the mission event log and projections.
- `policy-engine-prototype/run-policy-fixtures.js`: automatic testing of the policy engine's expected decisions.
- `runtime-demo-runner.js`: an end-to-end runner for demo payloads and policy checks.
- `dashboard-ui-prototype/dashboard-state.json`: the JSON state that drives the dashboard prototype.
- `event-fixtures/`: a demo event log for event-sourcing replay.
- `event-replay-prototype/`: a Node prototype that replays the event log into a mission projection.
- `dashboard-ui-prototype/render-state.js`: converts the event replay projection into dashboard JSON state.
- `event-replay-prototype/run-event-fixtures.js`: automatically verifies the replay projection and the dashboard conversion's expected values.
- `runtime-demo-payloads/opord.json`: the OPORD payload for the demo mission.
- `military-operating-deep-research-queue.md`: a queue of missing military operating domains and the next research deliverables.
- `commander-handbook.md`: practical guidance for a human operating intent, authority, approval, and reporting as an AI commander.
- `b2c2wg-operating-model.md`: a multi-agent operating model for boards, bureaus, centers, cells, and working groups.
- `ccir-alerting-model.md`: converts PIR/FFIR/EEFI/decision points into dashboard alerts and routing.
- `opsec-classification-model.md`: a control model for context sharing, EEFI, releasability, and sensitive output.
- `role-document-access-policy.md`: a document access policy that lets only the documents fixed by role, duty, and authority be read.
- `knowledge-management-sop.md`: operating procedures for the decision log, evidence store, event log, and handoff packet.
- `agent-metl.md`: per-role mission-essential task lists and the readiness-to-authority link.
- `schema-files/authority-matrix.schema.json`: an authority matrix schema based on role/task/tool/target/risk/readiness.
- `sample-payloads/valid-authority-matrix.json`: a valid authority matrix fixture.
- `sample-payloads/invalid-authority-matrix-red-without-approver.json`: a Red authority semantic validation fixture.
- `schema-files/decision-packet.schema.json`: the schema for the option/risk/evidence/authority packet raised to the commander board.
- `schema-files/working-group.schema.json`: the B2C2WG charter and disband condition schema.
- `schema-files/department-collaboration-charter.schema.json`: the contract for inter-department supported/supporting relationships, liaison, synchronization, and conflict route.
- `schema-files/force-structure-change-order.schema.json`: an order schema that approves organizational creation/disestablishment/expansion/reduction via capability gap, DOTMLPF-P, authority, readiness, transition, and documentation update.
- `schema-files/ccir-alert.schema.json`: the alert object and routing contract schema.
- `schema-files/handoff-packet.schema.json`: the schema for the packet that conveys current state before a context transition.
- `alert-router-prototype/`: a Node prototype that converts the event log into a CCIR alert projection.
- `readiness-gate-prototype/`: a prototype that combines the authority matrix and readiness rating to rule on execution authority.
- `context-releasability-policy.md`: per-role context packet filtering and the EEFI release policy.
- `schema-files/context-item.schema.json`: the schema for classification, EEFI, allowed roles, and final release metadata.
- `schema-files/document-access-manifest.schema.json`: the document access manifest schema based on role, duty, and authority.
- `schema-files/release-review.schema.json`: the final output/external release review schema.
- `context-filter-prototype/`: a generator of per-role raw/summary/redacted/reference/denied context packets.
- `document-access-runner.js`: checks role/duty/authority against the manifest to generate an allowed/denied document projection.
- `run-document-access-fixtures.js`: fixtures for S2/Executor/S6 document access and blocking overbroad access.
- `handoff-generator.js`: generates a handoff packet from the event replay and alert projections.
- `decision-packet-linter.js`: a validator for board packet option/risk/evidence/deadline.
- `event-fixtures/working-group-event-fixtures.json`: the WG opened/prepared/decided/closed event log.
- `maintenance-readiness-model.md`: a model for tool/resource availability and sustainment readiness.
- `schema-files/maintenance-readiness.schema.json`: the critical asset readiness report schema.
- `schema-files/backbrief.schema.json`: the schema for the task owner's restatement of intent/task/stop condition/approval boundary.
- `schema-files/rehearsal.schema.json`: the schema for execution sequence, friction, decision point, and disposition.
- `schema-files/approval-scope.schema.json`: single-use approval, expiry, rollback, evidence, and consumption metadata.
- `schema-files/approval-consumption-event.schema.json`: the audit event by which an approval scope is consumed by actual execution.
- `schema-files/approval-revocation-event.schema.json`: the audit event by which an approval scope is revoked before execution.
- `schema-files/approval-renewal-event.schema.json`: the audit event by which an approval scope's validity period alone is extended before execution.
- `schema-files/approval-delegation-event.schema.json`: the audit event for a limited delegation of approval authority.
- `schema-files/approval-delegation-revocation-event.schema.json`: the audit event for the revocation/expiry projection of a delegated approval authority.
- `schema-files/release-gate-decision-event.schema.json`: the composite decision audit event for execution approval and information release approval.
- `schema-files/risk-acceptance.schema.json`: residual risk, authority, duration, supervision, and AAR trigger.
- `maintenance-readiness-runner.js`: converts critical runner results into a readiness report.
- `orders-dissemination-runner.js`: a verifier for the connectivity of the OPORD, task order, backbrief, and rehearsal.
- `approval-consumption-runner.js`: checks the approval scope against the consumption event's mission/action/tool/target/time/evidence.
- `run-approval-consumption-fixtures.js`: fixtures for active consumption, target mismatch, and reused approval.
- `approval-revocation-runner.js`: checks the approval scope against the revocation event's active status/authority/time/notification/evidence.
- `run-approval-revocation-fixtures.js`: fixtures for active revocation, consumed revocation, and wrong authority.
- `approval-renewal-runner.js`: checks the approval scope against the renewal event's active status/authority/window/execution-count/evidence.
- `run-approval-renewal-fixtures.js`: fixtures for active renewal, expired renewal, and scope expansion.
- `approval-delegation-runner.js`: checks the authority matrix against the delegation event's base rule/ROE/risk/context/subdelegation restrictions.
- `run-approval-delegation-fixtures.js`: fixtures for bounded delegation, a staff-retained-authority attempt, and Red base rule delegation.
- `approval-delegation-revocation-runner.js`: checks the delegation event against the termination event's status/authority/time/snapshot/evidence.
- `run-approval-delegation-revocation-fixtures.js`: fixtures for Commander revocation, recorder expiry projection, and a staff revocation attempt.
- `policy-engine-authority-integration.js`: the composite gate for policy, authority matrix, approval scope, and risk acceptance.
- `run-authority-integration-fixtures.js`: fixtures blocking reuse of a consumed approval and missing risk acceptance.
- `policy-engine-release-integration.js`: the composite gate for the authority gate and release review.
- `run-release-integration-fixtures.js`: fixtures for valid release, missing review, invalid review, and authority-blocked release.
- `release-gate-decision-runner.js`: checks the release integration output against the release gate decision event's final decision/snapshot/evidence.
- `run-release-gate-decision-fixtures.js`: fixtures for release allow, a missing-review allow claim, and an authority-blocked release event.
- `release-gate-dashboard-runner.js`: projects the ReleaseGateDecided event into the release/authority/review dashboard queue.
- `run-release-gate-dashboard-fixtures.js`: fixtures for released, release-review-blocked, and authority-blocked projections.
- `dashboard-ui-prototype/release-gate-dashboard-state.json`: the release gate dashboard projection state.
- `maintenance-dashboard-runner.js`: converts the maintenance readiness report into a ready/degraded/down dashboard projection.
- `run-maintenance-dashboard-fixtures.js`: fixtures for ready, degraded, and unavailable sustainment projections.
- `dashboard-ui-prototype/maintenance-readiness-dashboard-state.json`: the sustainment readiness dashboard projection state.
- `authority-delegation-projection-runner.js`: converts the delegated approval authority lifecycle event into a dashboard projection.
- `run-authority-delegation-projection-fixtures.js`: fixtures for active, revoked, and expired delegation projections.
- `dashboard-ui-prototype/authority-delegation-projection-state.json`: the delegated authority dashboard projection state.
- `release-review-runner.js`: compares the context filter output with the release review.
- `dashboard-ui-prototype/working-group-projection-dashboard-state.json`: the B2C2WG dashboard projection state.
- `approval-scope-policy.md`: the approval once, constraints, expiry, and rollback policy.
- `risk-acceptance-authority.md`: risk acceptance authority and commander-retained authority.
- `source-map-linter.js`: verifies official source domain coverage.
- `source-map-url-coverage-report.json`: a per-host source-map coverage snapshot of official sources.
- `aar-to-readiness-update.js`: converts an AAR finding into a readiness recommendation and follow-up action.
- `schema-files/aar-readiness-update.schema.json`: the AAR readiness update contract.
- `run-aar-readiness-update-fixtures.js`: fixtures for normal improvement, critical source failure, and a sustain-only AAR.
- `schema-files/annex.schema.json`: the contract separating the OPORD body from role-specific annex detail.
- `schema-files/frago-scope-change.schema.json`: the FRAGO contract that separates mission scope/authority changes from an annex update.
- `rehearsal-to-ccir-router.js`: converts rehearsal friction points and decision points into CCIR alerts/decision packets.
- `run-rehearsal-to-ccir-fixtures.js`: fixtures for medium/high/sensitive rehearsal routing.
- `information-to-operations-cycle.md`: the flow of information collection, evaluation, CCIR, running estimate, SITREP, decision packet, and FRAGO change.
- `schema-files/information-report.schema.json`: the contract for raw information intake and source/CCIR/handling metadata.
- `schema-files/intelligence-assessment.schema.json`: the contract for an evaluated piece of information's confidence, operational impact, and recommended output.
- `information-to-operations-router.js`: converts an information report/assessment into a CCIR alert, decision packet, SITREP, or FRAGO scope-change draft.
- `run-information-to-operations-fixtures.js`: fixtures for order change, FFIR SITREP, and EEFI release-block routing.
- `personnel-continuity-model.md`: a model for role continuity, succession, vital records, degraded mode, and rotation gate.
- `schema-files/continuity-plan.schema.json`: the contract for essential function, successor chain, vital records, and degraded mode.
- `continuity-drill-runner.js`: converts a role loss/rotation event into successor activation and paused functions.
- `run-continuity-drill-fixtures.js`: fixtures for a Commander-unavailable and an S6-rotation continuity drill.
- `ai-special-operations-tf.md`: converts US military SOF principles into an AI high-risk task force operating model.
- `schema-files/sof-tf-charter.schema.json`: the contract for SOF TF activation, cell separation, context isolation, enablers, and rehearsal.
- `sof-tf-activation-runner.js`: projects the SOF TF charter into go/no-go, approval gate, context distribution, and preflight block.
- `run-sof-tf-fixtures.js`: fixtures for valid SOF TF activation and blocking an unbounded TF.
- `department-collaboration-runner.js`: projects the collaboration charter into relationship edges, missing liaisons, commander queue, and preflight block.
- `run-department-collaboration-fixtures.js`: fixtures for valid cross-functional collaboration and blocking siloed collaboration.
- `force-structure-change-runner.js`: projects an organizational change order into a preflight block, commander queue, transition task, documentation queue, and readiness requirement.
- `run-force-structure-change-fixtures.js`: fixtures for a justified organizational creation and blocking an unjustified expansion.
- `schema-files/model-force-assignment-plan.schema.json`: contract for mission profile, immutable model profiles, billets, routing, assurance, PACE, authority, budget, and reassessment.
- `model-force-assignment-runner.js`: projects model billets, escalation paths, assurance status, PACE, resource demand, blocks, and commander decisions.
- `run-model-force-assignment-fixtures.js`: fixtures for a validated mixed model force and blocking an unready model monoculture.
- `schema-files/model-registry.schema.json`: immutable model inventory and per-task readiness source contract.
- `schema-files/model-assignment-request.schema.json`: mission billet demand and selection constraint contract.
- `model-assignment-compiler.js`: hard-filter-then-score deterministic assignment compiler.
- `schema-files/integrated-mission-preflight.schema.json`: current-wave agent, receipt, and billet binding contract.
- `integrated-mission-preflight-runner.js`: combined routing and model assignment dispatch gate.
- `schema-files/model-usage-event.schema.json`: operational model-use evidence contract.
- `run-model-force-v0.2-fixtures.js`: integrated compiler, dispatch, and unsafe-case regression suite.
- `repository-artifact-store.js`: Git-identified journaled JSON/file artifact persistence utility.
- `repository-artifact-verify.js`: pending-transaction, manifest-history, sidecar, and artifact-integrity verifier/recovery CLI.
- `schema-files/repository-artifact-manifest.schema.json`: repository namespace and artifact evidence manifest contract.
- `run-repository-artifact-isolation-fixtures.js`: same-ID cross-repository isolation, overwrite, traversal, and CLI integration fixture.
- `run-repository-artifact-concurrency-fixtures.js`: 24-writer locking and stale-lock recovery fixture.
- `run-repository-artifact-recovery-fixtures.js`: interrupted-write recovery and tamper-detection fixture.
- `verification-runner.js`: shell-free exact-argv candidate verification and receipt issuer.
- `schema-files/verification-plan.schema.json`: repository-state-bound verification command plan.
- `schema-files/verification-receipt.schema.json`: executable/output/repository-state proof receipt.
- `autonomous-improvement-controller.js`: receipt, parent lineage, and approval-consumption decision gate.
- `run-verification-runner-fixtures.js`: shell, inline code, stale state, mutation, and receipt integrity fixture.
- `run-self-improvement-fixtures.js`: proof-carrying adaptive decision and persistence integration fixture.
- `validation-suite-runner.js`: unified shell-independent whole-repository proof gate.
- `role-document-access-policy.md`: the policy that lets each agent read only the documents fixed for its role, duty, and authority.
- `schema-files/document-access-manifest.schema.json`: the per-mission document access manifest contract.
- `document-access-runner.js`: a manifest-based runner producing an allowed/denied document projection.
- `run-document-access-fixtures.js`: fixtures for role-scoped document reading and blocking overbroad access.
- `research-compendium.md`: the collection of all research material and interpretation.

Documents to add next:

- The current deep research/documentation/runtime contract queue is left in completed status.
- The next expansion opens as a separate queue once the user designates a new priority.

## Multinational Doctrine Consistency Audit

Purpose: use US military material as the baseline, but cross-check against official NATO/UK/Canadian/Korean sources so that current policy does not harden US-military-only assumptions into universal rules.

Official source families checked:

- NATO/Allied: AJP-01 Allied Joint Doctrine official GOV.UK publication page and PDF.
- UK: JDP 0-01 UK Defence Doctrine, JDP 01 UK Joint Operations Doctrine, JDP 04 Understanding and Decision-making, UK NATOTerm supplement.
- Canada: Canadian Armed Forces public page, DND reports/publications, CAF Ethos: Trusted to Serve.
- Korea: Ministry of National Defense (MND), Korea Law Information Center, Korea Institute for Defense Analyses (KIDA).
- US: ADP 6-0, JCS authorities focus paper, existing force management and SOF anchors.

Key judgments:

- `S2/S3/S4/S6` may look like US military/US Army-style staff names, so they are used only as the framework's internal function IDs.
- `COMMANDER` is the final decision authority, not an actual general/commander rank.
- The OPORD five-paragraph format is kept as the runtime normalization contract, but NATO/UK/local annex naming differences are handled as aliases.
- ROE/legal support is used only as a tool-use control analogy. Law, personal data, public disclosure, and actual organizational impact require a local jurisdiction gate.
- DOTMLPF-P is a US-derived checklist. In multinational application, it is presented alongside a capability lifecycle review.
- USSOCOM SOF Truths are used only as an AI high-risk TF heuristic. They are not used to represent another country's special operations doctrine.

Deliverables:

- `docs/multinational-doctrine-consistency-review.md`
- `schema-files/doctrine-consistency-review.schema.json`
- `sample-payloads/valid-doctrine-consistency-review.json`
- `sample-payloads/invalid-doctrine-consistency-review-us-only.json`
- `doctrine-consistency-runner.js`
- `run-doctrine-consistency-fixtures.js`
- `doctrine-consistency-fixtures/README.md`

Verification criteria:

- At least 4 source families.
- At least 3 non-US source families.
- The `adopt_us_only` disposition is prohibited.
- Alias handling is mandatory for role/staff terminology findings.
- A jurisdiction gate is mandatory for ROE/legal findings.
- Documentation updates to the source-map, compendium, schema, sample, and runner are mandatory.

## Controls Doctrine Operator Skill

Purpose: as the number of documents grows, agents run into the problem of blindly reading the entire corpus. To reduce this, a Codex skill was built to proceduralize task routing, source discipline, validation command selection, and the self-improvement loop.

Deliverables:

- `codex-skills/controls-doctrine-operator/SKILL.md`
- `.claude/skills/controls-doctrine-operator/SKILL.md`
- `codex-skills/controls-doctrine-operator/references/document-routing.md`
- `codex-skills/controls-doctrine-operator/references/self-improvement-loop.md`
- `codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js`
- `install-ai-cli-skills.sh`

Operating principles:

- First, map the request to a document family using the router.
- When the user writes directly, the user is treated as the final decision authority, and the AI performs a briefing/recommendation/validation role.
- When the AI acts on the user's behalf, document access and execution scope are restricted by role, department, authority, task, and need-to-know.
- The Claude Code CLI project skill calls the same router and coverage gate, so it shares the same document system as the Codex skill.
- The install script checks/creates the skill folders for the Codex CLI and Claude Code CLI and installs each skill as a symlink.
- Read only the necessary primary docs, and confirm the evidence in the source-map.
- A runtime contract change updates the schema, valid sample, invalid sample, runner, and fixture together.
- The router scans the repo inventory and connects Markdown/HTML documents, JSON schemas, sample/runtime payloads, fixtures, runner/prototype scripts, and skill metadata to a route category.
- After a task, an AAR question identifies routing gaps, validation gaps, and source-map gaps.
- If a gap has repeat value, the skill reference/script itself is updated.

Verification:

- Ran `route_controls_docs.js` against 3 representative questions to confirm routing for authority/release, schema/fixture, and multinational source verification.
- Confirmed, per `node codex-skills/controls-doctrine-operator/scripts/route_controls_docs.js --coverage .`, that of 329 routable artifacts, 329 were routed and 0 were unrouted.
- The skill validator was run against a temporary PyYAML target and passed.

## Phase 14A: GitHub Actions Native Execution Identity

Purpose: replace policy-pinned but builder-restated GitHub metadata with a provider-signed OIDC token that is verified before execution evidence enters quorum.

Primary sources:

- GitHub Actions OIDC reference: https://docs.github.com/en/actions/reference/security/oidc
- GitHub reusable-workflow OIDC: https://docs.github.com/en/actions/how-tos/secure-your-work/security-harden-deployments/oidc-with-reusable-workflows
- GitHub live OIDC discovery: https://token.actions.githubusercontent.com/.well-known/openid-configuration
- GitHub artifact attestations: https://docs.github.com/en/actions/concepts/security/artifact-attestations
- IETF JWT RFC 7519: https://www.rfc-editor.org/rfc/rfc7519.html
- IETF JWK RFC 7517: https://www.rfc-editor.org/rfc/rfc7517.html

Findings:

1. GitHub's public issuer is exact and its discovery document currently advertises `RS256`. Algorithm and issuer selection must be fixed by policy, not accepted from the token.
2. The JOSE `kid` selects a key but does not authorize it. The selected JWK must come from the exact manifest-pinned trust bundle, use RSA signing material, and be accepted only within the bundle's review window.
3. Subject alone is insufficient. GitHub introduced immutable owner/repository IDs in newer default subjects, while older repositories may retain a name-based subject. Exact `sub` is still required, but independent `repository_id` and `repository_owner_id` claim pins prevent namespace reuse.
4. `workflow_ref` and `workflow_sha` identify the calling workflow context. The ref may name a branch, so the policy pins it exactly while requiring the signed `workflow_sha` to equal the repository commit. `job_workflow_ref` and `job_workflow_sha` identify a reusable workflow, whose ref is pinned directly by full commit SHA.
5. `runner_environment` distinguishes only `github-hosted` from `self-hosted`. It does not authenticate a runner group, machine, cloud account, infrastructure, region, or zone.
6. Unknown topology cannot become unique topology. GitHub-hosted infrastructure, region, and zone are projected as shared unknown components, so multiple GitHub jobs remain one correlated domain.
7. Self-hosted runners require a separate authenticated host/runner adapter. Treating a label, run ID, or unverified environment variable as infrastructure identity would allow quorum inflation.
8. JWT time claims are evaluated at evidence admission with bounded age and clock skew. The token's expiry also caps native execution evidence validity.
9. OIDC authenticates job context; it does not prove exact code execution. The existing builder-and-verifier DSSE remains necessary to bind code, image, lockfile, harness, argv, tools, network, sandbox, invocation, repository state, and result.
10. Artifact attestations are useful for release artifacts, but a per-verifier execution record needs a direct subject/result binding. Phase 14A therefore uses OIDC as an additional identity proof inside the existing execution-evidence architecture rather than treating artifact attestation as a complete verifier result.
11. Offline re-verification requires the exact compact JWT and exact trust material. The token is therefore persisted in the access-controlled, ignored artifact store and never printed by the adapter CLI.
12. HTTPS retrieval and human approval of the JWKS artifact remain roots of trust. Phase 13 transparency does not currently monitor GitHub OIDC signing-key equivocation or provide historical JWKS transparency.

Implemented contracts:

- `GitHubActionsOIDCTrustBundle` schema, digest, normalized JWK rules, retrieval window, runner, and sample.
- `GitHubActionsOIDCEvidence` schema, exact compact token retention, projection digest, runner, and sample.
- `VerifierRuntimePolicy` v0.3 native profile and `VerifierExecutionEvidence` v0.3 native reference.
- strict JWT parsing, `RS256` signature verification, exact identity/claim/time checks, and conservative failure-domain derivation.
- manifest loading in receipt and comparative-attestation quorum paths.
- adversarial fixtures for algorithm, key, signature, identity, workflow, runner, time, trust-bundle, projection, repository-state, and missing-evidence failures.

Residual limits:

- no GitHub Enterprise Server issuer support;
- no self-hosted or larger-runner identity adapter;
- no GitHub JWKS transparency monitor or historical key archive;
- no proof of physical runner isolation or sandbox enforcement;
- no enterprise/self-managed provider, local host, or TEE adapter;
- no authority expansion from successful OIDC or quorum verification.

## Phase 14B: GitLab CI Native Execution Identity

Purpose: replace policy-pinned but builder-restated GitLab metadata with a provider-signed GitLab.com ID token verified before execution evidence enters quorum.

Primary sources:

- GitLab ID token authentication and claims: https://docs.gitlab.com/ci/secrets/id_token_authentication/
- GitLab `id_tokens` YAML contract: https://docs.gitlab.com/ci/yaml/#id_tokens
- GitLab cloud trust and stable-ID guidance: https://docs.gitlab.com/ci/cloud_services/
- GitLab Runner model: https://docs.gitlab.com/runner/
- GitLab-hosted runner isolation: https://docs.gitlab.com/ci/runners/hosted_runners/
- GitLab.com live discovery: https://gitlab.com/.well-known/openid-configuration
- GitLab.com live JWKS: https://gitlab.com/oauth/discovery/keys

Findings:

1. GitLab.com currently publishes `https://gitlab.com` as issuer, `https://gitlab.com/oauth/discovery/keys` as JWKS URI, and `RS256` as its ID-token signing algorithm. The adapter fixes all three instead of trusting token-selected endpoints or algorithms.
2. `id_tokens` allows a scalar or array audience. The first Cannae profile requires one exact scalar audience so the runtime contract and projected identity remain unambiguous.
3. Exact subject remains required but is not sufficient because GitLab permits project-specific subject customization. Stable numeric project and namespace IDs are pinned with path claims, following GitLab's guidance to combine stable IDs with paths.
4. Source `project_*` and `namespace_*` claims can describe a merge-request source project, while `job_project_*` and `job_namespace_*` identify the project running the job. Phase 14B requires both sets to match, intentionally excluding fork and cross-project pipeline identities from this first profile.
5. `ref_protected`, `ref_type`, and `ref_path` are signed claims. The profile requires a protected branch and exact fully qualified ref; tags and unprotected refs are rejected.
6. `ci_config_ref_uri` and `ci_config_sha` are null when the top-level pipeline definition is not in the same project. The profile requires non-null same-project config, an exact ref URI, and `ci_config_sha=sha`.
7. A same-project top-level config claim does not transitively identify every remote include. Exact verifier code, dependency, harness, image, and policy digests remain necessary, and remote include closure remains a residual limitation.
8. `runner_environment` distinguishes `gitlab-hosted` from `self-hosted`; `runner_id` identifies a runner but not necessarily the runner manager, ephemeral machine, cloud project, region, or zone.
9. GitLab-hosted runner documentation describes fresh single-job VMs for standard GitLab.com hosted jobs, but the ID token does not carry a cryptographic machine or topology identity. Infrastructure, region, and zone must remain shared unknown values.
10. Pipeline, job, and runner IDs are retained as signed trace fields. They are deliberately excluded from failure-domain derivation so repeated jobs cannot inflate quorum diversity.
11. GitLab documents token expiry as the job timeout, or five minutes when no timeout is configured. Independent maximum-age and clock-skew policy still applies at admission.
12. OIDC proves provider-issued job context, not exact verifier execution. The separate builder/verifier DSSE remains the result-bearing proof, and no OIDC success grants release or policy authority.

Implemented contracts:

- `GitLabCIOIDCTrustBundle` schema, canonical digest, normalized key rules, freshness window, runner, and sample.
- `GitLabCIOIDCEvidence` schema, exact compact token retention, normalized numeric-ID projection, digest, runner, and sample.
- provider-neutral runtime-policy v0.3 native adapter union and execution-evidence v0.3 dispatch.
- strict signature, identity, time, stable source/job ID, protected-ref, same-project config, clean-commit, and conservative-domain checks.
- provider-specific manifest loading in receipt and comparative-attestation quorum paths.
- 25 adversarial fixtures including audience arrays, source/job divergence, false runner diversity, missing trust material, and missing nested evidence.

Residual limits:

- no GitLab Self-Managed or Dedicated issuer profile;
- no self-hosted runner or authenticated runner-manager/machine adapter;
- no immutable closure proof for remote CI includes;
- no GitLab JWKS transparency monitor or historical key archive;
- no proof of physical runner infrastructure, region, zone, or sandbox enforcement;
- no local-host or TEE adapter;
- no authority expansion from successful OIDC or quorum verification.

## Phase 15: Operational Skill Mission Lifecycle

Purpose: convert the doctrine skill from a document-routing guide into a fail-closed operational path that applies routing, context, evidence, reporting, and learning controls to real delegated work.

Synthesis from the existing doctrine and runtime:

1. A documented requirement to route every wave is not sufficient when each agent can still begin work before the requirement is checked.
2. The lifecycle entry point must generate receipts itself, compare them with the expected agent roster, and refuse to issue execution context when preflight is blocked.
3. The S3 routing role is a control-plane identity. It can coexist with an agent's actual operational role, department, task, and delegated authority inside the context pack.
4. A document path alone cannot preserve shared understanding over time. Context packs bind each selected file to a digest and bind the router/controller code plus doctrine revision used to select it.
5. A model assignment is usable only when a ready integrated preflight binds the same mission, wave, agent, and billet. Model family or capability labels do not create authority.
6. A completion statement is not evidence. Complete agent results cite exact manifest-backed work artifacts, while control metadata such as plans, receipts, and context packs is excluded as proof of task performance.
7. AAR learning should create a next-wave queue, not a claim that future improvement has already executed. Ordinary findings enter an existing finite campaign; approval, release, policy, authority, risk, push, and merge effects return to the human user.
8. One controller used by both Codex and Claude reduces procedural drift. The wrappers resolve one repository runtime while retaining separate native skill installations.
9. Expiration is not completion. A wave with no admitted report cannot truthfully enter the normal report/AAR closeout path after expiry. Append a separate immutable `MissionWaveTermination`, preserve every historical artifact (including older routing schemas), and keep readiness, continuation, and release ungranted. Abort/supersession requires a fresh, exact USER decision; an unresolved tool result requires reconciliation, not administrative erasure. This is an engineering synthesis of the local lifecycle, not a new external military-doctrine claim.

Implemented surfaces:

- `skill-mission-controller.js`
- `docs/skill-operational-mission-lifecycle.md`
- `schema-files/mission-wave-plan.schema.json`
- `schema-files/agent-context-pack.schema.json`
- `schema-files/mission-wave-report.schema.json`
- `schema-files/mission-wave-closeout.schema.json`
- `schema-files/mission-wave-termination-request.schema.json`
- `schema-files/mission-wave-termination.schema.json`
- `run-skill-mission-controller-fixtures.js`
- Codex and Claude `operate_controls_mission.js` wrappers

Residual limits:

- the controller is invoked by an operator or agent and is not a persistent background scheduler;
- queued adaptive work still requires supervisor, verification, attestation, checkpoint, and promotion evidence from the bounded self-improvement runtime;
- local process invocation cannot itself intercept every external tool call;
- production authorization, identity provider, event service, approval UI, distributed coordinator, and sandbox enforcement remain external;
- no lifecycle result grants commit, push, merge, risk acceptance, policy change, authority change, or release permission.

## Phase 16: Enforced Dispatch And Resumable Execution

Research question:

> How can a routed agent be required to present current, repository-bound
> authority at every covered tool call, and how can an interrupted session
> continue without inheriting stale authority?

Primary product sources:

- Codex lifecycle hooks: https://learn.chatgpt.com/docs/hooks
- Claude Code hooks reference: https://code.claude.com/docs/en/hooks
- Claude Code settings reference: https://code.claude.com/docs/en/settings
- Claude Agent SDK session behavior: https://code.claude.com/docs/en/agent-sdk/sessions

Findings:

1. A context pack is necessary but not sufficient. It proves what the agent was
   told, while a pre-tool admission proves whether that exact provider identity
   may perform that exact current action.
2. A policy supplied by the acting agent is not authority. The exact canonical
   policy-draft digest and agent/provider/policy tuple must be present in the
   retained-authority mission plan before `open`, and the controller must
   compile the final policy against the persisted plan and context pack.
3. Provider hooks should adapt one common decision contract. Policy, lease,
   repository state, replay state, and checkpoints remain provider-neutral.
4. An allow should not auto-approve the provider permission prompt. Cannae
   admission and native provider permission are cumulative gates.
5. Deny-by-default requires exact tool names, an exact action from the agent's
   plan `allowed_actions`, and deterministic argument
   constraints. Regex-only or prose-only tool scopes cannot support a strong
   execution claim.
6. Repository continuity is a state chain, not a single dispatch-time hash.
   One admitted tool is in flight at a time; the next request waits for a
   post-tool checkpoint carrying the exact tool/input binding, provider-result
   digest, effect disposition, resulting HEAD, and worktree fingerprint.
7. A tool-use ID is a transaction identifier. Reusing it is replay even when
   the input bytes are identical.
8. One mission-agent assignment needs one lease lineage. Repository-scoped
   issuance locking must reject concurrent initial issuance and a second
   provider session. In one repository-bound wave, covered-tool agents need
   ordered lease handoff. The local controller cannot safely infer a parallel
   read-only exception from caller-declared operation classes. Parallel
   worktrees become separate repository-scoped sub-missions and need a later
   integration wave.
9. Resume is a new admission boundary. Session history may be restored, but
   the old lease is interrupted and explicit resume creates a new nonce,
   expiry, and repository baseline only from an exact checkpoint.
10. Session-start hooks cannot be treated as an authority grant. They can
   reconstruct context and invalidate stale authority, while protected
   `PreToolUse` remains the executable gate.
11. Codex currently covers shell, `apply_patch`, MCP, and most local function
   tools, but not hosted tools and every specialized path. Codex also does not
   expose a distinct subagent identity in the documented `PreToolUse` input.
   Strict per-agent binding therefore uses separate top-level sessions or an
   external gateway.
12. Claude Code can expose a subagent `agent_id` to hooks, but project settings
    remain client-side. Managed endpoint policy is required when a user must
    not disable or replace hooks.
13. Repository-local hooks are a deterministic guardrail, not a complete
    security boundary. A production design makes an independently protected
    tool gateway the only side-effect path and applies the same contracts
    there.
14. Hook process launch failure is distinct from controller failure. The
    adapter can translate caught controller errors to native deny output, but
    only managed deployment, native deny rules, and process/tool isolation can
    address a skipped or disabled hook.
15. Mission `open` should report context readiness separately from executable
    authority. A dispatch-controlled wave should not accept a complete result
    until every agent has one settled lease lineage and no unresolved request.

Implemented surfaces:

- `DispatchToolPolicy`, `AgentDispatchLease`, `ToolAdmissionEvent`, and
  `AgentExecutionCheckpoint` schemas and samples;
- `dispatch-runtime-controller.js`;
- `dispatch-hook-adapter.js`;
- `install-dispatch-hooks.js`;
- `skill-mission-controller.js` context-authority separation and settled-lineage
  report gate;
- `MissionWavePlan.dispatch_control` exact one-policy-per-agent authorization;
- Codex and Claude runtime and hook wrappers;
- `run-dispatch-runtime-fixtures.js`;
- `docs/enforced-dispatch-and-resume.md`.

Residual limits:

- no authenticated human policy signature or remote authorization service;
- no protection when an agent can rewrite the mission plan, artifact store,
  issuer, hook configuration, or runtime;
- no complete command-semantic classifier;
- no universal provider-tool interception;
- no cancellation of a tool that was already admitted and began executing;
- no all-or-nothing transaction across multi-artifact policy, lease, and
  checkpoint transitions;
- no partition-tolerant distributed state machine;
- no non-bypassable claim for repository-local hooks;
- no production MCP/tool gateway or multi-user scheduler.

## Phase 17A: Protected Tool Gateway Contract

Research question:

> How can an external tool boundary authenticate the acting principal, bind one
> exact current authorization to one exact tool input, survive retries and
> crashes, and refuse to report success when the execution outcome is unknown?

Primary standards:

- NIST SP 800-207, Zero Trust Architecture:
  https://csrc.nist.gov/pubs/sp/800/207/final
- NIST SP 800-207A, cloud-native zero-trust access control:
  https://csrc.nist.gov/pubs/sp/800/207/a/final
- NIST SP 800-53 Rev. 5.1, AU-3 and AU-9:
  https://csrc.nist.gov/pubs/sp/800/53/r5/upd1/final
- RFC 8705, mutual-TLS client authentication and certificate-bound tokens:
  https://www.rfc-editor.org/rfc/rfc8705.html
- RFC 9449, DPoP:
  https://www.rfc-editor.org/rfc/rfc9449.html
- RFC 9700, OAuth 2.0 Security Best Current Practice:
  https://www.rfc-editor.org/rfc/rfc9700.html
- etcd v3.6 transaction model:
  https://etcd.io/docs/v3.6/learning/api/

Findings:

1. A gateway is an authorization boundary only if it authenticates the
   principal and appraises current authority for the exact resource operation.
   Being inside a provider process, repository, network, or prior approved
   session is not authority.
2. Identity and gateway configuration are separate trust inputs. The common
   contract can bind their canonical digests, but an external trusted adapter
   must establish issuer, audience, proof of possession, freshness, revocation,
   deployment, and configuration provenance.
3. The acting model cannot be both claimant and independent verifier. A CLI
   argument containing a digest is integration material, not proof that its
   source was trustworthy.
4. Phase 16 admission remains necessary. The gateway should reload the exact
   dispatch lease, policy, checkpoint, repository binding, and repository state
   rather than restating policy in a second caller-controlled format.
5. Raw tool input and audit retention have different confidentiality
   requirements. The gateway needs raw input transiently to calculate the
   canonical digest and execute, while durable ordinary artifacts need only the
   digest. Low-entropy secrets still require protected transport and secret
   handling because hashing is not redaction.
6. Tool name, canonical input digest, and operation class are one binding. If
   the gateway request labels a process execution as repository-read, the exact
   admission must be cancelled and the request denied.
7. A tool-use ID prevents dispatch replay; a gateway idempotency key prevents
   transaction replay. The same idempotency key may return retained state only
   for an identical canonical request. Changed bytes are a conflict.
8. Authorization and execution are separate transitions. A concrete
   `executing` event is the single current execution token, so a stale
   authorization or earlier retry cannot later submit a result.
9. A committed transaction means the tool outcome was correlated and durably
   recorded. It can record either a successful or failed invocation; it is not
   synonymous with business success, wave completion, or release.
10. Cancellation is safe only before execution and only when the exact raw
    input can settle the exact dispatch admission. A changed input cannot be
    used to manufacture an abort.
11. Once execution may have begun, absence of a result is not evidence of
    failure or no effect. The correct state is `recovery_required`, with unknown
    effects and a blocked lease pending external reconciliation.
12. Append-only request, decision, receipt, and predecessor-linked event
    artifacts make crash recovery reconstructable. Existing admission,
    checkpoint, receipt, or terminal-event evidence should be completed, not
    replayed or overwritten.
13. A shared-filesystem lock can serialize a reference implementation in one
    coherent filesystem. Transaction-ID and idempotency-key uniqueness must be
    checked under the same lock before a second request is persisted. It cannot
    establish partition-tolerant exclusivity. Multi-host production needs a
    linearizable coordinator and storage-side fencing.
14. `managed_exclusive` is a deployment claim, not a schema decoration. The
    Phase 17A reference controller must reject it because it cannot prove that
    its own process, configuration, network, sandbox, and all alternate tool
    paths are independently protected.
15. Tool execution authorization does not imply commit, push, merge, policy
    change, risk acceptance, authority change, or release. Every gateway
    contract preserves USER final decision authority and leaves those effects
    false.

Implemented surfaces:

- `schema-files/tool-gateway-request.schema.json`;
- `schema-files/tool-gateway-decision.schema.json`;
- `schema-files/tool-execution-receipt.schema.json`;
- `schema-files/tool-gateway-transaction-event.schema.json`;
- valid and adversarial sample payloads for all four contracts;
- `protected-tool-gateway.js`;
- exact dispatch-admission cancellation in `dispatch-runtime-controller.js`;
- `run-protected-tool-gateway-fixtures.js`;
- `docs/protected-tool-gateway-contract.md`;
- Codex and Claude `operate_protected_gateway.js` wrappers and routing
  instructions.

Measured behavior:

- exact admission, begin token, result correlation, receipt, and terminal event;
- no raw input in the persisted gateway request;
- idempotent equivalent replay, changed-request conflict, and reused
  transaction conflict before a second write;
- principal-digest substitution denial;
- managed-assurance overclaim denial;
- raw-input digest denial before dispatch authority is consumed;
- operation-class substitution cancellation;
- exact authorized-but-unstarted abort;
- exact cancellation or lease blocking for a crash-retained allow admission
  that has no gateway decision;
- rejection of begin/commit timestamps that precede retained transaction
  events;
- executing unknown-outcome transition to blocked recovery.

Residual limits and Phase 17B work:

- no production mTLS, DPoP, workload-OIDC, revocation, or identity-provider
  adapter;
- no MCP, shell, filesystem, network, or delegation executor adapter;
- no independently protected policy/configuration service;
- no OS/container sandbox or egress enforcement that removes side paths;
- no distributed linearizable coordinator or storage-enforced fencing;
- no protected secret transport or confidential raw-input vault;
- no multi-user permission, break-glass, incident, or reconciliation service;
- no deployment attestation proving gateway code and configuration;
- no adversarial production test proving tools are unreachable when the
  gateway is down;
- no production-execution, deployment-verification, or release authority.

## Phase 17B1: Authenticated Gateway Identity Admission

Research question:

> How can the protected gateway derive the acting principal from a live,
> sender-constrained channel instead of trusting a caller-provided digest,
> while preserving one-use freshness and refusing to overclaim deployment
> exclusivity?

Primary standards and runtime sources:

- SPIFFE X.509-SVID:
  https://spiffe.io/docs/latest/spiffe-specs/x509-svid/
- SPIFFE Workload API:
  https://github.com/spiffe/spiffe/blob/main/standards/SPIFFE_Workload_API.md
- TLS 1.3, RFC 8446:
  https://www.rfc-editor.org/rfc/rfc8446.html
- TLS 1.3 channel bindings, RFC 9266:
  https://www.rfc-editor.org/rfc/rfc9266.html
- OAuth 2.0 mutual-TLS client authentication, RFC 8705:
  https://www.rfc-editor.org/rfc/rfc8705.html
- OAuth 2.0 Security Best Current Practice, RFC 9700:
  https://www.rfc-editor.org/rfc/rfc9700.html
- Node.js TLS exporter API:
  https://nodejs.org/api/tls.html#tlssocketexportkeyingmateriallength-label-context

Findings:

1. Identity must be observed by the resource boundary. A principal projection
   assembled by the acting agent is a claim. The gateway-side TLS stack can
   establish certificate possession, protocol, peer authorization, endpoint
   certificates, and channel exporter state.
2. An X.509-SVID is selected by exact SPIFFE URI, not by display name or first
   favorable SAN. Admission should require one URI SAN, one non-root path, one
   configured trust domain, one pinned root, a non-CA leaf, ordered signatures,
   and current certificate validity.
3. TLS client authentication proves possession in one handshake but does not
   by itself bind an application request retained later. A TLS exporter binds
   the higher-layer principal proof to that exact negotiated channel.
4. The RFC 9266 profile supplies a stable interoperable choice:
   `EXPORTER-Channel-Binding`, empty context, and 32-byte output. The audit
   artifact stores only its SHA-256 digest.
5. A live channel is not sufficient freshness for a queued transaction. A
   gateway-signed unpredictable 32-byte challenge must bind transaction,
   mission, wave, agent, provider, provider session, gateway, repository,
   policy, issue time, and expiry.
6. Challenge state is durable security state. One challenge can produce one
   principal evidence artifact, and its evidence cannot enter another
   transaction. Repository-manifest custody makes stale/replay checks
   reconstructable after process restart. An identity-specific repository
   lease serializes challenge issuance and evidence consumption on one coherent
   filesystem; distributed deployments still need a linearizable coordinator.
7. The policy, challenge, and observation form separate claims. The policy is
   USER-controlled trust configuration; the challenge proves transaction
   freshness; the observation proves what the adapter saw. Exact references
   are repeated in request, decision, events, and receipt.
8. The adapter signature and signed-artifact digest address different
   failures. The digest detects content mismatch and binds the signature bytes;
   the signature prevents a caller from changing the observation and repairing
   only the digest.
9. The authenticated-principal projection must be deterministic:
   authentication method `mtls`, issuer `spiffe://<trust-domain>`, subject
   exact SPIFFE ID, audience exact gateway audience, credential digest exact
   client leaf, proof digest exact exporter, session exact challenge, and
   timestamps exact evidence window.
10. Revocation is policy state, not a model conclusion. The reference policy
    can revoke exact principal IDs or certificate digests. Production
    distribution, rotation, CRL/OCSP, and Workload API operation remain outside
    the prototype.
11. Every gateway transition that changes state should re-appraise the
    manifest evidence and current time. Conversation history, a previous
    successful `admit`, or a still-open provider session does not renew
    expired identity.
12. Re-authentication cannot silently rewrite an original request. A future
    long-running recovery path needs a separate USER-controlled recovery
    credential/event contract while preserving the original identity chain.
13. Exact mTLS identity does not prove gateway deployment integrity. The
    adapter private key, policy writer, server configuration, executor,
    sandbox, network routes, and alternate tool paths can remain correlated
    with the acting process.
14. `authenticated_reference` is therefore a useful but bounded assurance
    level. `managed_exclusive` remains a separate deployment assertion that
    requires independent key/configuration custody, provider executors,
    sandbox/egress enforcement, side-path denial, and deployment evidence.
15. Human authority remains unchanged. Identity evidence authorizes at most
    one otherwise policy-admissible tool transaction and cannot authorize
    production, commit, push, merge, release, risk acceptance, policy change,
    or authority change.

Implemented surfaces:

- `GatewayIdentityPolicy`, `GatewayIdentityChallenge`, and
  `GatewayPrincipalEvidence` schemas with valid and adversarial samples;
- `ToolGatewayRequest`, `ToolGatewayDecision`, `ToolExecutionReceipt`, and
  `ToolGatewayTransactionEvent` v0.2 immutable identity references;
- shared canonical signing, digest, certificate, SPIFFE, freshness, revocation,
  and projection verification in `gateway-identity-evidence.js`;
- policy persistence, signed challenge issuance, live `TLSSocket` observation,
  signed evidence creation, manifest reload, one-use, and replay appraisal in
  `gateway-identity-adapter.js`;
- authenticated-reference integration and transition-time revalidation in
  `protected-tool-gateway.js`;
- `run-gateway-identity-adapter-fixtures.js`;
- `docs/gateway-identity-admission.md`;
- equivalent Codex and Claude routing and operation instructions.

Measured behavior:

- a real ephemeral Ed25519 CA, server certificate, and SPIFFE client
  certificate complete an authorized TLS 1.3 mutual handshake;
- client and server derive equal exporter bytes;
- the gateway-side observation creates one valid signed evidence chain;
- that chain authorizes, begins, and commits one Phase 16-bound gateway
  transaction without a caller-provided principal digest;
- request identity references remain exact in decision and receipt;
- stale challenge/evidence, cross-transaction replay, challenge reuse,
  principal revocation, exporter substitution with repaired digest, signature
  tamper, and leaf/SPIFFE substitution are rejected.

Residual limits:

- policy approval and adapter key custody are not independently managed;
- the direct chain verifier is a documented PKIX subset, not a general RFC
  5280 path builder;
- no Workload API client, managed rotation service, CRL/OCSP distribution, or
  hardware-backed key;
- no production-grade provider executor, sandbox, egress enforcement, or
  side-path denial at Phase 17B1;
- no independent gateway deployment/configuration attestation;
- no multi-host linearizable transaction coordinator or storage-side fencing;
- no long-running re-authenticated recovery contract;
- no production execution, managed exclusivity, deployment verification, or
  release authority.

## Phase 17B2A: Protected Process Execution Evidence

### Research Question

How can the reference gateway execute one local process without accepting an
agent-authored command string, prove which policy and executable were used,
prevent automatic duplicate execution after a crash, and avoid overstating
unimplemented sandbox or network controls?

### Primary Findings

1. Node.js exposes an executable-plus-argv process API.
   `child_process.spawn(command, args, options)` keeps the executable and
   argument vector distinct, defaults `shell` to false, and permits exact cwd,
   environment, stdio, and timeout options. This is the appropriate primitive
   for an exact-command reference adapter. It does not itself make the child a
   sandbox.
2. Command injection must be prevented before process construction.
   CWE-78 describes the failure as externally influenced data changing an OS
   command. Escaping an arbitrary command string would retain parser and
   platform ambiguity. The stronger contract is to let the USER-controlled
   policy fix the complete executable and argv and let the runtime input select
   only one retained rule.
3. Privilege and syscall controls are separate evidence claims.
   Linux `no_new_privs` prevents `execve` from granting new privilege but does
   not create a general confinement boundary. Seccomp filter mode restricts
   syscalls and has explicit synchronization and privilege prerequisites.
   Neither can be inferred from `spawn`, a non-root UID, or a policy label.
4. OCI configuration shows that sandbox assurance is multidimensional.
   Namespaces, mounts, devices, resources, capabilities, seccomp, masked paths,
   and related controls are distinct runtime configuration. An executable,
   image, or runtime digest cannot prove that those controls were applied.
5. Container operation adds independent risk domains.
   NIST SP 800-190 separates image, registry, orchestrator, container runtime,
   and host risks. A later container adapter must retain and appraise evidence
   for each applicable layer rather than upgrade assurance from one image
   digest.
6. An execution receipt needs a durable claim marker before the side effect.
   Request idempotency prevents a second authorization record, but it cannot
   distinguish "authorized but never invoked" from "invoked and crashed before
   result." A signed, manifest-retained pre-execution envelope marks the
   transaction as claimed. Once present, the safe retry behavior is replay or
   reconciliation, never automatic process invocation.
7. Executor self-report is insufficient at commit.
   The gateway must reload policy, envelope, and observation bytes from the
   verified artifact manifest and reconstruct all command, transaction,
   result, time, and repository bindings. Otherwise a caller can pair protected
   input with a fabricated external result.
8. Direct-child termination is not process-tree containment.
   Killing the spawned child on timeout or output overflow does not prove that
   descendants are gone. The reference adapter records
   `process_tree_containment: false`; a cgroup, PID namespace, or equivalent
   provider control is required for a stronger claim.
9. A shebang introduces another executable.
   The kernel selects the script interpreter, while a policy that measures only
   the script would omit that executable from the evidence chain. The reference
   adapter therefore accepts only ELF or Mach-O executables. A native
   interpreter such as Node may be selected directly only when its digest and
   every code or script argument are fixed by policy.
10. User-space path appraisal has an unavoidable race.
    Digest checks at admission, immediately before spawn, and after process
    close narrow executable drift, but portable Node does not bind `spawn` to
    an already appraised file descriptor. An immutable executable mount or
    provider-native image/runtime evidence is required to eliminate a
    replace-execute-restore attack.

### Controls Interpretation

The bounded admission equation is:

```text
current dispatch and gateway authorization
+ exact retained policy and rule
+ measured executor and runtime
+ canonical ELF/Mach-O executable file and digest
+ exact argv/cwd/empty environment/no runtime-inserted shell/no stdin
+ signed envelope persisted before spawn
+ signed observation persisted after close
+ independent gateway bundle appraisal
= result may enter the execution receipt
```

The following are deliberately not terms in the Phase 17B2A equation:

- filesystem isolation;
- syscall filtering;
- `no_new_privs`, capability bounding, or privilege transition;
- process-tree containment;
- network or egress enforcement;
- exclusive tool routing;
- production or release authority.

Their policy values are fixed to false or unknown so downstream consumers
cannot confuse configuration intent with observed enforcement.

### Implemented Artifacts

- `schema-files/protected-executor-policy.schema.json`;
- `schema-files/protected-process-tool-input.schema.json`;
- `schema-files/protected-execution-envelope.schema.json`;
- `schema-files/protected-execution-observation.schema.json`;
- `protected-execution-evidence.js`;
- `protected-process-executor.js`;
- `ToolExecutionReceipt` v0.4 bounded evidence references;
- `run-protected-process-executor-fixtures.js`;
- `docs/protected-process-execution.md`;
- Codex and Claude protected-executor wrappers, routing, references, and
  mandatory operating guidance.

### Measured Behavior

- one real policy-pinned Node process creates signed envelope and observation
  artifacts and commits one exact receipt;
- replay returns the retained terminal transaction and does not increment an
  execution counter;
- a protected input paired with caller-declared fixture evidence cannot commit;
- a shebang script is rejected before gateway begin because its interpreter is
  not part of the executable measurement;
- rule substitution and executable file drift fail before process spawn;
- timeout is retained as a failed process result;
- a fault after process completion produces `recovery_required` and retry does
  not execute again;
- a rule that prohibits repository effects fails closed when the observed
  worktree changes;
- static valid/invalid contracts and both skill routing inventories validate.

### Residual Limits And Next Research

- The executor evidence key and policy approval path remain locally managed.
- The adapter file digest is measured locally and not independently attested.
- Repeated path and digest checks do not eliminate a
  replace-execute-restore race on a mutable executable filesystem.
- Empty environment does not prevent direct filesystem or network access by
  the executable.
- A policy-pinned native executable can still perform an indirect `exec` or
  create descendants; Phase 17B2A does not measure or contain those paths.
- Output is bounded and retained, but secret-aware redaction is not
  implemented.
- Direct child `SIGKILL` does not prove descendant termination.
- The shared-filesystem lease is not a multi-host consensus protocol.
- There is no provider-native filesystem, MCP, network, or delegation adapter.
- There is no adversarial deployment proof that all alternate executable paths
  are unavailable.

These gaps define the Phase 17B2B research boundary: exact image and runtime
configuration, mount and namespace policy, seccomp, `no_new_privs`, capability
and UID/GID state, cgroup/PID containment, network namespace and egress policy,
deployment identity, and tests that observe each claimed control directly.

## Phase 17B2B: OCI Linux Sandbox Provider

### Research Question

How can the protected gateway strengthen a bounded process claim into a
measured Linux container claim without confusing Docker configuration intent,
image identity, or provider self-report with direct enforcement evidence?

### Primary Findings

1. OCI Linux isolation is a composition, not one flag.
   The OCI Runtime Specification models PID, network, mount, IPC, UTS, user,
   cgroup, and time namespaces separately. An omitted namespace inherits the
   runtime namespace. Resources, capabilities, seccomp, masked/readonly paths,
   devices, and filesystem configuration are also independent fields.
2. Docker create is the correct pre-execution boundary.
   `docker container create` fixes image, process, mounts, security options,
   namespace modes, and cgroup limits without starting the target. Therefore a
   signed intent envelope can be retained before create, followed by a
   pre-start inspect appraisal and explicit start.
3. Image tags are mutable and pulls expand the authority surface.
   The provider must use an immutable `sha256:` image ID and `--pull never`.
   An image ID identifies local image content, but it does not prove source,
   signature, provenance, reproducibility, registry policy, or host trust.
4. Read-only configuration needs kernel-side confirmation.
   Docker's `ReadonlyRootfs` and bind-mount `RW: false` are necessary
   configuration evidence. `/proc/self/mountinfo` and denied writes provide
   the execution-side observation. Recursive read-only requires every
   repository submount to be read-only, not only the top bind.
5. Mountinfo VFS and superblock options must not be conflated.
   Overlay and bind observations may expose a read-only VFS mount while the
   underlying superblock reports `rw`. The probe evaluates the per-mount VFS
   options for the read-only claim and retains normalized options separately.
6. `no_new_privs`, capabilities, and seccomp are directly visible.
   `/proc/self/status` exposes four UID/GID values, five capability sets,
   `NoNewPrivs`, seccomp mode, filter count, and namespace PID projection. The
   provider requires non-root identities, all-zero capability sets,
   `NoNewPrivs: 1`, filter mode `2`, and at least one filter.
7. A seccomp label is weaker than an exact profile.
   Docker inspect retains the applied custom seccomp JSON. The provider
   compares that parsed object with a repository-retained profile whose bytes,
   source commit, and default action are policy-bound. `unconfined` is always
   rejected.
8. The general Moby default profile is one layer, not least privilege.
   Its default action is `SCMP_ACT_ERRNO` and it allows a broad set of common
   syscalls, with capability- and architecture-dependent rules. Dropping all
   capabilities disables capability-gated privileged rules, but an
   application-minimal syscall policy remains future work.
9. Cgroup configuration is directly readable under cgroup v2.
   `memory.max`, `pids.max`, and `cpu.max` can be compared with exact policy
   bytes, PID count, quota, and period. The provider requires unified cgroup
   v2 and rejects an unsupported daemon before gateway begin.
10. Process-tree containment requires a provider boundary.
    The target runs beneath Docker init in a private PID namespace and one
    resource-bounded container cgroup. The probe kills the target process
    group on timeout/output overflow, while provider timeout containment kills
    the container. Verified container exit and removal close the local
    reference lifecycle.
11. Network interface names alone are not portable egress evidence.
    Docker Engine documents `none` as an isolated network with loopback.
    Docker Desktop may still expose unaddressed tunnel device names. The
    provider therefore binds Docker `none` mode and directly requires only
    loopback to have addresses, no non-loopback address, no usable default
    route, and failure of a bounded outbound connection.
12. Docker inspect and an in-container probe have different trust roles.
    Inspect proves the daemon's retained configuration. The probe proves what
    the container process observed. Requiring both catches config/observation
    disagreement, but both still depend on the local daemon, runtime, kernel,
    provider code, and evidence key.
13. Cleanup is part of the result, not housekeeping.
    A terminal observation is signed only after the container has exited, was
    force-removed, and a successful all-states, full-ID Docker listing confirms
    that the exact ID or retained name is absent. A failed inspect also occurs
    when the daemon is unavailable; it cannot prove removal. Docker name
    filters match substrings, so returned rows require exact-name comparison.
    Failed, malformed, diagnostic-bearing, or ambiguous results block commit.
    This positive-evidence rule is a local policy inference from Docker's
    [listing](https://docs.docker.com/reference/cli/docker/container/ls/),
    [inspection](https://docs.docker.com/reference/cli/docker/container/inspect/),
    and [removal](https://docs.docker.com/reference/cli/docker/container/rm/)
    interfaces, not a documented nonzero-exit absence guarantee.
14. Pre-create intent remains the no-rerun marker.
    Once the signed envelope exists, a crash may trigger containment cleanup
    and human reconciliation but never another create/start. This preserves
    Phase 17B2A's unknown-outcome safety across the larger container lifecycle.
    A local live fixture reproduced the former false-absence result by using
    an unavailable Docker socket while the original daemon retained the target.
    Regression checks cover that failure, malformed listings, exact-name
    matching, and both CLI wrappers. Verified containment still leaves
    `recovery_required` and no new execution observation. Same-daemon trust,
    gateway effect settlement, and campaign restart are not proved by cleanup.
15. Image metadata does not prove the probe bytes.
    Image inspect binds the immutable local ID, architecture, entrypoint, and
    environment, but those fields do not prove that `/cannae-probe` equals the
    host-measured binary. Docker permits copying from a stopped container, so
    the provider creates an unstarted, network-none appraisal container,
    extracts the probe, compares its byte digest, verifies container removal,
    and repeats the appraisal immediately before the signed execution create.
    A substituted probe is denied before gateway begin.

### Assurance Interpretation

```text
exact active gateway transaction
+ immutable image ID and directly extracted static probe digest
+ digest-pinned seccomp profile
+ signed pre-create launch intent
+ exact Docker inspect projection
+ direct kernel privilege, mount, cgroup, and network observations
+ exact child output/result
+ unchanged repository
+ verified container removal
+ independent gateway evidence reconstruction
= OCI sandbox result may enter ToolExecutionReceipt v0.4
```

The equation does not include:

- independent Docker daemon or host-kernel attestation;
- image signature or provenance;
- rootless or user-namespace enforcement;
- mandatory access control;
- managed key custody or deployment identity;
- exclusive provider routing or side-path denial;
- multi-host fencing;
- production execution or release.

### Implemented Artifacts

- `schema-files/oci-linux-sandbox-policy.schema.json`;
- `schema-files/oci-sandbox-tool-input.schema.json`;
- `schema-files/oci-sandbox-execution-envelope.schema.json`;
- `schema-files/oci-sandbox-probe-observation.schema.json`;
- `schema-files/oci-sandbox-execution-observation.schema.json`;
- `oci-linux-sandbox-evidence.js`;
- `oci-linux-sandbox-provider.js`;
- `oci-linux-sandbox-probe.go`;
- `runtime-profiles/moby-seccomp-v0.2.1.json`;
- `ToolExecutionReceipt` v0.4 OCI mode and exact probe digest;
- five valid and five adversarial static samples;
- `run-oci-linux-sandbox-provider-fixtures.js`;
- `docs/oci-linux-sandbox-provider.md`;
- equivalent Codex and Claude wrappers, routes, references, and mandatory
  operating guidance.

### Measured Behavior

- the fixture compiles a static Linux probe for the Docker daemon architecture;
- it builds a network-disabled scratch image and resolves its immutable local
  image ID;
- it extracts `/cannae-probe` from an unstarted appraisal container and
  compares the exact bytes with the host-measured probe;
- one exact target commits with signed pre-create and post-cleanup evidence;
- replay returns the retained terminal transaction without another create;
- caller-declared fixture evidence cannot satisfy OCI sandbox input;
- seccomp byte drift, missing image identity, and an image containing a
  substituted probe fail before gateway begin;
- UID/GID, capabilities, `NoNewPrivs`, seccomp, namespace handles, VFS mounts,
  cgroup values, addressed interfaces, routes, and outbound-connect denial are
  retained from a real container;
- a changed privilege observation is rejected;
- timeout becomes a committed failed result;
- a post-container interruption removes the container, enters
  `recovery_required`, and cannot rerun.

### Residual Limits And Next Research

- The Docker socket and daemon remain highly privileged local trust roots.
- Docker Desktop adds a Linux VM boundary that this local evidence does not
  independently attest.
- The image ID and probe digest are locally measured, not supply-chain
  attestations.
- Probe-byte extraction does not inventory every image filesystem entry or
  prove that the image contains no additional files.
- The Moby default profile is broad and evolves separately from the provider.
- Rootless mode and user-namespace remapping are observed but not required.
- No AppArmor, SELinux, Landlock, or equivalent MAC policy is required.
- The probe and signed observation depend on a locally managed Ed25519 key.
- The provider supports measured external IP egress denial under Docker
  `none` networking, not approved egress or a proof that every network-related
  kernel mechanism is absent.
- The repository mount is read-only; controlled write workflows need a
  separate copy-on-write/output-promotion contract.
- The shared-filesystem artifact store remains a single-host reference.
- There is no proof that shell, Docker, MCP, filesystem, network, or delegation
  side paths are unreachable outside the gateway.

The Phase 17B2C1 research below defines the contract for those controls.
Provider deployment and installation-level side-path proof remain external.

## Phase 17B2C1: Production Sandbox Admission

### Research Question

Phase 17B2B proves one measured OCI execution under a local Docker reference
provider. It does not establish that the daemon, host, image supply chain,
evidence keys, policy, gateway deployment, distributed coordination, or
alternate tool paths are independently trustworthy.

The Phase 17B2C1 question is therefore:

> What exact evidence must a relying gateway require before it may set
> production execution and deployment verification true without also granting
> release or trusting one self-authored claim?

### Primary Standards Findings

1. RATS separates evidence production, appraisal, and reliance.
   [RFC 9334](https://www.rfc-editor.org/rfc/rfc9334.html) defines Attester,
   Verifier, Attestation Result, and Relying Party roles. The gateway should
   consume a signed appraisal result from a policy-trusted verifier; it should
   not treat raw evidence or a caller boolean as the trust decision.
2. Evidence inputs remain semantically distinct.
   [RFC 9999](https://www.rfc-editor.org/rfc/rfc9999.html) preserves Evidence,
   Reference Values, Endorsements, Appraisal Policy, and Attestation Results as
   different conceptual messages. A production record therefore retains a
   digest for each one.
3. Freshness must be profile-bound.
   [RFC 9711](https://www.rfc-editor.org/rfc/rfc9711.html) supports EAT
   freshness and profile constraints. Cannae fixes one EAT profile, nonce
   length, evidence age, and expiry in policy. A nonce string outside that
   profile cannot count.
4. Image identity is content identity, not a mutable name.
   The [OCI descriptor specification](https://github.com/opencontainers/image-spec/blob/main/descriptor.md)
   treats the digest as the content identifier and requires SHA-256
   verification support. Tags and unverified registry responses cannot enter
   production policy.
5. Provenance must bind a subject and be checked against expectations.
   [in-toto Statement v1](https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md)
   binds metadata to subject digests and predicate type.
   [SLSA provenance v1](https://slsa.dev/spec/v1.2/build-provenance) fixes the
   current in-toto and predicate type strings, while
   [SLSA artifact verification](https://slsa.dev/spec/v1.2/verifying-artifacts)
   requires consumers to compare provenance with protected expectations.
   A valid signature on an unexpected source, builder, or image is not
   sufficient.
6. Signature verification must preserve claims.
   [Sigstore verification guidance](https://docs.sigstore.dev/cosign/verifying/verify/)
   verifies the container digest and signer identity/issuer. Disabling claim
   checks would reduce the result to signature possession and is outside this
   production profile.
7. Credential custody and lifecycle are separate controls.
   The [SPIFFE Workload API](https://spiffe.io/docs/latest/spiffe-specs/spiffe_workload_api/)
   delivers short-lived credentials and bundles. Production evidence records
   verified workload identity, custody class, rotation, and revocation rather
   than equating a public key in JSON with managed key custody.
8. Container assurance is layered.
   [NIST SP 800-190](https://csrc.nist.gov/pubs/sp/800/190/final) identifies
   image, registry, orchestrator, runtime, and host risks separately. Cannae
   does not collapse those layers into one `sandbox_verified` field.
9. Rootless and user-namespace operation reduce different risks.
   [Docker rootless mode](https://docs.docker.com/engine/security/rootless/)
   places both daemon and containers in a user namespace without root.
   [Docker userns-remap](https://docs.docker.com/engine/security/userns-remap/)
   maps container root to an unprivileged host UID while the daemon remains
   rootful. Policy permits either only when independently appraised.
10. General seccomp compatibility is not application minimization.
    [Docker seccomp guidance](https://docs.docker.com/engine/security/seccomp/)
    describes its broad default compatibility profile. Production evidence
    requires a digest-pinned application profile with
    `SCMP_ACT_ERRNO` default action.
11. Mandatory access control is additional to namespaces and seccomp.
    [Docker AppArmor guidance](https://docs.docker.com/engine/security/apparmor/)
    demonstrates enforcing profiles, and
    [Linux Landlock](https://docs.kernel.org/security/landlock.html) adds
    restrictions for unprivileged processes. One enforcing MAC provider and
    profile digest is mandatory.
12. A local file lock is not a distributed production coordinator.
    The [etcd concurrency API](https://etcd.io/docs/v3.6/dev-guide/api_concurrency_reference_v3/)
    associates locks with leases, and the
    [etcd API](https://etcd.io/docs/v3.6/learning/api/) supplies atomic
    compare-and-swap transactions. Production needs equivalent linearizable
    acquisition, renewal, release, revision, and fencing behavior plus
    storage-side enforcement.

### Design Decisions

1. Use three artifacts, not one all-purpose certificate.
   `ProductionSandboxPolicy` defines trust, `ProductionSandboxEvidence`
   records one appraiser result, and `ProductionSandboxAdmission` aggregates
   current consensus. This keeps USER policy, appraiser observation, and
   admission authority reviewable and revocable independently.
2. Separate admission and appraiser keys.
   The admission authority cannot also be a counted appraiser. Otherwise one
   compromised key could both create evidence and declare its quorum valid.
3. Require at least two appraisers and compute failure domains.
   Nine provider/operator/infrastructure dimensions are signed. Any shared
   required component creates an edge; transitive connected components become
   the actual domains. Human-readable group labels are ignored for diversity.
4. Require byte-equivalent deployment consensus.
   Appraisers do not vote on a vague environment name. They must sign the same
   canonical deployment object and exact execution scope.
5. Keep vendor quote parsing in provider adapters.
   A generic TPM, TEE, cloud-attestation, EAT, endorsement, and reference-value
   parser would either be incomplete or pretend that incompatible trust models
   are interchangeable. The generic contract verifies the signed appraisal
   result and exact references; the selected provider must appraise the
   original evidence.
6. Bind production only to the OCI reference mode.
   Phase 17B2A intentionally lacks an isolation boundary. Production policy
   therefore permits one `oci_linux_sandbox_reference` mode and exact
   manifest-backed OCI policy refs.
7. Require a live coordinator in addition to signed deployment evidence.
   Evidence that a coordinator was configured does not prove that it is
   reachable for the current transaction. The gateway obtains a current
   handle and binds its adapter/configuration, transaction, idempotency key,
   admission digest, revision, fencing token, lease, and expiry.
8. Preserve local and external coordination roles.
   The repository lease still serializes one coherent artifact store. The
   external coordinator supplies the production claim. Neither silently
   substitutes for the other.
9. Reverify at every state-changing transition.
   Admission, begin, commit, and recovery can occur after evidence, identity,
   admission, or coordinator expiry. Every transition reloads the manifest and
   reacquires current production coordination.
10. Keep execution authorization and release independent.
    A production admission may authorize one exact tool transaction. It does
    not authorize source commit, push, merge, publication, risk acceptance,
    policy change, or release.

### Rejected Alternatives

- A caller-supplied `production: true` flag: no evidence or trust boundary.
- One self-signed appraiser: no independent observation or failure tolerance.
- Declared independence labels: shared accounts and infrastructure can be
  relabeled without becoming independent.
- Signature success without subject/source/builder expectations: authenticates
  a signer but not the intended image or build.
- Treating the existing artifact-store lease as multi-host linearizability:
  unsupported under partition, delayed visibility, or storage failover.
- Issuing admission from in-memory objects: bypasses repository custody and
  permits substituted refs.
- Letting the standalone CLI inject a fixture coordinator: would turn a test
  affordance into a production-claim bypass.
- Making release true when production succeeds: conflates execution assurance
  with retained human release authority.

### Implemented Artifacts

- `schema-files/production-sandbox-policy.schema.json`;
- `schema-files/production-sandbox-evidence.schema.json`;
- `schema-files/production-sandbox-admission.schema.json`;
- valid and adversarial samples for all three contracts;
- `production-sandbox-admission.js`;
- `production-sandbox-admission-adapter.js`;
- `production-sandbox-fixture-support.js`;
- `ToolGatewayRequest`/decision/event v0.3 and
  `ToolExecutionReceipt` v0.5;
- external `productionCoordinator` gateway interface;
- `run-production-sandbox-admission-fixtures.js`;
- `run-production-sandbox-gateway-fixtures.js`;
- `docs/production-sandbox-admission.md`;
- equivalent Codex and Claude wrappers, routes, references, and mandatory
  operating guidance.

### Measured Behavior

- two independently keyed and failure-domain-separated appraisals authorize one
  agreed deployment;
- an exact manifest-backed OCI policy verifies, while a foreign policy is
  denied before artifact loading;
- one shared required infrastructure component collapses diversity;
- appraisers that sign different deployment identities cannot form consensus;
- evidence payload mutation with a repaired digest still fails its signature;
- evidence and admission expiry remove production authorization;
- an admission payload mutation with a repaired digest still fails its
  admission signature;
- an appraiser signature under an unregistered key cannot enter quorum;
- a real TLS 1.3 SPIFFE identity plus exact production admission and matching
  external coordinator authorizes a managed gateway transaction;
- missing external coordination denies before dispatch admission is consumed;
- exact cancellation creates a v0.5 aborted receipt with deployment proof
  preserved and release false;
- legacy gateway, identity, protected-process, and OCI fixture families remain
  compatible.

### Residual Provider Work

- TPM 2.0, cloud confidential-computing, TEE, or other attestation adapters;
- profile-specific EAT/CMW parsing and endorsement/reference-value services;
- SLSA/Sigstore registry verification against protected expectations;
- KMS/HSM and SPIFFE Workload API key delivery, rotation, and revocation;
- hardened rootless or userns Docker hosts with independently appraised MAC,
  seccomp, cgroup, filesystem, and network policy;
- a real etcd/database/cloud coordinator adapter and storage-enforced fencing;
- installation-level adversarial tests that remove every shell, Docker, MCP,
  filesystem, network, and delegation side path;
- multi-user policy administration, health, incident, revocation, break-glass,
  reconciliation, and disaster-recovery operations;
- release approval.

The repository now has a fail-closed contract for consuming those provider
claims. It does not manufacture provider trust or convert an ordinary local
Docker installation into production.

## Phase 18: Exact GitHub Release Authorization

### Research Question

How can the framework finally set `release_authorized: true` without turning a
category-level release review, successful CI run, production admission, or AI
recommendation into reusable publication authority?

### Source Findings

1. A release target must be explicit.
   The [GitHub CLI release-create reference](https://cli.github.com/manual/gh_release_create)
   allows an explicit target branch or full commit SHA. If a tag does not
   already exist, GitHub otherwise creates it from the default branch. Cannae
   therefore supplies the full authorized commit SHA instead of relying on
   ambient branch state.
2. Release body input and no-change behavior are selectable controls.
   The same CLI supports an exact notes file and
   `--fail-on-no-commits`. Cannae hashes the tracked notes bytes before
   authorization and compares the reloaded body after publication.
3. Publication output must be reloaded.
   The [GitHub CLI release-view reference](https://cli.github.com/manual/gh_release_view)
   exposes release IDs, tag, target, body, URLs, draft/prerelease state, and
   publish time. Command success alone is not a terminal receipt.
4. The release object and Git tag are related but distinct state.
   The [GitHub Releases REST API](https://docs.github.com/en/rest/releases/releases#create-a-release)
   defines the target commitish used when a tag is created. Cannae separately
   resolves the remote tag after creation so a release object cannot hide a tag
   pointing elsewhere.
5. Human approval must name the action instance.
   Existing military-style authority doctrine already separates retained human
   decisions from staff recommendations. The release boundary therefore binds
   USER authority to one repository/tag/commit/notes tuple and a short expiry,
   rather than adding release authority to an agent role.

### Design Decisions

1. Keep every lower contract false.
   Mission, campaign, verifier, dispatch, gateway, executor, sandbox,
   production, and cycle-order evidence can inform the USER decision but cannot
   become publication authority.
2. Introduce one terminal authorization type.
   `GitHubReleaseAuthorization` is the only pre-action artifact that may carry
   release true. Its scope is a single stable release in one public repository.
3. Bind the exact successful main run.
   Pull-request success is not sufficient because the merged commit can differ.
   The authorization requires a completed successful `Validate` push run whose
   branch and head SHA equal the release target.
4. Reappraise immediately before action.
   A valid document is not enough if the worktree, origin, notes, CI, expiry,
   tag, or release changed after issuance.
5. Separate immutable authorization from consumption.
   Mutating `consumed` would invalidate the authorization digest. A terminal
   `GitHubReleaseReceipt` instead cites the exact authorization and records
   consumption.
6. Make exact retries idempotent.
   A retry may verify an already-created byte-equivalent release, but it cannot
   create, repair, retarget, delete, or overwrite mismatched state.
7. Record the actual trust boundary.
   The canonical SHA-256 digest detects accidental or unpaired mutation but is
   not a USER signature. The local operator process and authenticated `gh`
   credential remain trusted.

### Rejected Alternatives

- Changing all existing `release_authorized` constants to true: destroys
  authority separation.
- Treating `allow_scoped_execution_and_release` as a repository release token:
  it names only a release category, not a GitHub subject.
- Releasing from ambient `main`: branch state can drift after review.
- Trusting a successful `gh release create` exit code: does not independently
  establish body or tag correctness.
- Reusing an unexpired authorization for a different patch release: violates
  exact USER scope.
- Automatically deleting a mismatched tag or release: converts fail-closed
  verification into destructive repair.
- Calling a digest a human signature: overstates the current trust boundary.

### Implemented Artifacts

- `docs/github-release-authorization.md`;
- `schema-files/github-release-authorization.schema.json`;
- `schema-files/github-release-receipt.schema.json`;
- valid and adversarial authorization and receipt samples;
- `github-release-publisher.js`;
- `run-github-release-publisher-fixtures.js`;
- `github-release-fixtures/README.md`;
- equivalent Codex and Claude release wrappers, routing references, and skill
  operating rules; and
- tracked `docs/releases/v0.2.0.md` release notes.

### Measured Behavior

- one exact USER grant produces a schema-valid terminal authorization with
  release true;
- dirty state, wrong-commit CI, foreign repository/origin identity, and an
  authorization artifact outside the repository deny before publication;
- expiry and post-authorization notes mutation deny publication;
- one exact release publishes once and an exact retry performs verification
  without a second create call;
- an existing release whose remote tag resolves to a different commit denies;
- a tag without a release denies as partial state; and
- repaired self-digests do not make AI approval or tag drift valid.

### Residual Work

- USER digital signatures and protected signing-key custody;
- signed tag/provenance binding;
- GitHub environment and repository-rule evidence;
- independent release monitor, transparency witness, and mutation alerting;
- private repository, prerelease, first-release, and alternate provider
  profiles; and
- provider-neutral release adapters.

## Phase 19A: Repository Release Immutability

### Research Question

How can Cannae activate GitHub's persistent immutable-releases setting without
treating a repository administration action as a release, and how should that
setting become enforceable evidence for every later release?

### Source Findings

1. GitHub immutability is prospective.
   The [immutable releases concept](https://docs.github.com/en/code-security/concepts/supply-chain-security/immutable-releases)
   states that enabling the feature protects future releases rather than
   retroactively converting existing releases. Cannae therefore snapshots
   `v0.2.0` as non-immutable and rejects any claim that activation repaired it.
2. The platform locks both tag and assets.
   GitHub documents immutable tags and release assets and automatically creates
   a release attestation. This is stronger than merely checking a release body
   immediately after creation, but it still depends on GitHub's control plane
   and the authenticated repository administrator.
3. Repository activation is an administrative REST operation.
   The [repository REST API](https://docs.github.com/en/rest/repos/repos?apiVersion=2026-03-10)
   exposes GET, PUT, and DELETE operations at
   `/repos/{owner}/{repo}/immutable-releases`. Enabling requires repository
   administration permission and returns HTTP 204.
4. Owner enforcement and repository enablement are distinct observations.
   The policy response reports both `enabled` and `enforced_by_owner`. Cannae
   records both rather than collapsing organization policy into repository
   state.
5. Release attestation is separately verifiable.
   The [`gh release verify` reference](https://cli.github.com/manual/gh_release_verify)
   verifies the attestation associated with an immutable release. The current
   Phase 19A gate records GitHub's immutable listing state; independent
   attestation verification is retained as a follow-on control.

### Design Decisions

1. Create a separate policy authority class.
   `GitHubReleaseImmutabilityAuthorization` carries
   `repository_policy_change_authorized: true` and
   `release_authorized: false`. It cannot publish a tag, release, or asset.
2. Bind the activation to reviewed repository state.
   The grant names the exact public repository, normalized origin, clean main
   commit, successful main `Validate` run, policy endpoint, prior disabled
   state, and desired enabled state.
3. Reappraise before the persistent action.
   Execution reloads repository state, CI, current latest release, and current
   policy before PUT. Authorization stored outside the repository is rejected
   before any network-changing request.
4. Require response and resulting state.
   A zero exit code is insufficient. The adapter must observe HTTP 204 and then
   GET `enabled: true`.
5. Keep retries idempotent.
   If the exact authorization is retried after a successful activation, it
   performs no second PUT and emits a receipt only after verifying the enabled
   state and unchanged historical release.
6. Upgrade future release evidence prospectively.
   New release authorization and receipt version `0.2` require enabled policy
   at issuance and publication plus `isImmutable: true` after creation.
   Historical version `0.1` artifacts remain readable.
7. Do not automate rollback.
   GitHub exposes DELETE, but disabling immutability would weaken future
   releases and therefore needs its own exact future USER authorization. The
   Phase 19A runtime deliberately has no disable command.

### Rejected Alternatives

- Treating the user's release instruction as implicit repository-policy
  permission: release scope and persistent administration scope are different.
- Enabling the setting before merging and validating the control code: the
  durable action would lack exact reviewed execution evidence.
- Assuming HTTP 204 when response headers are missing: converts ambiguous CLI
  output into false success.
- Claiming `v0.2.0` became immutable: contradicts GitHub's prospective
  semantics.
- Letting an enabled-policy receipt carry release true: collapses policy and
  publication authority.
- Automatically disabling the setting for rollback: silently weakens all
  future releases.

### Implemented Artifacts

- `docs/github-release-immutability.md`;
- `schema-files/github-release-immutability-authorization.schema.json`;
- `schema-files/github-release-immutability-receipt.schema.json`;
- valid and adversarial policy authorization and receipt samples;
- `github-release-immutability.js`;
- `run-github-release-immutability-fixtures.js`;
- `github-release-immutability-fixtures/README.md`;
- release authorization/receipt version `0.2` prospective enforcement; and
- equivalent Codex and Claude wrappers, routing references, and operating
  rules.

### Measured Behavior

- one exact USER grant creates a valid disabled-to-enabled policy
  authorization while release remains false;
- non-admin, foreign origin, wrong-commit CI, expiry, and external
  authorization paths deny;
- one activation performs one PUT and an exact retry performs no second PUT;
- HTTP success without an enabled post-action observation denies;
- latest historical-release drift denies;
- valid policy samples pass while AI approval and release-authority expansion
  fail; and
- future publisher fixtures deny when policy is disabled and require immutable
  terminal release state.

### Residual Work

- protected USER signing keys and authenticated policy directives;
- organization-owner enforcement evidence;
- release transparency witnesses and cross-provider mutation alerts;
- signed tags, credential isolation, and environment protection; and
- provider-neutral policy and release adapters.

## Phase 19B: Release Attestation And Policy Drift Monitoring

### Research Question

How can Cannae continuously distinguish an intact immutable-release boundary
from policy drift, credential blindness, release/tag mutation, or a valid
GitHub attestation for the wrong release without turning a monitor into a
repository administrator or release authority?

### Source Findings

1. GitHub release attestations are cryptographically verified by a dedicated
   CLI path.
   The [`gh release verify` reference](https://cli.github.com/manual/gh_release_verify)
   states that the command fetches and verifies the signed release
   attestation and can return JSON metadata and asset digests. A successful
   command is stronger than reading `isImmutable`, but its result still needs
   exact repository/tag/commit scoping before Cannae can consume it.
2. The verified statement is a multi-subject release claim.
   A live immutable `cli/cli` release returned a Sigstore bundle v0.3 and
   verified in-toto Statement v1 with one package subject containing the Git
   SHA-1 plus uploaded-asset SHA-256 subjects. Cannae retains the complete
   result and normalizes those exact subjects instead of reducing success to a
   Boolean.
3. Historical releases correctly lack this evidence.
   Live verification of Cannae `v0.2.0`, which predates Phase 19A activation,
   returned no attestation. This matches GitHub's prospective semantics and
   requires an explicit grandfather baseline rather than retroactive failure
   or false upgrade.
4. Generated source archives are outside the asset-verification set.
   GitHub's [release-integrity guidance](https://docs.github.com/en/code-security/how-tos/secure-your-supply-chain/secure-your-dependencies/verify-release-integrity)
   states that source ZIP and tar archives are generated on demand and cannot
   be verified with the release-attestation asset path. The policy records
   that exclusion rather than implying complete archive coverage.
5. Policy observation has a stronger credential requirement than release
   observation.
   GitHub's [fine-grained token permission table](https://docs.github.com/en/rest/authentication/permissions-required-for-fine-grained-personal-access-tokens)
   requires repository Administration read permission for
   `GET /repos/{owner}/{repo}/immutable-releases`. An unauthenticated live
   request returned HTTP 401. Ordinary `contents: read` therefore cannot be
   assumed to prove policy state.
6. Workflow-token lifetime does not grant missing permissions.
   GitHub documents the repository `GITHUB_TOKEN` as a short-lived per-job
   installation token, but supported workflow permission keys do not include
   repository Administration. The full monitor must attempt the live GET,
   retain the result, and represent 401/403 as credential uncertainty rather
   than no drift.

### Design Decisions

1. Separate expected policy from observations.
   The tracked `GitHubReleaseIntegrityPolicy` seals repository identity,
   activation evidence, exact grandfathered releases, attestation profile,
   cadence, retries, and authority. Each
   `GitHubReleaseIntegrityObservation` is a time-specific measured result.
2. Preserve three policy meanings.
   `verified enabled`, `verified disabled`, and
   `credential_unavailable/inspection_failed` are distinct. Only the first
   can support readiness; the last does not set
   `policy_drift_assessed: true`.
3. Normalize after GitHub CLI verification.
   Cannae requires the CLI's successful cryptographic verification, then
   checks Sigstore bundle media type, strict DSSE payload decoding, canonical
   equality between the signed payload and verification-result statement,
   verified timestamp, GitHub signer identity, in-toto type, release
   predicate, package URI, repository, tag, commit, unique assets, and asset
   digests.
4. Retain the raw result.
   The normalized projection and complete JSON result enter the receipt or
   monitor observation under a canonical digest. This supports later
   independent re-verification and prevents lossy Boolean evidence.
5. Upgrade publication prospectively.
   New authorization and receipt version `0.3` binds the verifier profile and
   requires attestation after immutable publication. Version `0.2` remains
   historical evidence but does not claim retained attestation.
6. Split full and release-event scopes.
   The release-event path can verify one exact published tag with the
   short-lived repository token. It explicitly does not claim policy
   assessment. Full scope requires the administrative GET and every release.
7. Bind monitoring to committed repository state.
   A merely tracked or staged policy is insufficient. Its bytes must equal
   the current HEAD blob, its activation commit must be in HEAD ancestry, and
   HEAD must equal the current origin default-branch commit. Output parents
   resolving through a symlink outside the repository are rejected.
8. Make monitoring read-only.
   The workflow uses `contents: read` and `attestations: read`, never runs on
   pull requests, checks out `main`, and only uploads observations. Untrusted
   release-event values are passed to the shell through quoted environment
   variables. Every policy and observation field keeps repository-policy
   change and release false.
9. Reproduce the validator dependency closure.
   A clean Actions runner installs the exact package lock with
   `npm ci --ignore-scripts` before the monitor imports schema and semantic
   validators. A preinstalled local `node_modules` directory is not deployment
   evidence.
10. Fail visibly when credential setup is incomplete.
   A missing Administration-read monitor token produces a retained blocked
   observation and failed workflow. Cannae does not copy the owner's broad
   local OAuth credential into repository secrets.

### Rejected Alternatives

- Treating `isImmutable: true` as the attestation: it does not retain the
  signed repository/tag/commit/asset statement.
- Accepting any successful `gh release verify`: a valid attestation for
  repository or tag B must not satisfy A.
- Trusting the CLI's projected statement without comparing it with the signed
  DSSE payload: the two representations must be canonically identical.
- Accepting a staged policy or stale feature-branch checkout: either can
  rewrite the baseline without producing evidence from current protected
  `main`.
- Interpolating a release-event tag directly into a shell script: tags are
  untrusted event data and must enter through a quoted environment variable.
- Requiring attestations from `v0.1.0` or `v0.2.0`: contradicts prospective
  activation and observed GitHub state.
- Recording credential failure as `drift_detected: false` with assessment
  complete: turns blindness into false assurance.
- Storing the owner's `repo`/`workflow` OAuth token as an Actions secret:
  unnecessarily exposes broad write authority to the monitor.
- Automatically re-enabling a disabled policy or deleting a bad release:
  converts observation into an unreviewed persistent action.
- Trusting generated source archives as attested assets: contradicts GitHub's
  documented on-demand generation behavior.

### Implemented Artifacts

- `docs/github-release-integrity-monitoring.md`;
- `.github/release-integrity-policy.json`;
- `.github/workflows/release-integrity.yml`;
- `schema-files/github-release-integrity-policy.schema.json`;
- `schema-files/github-release-integrity-observation.schema.json`;
- valid and adversarial policy and observation samples;
- `github-release-integrity-monitor.js`;
- `run-github-release-integrity-fixtures.js`;
- `github-release-integrity-fixtures/README.md`;
- publisher authorization/receipt version `0.3` attestation enforcement; and
- equivalent Codex and Claude wrappers, routing references, and operating
  rules.

### Measured Behavior

- a pre-deployment live query verified the currently enabled policy and exact
  `v0.1.0`/`v0.2.0` grandfather baseline with no post-activation releases;
- a full fixture verifies one immutable post-activation release and retains
  its exact package/asset statement;
- disabled policy and unavailable Administration-read credentials produce
  different blocked states;
- mutable post-activation release, attestation commit substitution,
  grandfather tag drift, and missing baseline release all block;
- bounded retry does not convert an unavailable or mismatched attestation into
  success;
- release-event scope verifies one exact tag while policy assessment remains
  false;
- staged policy substitution, stale default-branch state, parent-symlink
  output escape, and repaired policy authority all fail closed;
- all 17 release-integrity fixtures preserve mutation and release false; and
- publisher fixtures require immutable state plus exact attestation before
  issuing a version `0.3` receipt.

### Residual Work

- short-lived GitHub App installation-token minting and automated rotation;
- signed release tags, protected USER keys, and environment protection;
- external monitor-liveness checks and long-term transparency storage;
- independent witnesses and cross-provider gossip; and
- private, prerelease, first-release, and provider-neutral profiles.

## Phase 19C: Independent Retained-Bundle Verification

### Research Question

How can Cannae independently replay the cryptographic verification of a
retained GitHub release-attestation bundle and its trust root without trusting
the GitHub CLI's success conclusion, a mutable downloaded root, or a wrapper
digest?

### Source Findings

1. Offline verification requires both the bundle and trusted-root material.
   GitHub's
   [offline-verification guidance](https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/verify-attestations-offline)
   separates bundle acquisition from later verification and documents
   acquiring a trusted root for disconnected use.
2. The GitHub trusted root is a TUF target, not an unversioned JSON constant.
   [`gh attestation trusted-root`](https://cli.github.com/manual/gh_attestation_trusted-root)
   exposes the current material, while the
   [TUF specification](https://theupdateframework.github.io/specification/latest/)
   requires trusted root rotation, role thresholds, metadata linkage, expiry,
   and target hash and length checks. Retaining only the final target loses the
   update proof from the pinned bootstrap root.
3. A Sigstore bundle is portable verification material.
   The [Sigstore bundle specification](https://docs.sigstore.dev/about/bundle/)
   packages the signature, certificate, and transparency or timestamp
   evidence needed by a verifier. The
   [Sigstore JavaScript client](https://docs.sigstore.dev/language_clients/javascript/)
   provides an independent verifier implementation that can consume explicit
   trusted-root material.
4. Cryptographic validity does not establish release scope.
   The [in-toto Statement v1 specification](https://github.com/in-toto/attestation/blob/main/spec/v1/statement.md)
   binds subjects and a predicate, but the consumer must still require the
   exact repository, tag, commit, package URI, and uploaded-asset set expected
   for the release.
5. GitHub release attestations currently use a GitHub-specific profile.
   A retained public `cli/cli v2.93.0` result used bundle v0.3, the
   `https://dotcom.releases.github.com` Fulcio certificate identity, and one
   RFC 3161 timestamp with no retained Rekor or CT-log entry. Those thresholds
   are exact profile constraints, not defaults for arbitrary Sigstore
   attestations.

### Design Decisions

1. Pin a bootstrap trust anchor in the repository.
   Cannae commits GitHub TUF root v1 and its exact digest. A refresh retains
   every root version through the current root plus timestamp, snapshot,
   targets, and `trusted_root.json` bytes.
2. Replay the complete TUF chain offline.
   Root v1 verifies its own threshold. Each subsequent root must advance by
   exactly one and satisfy both old-root and new-root thresholds. Current
   metadata signatures, expiry, version links, hashes, lengths, and the final
   target are verified again from retained bytes. Expiry is evaluated against
   an explicit caller clock, never the wrapper's self-declared retrieval time.
3. Use a second verifier, not the acquisition command's conclusion.
   `@sigstore/verify` validates the DSSE signature, certificate chain,
   certificate identity, and timestamp against the retained trusted root.
   GitHub CLI output remains acquisition and comparison evidence.
4. Require three-way statement agreement.
   The signed DSSE payload must equal the CLI-projected statement and the
   exact expected release scope. Recomputing an outer artifact digest cannot
   repair a changed signed payload, TUF role, tag, commit, or asset set.
5. Bind verifier implementation and dependencies into evidence.
   The independent record includes verifier package version, verifier-module
   digest, dependency-lock digest, trusted-root digests, bundle digest,
   payload digest, certificate digest, and timestamp projection.
6. Integrate prospectively without widening authority.
   Publisher authorization and receipt v0.4 require independent evidence.
   Older schemas remain readable but cannot enter active publication.
   Integrity policy and observation v0.2 refresh and retain one TUF artifact
   per run and one independent result per non-grandfathered release. All
   artifacts remain monitoring-only, USER-controlled, and release false.
7. Represent trust acquisition failure as blocked evidence.
   TUF refresh or offline replay failure does not disappear and does not
   become `drift_detected: false`; the monitor emits a schema-valid blocked
   observation when other repository checks remain possible.
8. Preflight every available trust input before external mutation.
   The publisher loads and replays the root before release creation and
   requires every signed TUF role to remain valid through authorization
   expiry. It verifies the post-publication bundle again under that root
   before issuing a receipt.

### Rejected Alternatives

- Trusting `gh release verify` exit zero as the final decision: this repeats
  the same implementation and trust conclusion rather than independently
  replaying it.
- Retaining only normalized trusted-root JSON: this omits the signed TUF
  rotation and target-delivery chain.
- Checking only an outer artifact digest: an attacker who can replace the
  wrapper can recompute that digest.
- Trusting the CLI statement without decoding the signed DSSE payload: the
  unsigned projection can be substituted independently.
- Treating any valid GitHub release signature as sufficient: repository, tag,
  commit, package, and assets must all match the exact release expectation.
- Reusing the GitHub release profile for arbitrary Sigstore artifacts:
  transparency and identity thresholds differ by profile.
- Defaulting current time to the artifact's `fetched_at`: a recomputable
  wrapper could backdate validation or remain usable after signed metadata
  expiry.
- Executing historical authorization v0.3 after v0.4 activation: readable
  compatibility must not become a downgrade around independent verification.
- Creating an immutable release before checking the supplied trusted root:
  preflightable trust failures must stop before the irreversible side effect.
- Allowing independent evidence to set release true: verification evidence is
  not decision or publication authority.

### Implemented Artifacts

- `docs/github-release-independent-verification.md`;
- `.github/tuf/github-release-root.json`;
- `github-release-trusted-root.js`;
- `github-release-bundle-verifier.js`;
- `schema-files/github-release-trusted-root.schema.json`;
- `schema-files/github-release-independent-verification.schema.json`;
- retained public release and TUF fixtures;
- `run-github-release-independent-verification-fixtures.js`;
- publisher authorization and receipt v0.4 integration;
- integrity policy and observation v0.2 integration;
- workflow retention of trusted-root and observation artifacts; and
- equivalent Codex and Claude verification wrappers, routing, and operating
  rules.

### Measured Behavior

- the retained GitHub TUF chain replays offline from root v1 through current
  signed metadata and the exact trusted-root target;
- the real public `cli/cli v2.93.0` bundle verifies with the independent
  Sigstore implementation and exact release scope;
- omitted clocks or root versions, signed metadata expiry within wrapper age,
  insufficient operation-window validity, forged root or targets bodies after
  wrapper rehash, DSSE mutation, CLI projection substitution, commit
  substitution, legacy authorization downgrade, and authority expansion all
  fail;
- Codex and Claude wrappers resolve the same repository runtime;
- the current integrated regression retains all 17 independent-verification,
  39 publisher, 24 monitor, 31 checkpoint, and 221 validator fixture passes;
  and
- every new root, verification, receipt, policy, and observation contract
  preserves USER final authority and release false.

### Residual Work

- independently durable prior-root state and a cross-provider continuity
  monitor beyond the Phase 19D GitHub Actions artifact chain;
- independent witnesses, gossip, and long-term transparency storage;
- short-lived GitHub App installation credentials for administrative policy
  inspection;
- protected USER signing keys, signed release tags, and environment
  protection;
- infrastructure-independent verification rather than a second verifier in
  the same job;
- an external trusted-time source where the local caller clock is not an
  acceptable freshness authority; and
- private, prerelease, first-release, and provider-neutral profiles.

## Phase 19D: Monotonic TUF Checkpoint Continuity

### Research Question

How can Cannae detect that a newly valid GitHub TUF state is older than, forks
from, or conflicts with a state it previously trusted, while keeping release
authority with the USER and representing provider-retention limits honestly?

### Source Findings

1. TUF rollback resistance depends on retained client state.
   The [TUF specification](https://theupdateframework.github.io/specification/latest/)
   requires trusted timestamp, snapshot, and targets metadata to be persisted
   to non-volatile storage. New metadata is compared with trusted versions;
   lower versions are rollback, equal timestamp versions stop the update, and
   expiry detects freeze.
2. Root continuity is sequential.
   TUF requires root `N+1` to follow root `N` exactly and establishes a trusted
   line through every intermediate root. A final valid root alone does not
   prove which state the client had previously accepted.
3. GitHub artifact metadata provides useful but bounded lineage fields.
   The [Actions artifact REST API](https://docs.github.com/en/rest/actions/artifacts?apiVersion=2026-03-10)
   exposes artifact ID, SHA-256 archive digest, expiry, workflow run, and head
   SHA. These can bind checkpoint bytes to one exact workflow execution.
4. GitHub artifacts are not independent durable storage.
   GitHub's [artifact-removal guidance](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/remove-workflow-artifacts)
   says a repository writer can delete an artifact, deletion is irreversible,
   retention is configurable, and artifacts from deleted runs disappear.
   The workflow's 30-day artifact is therefore same-provider continuity, not
   an external archive or witness.
5. Failure must remain distinguishable from reset.
   TUF reports attacks and aborts; it does not decide application-specific
   recovery. A missing predecessor cannot safely authorize a new genesis
   without a separate authority decision.
6. GitHub reruns preserve one stable run identity.
   GitHub's [rerun guidance](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/re-run-workflows-and-jobs)
   says reruns retain the original event SHA/ref. The
   [variables reference](https://docs.github.com/en/actions/reference/workflows-and-actions/variables)
   keeps run ID/number stable while incrementing the attempt, and the
   [workflow-run API](https://docs.github.com/en/rest/actions/workflow-runs?apiVersion=2026-03-10)
   exposes one exact attempt under Actions read permission.
7. Event SHA and workflow SHA are different trust inputs.
   GitHub's [event reference](https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows)
   defines release `GITHUB_SHA` as the tagged commit, while the
   [contexts reference](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts)
   exposes `workflow_ref` and the commit containing the workflow as
   `workflow_sha`. Release-tag code must remain inspection input rather than
   executable monitor code.
8. Full commit pins are the immutable action reference.
   GitHub's [secure-use guidance](https://docs.github.com/en/actions/reference/security/secure-use)
   states that a full-length commit SHA is the only immutable action
   reference. A moving major tag is not sufficient for a credential-bearing
   monitor.

### Design Decisions

1. Retain a canonical monotonic checkpoint.
   It binds repository, sequence, predecessor, every TUF role's
   version/digest/expiry, target/root digests, retrieval and evaluation times,
   producer, transition result, and release false.
2. Require exact prior-root authentication.
   Before comparing versions, advancement proves that the prior checkpoint
   exactly represents the retained predecessor root. Rehashing a fabricated
   prior state cannot create rollback evidence or authorize a transition.
3. Treat equal-version changed bytes as equivocation.
   Version monotonicity alone is insufficient. Every unchanged role version
   must retain the same signed digest, and unchanged targets must retain the
   same target and normalized-root digests.
4. Bind root and retrieval continuity.
   The current root chain must contain the exact previously trusted root
   bytes, and current retrieval time cannot precede prior retrieval time.
5. Use one bounded provider store.
   The greatest stable eligible run number must be in current ancestry,
   contain the exact current policy bytes, retain exactly one expected
   artifact, and match the checkpoint's workflow, run, attempt, and head
   producer. Archive digest, expiry, bounded file sizes, unique names, and
   safe paths are verified. The archive must carry one full observation whose
   schema, deterministic transition replay, root, checkpoint, repository,
   policy, run, branch, and producer bindings all verify. Mutable timestamp
   strings do not order lineage. A bidirectional 60-second
   observation-to-artifact creation tolerance covers API timestamp precision
   and immediate upload only and does not widen any trust expiry or
   authorization window.
6. Refuse silent fallback.
   If the latest eligible run exists but its artifact is absent, older
   artifacts and repository bootstrap are not considered. This turns
   deletion or interrupted lineage into a visible blocked state.
7. Bound genesis narrowly.
   One committed genesis carries an explicit USER grant. Repository bootstrap
   is accepted only for four hours after the commit that first introduces the
   checkpoint policy. Later policy edits cannot reopen the window.
8. Integrate without widening authority.
   Monitor policy/observation v0.3 require continuity. Publisher
   authorization/receipt v0.5 accept only a successful `ready` non-genesis
   observation/root/checkpoint triplet from the latest full-monitor artifact,
   bind its run/attempt/artifact lineage into the USER grant, resolve it
   again, and recheck mutable authorization/repository/policy state before any
   release creation.
   Checkpoint reset and all monitoring release fields remain false.
9. Treat reruns as attempts, not newer events.
   An attempt after the first may consume only its immediately prior attempt.
   If a newer stable run exists, rerunning the historical run would fork the
   checkpoint chain and is rejected.
10. Fail closed at schema and workflow boundaries.
    Used schema combinators, conditional requirements, positional items,
    contained items, and nested additional-property bans are executable
    errors. Workflows require exact default-branch workflow identity, check
    out immutable `workflow_sha`, pin every action by full commit SHA, grant
    Actions read, and run on every `main` push rather than maintaining a
    brittle dependency-path allowlist.

### Rejected Alternatives

- Comparing only the current TUF metadata with the pinned root: this proves
  point-in-time validity, not prior client state.
- Trusting version numbers without digests: a same-version signed-byte
  conflict would be invisible.
- Accepting a rehashed prior wrapper: an attacker could fabricate an arbitrary
  comparison baseline.
- Falling back to the oldest available artifact after the latest disappears:
  artifact deletion would become a rollback mechanism.
- Reopening bootstrap after every policy edit: routine changes would become
  implicit checkpoint-reset authority.
- Sorting by workflow `updated_at`: a rerun can mutate that field and make an
  older run look newer than its stable run number.
- Allowing historical reruns to consume their own old attempt after a newer
  run: this creates two valid-looking successors from one predecessor.
- Treating a downloaded local checkpoint as proof of latest artifact state:
  an operator or compromised process could mint or preserve a different
  sequence and present it to release authorization.
- Accepting only checkpoint/root files from an artifact: both are
  self-asserted without the schema-valid full observation that replays their
  predecessor transition and monitor result.
- Executing release-event `github.sha`: it is the tagged release commit, not
  the protected default-branch workflow commit.
- Referencing credential-bearing third-party actions through a moving major
  tag: the action source can change without a workflow commit.
- Maintaining a hand-written push path allowlist: future runtime inputs such
  as npm configuration or a new helper can escape checkpoint acquisition.
- Extracting the entire ZIP before path and type validation: crafted archive
  members could affect the filesystem before rejection.
- Calling GitHub artifacts independently durable: GitHub controls workflow,
  artifact, deletion, retention, and TUF state.
- Letting the monitor repair sequence state or issue release authority:
  observation is not command authority.

### Implemented Artifacts

- `docs/github-release-trust-checkpoint-continuity.md`;
- `.github/tuf/github-release-trust-checkpoint.json`;
- `.github/tuf/github-release-trust-bootstrap-root.json`;
- `github-release-trust-checkpoint.js`;
- `github-release-checkpoint-store.js`;
- `schema-files/github-release-trust-checkpoint.schema.json`;
- `run-github-release-trust-checkpoint-fixtures.js`;
- integrity policy/observation v0.3 integration;
- publisher authorization/receipt v0.5 integration;
- every-main-push, schedule, default-branch manual, and separate release-event
  attestation retention with immutable workflow/action source; and
- equivalent Codex and Claude routing and operating rules.

### Measured Behavior

- USER genesis, unchanged transitions, and later exact-root matching pass;
- authenticated higher prior versions detect current rollback;
- equal-version digest conflict detects equivocation;
- missing prior root bytes, backdated retrieval, stale predecessors, sequence
  forks, root substitution, and authority expansion fail;
- bootstrap expiry and ordinary-policy-change replay fail;
- latest artifact selection succeeds, while missing latest retention,
  producer substitution, historical rerun forks, missing exact attempts,
  path traversal, and option-like archive members fail;
- a real artifact ZIP requires all three observation/root/checkpoint members;
- blocked observations remain usable only as continuity predecessors, while
  release admission requires a successful `ready` replay;
- incomplete/off-default reruns, forged transition replay, policy drift or
  authorization expiry during lineage resolution, and schema-invalid trusted
  roots fail before release creation;
- a post-create attestation failure can reconcile only the exact immutable
  release published within the original authorization window and does not
  create a second release;
- missing, stale, schema-invalid, local, genesis, path-substituted,
  superseded, or alternate valid checkpoints stop the publisher before any
  release creation call; and
- all 36 checkpoint, 39 publisher, 30 monitor, and 223 validator fixtures
  pass.

### Residual Work

- independently operated append-only checkpoint storage;
- cross-provider witnesses, gossip, and monitor-liveness supervision;
- a separately specified exact USER-authorized incident reset;
- protected USER signatures and an external trusted-time source;
- recovery classification for provider setup failures versus artifact
  deletion without weakening fail-closed continuity;
- short-lived GitHub App monitoring credentials; and
- private, prerelease, first-release, and provider-neutral profiles.

## Phase 19E: Initial Bootstrap Recovery

### Operational Finding

The first live Phase 19D deployment exposed a failure class that the original
contract correctly blocked but could not repair:

1. run `30332600269` retained a schema-valid full observation and verified
   trusted root but no checkpoint because the committed genesis was stale;
2. the refreshed genesis was merged without deleting that artifact;
3. run `30333702332` correctly selected the latest exact-policy run, found its
   two-file archive, refused repository-bootstrap fallback, and retained
   another blocked observation/root pair with
   `GITHUB_RELEASE_CHECKPOINT_ARCHIVE_CONTENT_INVALID`; and
4. both runs independently recorded monitor-credential unavailability.

This was not established-lineage loss: no provider checkpoint had ever
existed. It was also not safe to ignore. Deleting the failed runs, rerunning an
old run, changing the policy ID, or selecting an older bootstrap would erase
the evidence boundary or create an implicit reset.

### Design Decision

Add one explicit `GitHubReleaseBootstrapRecovery` contract. The USER
authorizes consumption of the same sequence-zero genesis for monitoring only,
while the runtime derives and verifies the complete failed-run set from
GitHub.

Admission requires:

- exact current policy bytes and original introduction commit/time;
- one fresh committed genesis/root carrying the same USER grant;
- every exact policy-matching completed failed run and artifact;
- exactly one blocked full observation and verified root per artifact, with
  no checkpoint or extra member;
- only stale-genesis or missing-checkpoint archive failure, plus optional
  monitor-credential unavailability;
- a USER grant issued after all retained artifacts;
- maximum 60-minute validity inside the original four-hour bootstrap window;
- artifact retention through expiry; and
- the newest in-progress first attempt at exact current `HEAD`.

The accepted provenance advances the normal deterministic sequence from zero
to one. It does not change the genesis sequence, mint a replacement
predecessor, authorize reset, make a blocked observation ready, or authorize a
release.

### Rejected Alternatives

- Delete the partial artifacts: deletion would make failed acquisition
  invisible and could change predecessor selection.
- Rerun the old workflow: a rerun preserves the old commit and creates an
  attempt branch rather than a new stable checkpoint event.
- Change the policy ID or bytes to hide prior runs: routine policy mutation
  would become reset authority.
- Accept only the latest two-file artifact: an earlier matching failed run
  could be omitted or substituted.
- Accept arbitrary blocked observations: an unrelated integrity failure could
  be laundered through recovery.
- Recover after any complete checkpoint exists: that would fork established
  lineage.
- Treat recovery as release readiness: a separate credential or policy issue
  must remain blocked.

### Implemented Artifacts

- `github-release-bootstrap-recovery.js`;
- `github-release-bootstrap-recovery-operator.js`;
- `schema-files/github-release-bootstrap-recovery.schema.json`;
- valid and authority-invalid static samples;
- exact two-file artifact replay in
  `github-release-integrity-monitor.js`;
- one-time store admission and recovery provenance in
  `github-release-checkpoint-store.js`;
- observation provenance schema/semantic integration;
- Codex and Claude operating-wrapper support; and
- checkpoint, monitor, validator, routing, and skill regressions.

### Measured Behavior

- both retained live initial artifacts replay under the exact current policy;
- exact USER recovery, complete failed-run enumeration, and sequence-one
  provenance pass;
- omitted runs, AI authority, expiry, completed/offline current run, unknown
  issue, and any artifact carrying a checkpoint fail;
- normal complete checkpoint artifacts never invoke recovery;
- missing authorization never falls back to repository bootstrap; and
- all 36 checkpoint, 30 monitor, and 223 validator fixtures pass.

### Live Provider Continuation

PR `#41` merged Phase 19E at
`6fc3cba04d01fe69fdee2bd20fa301215def123e`. The resulting push run
`30338646806` consumed recovery `GRBR-73b3ec37a953`, replayed both prior
blocked artifacts, and retained artifact `8680141105` with digest
`sha256:ac623b59b4692dd537f3c94ef1ad5d8c304552efb6071c30cc3de5bc736949e3`.
Its observation proved
`GRTC-0-1b479ae7dab5 -> GRTC-1-2c648122261b` with
`repository_bootstrap_recovery` provenance.

A separate first-attempt manual run `30338779941` then retained artifact
`8680186259` with digest
`sha256:43f0940cb9ad77bea269a6cbd3a85620f1f20dfe1ec352bfdc3c5e1200d2bdec`.
It selected the exact run `30338646806` artifact through the ordinary provider
path and proved
`GRTC-1-2c648122261b -> GRTC-2-f4f90a807d04` with
`github_actions_artifact` provenance.

Both artifacts contained exactly three files. Both full observations passed
standalone schema and semantic validation, reported verified checkpoint
continuity, and retained false reset/release authority. Both workflow jobs
failed at that time because GitHub did not accept an Administration-read
monitor credential. The result proves checkpoint recovery and ordinary
successor continuity without claiming policy-monitor readiness or release
readiness.

### Live Credential Acceptance

Secret registration metadata was not treated as permission evidence. Manual
runs `30518311906` and `30518425006` retained valid sequence-12 and
sequence-13 triplets but still reported
`GITHUB_RELEASE_POLICY_MONITOR_CREDENTIAL_UNAVAILABLE`. After the token's
repository selection and Administration-read permission were corrected, a
new first-attempt run was required.

Manual run `30522252521` at
`1ce41636998742f65096ad1e0b4273ce3b359e42` succeeded and retained artifact
`8751232448`. Its downloaded ZIP digest,
`sha256:ea704b6e4c608b807e0b1dddc7cc3aa32e5cae7994a3f67c248b932b4dfe2a57`,
equaled the provider API digest and contained exactly the full observation,
trusted root, and checkpoint. Observation
`GRIO-20260730071430-6008f978239c` reported:

- immutable policy `verified`, `enabled: true`, and not owner-enforced;
- two exact grandfathered releases and no post-activation release;
- complete monitoring, no drift, zero issues, and status `ready`;
- ordinary `github_actions_artifact` continuity from
  `GRTC-13-1c58f2ba8c89` to `GRTC-14-cacb442c429b`; and
- checkpoint reset and release authorization false.

All three files passed standalone schema and semantic validation. The prior
and current embedded checkpoints exactly matched the retained checkpoint
artifacts. This proves the provider secret's live read capability and monitor
readiness, not token custody quality, independent persistence, or release
authority.

The operational lesson is that secret-name existence and local administrator
success are not provider-secret evidence. Every installation, permission
change, or rotation needs a fresh full provider run and retained ready
triplet. Diagnostics may expose only sanitized status: HTTP 401 identifies an
invalid, expired, or malformed value; HTTP 403 identifies insufficient
permission or repository selection.

### Residual Work

- migrate the accepted repository-scoped credential to a short-lived GitHub
  App installation token with automated rotation;
- retain checkpoint state in an independently operated append-only store;
- add independent liveness witnesses and trusted time; and
- design a separate incident-reset contract for established lineage. Phase
  19E must never be generalized into that reset path.

## Local Operator Authentication And Evidence Queries

The [local operator console](local-operator-console.md) replaces static sample
data only for its evidence and proposal-inspection surfaces. Actual owner login,
one-use viewer invitations, explicit restricted mission access, current-account
checks and repository-manifest verification are implemented. Login is not order
adoption; the authenticated one-use decision and controller-consumption adapter
remains a separate completion condition.

The engineering boundary is deliberately narrow: application authentication can
separate owner and viewer requests without proving that the same OS user cannot
read the private database or replace the service. Loopback cookies are not
port-isolated; remote deployment, protected keys, non-bypassable execution and
independent retention cannot be inferred from this local product increment.
The USER deferred the deployment target on 2026-10-22; local progress does not
remove the protected-production goal. Primary implementation sources and their
claim limits are indexed in [the source map](source-map.md).

The later [authenticated order integration](operator-consent-and-adoption.md)
now carries exact owner decisions through the real adoption controller rather
than merely recording a UI status. Password reauthentication, one-use
session-bound finite challenges and per-publication source/repository/manifest
checks preserve the reviewed subject. Signed consent is non-authorizing
metadata, excluded even when copied or reformatted as an agent output.
Interrupted publications retain a reconciliation-required hold; neither service
restart nor a lost HTTP response automatically retries an approval. Broader
tool approvals and explicit hold discharge remain separate work.

The local worker queue now distinguishes a provisional message or termination
request from an observed worker exit. It serializes the next job and defers
response/shutdown ownership release until exit, retaining the fence if
termination cannot be confirmed. Real-thread and controlled lifecycle tests
cover that ordering. This is a local execution-liveness prerequisite, not
proof of durable decision effects or an implemented reconciliation procedure;
unknown outcomes remain held. Node's versioned worker documentation is indexed
in the source map; these additional hold rules are project policy.

The later outcome inspector replays the exact signed consent, USER decision
and adoption record through current verified history. It distinguishes a
partial consent, an unconsumed decision and a recorded disposition even when
the private action is still held after interruption. Owner-only read-only
SQLite and snapshot/key/source checks prevent inspection from mutating the
decision. An expired historical consent is not renewed. This makes the actual
outcome inspectable; fresh terminal consent, old-decision cancellation, receipts
and guarded hold discharge belong to the separate
[terminal ceremony](operator-terminal-reconciliation.md), not the read-only
inspector. General tool/gateway/campaign holds are not interchangeable.
