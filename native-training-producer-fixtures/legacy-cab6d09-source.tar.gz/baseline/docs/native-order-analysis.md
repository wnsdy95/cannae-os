# Native Request Analysis And Proposed Orders

## Boundary

This local candidate lets the selected existing Codex CLI propose a typed mission
analysis from one retained request and compiles its result through the actual
request-to-OPORD compiler. It does not make an omission evaluator a planner, grant
task tools, calibrate semantics, adopt an order or close any program outcome.
The structural plan generator still uses an explicit roster/policy/control
envelope; a proposed analysis cannot invent capacity or reset parent budgets.

The shared bounded collector preserves the pinned CLI 0.162.1 transport, finite
process/output limits, private one-use journal, no automatic retry and observed
child/group exit. Purpose adapters fix the preview, prompt, schema, invocation,
consent and result types in trusted code. An omission consent cannot execute an
analysis invocation, nor can an analysis challenge be committed at the omission
endpoint. Saved login and prior order consent never authorize this transmission.
This is local process control, not protected-host or native-context attestation.

## Prepare And Review

The trusted host may use [CLI-default preparation](codex-default-model-binding.md)
to freeze a concrete model before opening. Each analysis packet retains that
resolution; no role, browser field or later default change can substitute a model
for the owner's exact consent. This remains separate from semantic calibration.

Capture the exact request with the existing compiler first. Both provider skills
offer a prepare-only wrapper; it requires the target repository and exposes no
run, model, role, approval or clock override:

```bash
node codex-skills/controls-doctrine-operator/scripts/prepare_controls_analysis.js \
  prepare --repository <repository> --request-id <retained-request-id> \
  --artifact-root <artifact-root>
```

Preparation verifies current source, request, manifest, handling, OPSEC/EEFI and
a finite proposed-role envelope. Only public/internal request text is transmitted;
there are no evidence-file or arbitrary source-ref inputs. The preview binds
exact source, schema, method, roles and runtime state and expires within five
minutes. It transmits nothing. Default proposed roles are S2/S3; a trusted library
host may configure a finite subset of the known non-command roles.

The trusted host separately configures `--analysis-executable` and
`--analysis-model`; neither comes from a browser body or request instructions.
Open the retained mission request in Evidence and select Propose Order Analysis.
Review the complete packet, model alias, CLI/executable digest, purpose, role
envelope, limits and absence of a provider billing cap. The authenticated owner
reauthenticates with a password and one-use session-bound nonce for purpose
`one_order_analysis_transfer_and_draft`. Never automate real owner approval,
create a development signing key for real work or expose private packet content
in agent chat. The distinct omission profile remains independently opt-in.

## Actual Output Consumption

Model responses contain only statements, section references, role tasks, retained
decisions and false authority flags. Mission/wave/request identities and analysis
ID are bound by the host. Source quotes must match exact UTF-8 bytes; unsupported
facts, duplicate/missing references, unknown fields, authority fields and roles
outside the reviewed envelope fail. Proposals, assumptions and unknowns remain
explicitly separate from attributed facts.

The full projected draft must also fit the compiler reader's unchanged 8 MiB
limit, including actual JSON formatting, escaping and inherited repetitions.
A small accepted response shape is not proof of bounded derived output. The
collector's assessment and actual compiler both reject excessive expansion
before draft publication; failed collection keeps its original journal and hold.
Do not retry a transfer, raise the reader limit or silently drop boundaries to
make it fit. Request a separately reviewed decomposition instead. Existing
oversized historical artifacts remain unreadable and held, not auto-repaired.

The actual compiler verifies the source again and persists a non-executable draft.
Blocking unknowns or incomplete required sections produce needs_clarification,
never a manufactured ready result. Successful analysis still needs independently
reviewed human inventory/coverage, complete bounded plan review, USER adoption,
backbrief/rehearsal, model/routing preflight and actual dispatch gates.

The signed `OperatorOrderAnalysis` binds response digest, original collector
journal and compiled draft reference/status. It is control metadata, including
nested/wrapped copies, not work evidence. The draft does not prove complete
extraction or good strategy. It does not yet carry a calibrated model-origin
admission class; actual adoption remains the separate human-review class.

A retained predecessor probe changed only the stored invocation's projected
mission while leaving its invocation-digest field and original signatures intact.
Historical inspection incorrectly returned the substituted scope as verified;
fresh collection still rejected it before launch. Positive transport/browser
checks did not cover that historical path. The shared verifier now independently
rehashes the entire invocation and nested preview before consent/result history
can be trusted, without live freshness renewal. Both analysis and omission
history fail closed on changed bodies; recomputing hashes cannot reuse the old
signed consent. Preserve the original failed probe and immutable journal instead
of re-signing altered history. This is not a native-execution bypass claim or
protected-host proof.

Inspect Model Actions after lost delivery. Failed, unknown, changed-source or
interrupted collection/publication remains held and fences both local model
purposes. The existing omission-only failed-transfer acknowledgment explicitly
rejects analysis actions. The separate [analysis ceremony](order-analysis-reconciliation.md)
now supports a verifiable failed transfer and exact observed compiler publication,
not missing/integrity/unknown-process recovery. Never delete rows, relabel purpose, reuse a nonce or rerun a model to
clear a hold. Result inspection cannot establish remote cancellation or billing.
If compilation publishes a draft before a later failure, keep that exact draft
and the held action. Inspect Evidence and Model Actions separately; neither
absence of a successful response nor a visible draft permits model replay.

## Sources And Evidence

The official [Codex exec documentation](https://learn.chatgpt.com/docs/developer-commands#codex-exec)
describes non-interactive JSON events and structured/ephemeral output options.
The exact fixed profile additionally follows the previously reviewed local CLI;
these settings are project policy, not a documentation guarantee of isolation.
Contract/HTTP/browser tests use measured fake providers and synthetic accounts,
not real owner approval or model-quality evidence. Independent held-out semantic
calibration, autonomous orchestration, hierarchical method planning, complete
recovery and protected deployment remain open.
