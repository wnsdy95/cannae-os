#!/usr/bin/env node

const crypto = require("crypto");
const fs = require("fs");
const path = require("path");
const { spawnSync } = require("child_process");

const RULES = [
  {
    id: "task-training",
    keywords: ["task training", "task-training", "training evidence", "training qualification", "training session", "training-session", "prepare_controls_training_session", "tasktrainingstandard", "tasktrainingtrialrequest", "tasktrainingsessionbinding", "tasktrainingtrialappraisal", "tasktrainingsessionproposal", "tasktrainingsessionauthorization", "native training", "native-training", "training product", "codex-training-product", "prepare_controls_training_product", "nativetrainingproductrequest", "nativetrainingproductappraisal", "nativetrainingproductresponse", "nativetrainingproductpreview", "codextrainingproductinvocation", "codextrainingproductcollection", "trainingproducttransferconsent", "training transfer", "training handling", "operator-native-training", "nativetrainingtransferreviewrequest", "nativetrainingtransferauthorization", "operatornativetrainingproduct"],
    docs: ["docs/task-training-evidence.md", "docs/training-session-consent.md", "docs/native-training-products.md", "docs/native-training-owner-consent.md", "docs/training-progression-model.md", "docs/force-registry-enrollment.md", "docs/readiness-to-authority-policy.md"],
    commands: ["node run-task-training-contract-fixtures.js", "node run-task-training-fixtures.js", "node run-training-session-contract-fixtures.js", "node run-training-session-fixtures.js", "node run-native-training-product-contract-fixtures.js", "node run-native-training-product-fixtures.js", "node run-native-training-transfer-contract-fixtures.js", "node run-native-training-transfer-fixtures.js", "node run-native-training-transfer-adversarial-fixtures.js"]
  },
  {
    id: "readiness-intersection",
    keywords: ["minimum readiness", "readiness authority intersection", "readiness-authority-intersection", "readiness intersection", "approval cannot replace readiness"],
    docs: ["docs/readiness-authority-intersection.md", "docs/readiness-to-authority-policy.md", "docs/readiness-drop-reconciliation.md", "docs/completion-backlog.md"],
    commands: ["node readiness-gate-prototype/run-readiness-fixtures.js", "node run-authority-integration-fixtures.js", "node run-release-integration-fixtures.js"]
  },
  {
    id: "cli-model-selection",
    keywords: ["@cli-default", "cli default model", "default model binding", "codexmodelselection", "codex-model-selection"],
    docs: ["docs/codex-default-model-binding.md", "docs/model-transfer-consent.md", "docs/native-order-analysis.md"],
    commands: ["node run-codex-model-selection-fixtures.js", "node run-model-invocation-integrity-fixtures.js", "node run-operator-semantic-fixtures.js", "node run-native-order-analysis-fixtures.js", "node run-skill-control-evidence-fixtures.js"]
  },
  {
    id: "advisory-dependency",
    keywords: ["ip-address", "ip-zone", "zone parser", "ghsa-rxp7-6hxx-x8q5", "verifier dependency", "dependency migration", "historical producer", "parser denial of service"],
    docs: ["docs/github-release-independent-verification.md", "docs/completion-backlog.md"],
    commands: ["node run-github-release-independent-verification-fixtures.js", "node run-github-release-integrity-fixtures.js"]
  },
  {
    id: "force-registry",
    keywords: ["force registry", "force-registry", "capability registry", "performer registry", "organization registry", "forceregistryentity", "forceregistryrequest", "forceregistryproposal", "forceregistryauthorization", "forceregistryevent", "operate_controls_force_registry"],
    docs: ["docs/force-registry-enrollment.md", "docs/readiness-drop-reconciliation.md", "docs/readiness-to-authority-policy.md", "docs/force-structure-change-policy.md", "docs/completion-backlog.md"],
    commands: ["node run-force-registry-contract-fixtures.js", "node run-force-registry-fixtures.js"]
  },
  {
    id: "workload-controls",
    keywords: ["workload control", "workload-control", "workload-policy-assessment", "workloadcontrolinput", "workloadcontrolreceipt", "workloadcontrolfailure", "workloadpolicyassessment", "subject-bound", "workload assessment", "report input binding", "actual evidence scan"],
    docs: ["docs/subject-bound-workload-controls.md", "docs/skill-operational-mission-lifecycle.md", "docs/sensitive-output-filter.md", "docs/completion-backlog.md"],
    commands: ["node run-workload-control-fixtures.js", "node run-skill-control-enforcement-fixtures.js"]
  },
  {
    id: "force-readiness",
    keywords: ["readiness drop", "readiness-drop", "readiness revocation", "readiness_requalification_required", "training progression", "cross-mission capability", "readiness-to-authority", "agent-readiness", "reconcile_controls_readiness"],
    docs: ["docs/readiness-drop-reconciliation.md", "docs/readiness-to-authority-policy.md", "docs/training-progression-model.md", "docs/agent-readiness-ledger.md", "docs/force-structure-change-policy.md", "docs/completion-backlog.md"],
    commands: ["node run-readiness-drop-revocation-fixtures.js", "node run-aar-readiness-update-fixtures.js", "node run-force-structure-change-fixtures.js"]
  },
  {
    id: "analysis-reconciliation",
    keywords: ["analysis reconciliation", "analysis-reconciliation", "analysis hold", "analysis-hold", "failed request analysis", "order analysis recovery", "order analysis failed transfer", "operator-analysis-publication", "operator-reconciliation-contract-core"],
    docs: ["docs/order-analysis-reconciliation.md", "docs/native-order-analysis.md", "docs/model-transfer-reconciliation.md"],
    commands: ["node run-operator-analysis-reconciliation-contract-fixtures.js", "node run-operator-analysis-reconciliation-fixtures.js", "node run-operator-model-reconciliation-contract-fixtures.js", "node run-operator-model-reconciliation-fixtures.js", "node run-skill-control-evidence-fixtures.js"]
  },
  {
    id: "order-analysis-generation",
    keywords: ["order analysis", "order-analysis", "native planning", "native-order-planning", "prepare_controls_analysis", "codex-bounded-collector", "model invocation integrity", "model-invocation-integrity", "derived order", "draft too large", "order_intake_draft_too_large"],
    docs: ["docs/native-order-analysis.md", "docs/request-order-intake.md", "docs/model-transfer-consent.md", "docs/bounded-plan-synthesis.md"],
    commands: ["node run-request-order-compiler-fixtures.js", "node run-order-analysis-generation-fixtures.js", "node run-native-order-analysis-fixtures.js", "node run-model-invocation-integrity-fixtures.js", "node run-semantic-evaluation-fixtures.js", "node run-operator-semantic-fixtures.js", "node run-skill-control-evidence-fixtures.js"]
  },
  {
    id: "bounded-planning",
    keywords: ["bounded planning", "bounded-planning", "automatic plan", "structural synthesis", "plan_controls_mission"],
    docs: ["docs/bounded-plan-synthesis.md", "docs/requirement-inventory-admission.md", "docs/order-adoption-and-plan-binding.md", "docs/order-revision-and-supersession.md"],
    commands: ["node run-bounded-planning-fixtures.js", "node run-bounded-planning-metadata-fixtures.js", "node run-order-adoption-fixtures.js", "node run-order-revision-fixtures.js", "node run-skill-control-evidence-fixtures.js"]
  },
  {
    id: "semantic-admission",
    keywords: ["requirement inventory", "requirement-inventory", "semantic admission", "semantic-admission", "semantic coverage", "semantic-coverage", "human coverage review", "semantic review assignment", "semantic-review-assignment", "review_controls_requirements"],
    docs: ["docs/requirement-inventory-admission.md", "docs/order-adoption-and-plan-binding.md", "docs/operator-consent-and-adoption.md", "docs/semantic-omission-evaluation.md"],
    commands: ["node run-requirement-inventory-fixtures.js", "node run-operator-coverage-ui-fixtures.js", "node run-order-adoption-fixtures.js", "node run-skill-control-evidence-fixtures.js"]
  },
  {
    id: "semantic-omission",
    keywords: ["semantic omission", "semantic completeness", "semantic-omission", "semantic-evaluation", "codex-semantic", "model transfer consent", "model-transfer-consent", "operator-semantic", "semantic-control", "evaluate_controls_request", "model hold", "model-reconciliation", "model-transfer-reconciliation"],
    docs: ["docs/semantic-omission-evaluation.md", "docs/model-transfer-consent.md", "docs/model-transfer-reconciliation.md", "docs/request-order-intake.md", "docs/operator-consent-and-adoption.md", "docs/completion-backlog.md"],
    commands: ["node run-semantic-evaluation-fixtures.js", "node run-operator-semantic-fixtures.js", "node run-operator-model-reconciliation-fixtures.js", "node run-skill-control-evidence-fixtures.js"]
  },
  {
    id: "operational-cop",
    keywords: ["operational cop", "operational-cop", "operations screen", "live situation", "role-filtered situation", "critical alert scope"],
    docs: ["docs/operational-cop.md", "docs/local-operator-console.md", "docs/command-post-dashboard.md", "docs/completion-backlog.md"],
    commands: ["node run-operational-cop-fixtures.js"]
  },
  {
    id: "local-operator-console",
    keywords: ["operator consent", "operator-consent", "operator-reconciliation", "operator terminal", "terminal order reconciliation", "terminal review", "review terminal outcome", "cancel interrupted order", "decision outcome", "inspect outcome", "authenticated order review", "operator console", "local-operator-console", "operator worker", "worker exit", "interrupted owner decision", "evidence api", "viewer invitation", "serve_controls_operator"],
    docs: ["docs/local-operator-console.md", "docs/operator-consent-and-adoption.md", "docs/operator-terminal-reconciliation.md", "docs/order-adoption-and-plan-binding.md", "docs/completion-backlog.md"],
    commands: ["node run-operator-console-fixtures.js", "node run-operator-consent-fixtures.js", "node run-operator-console-worker-fixtures.js", "node run-operator-consent-outcome-fixtures.js", "node run-operator-reconciliation-fixtures.js"]
  },
  {
    id: "orientation",
    keywords: ["overview", "framework", "start", "read", "use", "description", "overall", "concept", "begin", "usage"],
    docs: [
      "README.md",
      "docs/military-llm-framework-v0.1.md",
      "docs/military-operating-system.md",
      "docs/glossary.md",
      "docs/source-map.md"
    ],
    commands: []
  },
  {
    id: "orders",
    keywords: ["order replay", "order-replay", "order revision", "order-revision", "revise_controls_order", "order adoption", "order-adoption", "order-backbrief", "order-rehearsal", "adopt_controls_order", "request intake", "mission analysis", "request-order-compiler", "compile_controls_order", "order-intake", "order-draft", "mission-request", "mission-order-analysis", "opord", "warno", "frago", "sitrep", "aar", "backbrief", "rehearsal", "prompt", "orders", "command", "issuance", "prompting", "dry-run"],
    docs: [
      "docs/prompt-templates.md",
      "docs/orders-production-pipeline.md",
      "docs/request-order-intake.md",
      "docs/order-adoption-and-plan-binding.md",
      "docs/order-revision-and-supersession.md",
      "docs/opord-annex-model.md",
      "docs/backbrief-and-rehearsal-sop.md",
      "docs/information-to-operations-cycle.md"
    ],
    commands: [
      "node runtime-demo-runner.js",
      "node orders-dissemination-runner.js runtime-demo-payloads/opord.json runtime-demo-payloads/backbrief.json runtime-demo-payloads/rehearsal.json",
      "node run-request-order-compiler-fixtures.js",
      "node run-order-adoption-fixtures.js",
      "node run-order-revision-fixtures.js"
    ]
  },
  {
    id: "intent-initiative",
    keywords: ["commander intent", "commander's intent", "mission command", "mission-command", "intent continuity", "intent-continuity", "intent lineage", "task conservation", "disciplined initiative", "disciplined-initiative", "disciplined method", "method control", "method assignment", "method deviation", "method-deviation", "method baseline", "method drift", "report before", "report after", "check_controls_intent", "operate_controls_methods"],
    docs: ["docs/mission-command-runtime-policy.md", "docs/disciplined-initiative-rules.md", "docs/intent-continuity-runtime.md", "docs/method-deviation-runtime.md", "docs/commander-handbook.md"],
    commands: ["node run-intent-continuity-fixtures.js", "node run-method-deviation-contract-fixtures.js"]
  },
  {
    id: "method-control-channel",
    keywords: ["method control channel", "method channel", "method-control", "method broker", "MCP method", "operate_controls_channel", "serve_controls_methods"],
    docs: ["docs/method-control-channel.md", "docs/method-deviation-runtime.md", "docs/enforced-dispatch-and-resume.md"],
    commands: ["node run-method-control-contract-fixtures.js"]
  },
  {
    id: "authority-risk-release",
    keywords: ["dependency migration", "verifier dependency", "producer compatibility", "lockfile update", "ip-address", "authority", "approval", "risk", "roe", "release", "scope", "delegation", "sign-off", "authorization", "hazard", "disclosure", "publish", "entrustment", "immutability", "attestation", "integrity", "drift", "tuf", "trusted-root", "bundle", "sigstore", "offline verification"],
    docs: [
      "docs/agent-roles-and-authority.md",
      "docs/tool-use-roe.md",
      "docs/approval-scope-policy.md",
      "docs/risk-acceptance-authority.md",
      "docs/context-releasability-policy.md",
      "docs/github-release-authorization.md",
      "docs/github-release-immutability.md",
      "docs/github-release-integrity-monitoring.md",
      "docs/github-release-independent-verification.md",
      "docs/policy-engine-rules.md"
    ],
    commands: [
      "node run-authority-integration-fixtures.js",
      "node run-release-integration-fixtures.js",
      "node run-github-release-publisher-fixtures.js",
      "node run-github-release-immutability-fixtures.js",
      "node run-github-release-integrity-fixtures.js",
      "node run-github-release-independent-verification-fixtures.js"
    ]
  },
  {
    id: "multi-agent-organization",
    keywords: ["agent", "multi-agent", "role", "staff", "department", "collaboration", "b2c2wg", "liaison", "assistant", "billet", "staff officer", "division", "teamwork", "branch"],
    docs: [
      "docs/llm-agent-org-chart.md",
      "docs/agent-roles-and-authority.md",
      "docs/interdepartment-collaboration-policy.md",
      "docs/b2c2wg-operating-model.md",
      "docs/agent-battle-rhythm.md"
    ],
    commands: [
      "node run-department-collaboration-fixtures.js"
    ]
  },
  {
    id: "force-structure",
    keywords: ["force", "structure", "unit", "role creation", "disband", "expand", "reduce", "dotmlpf", "formation", "buildup", "drawdown", "stand-up", "deactivation"],
    docs: [
      "docs/force-structure-change-policy.md",
      "docs/military-operating-deep-research-queue.md",
      "docs/multinational-doctrine-consistency-review.md"
    ],
    commands: [
      "node run-force-structure-change-fixtures.js"
    ]
  },
  {
    id: "model-force-assignment",
    keywords: ["model", "models", "allocate", "model allocation", "model assignment", "model routing", "model selection", "cascade", "small model", "smaller", "strong model", "frontier model", "submodel", "model profile", "capability band", "model force", "model registry", "integrated preflight", "dispatch manifest", "model usage"],
    docs: [
      "docs/model-force-assignment-policy.md",
      "docs/model-force-v0.2-operations.md",
      "docs/agent-metl.md",
      "docs/agent-readiness-ledger.md",
      "docs/evaluation-metrics.md",
      "docs/ai-special-operations-tf.md"
    ],
    commands: [
      "node run-model-force-assignment-fixtures.js",
      "node run-model-force-v0.2-fixtures.js"
    ]
  },
  {
    id: "repository-artifact-isolation",
    keywords: ["artifact", "artifacts", "output", "outputs", "deliverable", "repository output", "multi-repo", "multiple repositories", "cross-repository", "artifact store", "repository isolation", "generated file", "lease", "fencing", "stale writer", "concurrency"],
    docs: [
      "docs/repository-artifact-isolation-policy.md",
      "docs/knowledge-management-sop.md",
      "docs/model-force-v0.2-operations.md"
    ],
    commands: [
      "node run-repository-artifact-isolation-fixtures.js",
      "node run-repository-artifact-concurrency-fixtures.js",
      "node run-repository-artifact-recovery-fixtures.js",
      "node validator-cli-prototype/validate.js sample-payloads/valid-repository-artifact-manifest.json repository-artifact-manifest"
    ]
  },
  {
    id: "gateway-effect-review",
    keywords: ["gateway effect", "gateway settlement", "gateway reconciliation", "gateway-effect", "orphan admission"],
    docs: ["docs/gateway-effect-review.md", "docs/gateway-effect-settlement.md", "docs/protected-tool-gateway-contract.md", "docs/enforced-dispatch-and-resume.md", "docs/approval-scope-policy.md", "docs/completion-backlog.md"],
    commands: ["node run-gateway-effect-review-fixtures.js", "node run-gateway-effect-settlement-fixtures.js", "node run-oci-linux-sandbox-provider-fixtures.js", "node run-protected-tool-gateway-fixtures.js", "node run-tool-effect-review-fixtures.js", "node run-tool-effect-settlement-fixtures.js"]
  },
  {
    id: "tool-effect-review",
    keywords: ["unknown tool effects", "effect reconciliation", "effect settlement", "effect scope", "tool effect review", "tool-effect", "unresolved effects", "reconciled failure", "reconciled_failed_effects", "post-settlement revocation"],
    docs: ["docs/tool-effect-review.md", "docs/tool-effect-settlement.md", "docs/enforced-dispatch-and-resume.md", "docs/approval-scope-policy.md", "docs/completion-backlog.md"],
    commands: ["node run-tool-effect-review-fixtures.js", "node run-tool-effect-settlement-fixtures.js"]
  },
  {
    id: "dispatch-issuance-recovery",
    keywords: ["dispatch-issuance", "dispatch-lease-issuance", "issuance recovery", "partial issuance", "recover-issuance", "cancel-issuance"],
    docs: ["docs/dispatch-issuance-recovery.md", "docs/enforced-dispatch-and-resume.md", "docs/method-control-channel.md"],
    commands: ["node run-dispatch-issuance-contract-fixtures.js"]
  },
  {
    id: "enforced-dispatch",
    keywords: ["gateway ownership", "gateway obligations", "late gateway callback", "dispatch lease", "agent lease", "tool admission", "pretooluse", "posttooluse", "sessionstart", "resume session", "resumable execution", "execution checkpoint", "dispatch policy", "hook enforcement", "interrupt agent", "revoke lease", "tool replay", "runtime gate", "protected tool gateway", "tool gateway", "gateway transaction", "gateway recovery", "gateway identity", "authenticated reference", "mtls gateway", "tls exporter", "execution receipt", "idempotency", "protected process", "bounded process", "process executor", "native executable", "shebang", "interpreter", "exact argv", "execution envelope", "execution observation", "oci linux sandbox", "oci sandbox", "linux sandbox", "sandbox provider", "immutable image", "seccomp profile", "no new privileges", "no_new_privs", "cap drop", "read only rootfs", "recursive read only", "cgroup v2", "network none", "kernel probe", "container cleanup", "cleanup failure", "daemon unavailable", "container absence", "containment observation", "daemon substitution", "production sandbox", "production admission", "rats", "eat", "slsa provenance", "managed exclusive", "appraiser quorum", "external coordinator", "storage fencing", "exclusive path"],
    docs: [
      "docs/enforced-dispatch-and-resume.md",
      "docs/protected-tool-gateway-contract.md",
      "docs/gateway-identity-admission.md",
      "docs/protected-process-execution.md",
      "docs/oci-linux-sandbox-provider.md",
      "docs/production-sandbox-admission.md",
      "docs/skill-operational-mission-lifecycle.md",
      "docs/tool-use-roe.md",
      "docs/repository-artifact-isolation-policy.md",
      "docs/agent-roles-and-authority.md"
    ],
    commands: [
      "node run-dispatch-runtime-fixtures.js",
      "node run-protected-tool-gateway-fixtures.js",
      "node run-gateway-identity-adapter-fixtures.js",
      "node run-protected-process-executor-fixtures.js",
      "node run-oci-linux-sandbox-provider-fixtures.js",
      "node run-production-sandbox-admission-fixtures.js",
      "node run-production-sandbox-gateway-fixtures.js",
      "node validator-cli-prototype/validate.js sample-payloads/valid-dispatch-tool-policy.json dispatch-tool-policy",
      "node validator-cli-prototype/validate.js sample-payloads/valid-agent-dispatch-lease.json agent-dispatch-lease",
      "node validator-cli-prototype/validate.js sample-payloads/valid-agent-execution-checkpoint.json agent-execution-checkpoint",
      "node validator-cli-prototype/validate.js sample-payloads/valid-tool-gateway-request.json tool-gateway-request"
    ]
  },
  {
    id: "bounded-self-improvement",
    keywords: ["activate_controls_successor", "campaign-successor", "successor admission", "successor proposal", "campaign successor", "campaign terminal", "successor activation", "campaign stop", "campaign lifecycle", "campaign termination", "successor restart", "self-improvement", "self improvement", "autonomous improvement", "continuous improvement", "adaptive work", "improvement campaign", "checkpoint controller", "campaign supervisor", "cycle order", "resume campaign", "proof carrying", "verification receipt", "verification attestation", "comparative attestation", "signed comparative report", "attestation", "ed25519", "dsse", "signed quorum", "trust policy", "trust admission", "verifier readiness", "verifier independence", "failure domain", "correlation domain", "shared runner", "shared account", "shared project", "pre-dispatch admission", "pre-dispatch challenge", "challenge", "nonce", "liveness", "replay", "stale responder", "offline verifier", "remote verifier", "verifier identity", "verifier execution", "execution integrity", "execution evidence", "runtime policy", "github actions oidc", "gitlab ci oidc", "gitlab oidc", "native provider adapter", "jwks", "jwt", "verifier oci", "verifier sandbox", "verifier execution sandbox", "workload identity", "spiffe", "svid", "x509", "x.509", "transparency log", "transparency operations", "transparency state", "consistency proof", "witness", "monitor", "gossip", "root rotation", "equivocation", "revocation", "tuf", "merkle", "checkpoint", "sigstore", "sigstore bundle", "cosign bundle", "fulcio", "trustedroot", "trusted root", "rekor", "compare", "comparison", "comparative evaluation", "comparative promotion", "candidate promotion", "promote candidate", "promotion gate", "canary", "non-regression", "baseline", "baseline candidate", "improve in-progress work", "evolve work", "quality loop", "learning loop"],
    docs: [
      "docs/bounded-self-improvement-operations.md",
      "docs/campaign-terminal-reconciliation.md",
      "docs/campaign-successor-admission.md",
      "docs/sigstore-verifier-workload-admission.md",
      "docs/verifier-execution-integrity.md",
      "docs/github-actions-native-verifier-adapter.md",
      "docs/gitlab-ci-native-verifier-adapter.md",
      "docs/verifier-pre-dispatch-challenge.md",
      "docs/verifier-independence-assurance.md",
      "docs/transparency-operations.md",
      "docs/agent-roles-and-authority.md",
      "docs/approval-scope-policy.md",
      "docs/repository-artifact-isolation-policy.md",
      "docs/knowledge-management-sop.md",
      "docs/evaluation-metrics.md",
      "docs/runtime-automation-roadmap.md"
    ],
    commands: [
      "node run-self-improvement-fixtures.js",
      "node run-signed-self-improvement-fixtures.js",
      "node run-campaign-supervisor-fixtures.js",
      "node run-campaign-terminal-fixtures.js",
      "node run-campaign-successor-fixtures.js",
      "node run-verifier-trust-readiness-fixtures.js",
      "node run-verifier-identity-evidence-fixtures.js",
      "node run-sigstore-verifier-identity-fixtures.js",
      "node run-verifier-execution-evidence-fixtures.js",
      "node run-github-actions-oidc-fixtures.js",
      "node run-gitlab-ci-oidc-fixtures.js",
      "node run-verifier-challenge-fixtures.js",
      "node run-verifier-independence-fixtures.js",
      "node run-transparency-operations-fixtures.js",
      "node run-transparency-supervisor-fixtures.js",
      "node run-workload-identity-admission-fixtures.js",
      "node run-cycle-order-admission-fixtures.js",
      "node run-verification-runner-fixtures.js",
      "node run-verification-attestation-fixtures.js",
      "node run-comparative-evaluation-fixtures.js",
      "node run-comparative-evaluation-attestation-fixtures.js",
      "node validator-cli-prototype/validate.js sample-payloads/valid-self-improvement-campaign.json self-improvement-campaign",
      "node validator-cli-prototype/validate.js sample-payloads/valid-self-improvement-checkpoint.json self-improvement-checkpoint",
      "node validator-cli-prototype/validate.js sample-payloads/valid-self-improvement-cycle-order.json self-improvement-cycle-order",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verification-receipt.json verification-receipt",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verifier-trust-policy.json verifier-trust-policy",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verifier-identity-evidence.json verifier-identity-evidence",
      "node validator-cli-prototype/validate.js sample-payloads/valid-sigstore-trusted-root.json sigstore-trusted-root",
      "node validator-cli-prototype/validate.js sample-payloads/valid-sigstore-verifier-identity-evidence.json sigstore-verifier-identity-evidence",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verifier-runtime-policy.json verifier-runtime-policy",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verifier-execution-evidence.json verifier-execution-evidence",
      "node validator-cli-prototype/validate.js sample-payloads/valid-github-actions-oidc-evidence.json github-actions-oidc-evidence",
      "node validator-cli-prototype/validate.js sample-payloads/valid-gitlab-ci-oidc-evidence.json gitlab-ci-oidc-evidence",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verifier-challenge-set.json verifier-challenge-set",
      "node validator-cli-prototype/validate.js sample-payloads/valid-verification-attestation.json verification-attestation",
      "node validator-cli-prototype/validate.js sample-payloads/valid-comparative-evaluation-attestation.json comparative-evaluation-attestation"
    ]
  },
  {
    id: "sof-tf",
    keywords: ["sof", "special", "task force", "tf", "incident", "high-risk", "special forces", "specialized", "critical-risk"],
    docs: [
      "docs/ai-special-operations-tf.md",
      "docs/multinational-doctrine-consistency-review.md"
    ],
    commands: [
      "node run-sof-tf-fixtures.js"
    ]
  },
  {
    id: "sources-research",
    keywords: ["source", "research", "citation", "doctrine", "nato", "uk", "canada", "korea", "multinational", "sourcing", "investigation", "paper", "doctrinal", "u.s. military", "korean military", "coalition"],
    docs: [
      "docs/source-map.md",
      "docs/research-compendium.md",
      "docs/source-reliability-rubric.md",
      "docs/korean-military-sources.md",
      "docs/korean-org-culture.md",
      "docs/multinational-doctrine-consistency-review.md"
    ],
    commands: [
      "node source-map-linter.js",
      "node run-doctrine-consistency-fixtures.js"
    ]
  },
  {
    id: "document-access-context",
    keywords: ["document access", "need-to-know", "context", "classification", "opsec", "eefi", "records", "entry", "situational context", "confidential", "security"],
    docs: [
      "docs/role-document-access-policy.md",
      "docs/context-releasability-policy.md",
      "docs/opsec-classification-model.md",
      "docs/knowledge-management-sop.md"
    ],
    commands: [
      "node run-document-access-fixtures.js",
      "node run-release-review-fixtures.js"
    ]
  },
  {
    id: "runtime-validation",
    keywords: ["schema", "validator", "runner", "fixture", "test", "json", "runtime", "verification", "schematic", "test runner", "testing"],
    docs: [
      "schema-files/README.md",
      "sample-payloads/README.md",
      "docs/evaluation-fixtures.md",
      "docs/validator-prototype.md",
      "validator-cli-prototype/README.md"
    ],
    commands: [
      "node validator-cli-prototype/run-fixtures.js"
    ]
  },
  {
    id: "runtime-architecture-dashboard",
    keywords: ["architecture", "dashboard", "event", "projection", "ui", "database", "maintenance", "readiness", "architectural", "control panel", "eventing", "projected view", "upkeep", "preparedness"],
    docs: [
      "docs/reference-architecture.md",
      "docs/event-sourcing-model.md",
      "docs/command-post-dashboard.md",
      "docs/dashboard-wireframes.md",
      "docs/maintenance-readiness-model.md",
      "docs/data-model.sql.md"
    ],
    commands: [
      "node run-maintenance-dashboard-fixtures.js",
      "node event-replay-prototype/run-event-fixtures.js"
    ]
  },
  {
    id: "continuity-handoff",
    keywords: ["continuity", "handoff", "rotation", "succession", "knowledge", "km", "handover", "succession planning", "replacement", "cycling", "knowledge transfer"],
    docs: [
      "docs/personnel-continuity-model.md",
      "docs/knowledge-management-sop.md",
      "docs/event-sourcing-model.md"
    ],
    commands: [
      "node run-continuity-drill-fixtures.js"
    ]
  },
  {
    id: "skill-operations",
    keywords: ["skill", "routing", "operator", "inventory", "coverage", "install", "installer", "cli", "codex", "claude", "skillset", "skill adaptation", "skill improvement", "mandatory skill improvement", "route mapping", "documentation system", "doc taxonomy", "coverage report", "setup", "auto-setup", "mission lifecycle", "open wave", "context pack", "wave report", "wave closeout", "operational skill", "termination", "supersession", "expired wave", "abort wave", "implementation candidate", "completion backlog", "completion audit", "corpus maintenance", "implementation-candidate", "completion-backlog"],
    docs: [
      ".claude/skills/controls-doctrine-operator/SKILL.md",
      "docs/implementation-candidate-registry.md",
      "docs/completion-backlog.md",
      ".claude/skills/controls-doctrine-operator/references/self-improvement-loop.md",
      "install-ai-cli-skills.sh",
      "codex-skills/controls-doctrine-operator/SKILL.md",
      "codex-skills/controls-doctrine-operator/references/document-routing.md",
      "codex-skills/controls-doctrine-operator/references/self-improvement-loop.md",
      "docs/skill-operational-mission-lifecycle.md",
      "docs/controls-doctrine-operator-skill.html"
    ],
    commands: [
      "node .claude/skills/controls-doctrine-operator/scripts/route_controls_docs.js --coverage .",
      "node run-skill-control-enforcement-fixtures.js",
      "node run-agent-routing-preflight-fixtures.js",
      "node implementation-candidate-registry.js audit",
      "node validate-controls-skill.js .claude/skills/controls-doctrine-operator",
      "node validate-controls-skill.js codex-skills/controls-doctrine-operator"
    ]
  }
];

const CAPABILITY_GAP_DOCS = [
  "docs/force-structure-change-policy.md",
  "docs/interdepartment-collaboration-policy.md",
  "docs/b2c2wg-operating-model.md",
  "docs/agent-roles-and-authority.md",
  "schema-files/force-structure-change-order.schema.json"
];

const CAPABILITY_GAP_COMMANDS = [
  "node run-force-structure-change-fixtures.js",
  "node validator-cli-prototype/validate.js sample-payloads/valid-force-structure-change-order.json force-structure-change-order"
];

const GENERIC_ROUTE_KEYWORDS = new Set([
  "agent",
  "approval",
  "artifact",
  "artifacts",
  "assistant",
  "authority",
  "branch",
  "command",
  "context",
  "department",
  "framework",
  "incident",
  "model",
  "models",
  "output",
  "outputs",
  "research",
  "risk",
  "role",
  "scope",
  "source",
  "special",
  "staff",
  "teamwork",
  "tf",
  "unit",
  "use"
]);

const ROLE_DOCS = {
  COMMANDER: [
    "docs/risk-acceptance-authority.md",
    "docs/approval-scope-policy.md",
    "docs/context-releasability-policy.md"
  ],
  COS: [
    "docs/agent-battle-rhythm.md",
    "docs/interdepartment-collaboration-policy.md",
    "docs/personnel-continuity-model.md"
  ],
  S2: [
    "docs/source-map.md",
    "docs/source-reliability-rubric.md",
    "docs/opsec-classification-model.md"
  ],
  S3: [
    "docs/orders-production-pipeline.md",
    "docs/tool-use-roe.md",
    "docs/policy-engine-rules.md",
    "docs/enforced-dispatch-and-resume.md",
    "docs/protected-tool-gateway-contract.md",
    "docs/protected-process-execution.md",
    "docs/oci-linux-sandbox-provider.md",
    "docs/production-sandbox-admission.md"
  ],
  S4: [
    "docs/maintenance-readiness-model.md",
    "docs/agent-readiness-ledger.md",
    "docs/data-model.sql.md"
  ],
  S6: [
    "docs/reference-architecture.md",
    "docs/event-sourcing-model.md",
    "docs/command-post-dashboard.md"
  ]
};

const DEPARTMENT_DOCS = [
  {
    keywords: ["operations", "ops", "s3", "operational"],
    docs: ["docs/orders-production-pipeline.md", "docs/information-to-operations-cycle.md"]
  },
  {
    keywords: ["intelligence", "intel", "s2", "information"],
    docs: ["docs/source-reliability-rubric.md", "docs/opsec-classification-model.md"]
  },
  {
    keywords: ["logistics", "readiness", "maintenance", "s4", "sustainment", "upkeep", "preparedness"],
    docs: ["docs/maintenance-readiness-model.md", "docs/agent-readiness-ledger.md"]
  },
  {
    keywords: ["systems", "platform", "architecture", "s6", "system", "platforms"],
    docs: ["docs/reference-architecture.md", "docs/event-sourcing-model.md"]
  },
  {
    keywords: ["collaboration", "cross-functional", "liaison", "cooperation", "contact"],
    docs: ["docs/interdepartment-collaboration-policy.md", "docs/b2c2wg-operating-model.md"]
  }
];

const AUTHORITY_DOCS = [
  {
    keywords: ["approval", "approve", "sign-off"],
    docs: ["docs/approval-scope-policy.md"]
  },
  {
    keywords: ["release", "external", "final", "disclosure", "publish", "finalized"],
    docs: ["docs/context-releasability-policy.md", "docs/opsec-classification-model.md"]
  },
  {
    keywords: ["risk", "acceptance", "high-risk", "hazard"],
    docs: ["docs/risk-acceptance-authority.md", "docs/tool-use-roe.md"]
  },
  {
    keywords: ["execution", "tool", "scoped-execution", "carry-out", "instrument"],
    docs: ["docs/tool-use-roe.md", "docs/policy-engine-rules.md", "docs/enforced-dispatch-and-resume.md", "docs/protected-tool-gateway-contract.md", "docs/protected-process-execution.md", "docs/oci-linux-sandbox-provider.md", "docs/production-sandbox-admission.md"]
  }
];

const ROUTABLE_EXTENSIONS = new Set([".md", ".html", ".css", ".json", ".js", ".go", ".sh", ".svg", ".yaml", ".yml"]);
const EXCLUDED_DIRS = new Set([
  ".cache",
  ".cannae",
  ".cxt",
  ".git",
  ".idea",
  ".npm",
  ".nyc_output",
  ".pnpm-store",
  ".tmp",
  ".vscode",
  "build",
  "coverage",
  "dist",
  "node_modules",
  "temp",
  "tmp"
]);

const ROUTE_HINTS = [
  { id: "cli-model-selection", keywords: ["codex-model-selection", "codex-default-model-binding"] },
  { id: "advisory-dependency", keywords: ["ip-zone", "pre-zone", "github-release-independent-verification"] },
  { id: "task-training", keywords: ["task-training", "training-session", "native-training", "codex-training-product", "prepare_controls_training_product", "prepare_controls_training_session", "operator-console/training.js"] },
  { id: "force-registry", keywords: ["force-registry", "operate_controls_force_registry", "operator-console/force.js"] },
  { id: "workload-controls", keywords: ["workload-control", "workload-policy-assessment", "subject-bound-workload"] },
  { id: "force-readiness", keywords: ["readiness-drop", "reconcile_controls_readiness", "readiness-to-authority", "training-progression", "agent-readiness-ledger"] },
  { id: "analysis-reconciliation", keywords: ["analysis-reconciliation", "operator-analysis-publication", "operator-reconciliation-contract-core", "order-analysis-fixtures/reconciliation", "order-analysis-fixtures/write-reconciliation"] },
  { id: "order-analysis-generation", keywords: ["order-analysis", "native-order-planning", "native-order-analysis", "codex-bounded-collector", "prepare_controls_analysis", "model-invocation-integrity"] },
  { id: "bounded-planning", keywords: ["bounded-planning", "bounded-plan-synthesis", "plan_controls_mission"] },
  { id: "semantic-admission", keywords: ["requirement-inventory", "semantic-coverage", "semantic-review-assignment", "review_controls_requirements"] },
  { id: "semantic-omission", keywords: ["semantic-omission", "semantic-evaluation", "codex-semantic", "evaluate_controls_request", "operator-semantic", "semantic-control", "model-transfer-consent", "model-reconciliation", "model-transfer-reconciliation"] },
  { id: "method-control-channel", keywords: ["method-control", "operate_controls_channel", "serve_controls_methods"] },
  { id: "operational-cop", keywords: ["operational-cop"] },
  { id: "local-operator-console", keywords: ["operator-console", "operator-consent", "operator-reconciliation", "operator-terminal-reconciliation", "serve_controls_operator"] },
  { id: "intent-initiative", keywords: ["intent-continuity", "intent-delegation", "commander-intent", "mission-command", "disciplined-initiative", "method-control-baseline", "method-deviation", "initiative-deviation", "degeneration-incident", "check_controls_intent"] },
  {
    id: "gateway-effect-review",
    keywords: ["gateway-effect", "review_gateway_effects", "settle_gateway_effects", "effect-settlement-fixture-support"]
  },
  {
    id: "tool-effect-review",
    keywords: ["tool-effect", "effect-review-evidence", "effect-settlement-proof"]
  },
  {
    id: "skill-operations",
    keywords: ["codex-skills", ".claude", "claude", "controls-doctrine-operator", "skill", "skills", "install-ai-cli-skills", "route_controls_docs", "operate_controls_mission", "skill-mission-controller", "mission-wave", "agent-context-pack", "wave-closeout", "operational-mission-lifecycle", "operator-skill", "openai.yaml", "implementation-candidate", "completion-backlog"]
  },
  {
    id: "orientation",
    keywords: ["assets", "banner", "diagram", "image", "operating-loop", "repository-map", "readme", "contributing", "code-of-conduct", "governance", "support", "changelog", "military-llm-framework", "military-operating-system", "glossary", "commander-handbook", "sop-library", "case-studies", "functional-domains", "experiments", "implementation-guide"]
  },
  {
    id: "orders",
    keywords: ["order-revision", "revise_controls_order", "order-adoption", "order-backbrief", "order-rehearsal", "adopt_controls_order", "request-order", "order-intake", "order-draft", "mission-request", "mission-order-analysis", "compile_controls_order", "opord", "warno", "frago", "sitrep", "aar", "backbrief", "rehearsal", "orders", "task-order", "runtime-demo", "information-to-operations", "decision-packet", "ccir-alert", "ccir-linter", "alert-router", "reporting-threshold", "prompt", "prompt-dsl", "prompt-templates"]
  },
  {
    id: "authority-risk-release",
    keywords: ["authority", "authority-gates", "approval", "risk", "roe", "release", "security", "policy-engine", "decision-risk", "disciplined-initiative", "mission-command", "readiness-to-authority", "tool-use", "approval-", "risk-acceptance", "release-gate", "release-review", "github-release", "release-immutability", "release-integrity", "release-attestation", "trusted-root", "bundle-verifier", "independent-verification", "operate-github-release", "operate-github-release-immutability", "operate-github-release-integrity", "operate-github-release-verification", "decision-packet"]
  },
  {
    id: "multi-agent-organization",
    keywords: ["agent", "routing-preflight", "department", "collaboration", "b2c2wg", "working-group", "liaison", "partner-command", "interop", "chief-of-staff", "metl", "battle-rhythm", "board-decision", "llm-agent-org-chart", "functional-domains"]
  },
  {
    id: "force-structure",
    keywords: ["force-structure", "force", "structure-change", "unit", "dotmlpf"]
  },
  {
    id: "model-force-assignment",
    keywords: ["model-force-assignment", "model-profile", "model-allocation", "model-routing", "capability-band", "model-force", "model-registry", "model-assignment-compiler", "integrated-mission-preflight", "model-usage-event", "model-force-v0.2", "training-progression", "readiness-event"]
  },
  {
    id: "repository-artifact-isolation",
    keywords: ["repository-artifact", "artifact-store", "artifact-verify", "artifact-recovery", "repository-lease", "lease", "fencing", "stale-writer", "write-ahead", "manifest-history", "artifact-isolation", "repository-output", "multi-repo", "cross-repository", "generated-artifact"]
  },
  {
    id: "enforced-dispatch",
    keywords: ["dispatch-issuance", "dispatch-lease-issuance", "enforced-dispatch", "dispatch-runtime", "dispatch-hook", "dispatch-tool-policy", "agent-dispatch-lease", "tool-admission-event", "agent-execution-checkpoint", "operate-dispatch-runtime", "enforce-controls-dispatch", "install-dispatch-hooks", "dispatch-hook-installer", "pretooluse", "posttooluse", "sessionstart", "resumable-execution", "protected-tool-gateway", "operate_protected_gateway", "gateway-identity", "authenticated-reference", "mtls", "tls-exporter", "tool-gateway", "tool-execution-receipt", "gateway-transaction", "protected-process", "protected-executor", "bounded-process", "native-executable", "shebang", "interpreter", "execution-envelope", "execution-observation", "operate_protected_executor", "exact-argv", "oci-linux-sandbox", "oci-sandbox", "sandbox-provider", "operate_oci_sandbox", "production-sandbox", "production-admission", "operate_production_sandbox", "rats", "eat", "slsa-provenance", "managed-exclusive", "appraiser-quorum", "external-coordinator", "storage-fencing", "exclusive-path", "seccomp", "no-new-privileges", "cgroup", "network-none", "kernel-probe", "container-cleanup"]
  },
  {
    id: "bounded-self-improvement",
    keywords: ["campaign-successor", "activate_controls_successor", "campaign-terminal", "reconcile_controls_campaign", "campaign-stop", "stop_controls_campaign", "self-improvement", "self-improvement-campaign", "self-improvement-checkpoint", "self-improvement-decision", "self-improvement-cycle-order", "campaign-supervisor", "cycle-order", "verification-plan", "verification-receipt", "verification-attestation", "comparative-evaluation-attestation", "signed-comparative-report", "verifier-trust-policy", "verifier-identity-evidence", "verifier-runtime-policy", "verifier-execution-evidence", "verifier-execution-integrity", "native-verifier-adapter", "gitlab-ci", "oidc", "jwks", "verifier-independence", "failure-domain", "correlation-domain", "execution-integrity", "verifier-challenge-set", "verifier-pre-dispatch-challenge", "pre-dispatch-challenge", "challenge", "nonce", "liveness", "replay", "sigstore-verifier-identity-evidence", "sigstore-trusted-root", "workload-identity", "spiffe", "svid", "x509", "transparency-log", "transparency-operations", "transparency-state", "transparency-policy", "transparency-observation", "transparency-incident", "trust-root-rotation", "consistency-proof", "witness", "monitor", "gossip", "equivocation", "revocation", "tuf", "merkle", "sigstore", "fulcio", "trustedroot", "rekor", "verifier-oci", "verifier-sandbox", "attestation", "ed25519", "dsse", "quorum", "verification-runner", "comparative-evaluation", "comparative-promotion", "canary", "non-regression", "baseline-candidate", "proof-carrying", "autonomous-improvement", "continuous-improvement", "adaptive-work", "quality-loop", "learning-loop"]
  },
  {
    id: "sof-tf",
    keywords: ["sof", "special-operations", "special", "tf", "task-force"]
  },
  {
    id: "sources-research",
    keywords: ["source", "research", "citation", "doctrine", "korean", "multinational", "reliability", "compendium", "culture"]
  },
  {
    id: "document-access-context",
    keywords: ["document-access", "context", "classification", "opsec", "eefi", "releasability", "sensitive-output", "evidence-redactor", "context-filter", "handoff-packet"]
  },
  {
    id: "runtime-validation",
    keywords: ["validation-stack", ".github", "github", "workflow", "workflows", "pull-request-template", "issue-template", "bug-report", "docs-change", "dependabot", "check-json", "check-markdown", "schema-files", "sample-payloads", "fixture", "fixtures", "validator", "validate", "linter", "runner", "run-", "prototype", "payloads", "evaluation-metrics"]
  },
  {
    id: "runtime-architecture-dashboard",
    keywords: ["architecture", "dashboard", "event", "projection", "ui", "database", "maintenance", "readiness", "data-model", "runtime", "event-replay", "common-operational-picture", "dry-run-approval", "resource-status", "resource-budget", "tool-fallback"]
  },
  {
    id: "continuity-handoff",
    keywords: ["continuity", "handoff", "rotation", "succession", "knowledge-management", "km-review", "decision-log", "source-record", "personnel-continuity"]
  }
];

function usage() {
  console.error("Usage: node scripts/route_controls_docs.js [--actor=user|ai] [--role=ROLE] [--department=DEPT] [--authority=SCOPE] [--capability-query=MISSION_OBJECTIVE] [--all] [--limit=N] <query> [repo-root]");
  console.error("       node scripts/route_controls_docs.js --receipt --scope=wave|agent --mission=MISSION_ID --wave=WAVE_ID --agent=AGENT_ID --actor=ai --role=ROLE --department=DEPT --authority=SCOPE [--write-artifact --target-repository=PATH] <query> [repo-root]");
  console.error("       node scripts/route_controls_docs.js --coverage [repo-root]");
  process.exit(2);
}

function findRepoRoot(start) {
  let current = path.resolve(start || process.cwd());
  while (true) {
    if (
      fs.existsSync(path.join(current, "README.md")) &&
      fs.existsSync(path.join(current, "docs", "source-map.md")) &&
      fs.existsSync(path.join(current, "schema-files", "README.md"))
    ) {
      return current;
    }
    const parent = path.dirname(current);
    if (parent === current) return null;
    current = parent;
  }
}

function countMatches(text, keywords) {
  const lower = text.toLowerCase();
  return keywords.reduce((score, keyword) => {
    const needle = String(keyword).toLowerCase();
    return score + (keywordMatches(lower, needle) ? 1 : 0);
  }, 0);
}

function countSpecificMatches(text, keywords) {
  return keywords.reduce((score, keyword) => {
    const needle = String(keyword).toLowerCase();
    return score + (!GENERIC_ROUTE_KEYWORDS.has(needle) && keywordMatches(text.toLowerCase(), needle) ? 1 : 0);
  }, 0);
}

function keywordMatches(text, keyword) {
  if (!keyword) return false;
  if (!/^[a-z0-9]+$/.test(keyword)) return text.includes(keyword);
  const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|[^a-z0-9])${escaped}([^a-z0-9]|$)`).test(text);
}

function isCorpusOrientationRequest(query, scoredRules) {
  const orientationMatched = scoredRules.some(rule => rule.id === "orientation");
  if (!orientationMatched) return false;
  const text = String(query || "").toLowerCase().replace(/\s+/g, " ").trim();
  const corpus = "(?:cannae(?: os)?|controls (?:doctrine|framework)|(?:this|the) (?:doctrine|framework|repository|corpus)|(?:the )?operator skill)";
  return [
    new RegExp(`\\b(?:give|provide|show)(?: me)? (?:an? )?overview of ${corpus}\\b`),
    new RegExp(`\\b(?:explain|describe|introduce|summarize) ${corpus}\\b`),
    new RegExp(`\\bwhat is ${corpus}\\b`),
    new RegExp(`\\bhow (?:does|do) ${corpus} work\\b`),
    new RegExp(`\\bhow (?:can|should|do) i (?:start|begin|use) (?:with )?${corpus}\\b`),
    /\bwhere (?:can|should|do) i (?:start|begin)(?: with (?:cannae(?: os)?|controls (?:doctrine|framework)|(?:this|the) (?:doctrine|framework|repository|corpus)))?\b/,
    /\b(?:read|review|summarize) (?:the )?readme\b/
  ].some(pattern => pattern.test(text));
}

function capabilityRouting(query, scoredRules, missionId) {
  const capabilityRules = scoredRules.filter(rule =>
    rule.id !== "orientation" && rule.specific_score > 0);
  if (capabilityRules.length === 0 && isCorpusOrientationRequest(query, scoredRules)) {
    capabilityRules.push(scoredRules.find(rule => rule.id === "orientation"));
  }

  if (capabilityRules.length > 0) {
    return {
      status: "covered",
      reason_code: capabilityRules[0].id === "orientation"
        ? "CORPUS_ORIENTATION_REQUEST"
        : "MATCHED_DOCTRINE_ROUTE",
      capability_scope: String(query),
      matched_capability_routes: capabilityRules.map(rule => rule.id),
      provisional_organization: {
        required: false,
        organization_type: "existing_doctrine_route",
        organization_id: "none",
        name: "Existing doctrine route",
        task_organization_status: "not_required",
        authority_scope: "Use the declared operator mode and existing role, department, and authority boundaries.",
        authority_expansion_authorized: false,
        standing_department_activation_authorized: false,
        disband_condition: "Not applicable; no provisional organization was created."
      },
      force_structure_review: {
        required: false,
        change_type: "none",
        target_kind: "none",
        status: "not_required",
        candidate_department_id: "none",
        candidate_department_name: "none",
        final_decision_authority: "USER",
        formal_approving_role: "COMMANDER"
      },
      operator_directive: "Use the matched doctrine routes and remain inside the declared authority boundary."
    };
  }

  const digest = crypto.createHash("sha256")
    .update(String(missionId || query || "unscoped-capability-gap"))
    .digest("hex")
    .slice(0, 12)
    .toUpperCase();
  return {
    status: "gap_detected",
    reason_code: "NO_CAPABILITY_ROUTE",
    capability_scope: String(query),
    matched_capability_routes: [],
    provisional_organization: {
      required: true,
      organization_type: "mission_scoped_capability_cell",
      organization_id: `CELL-${digest}`,
      name: "Mission-scoped capability cell",
      task_organization_status: "task_organized",
      authority_scope: "Perform analysis and reversible drafting for the original request under existing delegated authority only.",
      authority_expansion_authorized: false,
      standing_department_activation_authorized: false,
      disband_condition: "Disband at mission handoff unless the USER approves a validated force-structure change order."
    },
    force_structure_review: {
      required: true,
      change_type: "create",
      target_kind: "department",
      status: "analysis_required",
      candidate_department_id: `DEPT-${digest}`,
      candidate_department_name: "Mission capability department candidate",
      final_decision_authority: "USER",
      formal_approving_role: "COMMANDER"
    },
    operator_directive: "Do not stop as outside the corpus or continue as unowned general work. Use the provisional capability cell now, preserve all existing authority limits, and evaluate a standing department through the force-structure process."
  };
}

function unique(items) {
  return [...new Set(items)];
}

function normalizeText(value) {
  return String(value || "")
    .toLowerCase()
    .replace(/[_./:-]+/g, " ");
}

function walkRoutableFiles(repoRoot) {
  const listed = spawnSync(
    "git",
    ["ls-files", "--cached", "--others", "--exclude-standard", "-z"],
    {
      cwd: repoRoot,
      encoding: "utf8",
      maxBuffer: 16 * 1024 * 1024
    }
  );
  if (!listed.error && listed.status === 0) {
    return listed.stdout
      .split("\0")
      .filter(Boolean)
      .map(file => file.split(path.sep).join("/"))
      .filter(file => fs.existsSync(path.join(repoRoot, file)))
      .filter(file => {
        const ext = path.extname(file).toLowerCase();
        return ROUTABLE_EXTENSIONS.has(ext);
      })
      .filter(file =>
        !file.startsWith(".claude/") ||
        file.startsWith(".claude/skills/"))
      .sort((left, right) => left.localeCompare(right));
  }

  if (!walkRoutableFiles.warnedFallback) {
    walkRoutableFiles.warnedFallback = true;
    process.stderr.write(
      "route_controls_docs: git file listing unavailable; falling back to a directory walk that only excludes known local-state directories.\n"
    );
  }

  const files = [];

  function walk(relativeDir) {
    const absoluteDir = path.join(repoRoot, relativeDir);
    for (const entry of fs.readdirSync(absoluteDir, { withFileTypes: true })) {
      if (EXCLUDED_DIRS.has(entry.name)) continue;
      if (entry.name === ".DS_Store") continue;

      const relativePath = path.join(relativeDir, entry.name);
      const normalizedRelativePath = relativePath.split(path.sep).join("/");
      if (
        normalizedRelativePath.startsWith(".claude/") &&
        normalizedRelativePath !== ".claude/skills" &&
        !normalizedRelativePath.startsWith(".claude/skills/")
      ) {
        continue;
      }

      if (entry.isDirectory()) {
        walk(relativePath);
        continue;
      }

      const ext = path.extname(entry.name).toLowerCase();
      if (ROUTABLE_EXTENSIONS.has(ext)) {
        files.push(relativePath.split(path.sep).join("/"));
      }
    }
  }

  walk("");
  return files.sort((left, right) => left.localeCompare(right));
}

function artifactType(file) {
  if (file.endsWith(".svg")) return "image-asset";
  if (file.endsWith(".html")) return "html-document";
  if (file.endsWith(".md")) return "document";
  if (file.endsWith(".yaml") || file.endsWith(".yml")) return "skill-metadata";
  if (file.endsWith("README.md") || file.startsWith("docs/") || file.startsWith("codex-skills/")) {
    if (file.endsWith(".js")) return "skill-script";
    return "document";
  }
  if (file.startsWith("schema-files/")) return "schema";
  if (file.startsWith("sample-payloads/") || file.startsWith("runtime-demo-payloads/")) return "sample";
  if (file.includes("-fixtures/") || file.startsWith("event-fixtures/")) return "fixture";
  if (file.endsWith(".js") || file.endsWith(".go") || file.endsWith(".sh")) return "runner-or-tool";
  if (file.endsWith(".json")) return "projection-or-data";
  return "artifact";
}

function routeIdsForArtifact(file) {
  const normalized = normalizeText(file);
  const routeIds = [];

  for (const hint of ROUTE_HINTS) {
    if (hint.keywords.some(keyword => normalized.includes(normalizeText(keyword)))) {
      routeIds.push(hint.id);
    }
  }

  if (file.endsWith(".schema.json") || file.startsWith("schema-files/")) {
    routeIds.push("runtime-validation");
  }

  if (file.startsWith("sample-payloads/") || file.startsWith("runtime-demo-payloads/")) {
    routeIds.push("runtime-validation");
  }

  if (file.includes("-fixtures/") || file.startsWith("event-fixtures/")) {
    routeIds.push("runtime-validation");
  }

  if (file === "README.md") routeIds.push("orientation");
  if (file === "package.json" || file === "package-lock.json") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "source-map-linter.js" || file === "source-map-url-coverage-report.json") routeIds.push("sources-research");
  if (file === "orders-dissemination-runner.js") routeIds.push("orders");
  if (file === "order-replay-context.js") routeIds.push("orders");
  if (file === "handoff-generator.js") routeIds.push("continuity-handoff");
  if (file === "maintenance-readiness-runner.js") routeIds.push("runtime-architecture-dashboard");
  if (file === "maintenance-dashboard-runner.js") routeIds.push("runtime-architecture-dashboard");
  if (file === "decision-packet-linter.js") routeIds.push("authority-risk-release", "orders");
  if (file === "aar-to-readiness-update.js") routeIds.push("orders", "runtime-architecture-dashboard");
  if (file === "autonomous-improvement-controller.js" || file === "campaign-supervisor.js" || file === "verifier-trust-readiness.js" || file === "verifier-identity-evidence.js" || file === "verifier-identity-fixture-support.js" || file === "verifier-execution-evidence.js" || file === "verifier-execution-runner.js" || file === "run-verifier-execution-evidence-fixtures.js" || file === "verifier-challenge-set.js" || file === "run-verifier-challenge-fixtures.js" || file === "verifier-independence.js" || file === "run-verifier-independence-fixtures.js" || file === "sigstore-trusted-root.js" || file === "sigstore-trusted-root-runner.js" || file === "sigstore-verifier-identity-evidence.js" || file === "sigstore-verifier-identity-runner.js" || file === "run-sigstore-verifier-identity-fixtures.js" || file === "run-campaign-supervisor-fixtures.js" || file === "run-verifier-trust-readiness-fixtures.js" || file === "run-verifier-identity-evidence-fixtures.js" || file === "run-workload-identity-admission-fixtures.js" || file === "run-cycle-order-admission-fixtures.js" || file === "run-self-improvement-fixtures.js" || file === "run-signed-self-improvement-fixtures.js") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "transparency-operations.js" || file === "transparency-operations-runner.js" || file === "run-transparency-operations-fixtures.js" || file === "run-transparency-supervisor-fixtures.js") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "github-actions-oidc.js" || file === "github-actions-oidc-runner.js" || file === "run-github-actions-oidc-fixtures.js") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "gitlab-ci-oidc.js" || file === "gitlab-ci-oidc-runner.js" || file === "run-gitlab-ci-oidc-fixtures.js") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "verification-runner.js" || file === "verification-attestation.js" || file === "verification-attestation-runner.js" || file === "run-verification-attestation-fixtures.js") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "comparative-evaluation-runner.js" || file === "run-comparative-evaluation-fixtures.js" ||
      file === "comparative-evaluation-attestation.js" || file === "comparative-evaluation-attestation-runner.js" ||
      file === "run-comparative-evaluation-attestation-fixtures.js") routeIds.push("bounded-self-improvement", "runtime-validation");
  if (file === "repository-artifact-verify.js" || file === "repository-lease.js" || file === "run-repository-artifact-recovery-fixtures.js" || file === "run-repository-artifact-concurrency-fixtures.js") routeIds.push("repository-artifact-isolation", "runtime-validation");
  if (file === "dispatch-runtime-controller.js" || file === "dispatch-hook-adapter.js" || file === "install-dispatch-hooks.js" || file === "protected-tool-gateway.js" || file === "gateway-identity-adapter.js" || file === "gateway-identity-evidence.js" || file === "protected-process-executor.js" || file === "protected-execution-evidence.js" || file === "oci-linux-sandbox-provider.js" || file === "oci-linux-sandbox-evidence.js" || file === "oci-linux-sandbox-probe.go" || file === "run-dispatch-runtime-fixtures.js" || file === "run-protected-tool-gateway-fixtures.js" || file === "run-gateway-identity-adapter-fixtures.js" || file === "run-protected-process-executor-fixtures.js" || file === "run-oci-linux-sandbox-provider-fixtures.js") routeIds.push("enforced-dispatch", "runtime-validation");

  if (file === "protected-gateway-fixture-support.js") routeIds.push("enforced-dispatch", "runtime-validation");
  return unique(routeIds);
}

function buildArtifactInventory(repoRoot) {
  return walkRoutableFiles(repoRoot).map(file => ({
    path: file,
    type: artifactType(file),
    route_ids: routeIdsForArtifact(file)
  }));
}

function routeCounts(inventory) {
  const counts = {};
  for (const artifact of inventory) {
    for (const routeId of artifact.route_ids) {
      counts[routeId] = (counts[routeId] || 0) + 1;
    }
  }
  return Object.fromEntries(Object.entries(counts).sort(([left], [right]) => left.localeCompare(right)));
}

function typeCounts(inventory) {
  const counts = {};
  for (const artifact of inventory) {
    counts[artifact.type] = (counts[artifact.type] || 0) + 1;
  }
  return Object.fromEntries(Object.entries(counts).sort(([left], [right]) => left.localeCompare(right)));
}

function coverageReport(repoRoot) {
  const inventory = buildArtifactInventory(repoRoot);
  const unrouted = inventory.filter(artifact => artifact.route_ids.length === 0);

  return {
    valid: unrouted.length === 0,
    repo_root: repoRoot,
    routable_artifact_count: inventory.length,
    routed_artifact_count: inventory.length - unrouted.length,
    unrouted_artifact_count: unrouted.length,
    route_counts: routeCounts(inventory),
    type_counts: typeCounts(inventory),
    unrouted_artifacts: unrouted
  };
}

function collectKeywordDocs(value, rules) {
  const text = String(value || "").toLowerCase();
  if (!text) return [];

  const docs = [];
  for (const rule of rules) {
    if (rule.keywords.some(keyword => keywordMatches(text, String(keyword).toLowerCase()))) {
      docs.push(...rule.docs);
    }
  }
  return docs;
}

function parseArgs(argv) {
  const options = {
    actor: null,
    role: null,
    department: null,
    authority: null,
    capabilityQuery: null,
    receipt: false,
    scope: null,
    mission: null,
    wave: null,
    agent: null,
    targetRepository: null,
    artifactRoot: null,
    writeArtifact: false,
    overwriteArtifact: false,
    coverage: false,
    all: false,
    limit: 40
  };
  const queryParts = [];
  const valueOptionNames = new Set(["actor", "role", "department", "authority", "capability-query", "scope", "mission", "wave", "agent", "limit", "target-repository", "artifact-root"]);
  const booleanOptionNames = new Set(["coverage", "all", "receipt", "write-artifact", "overwrite-artifact"]);

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    const equalsMatch = arg.match(/^--([^=]+)=(.*)$/);

    if (equalsMatch && valueOptionNames.has(equalsMatch[1])) {
      const key = equalsMatch[1].replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      options[key] = equalsMatch[2];
      continue;
    }

    if (arg.startsWith("--") && valueOptionNames.has(arg.slice(2))) {
      const key = arg.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      index += 1;
      if (index >= argv.length) usage();
      options[key] = argv[index];
      continue;
    }

    if (arg.startsWith("--") && booleanOptionNames.has(arg.slice(2))) {
      const key = arg.slice(2).replace(/-([a-z])/g, (_, letter) => letter.toUpperCase());
      options[key] = true;
      continue;
    }

    queryParts.push(arg);
  }

  const parsedLimit = Number.parseInt(options.limit, 10);
  options.limit = Number.isFinite(parsedLimit) && parsedLimit > 0 ? parsedLimit : 40;

  let repoRootArg = null;
  if (queryParts.length > 0) {
    const last = queryParts[queryParts.length - 1];
    if (fs.existsSync(last) && findRepoRoot(last)) {
      repoRootArg = queryParts.pop();
    }
  }

  const query = queryParts.join(" ").trim();
  if (!query && !options.coverage) usage();

  return { query, repoRootArg, options };
}

function operatorMode(options) {
  const hasDelegationFields = Boolean(options.role || options.department || options.authority);
  const actor = String(options.actor || (hasDelegationFields ? "ai" : "user")).toLowerCase();

  if (!["user", "ai"].includes(actor)) {
    console.error("--actor must be either user or ai");
    process.exit(2);
  }

  if (actor === "user") {
    return {
      actor,
      mode: "human_final_decision_authority",
      decision_authority: "human_user",
      routing_scope: "Route for efficiency and evidence. Do not restrict the user's corpus visibility by the AI assistant's role.",
      role: options.role || null,
      department: options.department || null,
      authority: options.authority || null,
      mode_documents: [],
      escalation_required_when: [
        "The user asks for high-risk, release, destructive, or irreversible action.",
        "The framework lacks source-map or validation coverage for the requested claim."
      ]
    };
  }

  const modeDocs = [
    "docs/role-document-access-policy.md",
    "docs/agent-roles-and-authority.md",
    "docs/approval-scope-policy.md",
    "docs/tool-use-roe.md"
  ];

  const roleKey = String(options.role || "").toUpperCase();
  if (ROLE_DOCS[roleKey]) modeDocs.push(...ROLE_DOCS[roleKey]);
  modeDocs.push(...collectKeywordDocs(options.department, DEPARTMENT_DOCS));
  modeDocs.push(...collectKeywordDocs(options.authority, AUTHORITY_DOCS));

  const missingDelegationFields = ["role", "department", "authority"]
    .filter(field => !options[field]);
  const escalationRequiredWhen = [
    "Requested action exceeds delegated role, department, or authority.",
    "A provisional capability cell is proposed as a standing department or requests broader authority.",
    "Release target is external, final, or cross-boundary.",
    "Risk level requires acceptance authority above the AI delegate.",
    "Need-to-know cannot justify reading or sharing extra documents."
  ];

  if (missingDelegationFields.length > 0) {
    escalationRequiredWhen.unshift(
      `Delegation context is incomplete: missing ${missingDelegationFields.join(", ")}.`
    );
  }

  return {
    actor,
    mode: "delegated_ai_role_department_authority",
    decision_authority: "bounded_ai_delegate",
    routing_scope: "Route by declared role, department, authority, task, release target, risk, and need-to-know.",
    role: options.role || "unspecified",
    department: options.department || "unspecified",
    authority: options.authority || "unspecified",
    mode_documents: unique(modeDocs),
    escalation_required_when: escalationRequiredWhen
  };
}

function route(query, repoRoot, options) {
  const mode = operatorMode(options);
  const inventory = buildArtifactInventory(repoRoot);
  const scoredRules = RULES.map(rule => ({
    ...rule,
    score: countMatches(query, rule.keywords),
    specific_score: countSpecificMatches(query, rule.keywords)
  })).filter(rule => rule.score > 0)
    .sort((left, right) => right.score - left.score || left.id.localeCompare(right.id));

  const capabilityQuery = options.capabilityQuery || query;
  const capabilityScoredRules = RULES.map(rule => ({
    ...rule,
    score: countMatches(capabilityQuery, rule.keywords),
    specific_score: countSpecificMatches(capabilityQuery, rule.keywords)
  })).filter(rule => rule.score > 0)
    .sort((left, right) => right.score - left.score || left.id.localeCompare(right.id));
  const capability = capabilityRouting(capabilityQuery, capabilityScoredRules, options.mission);
  const forceStructureRule = RULES.find(rule => rule.id === "force-structure");
  const selectedById = new Map(scoredRules.map(rule => [rule.id, rule]));
  for (const routeId of capability.matched_capability_routes) {
    if (!selectedById.has(routeId)) {
      selectedById.set(routeId, capabilityScoredRules.find(rule => rule.id === routeId));
    }
  }
  const selectedRules = [...selectedById.values()].filter(Boolean)
    .sort((left, right) => right.score - left.score || left.id.localeCompare(right.id));
  if (capability.status === "gap_detected" &&
      !selectedRules.some(rule => rule.id === "force-structure")) {
    selectedRules.unshift({ ...forceStructureRule, score: 0 });
  }
  const docs = ["README.md", "docs/source-map.md"];
  const commands = [];

  if (capability.status === "gap_detected") {
    docs.push(...CAPABILITY_GAP_DOCS);
    commands.push(...CAPABILITY_GAP_COMMANDS);
  }
  docs.push(...mode.mode_documents);
  for (const rule of selectedRules.slice(0, 4)) {
    docs.push(...rule.docs);
    commands.push(...rule.commands);
  }

  // Bound scope by selected routes, not by dropping task docs behind role docs.
  const recommended = unique(docs)
    .filter(file => fs.existsSync(path.join(repoRoot, file)))
    .map(file => ({
      path: file,
      exists: true
    }));
  const recommendedPaths = new Set(recommended.map(item => item.path));
  const selectedRouteIds = selectedRules.map(rule => rule.id);
  const routePriority = new Map(selectedRouteIds.map((routeId, index) => [routeId, index]));
  const artifactRoutePriority = artifact => Math.min(
    ...artifact.route_ids
      .filter(routeId => routePriority.has(routeId))
      .map(routeId => routePriority.get(routeId))
  );
  const supportingArtifacts = inventory
    .filter(artifact => artifact.route_ids.some(routeId => selectedRouteIds.includes(routeId)))
    .filter(artifact => !recommendedPaths.has(artifact.path))
    .sort((left, right) => {
      const leftRoutePriority = artifactRoutePriority(left);
      const rightRoutePriority = artifactRoutePriority(right);
      if (leftRoutePriority !== rightRoutePriority) return leftRoutePriority - rightRoutePriority;

      const leftPrimary = left.type === "document" || left.type === "html-document" ? 0 : 1;
      const rightPrimary = right.type === "document" || right.type === "html-document" ? 0 : 1;
      return leftPrimary - rightPrimary || left.path.localeCompare(right.path);
    });
  const visibleSupportingArtifacts = options.all
    ? supportingArtifacts
    : supportingArtifacts.slice(0, options.limit);
  const coverage = coverageReport(repoRoot);

  return {
    query,
    capability_query: capabilityQuery,
    repo_root: repoRoot,
    operating_mode: mode,
    matched_routes: selectedRules.map(rule => ({ id: rule.id, score: rule.score })),
    capability_routing: capability,
    recommended_documents: recommended,
    supporting_artifacts: visibleSupportingArtifacts,
    supporting_artifact_count: supportingArtifacts.length,
    supporting_artifacts_truncated: !options.all && supportingArtifacts.length > visibleSupportingArtifacts.length,
    route_inventory: {
      routable_artifact_count: coverage.routable_artifact_count,
      routed_artifact_count: coverage.routed_artifact_count,
      unrouted_artifact_count: coverage.unrouted_artifact_count
    },
    validation_commands: unique(commands),
    always_consider: [
      "When actor=user, preserve the human user as final decision authority.",
      "When actor=ai, route by role, department, authority, task, and need-to-know.",
      "Run --coverage after adding, renaming, or deleting docs, schemas, samples, runners, or fixtures.",
      "Update docs/source-map.md when adding official-source claims.",
      "Update docs/research-compendium.md when adding durable research conclusions.",
      "Add or update schema/sample/runner/fixture when changing runtime contracts.",
      "Run git diff --check before committing."
    ]
  };
}

function sanitizeIdPart(value) {
  const sanitized = String(value || "unspecified").replace(/[^A-Za-z0-9_-]+/g, "_");
  return sanitized || "unspecified";
}

function commandString() {
  const rawArgs = process.argv.slice(1);
  const redactedArgs = [];
  for (let index = 0; index < rawArgs.length; index += 1) {
    const arg = rawArgs[index];
    if (["--target-repository", "--artifact-root"].includes(arg)) {
      redactedArgs.push(arg, "<local-path>");
      index += 1;
      continue;
    }
    if (/^--(?:target-repository|artifact-root)=/.test(arg)) {
      redactedArgs.push(arg.replace(/=.*/, "=<local-path>"));
      continue;
    }
    redactedArgs.push(arg);
  }
  const args = redactedArgs.map(arg => {
    if (/^[A-Za-z0-9_./:=@-]+$/.test(arg)) return arg;
    return `"${String(arg).replace(/(["\\$`])/g, "\\$1")}"`;
  });
  return `node ${args.join(" ")}`;
}

function routingReceipt(routeResult, options) {
  const scope = options.scope || (String(options.role || "").toUpperCase() === "COS" ? "wave" : "agent");
  if (!["wave", "agent"].includes(scope)) {
    console.error("--scope must be wave or agent when --receipt is used");
    process.exit(2);
  }
  if (!options.mission || !options.wave || !options.agent) {
    console.error("--receipt requires --mission, --wave, and --agent");
    process.exit(2);
  }
  if (routeResult.operating_mode.actor !== "ai") {
    console.error("--receipt requires --actor=ai");
    process.exit(2);
  }
  if (!options.role || !options.department || !options.authority) {
    console.error("--receipt requires --role, --department, and --authority");
    process.exit(2);
  }

  return {
    schema_version: "0.2",
    type: "RoutingReceipt",
    id: `RR-${sanitizeIdPart(options.wave)}-${sanitizeIdPart(options.agent)}`,
    mission_id: options.mission,
    wave_id: options.wave,
    agent_id: options.agent,
    wave_scope: scope,
    actor: "ai",
    agent_role: String(routeResult.operating_mode.role || options.role).toUpperCase(),
    department: String(routeResult.operating_mode.department || options.department).toLowerCase(),
    authority_scope: String(routeResult.operating_mode.authority || options.authority).toLowerCase(),
    routing_mode: routeResult.operating_mode.mode,
    router_query: routeResult.query,
    capability_query: routeResult.capability_query,
    router_command: commandString(),
    matched_routes: routeResult.matched_routes,
    capability_routing: routeResult.capability_routing,
    recommended_documents: routeResult.recommended_documents,
    supporting_artifacts: routeResult.supporting_artifacts,
    supporting_artifact_count: routeResult.supporting_artifact_count,
    route_inventory: routeResult.route_inventory,
    validation_commands: routeResult.validation_commands,
    escalation_required_when: routeResult.operating_mode.escalation_required_when,
    created_at: new Date().toISOString()
  };
}

const parsed = parseArgs(process.argv.slice(2));
const possibleRoot = parsed.repoRootArg ? findRepoRoot(parsed.repoRootArg) : null;
const repoRoot = possibleRoot || findRepoRoot(process.cwd());

if (!repoRoot) {
  console.error("Could not find controls repo root. Pass it as the last argument.");
  process.exit(2);
}

if (parsed.options.coverage) {
  const report = coverageReport(repoRoot);
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  process.exit(report.valid ? 0 : 1);
}

const routed = route(parsed.query, repoRoot, parsed.options);
const output = parsed.options.receipt ? routingReceipt(routed, parsed.options) : routed;
if (parsed.options.writeArtifact) {
  if (!parsed.options.receipt || !parsed.options.targetRepository) {
    console.error("--write-artifact requires --receipt and --target-repository <path>.");
    process.exit(2);
  }
  try {
    const { writeRepositoryArtifact } = require(path.join(repoRoot, "repository-artifact-store.js"));
    const artifact = writeRepositoryArtifact({
      repositoryPath: parsed.options.targetRepository,
      artifactRoot: parsed.options.artifactRoot,
      missionId: output.mission_id,
      waveId: output.wave_id,
      kind: "routing-receipts",
      artifactId: output.id,
      payload: output,
      overwrite: parsed.options.overwriteArtifact
    });
    console.error(`Artifact written: ${artifact.artifact_path}`);
  } catch (error) {
    console.error(`Artifact persistence failed: ${error.message}`);
    process.exit(1);
  }
}
process.stdout.write(`${JSON.stringify(output, null, 2)}\n`);
